﻿param(
    [string]$DllPath,
    [string]$SampleSai2Path,
    [string]$ReportPath,
    [switch]$SkipEventLog
)

$providerClsid = "{3259D2F0-B82C-486D-8304-A8681E50B131}"
$thumbnailHandlerGuid = "{E357FCCD-A995-4576-B01F-234630154E96}"
$recordGuid = "{A3803D46-7EBD-3958-AD38-8539AF3BCBA4}"
$providerClassName = "RecSAI.Sai2ThumbnailProvider.Sai2ThumbnailProvider"
$decoderClassName = "RecSAI.Sai2ThumbnailProvider.Sai2ThumbnailDecoder"
$legacyDecoderClassName = "RecSAI.Sai2ThumbnailProvider.Sai2IntgThumbnailDecoder"
$providerDllName = "RecSAI.Sai2ThumbnailProvider.dll"

try {
    Add-Type -AssemblyName System.Drawing -ErrorAction SilentlyContinue
} catch {
}

$script:ReportLines = New-Object System.Collections.Generic.List[string]
$script:ResolvedProviderPath = $null
$script:LoadedProviderAssembly = $null

function Write-Diag {
    param([string]$Text = "")

    Write-Host $Text
    $script:ReportLines.Add($Text) | Out-Null
}

function Write-Section {
    param([string]$Title)

    Write-Diag ""
    Write-Diag ("==== " + $Title + " ====")
}

function Format-Value {
    param([object]$Value)

    if ($null -eq $Value) {
        return "<null>"
    }
    $text = [string]$Value
    if ([string]::IsNullOrEmpty($text)) {
        return "<empty>"
    }
    return $text
}

function Format-HResult {
    param([int]$HResult)

    return ("0x{0:X8}" -f ($HResult -band 0xffffffff))
}

function Write-ExceptionDetail {
    param(
        [object]$ErrorObject,
        [string]$Indent = "  "
    )

    if ($ErrorObject -is [System.Management.Automation.ErrorRecord]) {
        $ex = $ErrorObject.Exception
    } elseif ($ErrorObject -is [System.Exception]) {
        $ex = $ErrorObject
    } else {
        Write-Diag ($Indent + (Format-Value $ErrorObject))
        return
    }

    $level = 0
    while ($null -ne $ex) {
        $prefix = $Indent + ("inner[{0}] " -f $level)
        Write-Diag ($prefix + $ex.GetType().FullName)
        Write-Diag ($prefix + "HResult=" + (Format-HResult $ex.HResult))
        Write-Diag ($prefix + "Message=" + $ex.Message)

        try {
            $fusionLog = $ex.FusionLog
            if (-not [string]::IsNullOrWhiteSpace($fusionLog)) {
                Write-Diag ($prefix + "FusionLog:")
                foreach ($line in ($fusionLog -split "(`r`n|`n|`r)")) {
                    if (-not [string]::IsNullOrWhiteSpace($line)) {
                        Write-Diag ($Indent + "  " + $line)
                    }
                }
            }
        } catch {
        }

        $ex = $ex.InnerException
        $level++
    }
}

function Get-RegistryValue {
    param(
        [string]$Path,
        [string]$Name
    )

    try {
        $key = Get-Item -LiteralPath $Path -ErrorAction Stop
        return $key.GetValue($Name)
    } catch {
        return $null
    }
}

function Get-RegistryViewValue {
    param(
        [Microsoft.Win32.RegistryHive]$Hive,
        [Microsoft.Win32.RegistryView]$View,
        [string]$SubKey,
        [string]$Name
    )

    $base = $null
    $key = $null
    try {
        $base = [Microsoft.Win32.RegistryKey]::OpenBaseKey($Hive, $View)
        $key = $base.OpenSubKey($SubKey)
        if ($null -eq $key) {
            return $null
        }
        return $key.GetValue($Name)
    } catch {
        return $null
    } finally {
        if ($null -ne $key) {
            $key.Close()
        }
        if ($null -ne $base) {
            $base.Close()
        }
    }
}

function Write-RegistryPath {
    param(
        [string]$Title,
        [string]$Path
    )

    Write-Diag $Title
    Write-Diag ("  Path: " + $Path)
    try {
        $key = Get-Item -LiteralPath $Path -ErrorAction Stop
    } catch {
        Write-Diag "  Missing"
        return
    }

    $names = @($key.GetValueNames())
    if ($names.Count -eq 0) {
        Write-Diag "  Values: <none>"
        return
    }

    foreach ($name in $names) {
        $displayName = $name
        if ([string]::IsNullOrEmpty($displayName)) {
            $displayName = "(default)"
        }
        try {
            $kind = $key.GetValueKind($name)
        } catch {
            $kind = "Unknown"
        }
        $value = $key.GetValue($name)
        Write-Diag ("  {0} [{1}] = {2}" -f $displayName, $kind, (Format-Value $value))
    }
}

function Write-RegistryViewKey {
    param(
        [string]$Title,
        [Microsoft.Win32.RegistryHive]$Hive,
        [Microsoft.Win32.RegistryView]$View,
        [string]$SubKey
    )

    Write-Diag $Title
    Write-Diag ("  Hive: {0}, View: {1}, SubKey: {2}" -f $Hive, $View, $SubKey)
    $base = $null
    $key = $null
    try {
        $base = [Microsoft.Win32.RegistryKey]::OpenBaseKey($Hive, $View)
        $key = $base.OpenSubKey($SubKey)
        if ($null -eq $key) {
            Write-Diag "  Missing"
            return
        }

        $names = @($key.GetValueNames())
        if ($names.Count -eq 0) {
            Write-Diag "  Values: <none>"
            return
        }

        foreach ($name in $names) {
            $displayName = $name
            if ([string]::IsNullOrEmpty($displayName)) {
                $displayName = "(default)"
            }
            $kind = $key.GetValueKind($name)
            $value = $key.GetValue($name)
            Write-Diag ("  {0} [{1}] = {2}" -f $displayName, $kind, (Format-Value $value))
        }
    } catch {
        Write-Diag "  Failed:"
        Write-ExceptionDetail $_ "    "
    } finally {
        if ($null -ne $key) {
            $key.Close()
        }
        if ($null -ne $base) {
            $base.Close()
        }
    }
}

function Convert-CodeBaseToPath {
    param([string]$Value)

    if ([string]::IsNullOrWhiteSpace($Value)) {
        return $null
    }

    $text = $Value.Trim()
    if ($text.StartsWith("file:", [System.StringComparison]::OrdinalIgnoreCase)) {
        try {
            return (New-Object System.Uri($text)).LocalPath
        } catch {
            return $text
        }
    }

    return $text
}

function Convert-IconReferenceToPath {
    param([string]$Value)

    if ([string]::IsNullOrWhiteSpace($Value)) {
        return $null
    }

    $text = $Value.Trim()
    if ($text.StartsWith('"')) {
        $endQuote = $text.IndexOf('"', 1)
        if ($endQuote -gt 1) {
            return $text.Substring(1, $endQuote - 1)
        }
    }

    $comma = $text.LastIndexOf(",")
    if ($comma -gt 0) {
        return $text.Substring(0, $comma).Trim()
    }

    return $text
}

function Resolve-ProviderPath {
    if (-not [string]::IsNullOrWhiteSpace($DllPath)) {
        try {
            return (Resolve-Path -LiteralPath $DllPath -ErrorAction Stop).ProviderPath
        } catch {
            return $DllPath
        }
    }

    $candidateValues = @(
        (Get-RegistryViewValue ([Microsoft.Win32.RegistryHive]::ClassesRoot) ([Microsoft.Win32.RegistryView]::Registry64) ("CLSID\" + $providerClsid + "\InprocServer32") "CodeBase"),
        (Get-RegistryValue ("HKCU:\Software\Classes\CLSID\" + $providerClsid + "\InprocServer32") "CodeBase"),
        (Get-RegistryValue ("HKLM:\Software\Classes\CLSID\" + $providerClsid + "\InprocServer32") "CodeBase")
    )

    foreach ($value in $candidateValues) {
        $path = Convert-CodeBaseToPath $value
        if (-not [string]::IsNullOrWhiteSpace($path) -and (Test-Path -LiteralPath $path -PathType Leaf)) {
            return (Resolve-Path -LiteralPath $path).ProviderPath
        }
    }

    foreach ($value in $candidateValues) {
        $path = Convert-CodeBaseToPath $value
        if (-not [string]::IsNullOrWhiteSpace($path)) {
            return $path
        }
    }

    return $null
}

function Get-NetFxRelease {
    param([Microsoft.Win32.RegistryView]$View)

    try {
        $base = [Microsoft.Win32.RegistryKey]::OpenBaseKey([Microsoft.Win32.RegistryHive]::LocalMachine, $View)
        try {
            $key = $base.OpenSubKey("SOFTWARE\Microsoft\NET Framework Setup\NDP\v4\Full")
            if ($null -eq $key) {
                return $null
            }
            return $key.GetValue("Release")
        } finally {
            if ($null -ne $key) {
                $key.Close()
            }
            $base.Close()
        }
    } catch {
        return $null
    }
}

function Format-NetFxRelease {
    param([object]$Release)

    if ($null -eq $Release) {
        return "<missing>"
    }

    $value = 0
    if (-not [int]::TryParse([string]$Release, [ref]$value)) {
        return [string]$Release
    }

    $version = "unknown"
    if ($value -ge 533320) {
        $version = "4.8.1 or later"
    } elseif ($value -ge 528040) {
        $version = "4.8"
    } elseif ($value -ge 461808) {
        $version = "4.7.2"
    } elseif ($value -ge 461308) {
        $version = "4.7.1"
    } elseif ($value -ge 460798) {
        $version = "4.7"
    } elseif ($value -ge 394802) {
        $version = "4.6.2"
    } elseif ($value -ge 393295) {
        $version = "4.6"
    }

    $status = "OK"
    if ($value -lt 394802) {
        $status = "TOO_OLD"
    }
    return ("{0} ({1}, {2})" -f $value, $version, $status)
}

function Write-SystemInfo {
    Write-Section "System"
    Write-Diag ("Timestamp: " + (Get-Date).ToString("yyyy-MM-dd HH:mm:ss zzz"))
    Write-Diag ("Computer: " + $env:COMPUTERNAME)
    Write-Diag ("User: " + [System.Security.Principal.WindowsIdentity]::GetCurrent().Name)
    Write-Diag ("OSVersion: " + [System.Environment]::OSVersion.VersionString)
    Write-Diag ("Is64BitOperatingSystem: " + [System.Environment]::Is64BitOperatingSystem)
    Write-Diag ("Is64BitProcess: " + [System.Environment]::Is64BitProcess)
    Write-Diag ("PowerShell: " + $PSVersionTable.PSVersion.ToString())
    Write-Diag ("ProcessPath: " + (Get-Process -Id $PID).Path)
    try {
        $principal = New-Object System.Security.Principal.WindowsPrincipal([System.Security.Principal.WindowsIdentity]::GetCurrent())
        Write-Diag ("Elevated: " + $principal.IsInRole([System.Security.Principal.WindowsBuiltInRole]::Administrator))
    } catch {
        Write-Diag "Elevated: <unknown>"
    }

    Write-Diag ("NET Framework Release 64: " + (Format-NetFxRelease (Get-NetFxRelease ([Microsoft.Win32.RegistryView]::Registry64))))
    Write-Diag ("NET Framework Release 32: " + (Format-NetFxRelease (Get-NetFxRelease ([Microsoft.Win32.RegistryView]::Registry32))))
}

function Write-ExplorerSettings {
    Write-Section "Explorer thumbnail settings"
    Write-RegistryPath "Explorer Advanced" "HKCU:\Software\Microsoft\Windows\CurrentVersion\Explorer\Advanced"
    $iconsOnly = Get-RegistryValue "HKCU:\Software\Microsoft\Windows\CurrentVersion\Explorer\Advanced" "IconsOnly"
    if ($null -eq $iconsOnly) {
        Write-Diag "IconsOnly summary: <missing, usually treated as thumbnails allowed>"
    } elseif ([int]$iconsOnly -eq 1) {
        Write-Diag "IconsOnly summary: BLOCKING, Explorer is configured to always show icons."
    } else {
        Write-Diag "IconsOnly summary: OK, thumbnails are not globally disabled by IconsOnly."
    }

    Write-RegistryPath "HKCU Explorer policies" "HKCU:\Software\Microsoft\Windows\CurrentVersion\Policies\Explorer"
    Write-RegistryPath "HKLM Explorer policies" "HKLM:\Software\Microsoft\Windows\CurrentVersion\Policies\Explorer"
    Write-RegistryPath "HKCU Windows Explorer policies" "HKCU:\Software\Policies\Microsoft\Windows\Explorer"
    Write-RegistryPath "HKLM Windows Explorer policies" "HKLM:\Software\Policies\Microsoft\Windows\Explorer"

    $cacheDirectory = Join-Path $env:LOCALAPPDATA "Microsoft\Windows\Explorer"
    Write-Diag ("Thumbnail cache directory: " + $cacheDirectory)
    if (Test-Path -LiteralPath $cacheDirectory -PathType Container) {
        $cacheFiles = @(Get-ChildItem -LiteralPath $cacheDirectory -Filter "thumbcache_*.db" -ErrorAction SilentlyContinue)
        Write-Diag ("Thumbnail cache files: " + $cacheFiles.Count)
        foreach ($file in ($cacheFiles | Sort-Object LastWriteTime -Descending | Select-Object -First 8)) {
            Write-Diag ("  {0} size={1} modified={2}" -f $file.Name, $file.Length, $file.LastWriteTime.ToString("yyyy-MM-dd HH:mm:ss"))
        }
    } else {
        Write-Diag "Thumbnail cache directory missing."
    }
}

function Write-RegistrationInfo {
    Write-Section "SAI2 thumbnail registration"

    Write-RegistryPath ".sai2 HKCU" "HKCU:\Software\Classes\.sai2"
    Write-RegistryViewKey ".sai2 HKCR 64-view" ([Microsoft.Win32.RegistryHive]::ClassesRoot) ([Microsoft.Win32.RegistryView]::Registry64) ".sai2"
    Write-RegistryViewKey ".sai2 HKCR 32-view" ([Microsoft.Win32.RegistryHive]::ClassesRoot) ([Microsoft.Win32.RegistryView]::Registry32) ".sai2"
    Write-RegistryPath ".sai2 shell handler HKCU" ("HKCU:\Software\Classes\.sai2\shellex\" + $thumbnailHandlerGuid)
    Write-RegistryViewKey ".sai2 shell handler HKCR 64-view" ([Microsoft.Win32.RegistryHive]::ClassesRoot) ([Microsoft.Win32.RegistryView]::Registry64) (".sai2\shellex\" + $thumbnailHandlerGuid)
    Write-RegistryViewKey ".sai2 shell handler HKCR 32-view" ([Microsoft.Win32.RegistryHive]::ClassesRoot) ([Microsoft.Win32.RegistryView]::Registry32) (".sai2\shellex\" + $thumbnailHandlerGuid)
    Write-RegistryPath ".sai2 DefaultIcon HKCU" "HKCU:\Software\Classes\.sai2\DefaultIcon"
    Write-RegistryViewKey ".sai2 DefaultIcon HKCR 64-view" ([Microsoft.Win32.RegistryHive]::ClassesRoot) ([Microsoft.Win32.RegistryView]::Registry64) ".sai2\DefaultIcon"
    Write-RegistryViewKey ".sai2 DefaultIcon HKCR 32-view" ([Microsoft.Win32.RegistryHive]::ClassesRoot) ([Microsoft.Win32.RegistryView]::Registry32) ".sai2\DefaultIcon"

    $progId = Get-RegistryViewValue ([Microsoft.Win32.RegistryHive]::ClassesRoot) ([Microsoft.Win32.RegistryView]::Registry64) ".sai2" ""
    if (-not [string]::IsNullOrWhiteSpace($progId)) {
        Write-Diag ("Effective .sai2 ProgID: " + $progId)
        Write-RegistryPath "ProgID shell handler HKCU" ("HKCU:\Software\Classes\" + $progId + "\shellex\" + $thumbnailHandlerGuid)
        Write-RegistryViewKey "ProgID shell handler HKCR 64-view" ([Microsoft.Win32.RegistryHive]::ClassesRoot) ([Microsoft.Win32.RegistryView]::Registry64) ($progId + "\shellex\" + $thumbnailHandlerGuid)
        Write-RegistryViewKey "ProgID shell handler HKCR 32-view" ([Microsoft.Win32.RegistryHive]::ClassesRoot) ([Microsoft.Win32.RegistryView]::Registry32) ($progId + "\shellex\" + $thumbnailHandlerGuid)
        Write-RegistryViewKey "ProgID DefaultIcon HKCR 64-view" ([Microsoft.Win32.RegistryHive]::ClassesRoot) ([Microsoft.Win32.RegistryView]::Registry64) ($progId + "\DefaultIcon")
        Write-RegistryViewKey "ProgID DefaultIcon HKCR 32-view" ([Microsoft.Win32.RegistryHive]::ClassesRoot) ([Microsoft.Win32.RegistryView]::Registry32) ($progId + "\DefaultIcon")
    } else {
        Write-Diag "Effective .sai2 ProgID: <not set>"
    }

    Write-RegistryPath "CLSID Inproc HKCU" ("HKCU:\Software\Classes\CLSID\" + $providerClsid + "\InprocServer32")
    Write-RegistryPath "CLSID Inproc HKLM" ("HKLM:\Software\Classes\CLSID\" + $providerClsid + "\InprocServer32")

    $clsidSubKey = "Software\Classes\CLSID\" + $providerClsid + "\InprocServer32"
    Write-RegistryViewKey "CLSID Inproc HKCU 64-view" ([Microsoft.Win32.RegistryHive]::CurrentUser) ([Microsoft.Win32.RegistryView]::Registry64) $clsidSubKey
    Write-RegistryViewKey "CLSID Inproc HKCU 32-view" ([Microsoft.Win32.RegistryHive]::CurrentUser) ([Microsoft.Win32.RegistryView]::Registry32) $clsidSubKey
    Write-RegistryViewKey "CLSID Inproc HKLM 64-view" ([Microsoft.Win32.RegistryHive]::LocalMachine) ([Microsoft.Win32.RegistryView]::Registry64) $clsidSubKey
    Write-RegistryViewKey "CLSID Inproc HKLM 32-view" ([Microsoft.Win32.RegistryHive]::LocalMachine) ([Microsoft.Win32.RegistryView]::Registry32) $clsidSubKey
    Write-RegistryViewKey "CLSID Inproc HKCR 64-view" ([Microsoft.Win32.RegistryHive]::ClassesRoot) ([Microsoft.Win32.RegistryView]::Registry64) ("CLSID\" + $providerClsid + "\InprocServer32")
    Write-RegistryViewKey "CLSID Inproc HKCR 32-view" ([Microsoft.Win32.RegistryHive]::ClassesRoot) ([Microsoft.Win32.RegistryView]::Registry32) ("CLSID\" + $providerClsid + "\InprocServer32")

    $assemblyValue = Get-RegistryViewValue ([Microsoft.Win32.RegistryHive]::ClassesRoot) ([Microsoft.Win32.RegistryView]::Registry64) ("CLSID\" + $providerClsid + "\InprocServer32") "Assembly"
    $assemblyVersionText = $null
    if (-not [string]::IsNullOrWhiteSpace($assemblyValue)) {
        try {
            $assemblyVersionText = (New-Object System.Reflection.AssemblyName($assemblyValue)).Version.ToString()
        } catch {
        }
    }
    if (-not [string]::IsNullOrWhiteSpace($assemblyVersionText)) {
        $versionSubKey = $clsidSubKey + "\" + $assemblyVersionText
        Write-RegistryViewKey "CLSID Inproc version HKCU 64-view" ([Microsoft.Win32.RegistryHive]::CurrentUser) ([Microsoft.Win32.RegistryView]::Registry64) $versionSubKey
        Write-RegistryViewKey "CLSID Inproc version HKCU 32-view" ([Microsoft.Win32.RegistryHive]::CurrentUser) ([Microsoft.Win32.RegistryView]::Registry32) $versionSubKey
        Write-RegistryViewKey "CLSID Inproc version HKCR 64-view" ([Microsoft.Win32.RegistryHive]::ClassesRoot) ([Microsoft.Win32.RegistryView]::Registry64) ("CLSID\" + $providerClsid + "\InprocServer32\" + $assemblyVersionText)
        Write-RegistryViewKey "CLSID Inproc version HKCR 32-view" ([Microsoft.Win32.RegistryHive]::ClassesRoot) ([Microsoft.Win32.RegistryView]::Registry32) ("CLSID\" + $providerClsid + "\InprocServer32\" + $assemblyVersionText)
        Write-RegistryViewKey "CLSID ProgId HKCR 64-view" ([Microsoft.Win32.RegistryHive]::ClassesRoot) ([Microsoft.Win32.RegistryView]::Registry64) ("CLSID\" + $providerClsid + "\ProgId")
        Write-RegistryViewKey "Provider COM ProgID HKCR 64-view" ([Microsoft.Win32.RegistryHive]::ClassesRoot) ([Microsoft.Win32.RegistryView]::Registry64) ($providerClassName + "\CLSID")
        Write-RegistryViewKey "Provider Record HKCU 64-view" ([Microsoft.Win32.RegistryHive]::CurrentUser) ([Microsoft.Win32.RegistryView]::Registry64) ("Software\Classes\Record\" + $recordGuid + "\" + $assemblyVersionText)
        Write-RegistryViewKey "Provider Record HKLM 64-view" ([Microsoft.Win32.RegistryHive]::LocalMachine) ([Microsoft.Win32.RegistryView]::Registry64) ("Software\Classes\Record\" + $recordGuid + "\" + $assemblyVersionText)
        Write-RegistryViewKey "Provider Record HKCR 64-view" ([Microsoft.Win32.RegistryHive]::ClassesRoot) ([Microsoft.Win32.RegistryView]::Registry64) ("Record\" + $recordGuid + "\" + $assemblyVersionText)
    } else {
        Write-Diag "CLSID Inproc version subkey: SKIP, assembly version could not be read from HKCR root."
    }

    $hkcuCodeBase = Get-RegistryValue ("HKCU:\Software\Classes\CLSID\" + $providerClsid + "\InprocServer32") "CodeBase"
    $hklmCodeBase = Get-RegistryViewValue ([Microsoft.Win32.RegistryHive]::LocalMachine) ([Microsoft.Win32.RegistryView]::Registry64) $clsidSubKey "CodeBase"
    $hkcrCodeBase = Get-RegistryViewValue ([Microsoft.Win32.RegistryHive]::ClassesRoot) ([Microsoft.Win32.RegistryView]::Registry64) ("CLSID\" + $providerClsid + "\InprocServer32") "CodeBase"
    Write-Diag ("HKCU CodeBase local path: " + (Format-Value (Convert-CodeBaseToPath $hkcuCodeBase)))
    Write-Diag ("HKLM CodeBase local path: " + (Format-Value (Convert-CodeBaseToPath $hklmCodeBase)))
    Write-Diag ("HKCR CodeBase local path: " + (Format-Value (Convert-CodeBaseToPath $hkcrCodeBase)))
    if (-not [string]::IsNullOrWhiteSpace($hkcuCodeBase) -and -not [string]::IsNullOrWhiteSpace($hklmCodeBase) -and $hkcuCodeBase -ine $hklmCodeBase) {
        Write-Diag "WARNING: HKCU CLSID registration differs from HKLM. HKCU overrides HKLM for this user."
    }
    if (-not [string]::IsNullOrWhiteSpace($hkcuCodeBase) -and -not [string]::IsNullOrWhiteSpace($hkcrCodeBase) -and $hkcuCodeBase -ine $hkcrCodeBase) {
        Write-Diag "WARNING: HKCU and HKCR CodeBase differ. COM may not be using the path you expect."
    }
}

function Write-ProviderFileInfo {
    Write-Section "Provider file"

    $script:ResolvedProviderPath = Resolve-ProviderPath
    Write-Diag ("Resolved provider path: " + (Format-Value $script:ResolvedProviderPath))
    if ([string]::IsNullOrWhiteSpace($script:ResolvedProviderPath)) {
        Write-Diag "Provider path could not be resolved."
        return
    }

    if (-not (Test-Path -LiteralPath $script:ResolvedProviderPath -PathType Leaf)) {
        Write-Diag "Provider file missing."
        return
    }

    $file = Get-Item -LiteralPath $script:ResolvedProviderPath
    Write-Diag ("FullName: " + $file.FullName)
    Write-Diag ("Length: " + $file.Length)
    Write-Diag ("LastWriteTime: " + $file.LastWriteTime.ToString("yyyy-MM-dd HH:mm:ss"))
    try {
        Write-Diag ("SHA256: " + (Get-FileHash -LiteralPath $file.FullName -Algorithm SHA256).Hash)
    } catch {
        Write-Diag "SHA256: <failed>"
        Write-ExceptionDetail $_ "  "
    }

    try {
        $assemblyName = [System.Reflection.AssemblyName]::GetAssemblyName($file.FullName)
        Write-Diag ("AssemblyName: " + $assemblyName.FullName)
        Write-Diag ("Assembly ProcessorArchitecture: " + $assemblyName.ProcessorArchitecture)
    } catch {
        Write-Diag "AssemblyName: <failed>"
        Write-ExceptionDetail $_ "  "
    }

    try {
        $zone = Get-Item -LiteralPath $file.FullName -Stream Zone.Identifier -ErrorAction SilentlyContinue
        if ($null -eq $zone) {
            Write-Diag "Zone.Identifier: <none>"
        } else {
            Write-Diag ("Zone.Identifier: present, length=" + $zone.Length)
        }
    } catch {
        Write-Diag "Zone.Identifier: <not supported or failed>"
    }

    if ($file.FullName -match "[^\u0000-\u007F]") {
        Write-Diag "Path note: contains non-ASCII characters."
    }
    if ($file.FullName.Contains("'")) {
        Write-Diag "Path note: contains apostrophe."
    }
    if ($file.FullName -match "\s") {
        Write-Diag "Path note: contains whitespace."
    }
}

function Test-ProviderAssemblyLoad {
    param(
        [string]$Label,
        [string]$LoadPath
    )

    Write-Diag ("Test: " + $Label)
    Write-Diag ("  LoadPath: " + (Format-Value $LoadPath))
    if ([string]::IsNullOrWhiteSpace($LoadPath)) {
        Write-Diag "  SKIP: empty path"
        return $null
    }

    try {
        $assembly = [System.Reflection.Assembly]::LoadFrom($LoadPath)
        Write-Diag ("  LoadFrom: OK")
        Write-Diag ("  FullName: " + $assembly.FullName)
        Write-Diag ("  Location: " + $assembly.Location)
        foreach ($ref in $assembly.GetReferencedAssemblies()) {
            Write-Diag ("  Reference: " + $ref.FullName)
        }

        $type = $assembly.GetType($providerClassName, $true)
        Write-Diag ("  Type lookup: OK")
        $instance = [System.Activator]::CreateInstance($type)
        Write-Diag ("  Activator.CreateInstance(type): OK, " + $instance.GetType().FullName)
        if ($null -eq $script:LoadedProviderAssembly) {
            $script:LoadedProviderAssembly = $assembly
        }
        return $assembly
    } catch {
        Write-Diag "  FAILED"
        Write-ExceptionDetail $_ "    "
        return $null
    }
}

function Test-AssemblyLoads {
    Write-Section "Direct assembly load tests"

    if (-not [string]::IsNullOrWhiteSpace($script:ResolvedProviderPath)) {
        [void](Test-ProviderAssemblyLoad "LoadFrom resolved local path" $script:ResolvedProviderPath)
    }

    $hkcrCodeBase = Get-RegistryViewValue ([Microsoft.Win32.RegistryHive]::ClassesRoot) ([Microsoft.Win32.RegistryView]::Registry64) ("CLSID\" + $providerClsid + "\InprocServer32") "CodeBase"
    if (-not [string]::IsNullOrWhiteSpace($hkcrCodeBase)) {
        [void](Test-ProviderAssemblyLoad "LoadFrom HKCR CodeBase value" $hkcrCodeBase)
        [void](Test-ProviderAssemblyLoad "LoadFrom HKCR CodeBase local path" (Convert-CodeBaseToPath $hkcrCodeBase))
    }

    $hkcuCodeBase = Get-RegistryValue ("HKCU:\Software\Classes\CLSID\" + $providerClsid + "\InprocServer32") "CodeBase"
    if (-not [string]::IsNullOrWhiteSpace($hkcuCodeBase) -and $hkcuCodeBase -ine $hkcrCodeBase) {
        [void](Test-ProviderAssemblyLoad "LoadFrom HKCU CodeBase value" $hkcuCodeBase)
        [void](Test-ProviderAssemblyLoad "LoadFrom HKCU CodeBase local path" (Convert-CodeBaseToPath $hkcuCodeBase))
    }
}

function Test-ComActivation {
    Write-Section "COM activation"

    try {
        $type = [type]::GetTypeFromCLSID([guid]$providerClsid)
        Write-Diag ("GetTypeFromCLSID: OK, " + (Format-Value $type))
    } catch {
        Write-Diag "GetTypeFromCLSID: FAILED"
        Write-ExceptionDetail $_ "  "
        return
    }

    try {
        $instance = [System.Activator]::CreateInstance($type)
        Write-Diag ("Activator.CreateInstance(CLSID type): OK, " + $instance.GetType().FullName)
    } catch {
        Write-Diag "Activator.CreateInstance(CLSID type): FAILED"
        Write-ExceptionDetail $_ "  "
    }
}

function Test-SampleSai2Decode {
    Write-Section "Sample .sai2 decode"

    if ([string]::IsNullOrWhiteSpace($SampleSai2Path)) {
        Write-Diag "SKIP: pass -SampleSai2Path to test file content decoding."
        return
    }

    try {
        $samplePath = (Resolve-Path -LiteralPath $SampleSai2Path -ErrorAction Stop).ProviderPath
    } catch {
        Write-Diag ("Sample file missing: " + $SampleSai2Path)
        Write-ExceptionDetail $_ "  "
        return
    }

    Write-Diag ("Sample path: " + $samplePath)
    $sample = Get-Item -LiteralPath $samplePath
    Write-Diag ("Sample length: " + $sample.Length)

    $assembly = $script:LoadedProviderAssembly
    if ($null -eq $assembly) {
        if ([string]::IsNullOrWhiteSpace($script:ResolvedProviderPath) -or -not (Test-Path -LiteralPath $script:ResolvedProviderPath -PathType Leaf)) {
            Write-Diag "SKIP: provider assembly is not loaded and no provider path is available."
            return
        }
        try {
            $assembly = [System.Reflection.Assembly]::LoadFrom($script:ResolvedProviderPath)
        } catch {
            Write-Diag "SKIP: provider assembly load failed."
            Write-ExceptionDetail $_ "  "
            return
        }
    }

    try {
        $decoderType = $assembly.GetType($decoderClassName, $false)
        if ($null -eq $decoderType) {
            $decoderType = $assembly.GetType($legacyDecoderClassName, $true)
        }
        $flags = [System.Reflection.BindingFlags]::Public -bor [System.Reflection.BindingFlags]::NonPublic -bor [System.Reflection.BindingFlags]::Static
        $parameterTypes = [type[]]@(
            [System.IO.Stream],
            [int],
            [System.Drawing.Bitmap].MakeByRefType(),
            [int].MakeByRefType(),
            [int].MakeByRefType(),
            [string].MakeByRefType()
        )
        $method = $decoderType.GetMethod("TryDecodeThumbnail", $flags, $null, $parameterTypes, $null)
        if ($null -eq $method) {
            Write-Diag "Decoder method not found."
            return
        }

        $stream = [System.IO.File]::OpenRead($samplePath)
        $bitmap = $null
        try {
            $args = @($stream, 256, $null, 0, 0, $null)
            $ok = [bool]$method.Invoke($null, $args)
            $bitmap = $args[2]
            $widthPx = $args[3]
            $heightPx = $args[4]
            $error = $args[5]
            Write-Diag ("Decoder TryDecodeThumbnail(256): " + $ok)
            Write-Diag ("Canvas width: " + (Format-Value $widthPx))
            Write-Diag ("Canvas height: " + (Format-Value $heightPx))
            Write-Diag ("Decoder error/status: " + (Format-Value $error))
            if ($null -ne $bitmap) {
                Write-Diag ("Bitmap size: {0}x{1}" -f $bitmap.Width, $bitmap.Height)
            }
        } finally {
            if ($null -ne $bitmap) {
                $bitmap.Dispose()
            }
            $stream.Dispose()
        }
    } catch {
        Write-Diag "Decoder test failed."
        Write-ExceptionDetail $_ "  "
    }
}

function Write-ProcessModuleInfo {
    Write-Section "Explorer and dllhost module state"

    $processes = @(Get-Process explorer,dllhost -ErrorAction SilentlyContinue)
    if ($processes.Count -eq 0) {
        Write-Diag "No explorer or dllhost process found."
        return
    }

    foreach ($process in $processes | Sort-Object ProcessName, Id) {
        $matched = $false
        $moduleError = $null
        try {
            foreach ($module in $process.Modules) {
                $name = [System.IO.Path]::GetFileName($module.FileName)
                if ($name -ieq $providerDllName) {
                    if (-not $matched) {
                        Write-Diag ("Process {0} pid={1} has provider module:" -f $process.ProcessName, $process.Id)
                    }
                    $matched = $true
                    Write-Diag ("  " + $module.FileName)
                }
            }
        } catch {
            $moduleError = $_
        }

        if ($matched) {
            continue
        }

        if ($null -ne $moduleError) {
            Write-Diag ("Process {0} pid={1}: module enumeration failed." -f $process.ProcessName, $process.Id)
            Write-ExceptionDetail $moduleError "  "
        }
    }
}

function Write-RecentEventLogInfo {
    if ($SkipEventLog) {
        return
    }

    Write-Section "Recent relevant Application events"
    try {
        $startTime = (Get-Date).AddHours(-8)
        $events = Get-WinEvent -FilterHashtable @{ LogName = "Application"; StartTime = $startTime; Level = @(2, 3) } -MaxEvents 120 -ErrorAction Stop |
            Where-Object {
                $_.ProviderName -in @(".NET Runtime", "Application Error", "Windows Error Reporting", "SideBySide") -or
                $_.Message -match "RecSAI|Sai2Thumbnail|3259D2F0|mscoree|thumbnail"
            } |
            Select-Object -First 20

        if ($null -eq $events -or @($events).Count -eq 0) {
            Write-Diag "No matching recent Application errors or warnings."
            return
        }

        foreach ($event in $events) {
            Write-Diag ("Event {0} {1} {2} Level={3}" -f $event.TimeCreated.ToString("yyyy-MM-dd HH:mm:ss"), $event.ProviderName, $event.Id, $event.LevelDisplayName)
            $message = ($event.Message -replace "(`r`n|`n|`r)", " ")
            if ($message.Length -gt 800) {
                $message = $message.Substring(0, 800) + "..."
            }
            Write-Diag ("  " + $message)
        }
    } catch {
        Write-Diag "Event log query failed."
        Write-ExceptionDetail $_ "  "
    }
}

function Write-SummaryHints {
    Write-Section "Summary hints"

    $iconsOnly = Get-RegistryValue "HKCU:\Software\Microsoft\Windows\CurrentVersion\Explorer\Advanced" "IconsOnly"
    if ($null -ne $iconsOnly -and [int]$iconsOnly -eq 1) {
        Write-Diag "BLOCKER: IconsOnly=1 means Explorer is configured to show icons instead of thumbnails."
    }

    $handler = Get-RegistryViewValue ([Microsoft.Win32.RegistryHive]::ClassesRoot) ([Microsoft.Win32.RegistryView]::Registry64) (".sai2\shellex\" + $thumbnailHandlerGuid) ""
    if ($handler -ine $providerClsid) {
        Write-Diag ("BLOCKER: effective .sai2 thumbnail handler is not the RecSAI provider. Actual=" + (Format-Value $handler))
    }

    $codeBase = Get-RegistryViewValue ([Microsoft.Win32.RegistryHive]::ClassesRoot) ([Microsoft.Win32.RegistryView]::Registry64) ("CLSID\" + $providerClsid + "\InprocServer32") "CodeBase"
    $codeBasePath = Convert-CodeBaseToPath $codeBase
    if ([string]::IsNullOrWhiteSpace($codeBasePath)) {
        Write-Diag "BLOCKER: HKCR CodeBase is missing."
    } elseif (-not (Test-Path -LiteralPath $codeBasePath -PathType Leaf)) {
        Write-Diag ("BLOCKER: HKCR CodeBase file is missing: " + $codeBasePath)
    }

    $assemblyValue = Get-RegistryViewValue ([Microsoft.Win32.RegistryHive]::ClassesRoot) ([Microsoft.Win32.RegistryView]::Registry64) ("CLSID\" + $providerClsid + "\InprocServer32") "Assembly"
    $assemblyVersionText = $null
    if (-not [string]::IsNullOrWhiteSpace($assemblyValue)) {
        try {
            $assemblyVersionText = (New-Object System.Reflection.AssemblyName($assemblyValue)).Version.ToString()
        } catch {
        }
    }
    if (-not [string]::IsNullOrWhiteSpace($assemblyVersionText)) {
        $versionCodeBase = Get-RegistryViewValue ([Microsoft.Win32.RegistryHive]::ClassesRoot) ([Microsoft.Win32.RegistryView]::Registry64) ("CLSID\" + $providerClsid + "\InprocServer32\" + $assemblyVersionText) "CodeBase"
        if ([string]::IsNullOrWhiteSpace($versionCodeBase)) {
            Write-Diag ("BLOCKER: HKCR InprocServer32\" + $assemblyVersionText + " CodeBase is missing.")
        }
        $recordCodeBase = Get-RegistryViewValue ([Microsoft.Win32.RegistryHive]::ClassesRoot) ([Microsoft.Win32.RegistryView]::Registry64) ("Record\" + $recordGuid + "\" + $assemblyVersionText) "CodeBase"
        if ([string]::IsNullOrWhiteSpace($recordCodeBase)) {
            Write-Diag ("BLOCKER: HKCR Record\" + $recordGuid + "\" + $assemblyVersionText + " CodeBase is missing.")
        }
    }

    Write-Diag "If direct assembly load is OK but COM activation fails, compare HKCR/HKCU/HKLM CodeBase above and check the COM exception HResult/FusionLog."
    Write-Diag "If COM activation is OK but Explorer still shows icons, check IconsOnly/policies, thum/jssf or intg/dpcm sample decode status, and whether Explorer loaded the provider module."
}

Write-SystemInfo
Write-ExplorerSettings
Write-RegistrationInfo
Write-ProviderFileInfo
Test-AssemblyLoads
Test-ComActivation
Test-SampleSai2Decode
Write-ProcessModuleInfo
Write-RecentEventLogInfo
Write-SummaryHints

if ([string]::IsNullOrWhiteSpace($ReportPath)) {
    $ReportPath = Join-Path $env:TEMP ("RecSAI-Sai2ThumbnailDiag-{0}.txt" -f (Get-Date).ToString("yyyyMMdd-HHmmss"))
}

try {
    $reportDirectory = Split-Path -Path $ReportPath -Parent
    if (-not [string]::IsNullOrWhiteSpace($reportDirectory) -and -not (Test-Path -LiteralPath $reportDirectory -PathType Container)) {
        New-Item -ItemType Directory -Path $reportDirectory -Force | Out-Null
    }
    $encoding = New-Object System.Text.UTF8Encoding($true)
    [System.IO.File]::WriteAllLines($ReportPath, $script:ReportLines.ToArray(), $encoding)
    Write-Host ""
    Write-Host ("诊断报告已保存: " + $ReportPath)
} catch {
    Write-Host ""
    Write-Host "诊断报告写入失败:"
    Write-ExceptionDetail $_ "  "
}
