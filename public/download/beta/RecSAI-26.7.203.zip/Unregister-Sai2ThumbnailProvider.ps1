﻿param(
    [switch]$Force,
    [switch]$RestartExplorer
)

$ErrorActionPreference = "Stop"

function Confirm-Continue {
    param([string]$Question)
    if ($Force) {
        return $true
    }
    $answer = Read-Host "$Question [y/N]"
    return $answer -match "^(y|yes|是)$"
}

function Confirm-RestartExplorer {
    if ($RestartExplorer) {
        return $true
    }
    if ($Force) {
        return $false
    }
    $answer = Read-Host "要关闭并重启资源管理器以刷新缩略图/图标缓存吗？[y/N]"
    return $answer -match "^(y|yes|是)$"
}

function Get-ThumbnailDllHosts {
    foreach ($process in Get-Process dllhost -ErrorAction SilentlyContinue) {
        $matched = $false
        try {
            foreach ($module in $process.Modules) {
                $name = [System.IO.Path]::GetFileName($module.FileName)
                if ($name -ieq "RecSAI.Sai2ThumbnailProvider.dll" -or $name -ieq "RecSAI.ThumbnailProvider.dll") {
                    $matched = $true
                    break
                }
            }
        } catch {
        }
        if ($matched) {
            $process
        }
    }
}

function Restart-ExplorerForThumbnailRefresh {
    $dllHosts = @(Get-ThumbnailDllHosts)
    if ($dllHosts.Count -gt 0) {
        $dllHosts | Stop-Process -Force -ErrorAction SilentlyContinue
        Write-Host "已关闭 $($dllHosts.Count) 个缩略图 COM Surrogate 进程。"
    }

    $explorers = @(Get-Process explorer -ErrorAction SilentlyContinue)
    if ($explorers.Count -gt 0) {
        $explorers | Stop-Process -Force -ErrorAction SilentlyContinue
        Write-Host "已关闭 $($explorers.Count) 个资源管理器进程。"
    }
    Start-Process explorer.exe
    Write-Host "资源管理器已重新启动。"
}

function Get-EffectiveClassDefaultValue {
    param([string]$KeyPath)

    $userPath = "HKCU:\Software\Classes\$KeyPath"
    if (Test-Path -LiteralPath $userPath) {
        $value = (Get-Item -LiteralPath $userPath).GetValue("")
        if (-not [string]::IsNullOrWhiteSpace($value)) {
            return $value
        }
    }

    $machinePath = "HKLM:\Software\Classes\$KeyPath"
    if (Test-Path -LiteralPath $machinePath) {
        $value = (Get-Item -LiteralPath $machinePath).GetValue("")
        if (-not [string]::IsNullOrWhiteSpace($value)) {
            return $value
        }
    }

    return $null
}

function Test-IsElevated {
    $identity = [System.Security.Principal.WindowsIdentity]::GetCurrent()
    $principal = New-Object System.Security.Principal.WindowsPrincipal($identity)
    return $principal.IsInRole([System.Security.Principal.WindowsBuiltInRole]::Administrator)
}

function Remove-ProviderDefaultIcon {
    param([string]$IconPath)

    if (Test-Path -LiteralPath $IconPath) {
        $value = (Get-Item -LiteralPath $IconPath).GetValue("")
        if ($value -match "(?i)RecSAI\.Sai2ThumbnailProvider\.dll") {
            Remove-Item -LiteralPath $IconPath -Recurse -Force
        }
    }
}

function Remove-ProviderTypeOverlay {
    param([string]$KeyPath)

    if (Test-Path -LiteralPath $KeyPath) {
        $item = Get-Item -LiteralPath $KeyPath
        $value = $item.GetValue("TypeOverlay")
        if ($value -match "(?i)RecSAI\.Sai2ThumbnailProvider\.dll") {
            Remove-ItemProperty -LiteralPath $KeyPath -Name "TypeOverlay" -ErrorAction SilentlyContinue
        }
    }
}

function Remove-ManagedComRegistration {
    param([string]$ClassesPath)

    foreach ($path in @(
        "$ClassesPath\CLSID\$clsid",
        "$ClassesPath\$className",
        "$ClassesPath\Record\$recordGuid"
    )) {
        if (Test-Path -LiteralPath $path) {
            Remove-Item -LiteralPath $path -Recurse -Force
        }
    }
}

$clsid = "{3259D2F0-B82C-486D-8304-A8681E50B131}"
$handler = "{E357FCCD-A995-4576-B01F-234630154E96}"
$className = "RecSAI.Sai2ThumbnailProvider.Sai2ThumbnailProvider"
$recordGuid = "{A3803D46-7EBD-3958-AD38-8539AF3BCBA4}"
$classes = "HKCU:\Software\Classes"
$machineClasses = "HKLM:\Software\Classes"
$machineComRegistration = Test-IsElevated
$handlerPath = "$classes\.sai2\shellex\$handler"
$iconPath = "$classes\.sai2\DefaultIcon"
$progId = Get-EffectiveClassDefaultValue ".sai2"
$progIdHandlerPath = if ([string]::IsNullOrWhiteSpace($progId)) { $null } else { "$classes\$progId\shellex\$handler" }
$progIdIconPath = if ([string]::IsNullOrWhiteSpace($progId)) { $null } else { "$classes\$progId\DefaultIcon" }

Write-Host ""
Write-Host "将执行以下操作："
Write-Host "  1. 如果 .sai2 当前缩略图处理器指向 $clsid，则删除该处理器注册。"
Write-Host "  2. 如果 .sai2 的 DefaultIcon/TypeOverlay 指向 RecSAI.Sai2ThumbnailProvider.dll，则删除该图标配置。"
if (-not [string]::IsNullOrWhiteSpace($progId)) {
    Write-Host "  3. 当前 .sai2 ProgID 为 $progId，如果 HKCU\Software\Classes\$progId\DefaultIcon/TypeOverlay 指向 Provider DLL，也会删除。"
} else {
    Write-Host "  3. 未发现 .sai2 ProgID，不处理 ProgID 图标覆盖。"
}
if ($machineComRegistration) {
    Write-Host "  4. 删除 HKCU 和 HKLM 中的 Provider COM 注册。"
} else {
    Write-Host "  4. 删除 HKCU 中的 Provider COM 注册；如存在 HKLM 注册，需要管理员运行本脚本才能删除。"
}
Write-Host "  5. 不修改 .sai2 的默认打开方式。"
Write-Host ""

if (-not (Confirm-Continue "继续注销 .sai2 缩略图支持吗？")) {
    Write-Host "已取消。"
    exit 0
}

$restartExplorerAfterChanges = Confirm-RestartExplorer

if (Test-Path -LiteralPath $handlerPath) {
    $value = (Get-Item -LiteralPath $handlerPath).GetValue("")
    if ($value -ieq $clsid) {
        Remove-Item -LiteralPath $handlerPath -Recurse -Force
    }
}
if (-not [string]::IsNullOrWhiteSpace($progIdHandlerPath) -and (Test-Path -LiteralPath $progIdHandlerPath)) {
    $value = (Get-Item -LiteralPath $progIdHandlerPath).GetValue("")
    if ($value -ieq $clsid) {
        Remove-Item -LiteralPath $progIdHandlerPath -Recurse -Force
    }
}

Remove-ProviderDefaultIcon $iconPath
Remove-ProviderTypeOverlay "$classes\.sai2"
if (-not [string]::IsNullOrWhiteSpace($progIdIconPath)) {
    Remove-ProviderDefaultIcon $progIdIconPath
    Remove-ProviderTypeOverlay "$classes\$progId"
}

Remove-ManagedComRegistration $classes
if ($machineComRegistration) {
    Remove-ManagedComRegistration $machineClasses
}

Write-Host ".sai2 thumbnail provider unregistered."

if ($restartExplorerAfterChanges) {
    Restart-ExplorerForThumbnailRefresh
} else {
    Write-Host "未重启资源管理器；缩略图/图标可能需要稍后刷新后才会变化。"
}

