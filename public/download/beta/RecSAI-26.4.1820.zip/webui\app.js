const storageKey = "readsai2-webui-state";
const statusPollMs = 1000;
const backendErrorLogThrottleMs = 10000;
const previewReconnectMs = 1000;
const previewResizeDebounceMs = 80;
const previewTileHeaderBytes = 48;
const previewTileFlags = {
  reset: 1,
  full: 2,
  present: 4
};

const defaultState = {
  backendAvailable: true,
  connected: true,
  recordingState: "idle",
  sidebarHidden: false,
  savePath: "",
  currentFile: "project_20260318_1738",
  processName: "sai2.exe",
  processBaseAddress: "0x00007FF6A1BE0000",
  processId: "18420",
  canvasSize: "5120 x 2880",
  canvasWidthValue: 5120,
  canvasHeightValue: 2880,
  thumbSize: "1280 x 720",
  thumbWidthValue: 1280,
  thumbHeightValue: 720,
  pointerX: 3400,
  pointerY: 1212,
  historyInterval: "1000",
  stepInterval: "1",
  quality: "95",
  previewMode: "fit",
  themeMode: "light",
  alwaysOnTop: false,
  autoLaunch: false,
  navigatorAutoResize: false,
  updateChannel: "stable",
  volumeModeIndex: 0,
  frameCount: 0,
  sessionStartedAt: null,
  volumeEstimateMbPerFrame: 26.8,
  volumeRecentMbPerFrame: 24.8,
  volumePreviousMbPerFrame: 23.4,
  volumeRecentCount: 100,
  volumePreviousCount: 2000,
  activityLog: []
};

const els = {
  connectionBadge: document.getElementById("connectionBadge"),
  statusSubtext: document.getElementById("statusSubtext"),
  topRecordButton: document.getElementById("topRecordButton"),
  overlayRecordButton: document.getElementById("overlayRecordButton"),
  topSidebarButton: document.getElementById("topSidebarButton"),
  themeToggleButton: document.getElementById("themeToggleButton"),
  overlaySidebarButton: document.getElementById("overlaySidebarButton"),
  controlRail: document.getElementById("controlRail"),
  savePathInput: document.getElementById("savePathInput"),
  currentFileLabel: document.getElementById("currentFileLabel"),
  openedFileNameLabel: document.getElementById("openedFileNameLabel"),
  recordSummaryLabel: document.getElementById("recordSummaryLabel"),
  processNameLabel: document.getElementById("processNameLabel"),
  processBaseAddressLabel: document.getElementById("processBaseAddressLabel"),
  processIdLabel: document.getElementById("processIdLabel"),
  canvasSizeLabel: document.getElementById("canvasSizeLabel"),
  thumbSizeLabel: document.getElementById("thumbSizeLabel"),
  pointerLabel: document.getElementById("pointerLabel"),
  volumeApproxLabel: document.getElementById("volumeApproxLabel"),
  recordingStateLabel: document.getElementById("recordingStateLabel"),
  statusLamp: document.getElementById("statusLamp"),
  historyIntervalSelect: document.getElementById("historyIntervalSelect"),
  stepIntervalSelect: document.getElementById("stepIntervalSelect"),
  qualitySelect: document.getElementById("qualitySelect"),
  alwaysOnTopToggle: document.getElementById("alwaysOnTopToggle"),
  autoLaunchToggle: document.getElementById("autoLaunchToggle"),
  navigatorResizeToggle: document.getElementById("navigatorResizeToggle"),
  updateChannelSelect: document.getElementById("updateChannelSelect"),
  activityLog: document.getElementById("activityLog"),
  clearLogButton: document.getElementById("clearLogButton"),
  browsePathButton: document.getElementById("browsePathButton"),
  openFolderButton: document.getElementById("openFolderButton"),
  launchSaiButton: document.getElementById("launchSaiButton"),
  checkUpdateButton: document.getElementById("checkUpdateButton"),
  diagnosticsButton: document.getElementById("diagnosticsButton"),
  unregisterButton: document.getElementById("unregisterButton"),
  contactButton: document.getElementById("contactButton"),
  volumeModeButton: document.getElementById("volumeModeButton"),
  volumeMetricPanel: document.getElementById("volumeMetricPanel"),
  simulateDetachButton: document.getElementById("simulateDetachButton"),
  previewFrame: document.getElementById("previewFrame"),
  previewScroll: document.getElementById("previewScroll"),
  previewSurface: document.getElementById("previewSurface"),
  displayCanvas: document.getElementById("displayCanvas"),
  overlayCanvas: document.getElementById("overlayCanvas")
};

const runtime = {
  provider: null,
  mockTimer: 0,
  statusPollTimer: 0,
  actionInFlight: false,
  backendErrorLoggedAt: 0
};

const preview = {
  atlasCanvas: document.createElement("canvas"),
  atlasCtx: null,
  displayCtx: null,
  overlayCtx: null,
  session: null,
  cursor: {
    x: 0,
    y: 0,
    thumbWidth: 0,
    thumbHeight: 0,
    attached: true
  },
  socket: null,
  reconnectTimer: 0,
  resizeSendTimer: 0,
  resizeObserver: null,
  renderQueued: false,
  overlayQueued: false,
  openSent: false,
  lastSentMaxDim: 0,
  lastSentMode: "",
  disposed: true,
  error: null,
  layout: null,
  dots: [],
  lastLogAt: 0
};

preview.atlasCtx = preview.atlasCanvas.getContext("2d");
preview.displayCtx = els.displayCanvas.getContext("2d");
preview.overlayCtx = els.overlayCanvas.getContext("2d");

const state = loadState();
document.documentElement.dataset.theme = state.themeMode === "dark" ? "dark" : "light";

function cloneState(src) {
  return JSON.parse(JSON.stringify(src));
}

function loadState() {
  try {
    const raw = localStorage.getItem(storageKey);
    if (!raw) {
      return cloneState(defaultState);
    }

    const parsed = { ...cloneState(defaultState), ...JSON.parse(raw) };
    parsed.previewMode = "fit";
    parsed.themeMode = parsed.themeMode === "dark" ? "dark" : "light";
    return parsed;
  } catch {
    return cloneState(defaultState);
  }
}

function persistState() {
  const persistent = {
    sidebarHidden: state.sidebarHidden,
    savePath: state.savePath,
    historyInterval: state.historyInterval,
    stepInterval: state.stepInterval,
    quality: state.quality,
    previewMode: state.previewMode,
    themeMode: state.themeMode,
    alwaysOnTop: state.alwaysOnTop,
    autoLaunch: state.autoLaunch,
    navigatorAutoResize: state.navigatorAutoResize,
    updateChannel: state.updateChannel,
    volumeModeIndex: state.volumeModeIndex
  };
  localStorage.setItem(storageKey, JSON.stringify(persistent));
}

function addLog(message) {
  const now = new Date();
  state.activityLog.unshift({
    time: now.toLocaleTimeString("zh-CN", { hour12: false }),
    message
  });
  state.activityLog = state.activityLog.slice(0, 12);
  renderLog();
}

function renderLog() {
  els.activityLog.innerHTML = "";
  if (state.activityLog.length === 0) {
    const empty = document.createElement("li");
    empty.className = "activity-item";
    empty.innerHTML = "<time>--:--:--</time><span>No recent activity.</span>";
    els.activityLog.appendChild(empty);
    return;
  }

  state.activityLog.forEach((item) => {
    const li = document.createElement("li");
    li.className = "activity-item";
    li.innerHTML = `<time>${item.time}</time><span>${item.message}</span>`;
    els.activityLog.appendChild(li);
  });
}

function clamp(value, min, max) {
  return Math.max(min, Math.min(max, value));
}

function formatSize(width, height) {
  if (!width || !height || width <= 0 || height <= 0) {
    return "N";
  }
  return `${width} x ${height}`;
}

function formatHex(value) {
  const numeric = Number(value);
  if (!Number.isFinite(numeric) || numeric <= 0) {
    return "N";
  }
  return `0x${Math.trunc(numeric).toString(16).toUpperCase()}`;
}

function fileNameFromPath(path) {
  if (!path) {
    return "";
  }
  const parts = path.split(/[/\\]/);
  return parts[parts.length - 1] || path;
}

function toNumber(value, fallback) {
  const numeric = Number(value);
  return Number.isFinite(numeric) ? numeric : fallback;
}

function isHttpProvider() {
  return runtime.provider && runtime.provider.kind === "http";
}

function setActionInFlight(active) {
  runtime.actionInFlight = active;
  renderButtons();
}

function getRecordingLabel() {
  if (state.recordingState === "recording") {
    return "Recording";
  }
  if (state.recordingState === "starting") {
    return "Starting...";
  }
  if (state.recordingState === "stopping") {
    return "Stopping...";
  }
  return "Record";
}

function getStatusPillText() {
  if (!state.backendAvailable && isHttpProvider()) {
    return "Web API unavailable";
  }
  if (!state.connected) {
    return "Waiting for SAI2";
  }
  if (state.recordingState === "recording") {
    return "Connected / Recording";
  }
  if (state.recordingState === "starting" || state.recordingState === "stopping") {
    return "Syncing runtime state";
  }
  return "Connected to SAI2";
}

function getStatusSubtext() {
  if (!state.backendAvailable && isHttpProvider()) {
    return "The local HTTP bridge did not respond.";
  }
  const channel = state.updateChannel === "beta" ? "beta" : "stable";
  if (!state.connected) {
    return `Output is paused. Update channel: ${channel}.`;
  }
  return `Recording follows runtime changes. Update channel: ${channel}.`;
}

function getVolumeText() {
  if (state.volumeModeIndex === 1) {
    if (state.volumeRecentCount > 0) {
      return `${state.volumeRecentMbPerFrame.toFixed(1)} MB / frame (${state.volumeRecentCount} recent)`;
    }
    return "No recent volume data";
  }
  if (state.volumeModeIndex === 2) {
    if (state.volumePreviousCount > 0) {
      return `${state.volumePreviousMbPerFrame.toFixed(1)} MB / frame (${state.volumePreviousCount} previous)`;
    }
    return "No previous volume data";
  }
  return `${state.volumeEstimateMbPerFrame.toFixed(1)} MB / frame`;
}

function getRecordSummary() {
  if (isHttpProvider()) {
    if (!state.backendAvailable) {
      return "Waiting for the local HTTP bridge";
    }
    if (state.recordingState === "recording") {
      return `poll=${state.historyInterval}ms / step=${state.stepInterval} / quality=${state.quality}`;
    }
    if (state.recordingState === "starting") {
      return "Preparing the recording session";
    }
    if (state.recordingState === "stopping") {
      return "Waiting for the CLI to stop recording";
    }
    return "Idle";
  }

  if (state.recordingState === "recording" && state.sessionStartedAt) {
    const elapsedSeconds = Math.max(1, Math.floor((Date.now() - state.sessionStartedAt) / 1000));
    return `${state.frameCount} frames / ${elapsedSeconds}s / step=${state.stepInterval}`;
  }
  if (state.recordingState === "starting") {
    return "Preparing the recording session";
  }
  if (state.recordingState === "stopping") {
    return "Stopping the recording session";
  }
  return "Idle";
}

function renderButtons() {
  const label = getRecordingLabel();
  [els.topRecordButton, els.overlayRecordButton].forEach((button) => {
    button.textContent = label;
    button.disabled = runtime.actionInFlight;
    button.classList.toggle("is-recording", state.recordingState === "recording");
  });

  const sidebarLabel = state.sidebarHidden ? "Show Sidebar" : "Hide Sidebar";
  els.topSidebarButton.textContent = sidebarLabel;
  els.overlaySidebarButton.textContent = sidebarLabel;
  els.controlRail.classList.toggle("is-hidden", state.sidebarHidden);
}

function renderStatus() {
  els.connectionBadge.textContent = getStatusPillText();
  els.connectionBadge.classList.toggle("is-offline", !state.connected || (!state.backendAvailable && isHttpProvider()));
  els.connectionBadge.classList.toggle("is-busy", state.recordingState === "starting" || state.recordingState === "stopping");
  els.statusSubtext.textContent = getStatusSubtext();
  els.recordingStateLabel.textContent = state.recordingState === "idle" ? "Idle" : getRecordingLabel();
  els.statusLamp.classList.toggle("is-recording", state.recordingState === "recording");
  els.statusLamp.classList.toggle("is-busy", state.recordingState === "starting" || state.recordingState === "stopping");
}

function renderFields() {
  els.savePathInput.value = state.savePath;
  els.currentFileLabel.textContent = state.currentFile;
  els.openedFileNameLabel.textContent = state.currentFile;
  els.recordSummaryLabel.textContent = getRecordSummary();

  if (!state.backendAvailable && isHttpProvider()) {
    els.processNameLabel.textContent = "Web API unavailable";
    els.processBaseAddressLabel.textContent = "N";
    els.processIdLabel.textContent = "N";
    els.canvasSizeLabel.textContent = "N";
    els.thumbSizeLabel.textContent = "N";
    els.pointerLabel.textContent = "N";
    els.volumeApproxLabel.textContent = "N";
  } else {
    els.processNameLabel.textContent = state.connected ? state.processName : "SAI2 is not running";
    els.processBaseAddressLabel.textContent = state.connected ? state.processBaseAddress : "N";
    els.processIdLabel.textContent = state.connected ? state.processId : "N";
    els.canvasSizeLabel.textContent = state.connected ? state.canvasSize : "N";
    els.thumbSizeLabel.textContent = state.connected ? state.thumbSize : "N";
    els.pointerLabel.textContent = state.connected ? `${Math.round(state.pointerX)}, ${Math.round(state.pointerY)}` : "N";
    els.volumeApproxLabel.textContent = state.connected ? getVolumeText() : "N";
  }

  els.historyIntervalSelect.value = state.historyInterval;
  els.stepIntervalSelect.value = state.stepInterval;
  els.qualitySelect.value = state.quality;
  els.alwaysOnTopToggle.checked = state.alwaysOnTop;
  els.autoLaunchToggle.checked = state.autoLaunch;
  els.navigatorResizeToggle.checked = state.navigatorAutoResize;
  els.updateChannelSelect.value = state.updateChannel;
}

function renderTheme() {
  const themeMode = state.themeMode === "dark" ? "dark" : "light";
  document.documentElement.dataset.theme = themeMode;

  if (els.themeToggleButton) {
    els.themeToggleButton.textContent = themeMode === "light" ? "Theme: Light" : "Theme: Dark";
    els.themeToggleButton.setAttribute("aria-pressed", themeMode === "dark" ? "true" : "false");
  }
}

function renderPreviewChrome() {
  const hasPreviewIssue = (!!preview.error && isHttpProvider()) || (!state.connected && isHttpProvider()) || (!state.backendAvailable && isHttpProvider());
  els.previewFrame.classList.toggle("is-recording", state.recordingState === "recording" || state.recordingState === "starting");
  els.previewFrame.classList.toggle("is-offline", hasPreviewIssue);
  els.previewScroll.classList.add("is-fit");
  els.previewScroll.classList.remove("is-actual");
}

function render() {
  renderTheme();
  renderStatus();
  renderButtons();
  renderFields();
  renderPreviewChrome();
  persistState();
}

function toggleSidebar() {
  state.sidebarHidden = !state.sidebarHidden;
  addLog(state.sidebarHidden ? "Sidebar hidden." : "Sidebar shown.");
  render();
}

function cycleVolumeMode() {
  state.volumeModeIndex = (state.volumeModeIndex + 1) % 3;
  addLog(`Volume display mode changed to ${state.volumeModeIndex + 1}.`);
  render();
}

function toggleThemeMode() {
  state.themeMode = state.themeMode === "dark" ? "light" : "dark";
  addLog(`Theme changed to ${state.themeMode}.`);
  render();
  drawPreview();
}

function getPreviewDeviceScale() {
  return clamp(window.devicePixelRatio || 1, 1, 2);
}

function getPreviewViewportSize() {
  return {
    width: Math.max(els.previewScroll.clientWidth || 0, 320),
    height: Math.max(els.previewScroll.clientHeight || 0, 240)
  };
}

function setCanvasSize(canvas, cssWidth, cssHeight, pixelWidth, pixelHeight) {
  const nextWidth = Math.max(1, Math.round(pixelWidth));
  const nextHeight = Math.max(1, Math.round(pixelHeight));
  if (canvas.width !== nextWidth) {
    canvas.width = nextWidth;
  }
  if (canvas.height !== nextHeight) {
    canvas.height = nextHeight;
  }
  canvas.style.width = `${Math.max(1, cssWidth)}px`;
  canvas.style.height = `${Math.max(1, cssHeight)}px`;
}

function ensureAtlasSize(width, height) {
  const safeWidth = Math.max(1, Math.round(width || 1));
  const safeHeight = Math.max(1, Math.round(height || 1));
  if (preview.atlasCanvas.width !== safeWidth) {
    preview.atlasCanvas.width = safeWidth;
  }
  if (preview.atlasCanvas.height !== safeHeight) {
    preview.atlasCanvas.height = safeHeight;
  }
}

function clearAtlas() {
  ensureAtlasSize(preview.session ? preview.session.width : 1, preview.session ? preview.session.height : 1);
  preview.atlasCtx.clearRect(0, 0, preview.atlasCanvas.width, preview.atlasCanvas.height);
}

function computeContainRect(sourceWidth, sourceHeight, targetWidth, targetHeight) {
  if (sourceWidth <= 0 || sourceHeight <= 0 || targetWidth <= 0 || targetHeight <= 0) {
    return { x: 0, y: 0, width: Math.max(0, targetWidth), height: Math.max(0, targetHeight) };
  }

  const sourceRatio = sourceWidth / sourceHeight;
  const targetRatio = targetWidth / targetHeight;
  let width = targetWidth;
  let height = targetHeight;
  if (sourceRatio > targetRatio) {
    height = width / sourceRatio;
  } else {
    width = height * sourceRatio;
  }

  return {
    x: Math.round((targetWidth - width) * 0.5),
    y: Math.round((targetHeight - height) * 0.5),
    width: Math.round(width),
    height: Math.round(height)
  };
}

function updatePreviewLayout() {
  const viewport = getPreviewViewportSize();
  const sessionWidth = preview.session && preview.session.width > 0 ? preview.session.width : 1280;
  const sessionHeight = preview.session && preview.session.height > 0 ? preview.session.height : 720;
  const canUseActual = false;

  let cssWidth;
  let cssHeight;
  let pixelWidth;
  let pixelHeight;
  let drawRect;

  if (canUseActual) {
    cssWidth = sessionWidth;
    cssHeight = sessionHeight;
    pixelWidth = sessionWidth;
    pixelHeight = sessionHeight;
    drawRect = { x: 0, y: 0, width: pixelWidth, height: pixelHeight };
  } else {
    const scale = getPreviewDeviceScale();
    cssWidth = viewport.width;
    cssHeight = viewport.height;
    pixelWidth = Math.max(1, Math.round(cssWidth * scale));
    pixelHeight = Math.max(1, Math.round(cssHeight * scale));
    drawRect = computeContainRect(sessionWidth, sessionHeight, pixelWidth, pixelHeight);
  }

  setCanvasSize(els.displayCanvas, cssWidth, cssHeight, pixelWidth, pixelHeight);
  setCanvasSize(els.overlayCanvas, cssWidth, cssHeight, pixelWidth, pixelHeight);
  els.previewSurface.style.width = `${Math.max(1, cssWidth)}px`;
  els.previewSurface.style.height = `${Math.max(1, cssHeight)}px`;

  preview.layout = {
    viewportWidth: viewport.width,
    viewportHeight: viewport.height,
    cssWidth,
    cssHeight,
    pixelWidth,
    pixelHeight,
    sessionWidth,
    sessionHeight,
    drawRect,
    mode: canUseActual ? "actual" : "fit"
  };
  renderPreviewChrome();
  return preview.layout;
}

function getPreviewPlaceholderLines() {
  if (isHttpProvider() && !state.backendAvailable) {
    return ["Waiting for HTTP bridge", "The preview socket opens after the local bridge is ready."];
  }
  if (preview.error && preview.error.message) {
    return ["Runtime preview unavailable", preview.error.message];
  }
  if (isHttpProvider()) {
    return ["Connecting runtime preview", "Waiting for hello/session over /ws/preview/runtime."];
  }
  return ["Mock preview", "Click the preview to toggle fit and 1:1 modes."];
}

function drawPreviewBackdrop(ctx, width, height) {
  ctx.clearRect(0, 0, width, height);
  const bg = ctx.createLinearGradient(0, 0, width, height);
  bg.addColorStop(0, "#122730");
  bg.addColorStop(0.45, "#163440");
  bg.addColorStop(1, "#214753");
  ctx.fillStyle = bg;
  ctx.fillRect(0, 0, width, height);

  ctx.strokeStyle = "rgba(255,255,255,0.08)";
  ctx.lineWidth = 1;
  for (let x = 60; x < width; x += 60) {
    ctx.beginPath();
    ctx.moveTo(x, 0);
    ctx.lineTo(x, height);
    ctx.stroke();
  }
  for (let y = 60; y < height; y += 60) {
    ctx.beginPath();
    ctx.moveTo(0, y);
    ctx.lineTo(width, y);
    ctx.stroke();
  }
}

function drawPreviewPlaceholder(ctx, width, height) {
  const lines = getPreviewPlaceholderLines();
  ctx.fillStyle = "rgba(242, 198, 108, 0.12)";
  ctx.fillRect(40, 48, Math.max(0, width - 80), Math.max(0, height - 96));
  ctx.fillStyle = "#f6e8e2";
  ctx.font = "700 30px Georgia";
  ctx.fillText(lines[0], 56, Math.max(74, height - 92));
  ctx.fillStyle = "rgba(246, 232, 226, 0.78)";
  ctx.font = "16px Segoe UI Variable Display";
  ctx.fillText(lines[1], 56, Math.max(98, height - 60));
}

function drawRuntimePreviewFrame(ctx, layout) {
  drawPreviewBackdrop(ctx, layout.pixelWidth, layout.pixelHeight);
  if (!preview.session) {
    drawPreviewPlaceholder(ctx, layout.pixelWidth, layout.pixelHeight);
    return;
  }

  const rect = layout.drawRect;
  ctx.imageSmoothingEnabled = true;
  ctx.drawImage(
    preview.atlasCanvas,
    0,
    0,
    preview.session.width,
    preview.session.height,
    rect.x,
    rect.y,
    rect.width,
    rect.height
  );
}

function drawMockPreviewFrame(ctx, layout) {
  drawPreviewBackdrop(ctx, layout.pixelWidth, layout.pixelHeight);
  const rect = layout.drawRect;
  ctx.fillStyle = "rgba(242, 198, 108, 0.12)";
  ctx.fillRect(rect.x, rect.y, rect.width, rect.height);

  preview.dots.forEach((dot, index) => {
    const alpha = (index + 1) / Math.max(1, preview.dots.length);
    ctx.beginPath();
    ctx.fillStyle = `hsla(${dot.hue}, 88%, 66%, ${alpha * 0.72})`;
    ctx.arc(dot.x, dot.y, dot.size, 0, Math.PI * 2);
    ctx.fill();
  });
}

function drawPreviewFrameNow() {
  const layout = updatePreviewLayout();
  if (!preview.displayCtx || !layout) {
    return;
  }

  if (runtime.provider && runtime.provider.kind === "mock") {
    drawMockPreviewFrame(preview.displayCtx, layout);
  } else {
    drawRuntimePreviewFrame(preview.displayCtx, layout);
  }
}

function getPreviewCursorPoint() {
  if (!preview.layout || !preview.session || !preview.cursor.attached) {
    return null;
  }
  if (preview.cursor.thumbWidth <= 0 || preview.cursor.thumbHeight <= 0) {
    return null;
  }

  const ratioX = clamp(preview.cursor.x / preview.cursor.thumbWidth, 0, 1);
  const ratioY = clamp(preview.cursor.y / preview.cursor.thumbHeight, 0, 1);
  const rect = preview.layout.drawRect;
  return {
    x: rect.x + (rect.width * ratioX),
    y: rect.y + (rect.height * ratioY)
  };
}

function drawPreviewRecordingOverlay(ctx, rect) {
  if (state.recordingState !== "recording" && state.recordingState !== "starting" && state.recordingState !== "stopping") {
    return;
  }

  ctx.save();
  ctx.strokeStyle = state.recordingState === "recording" ? "rgba(255, 110, 99, 0.92)" : "rgba(242, 198, 108, 0.92)";
  ctx.lineWidth = 4;
  ctx.strokeRect(rect.x + 2, rect.y + 2, Math.max(0, rect.width - 4), Math.max(0, rect.height - 4));
  ctx.fillStyle = "rgba(5, 15, 18, 0.82)";
  ctx.fillRect(rect.x + 16, rect.y + 16, 82, 34);
  ctx.fillStyle = "#fff4ec";
  ctx.font = "700 16px Segoe UI Variable Display";
  ctx.fillText(state.recordingState === "recording" ? "REC" : "SYNC", rect.x + 34, rect.y + 38);
  ctx.restore();
}

function drawPreviewOfflineOverlay(ctx, rect) {
  const offline = (!state.backendAvailable && isHttpProvider()) || !preview.cursor.attached || !!preview.error;
  if (!offline) {
    return;
  }

  ctx.save();
  ctx.fillStyle = "rgba(5, 12, 15, 0.52)";
  ctx.fillRect(rect.x, rect.y, rect.width, rect.height);
  ctx.fillStyle = "#f6e8e2";
  ctx.font = "700 20px Georgia";
  ctx.fillText(preview.error ? "Preview offline" : "Detached", rect.x + 24, rect.y + 36);
  ctx.restore();
}

function drawPreviewPointerOverlay(ctx) {
  const point = getPreviewCursorPoint();
  if (!point) {
    return;
  }

  ctx.save();
  ctx.strokeStyle = "rgba(98, 221, 192, 0.92)";
  ctx.lineWidth = 2;
  ctx.beginPath();
  ctx.moveTo(point.x - 24, point.y);
  ctx.lineTo(point.x + 24, point.y);
  ctx.moveTo(point.x, point.y - 24);
  ctx.lineTo(point.x, point.y + 24);
  ctx.stroke();
  ctx.beginPath();
  ctx.fillStyle = "rgba(98, 221, 192, 0.98)";
  ctx.arc(point.x, point.y, 6, 0, Math.PI * 2);
  ctx.fill();
  ctx.restore();
}

function drawPreviewOverlayNow() {
  const layout = preview.layout || updatePreviewLayout();
  if (!preview.overlayCtx || !layout) {
    return;
  }

  preview.overlayCtx.clearRect(0, 0, layout.pixelWidth, layout.pixelHeight);
  drawPreviewRecordingOverlay(preview.overlayCtx, layout.drawRect);
  drawPreviewOfflineOverlay(preview.overlayCtx, layout.drawRect);
  drawPreviewPointerOverlay(preview.overlayCtx);
}

function requestPreviewFrameDraw() {
  if (preview.renderQueued) {
    return;
  }
  preview.renderQueued = true;
  window.requestAnimationFrame(() => {
    preview.renderQueued = false;
    drawPreviewFrameNow();
  });
}

function requestPreviewOverlayDraw() {
  if (preview.overlayQueued) {
    return;
  }
  preview.overlayQueued = true;
  window.requestAnimationFrame(() => {
    preview.overlayQueued = false;
    drawPreviewOverlayNow();
  });
}

function drawPreview() {
  requestPreviewFrameDraw();
  requestPreviewOverlayDraw();
}

function computePreviewMaxDim() {
  const viewport = getPreviewViewportSize();
  const longestCssPx = Math.max(viewport.width, viewport.height);
  const scale = getPreviewDeviceScale();
  return clamp(Math.round(longestCssPx * scale), 1024, 3072);
}

function logPreviewEventThrottled(message) {
  const now = Date.now();
  if (now - preview.lastLogAt < 2000) {
    return;
  }
  preview.lastLogAt = now;
  addLog(message);
}

function sendPreviewControlMessage(type) {
  if (!preview.socket || preview.socket.readyState !== WebSocket.OPEN) {
    return;
  }

  const maxDim = computePreviewMaxDim();
  const mode = "fit";
  if (type === "resize" && preview.lastSentMaxDim === maxDim && preview.lastSentMode === mode) {
    return;
  }

  preview.socket.send(JSON.stringify({
    type,
    max_dim: maxDim,
    mode
  }));
  preview.openSent = true;
  preview.lastSentMaxDim = maxDim;
  preview.lastSentMode = mode;
}

function queuePreviewResizeSend() {
  if (!isHttpProvider() || preview.disposed) {
    return;
  }
  if (preview.resizeSendTimer) {
    window.clearTimeout(preview.resizeSendTimer);
  }
  preview.resizeSendTimer = window.setTimeout(() => {
    preview.resizeSendTimer = 0;
    sendPreviewControlMessage(preview.openSent ? "resize" : "open");
  }, previewResizeDebounceMs);
}

function disposeRuntimePreviewTransport(resetSession) {
  preview.disposed = true;
  if (preview.resizeSendTimer) {
    window.clearTimeout(preview.resizeSendTimer);
    preview.resizeSendTimer = 0;
  }
  if (preview.reconnectTimer) {
    window.clearTimeout(preview.reconnectTimer);
    preview.reconnectTimer = 0;
  }
  if (preview.socket) {
    try {
      preview.socket.close();
    } catch {
    }
    preview.socket = null;
  }
  preview.openSent = false;
  preview.lastSentMaxDim = 0;
  preview.lastSentMode = "";
  preview.layout = null;
  if (resetSession) {
    preview.session = null;
    preview.error = null;
    clearAtlas();
  }
}

function schedulePreviewReconnect() {
  if (preview.disposed || preview.reconnectTimer) {
    return;
  }
  preview.reconnectTimer = window.setTimeout(() => {
    preview.reconnectTimer = 0;
    connectRuntimePreviewSocket();
  }, previewReconnectMs);
}

function connectRuntimePreviewSocket() {
  if (!isHttpProvider() || preview.disposed || preview.socket) {
    return;
  }

  const protocol = window.location.protocol === "https:" ? "wss:" : "ws:";
  const url = `${protocol}//${window.location.host}/ws/preview/runtime`;
  const socket = new WebSocket(url);
  socket.binaryType = "arraybuffer";
  preview.socket = socket;
  preview.error = null;
  preview.openSent = false;
  preview.lastSentMaxDim = 0;
  preview.lastSentMode = "";

  socket.addEventListener("open", () => {
    if (preview.socket !== socket) {
      return;
    }
    preview.error = null;
    sendPreviewControlMessage("open");
    requestPreviewOverlayDraw();
  });

  socket.addEventListener("message", (event) => {
    if (typeof event.data === "string") {
      handlePreviewTextMessage(event.data);
      return;
    }
    if (event.data instanceof ArrayBuffer) {
      applyPreviewTilePacket(event.data);
      return;
    }
    if (event.data instanceof Blob) {
      void event.data.arrayBuffer().then(applyPreviewTilePacket).catch(() => {
      });
    }
  });

  socket.addEventListener("error", () => {
    logPreviewEventThrottled("Preview websocket error.");
  });

  socket.addEventListener("close", () => {
    if (preview.socket === socket) {
      preview.socket = null;
      preview.openSent = false;
      preview.lastSentMaxDim = 0;
      preview.lastSentMode = "";
      if (!preview.error) {
        preview.error = {
          code: "preview_socket_closed",
          message: "The preview socket closed.",
          retryable: true
        };
      }
      if (!preview.session) {
        requestPreviewFrameDraw();
      }
      requestPreviewOverlayDraw();
      schedulePreviewReconnect();
    }
  });
}

function handlePreviewTextMessage(text) {
  let message;
  try {
    message = JSON.parse(text);
  } catch {
    return;
  }

  if (!message || typeof message.type !== "string") {
    return;
  }

  if (message.type === "hello") {
    preview.error = null;
    requestPreviewOverlayDraw();
    return;
  }
  if (message.type === "session") {
    preview.error = null;
    const previousSession = preview.session;
    preview.session = {
      width: Math.max(1, toNumber(message.width, 1)),
      height: Math.max(1, toNumber(message.height, 1)),
      tileSize: Math.max(1, toNumber(message.tile_size, 256)),
      tilesX: Math.max(1, toNumber(message.tiles_x, 1)),
      tilesY: Math.max(1, toNumber(message.tiles_y, 1)),
      generation: toNumber(message.generation, 0),
      lodMaxDim: Math.max(0, toNumber(message.lod_max_dim, 0))
    };
    preview.layout = null;
    ensureAtlasSize(preview.session.width, preview.session.height);
    if (message.reset) {
      clearAtlas();
      requestPreviewFrameDraw();
    }
    if (!message.reset && (!previousSession
      || previousSession.width !== preview.session.width
      || previousSession.height !== preview.session.height
      || previousSession.tileSize !== preview.session.tileSize
      || previousSession.generation !== preview.session.generation)) {
      requestPreviewFrameDraw();
    }
    requestPreviewOverlayDraw();
    return;
  }
  if (message.type === "cursor") {
    const previousAttached = state.connected;
    const nextAttached = !!message.attached;
    preview.cursor = {
      x: toNumber(message.x, 0),
      y: toNumber(message.y, 0),
      thumbWidth: Math.max(0, toNumber(message.thumb_width, 0)),
      thumbHeight: Math.max(0, toNumber(message.thumb_height, 0)),
      attached: nextAttached
    };
    state.connected = nextAttached;
    if (preview.cursor.thumbWidth > 0 && preview.cursor.thumbHeight > 0) {
      state.thumbWidthValue = preview.cursor.thumbWidth;
      state.thumbHeightValue = preview.cursor.thumbHeight;
      state.thumbSize = formatSize(state.thumbWidthValue, state.thumbHeightValue);
    }
    if (previousAttached !== nextAttached) {
      renderStatus();
      renderFields();
      renderPreviewChrome();
    }
    requestPreviewOverlayDraw();
    return;
  }
  if (message.type === "error") {
    preview.error = {
      code: message.code || "preview_error",
      message: message.message || "Preview error.",
      retryable: message.retryable !== false
    };
    logPreviewEventThrottled(preview.error.message);
    if (!preview.session) {
      requestPreviewFrameDraw();
    }
    requestPreviewOverlayDraw();
  }
}

function applyPreviewTilePacket(buffer) {
  if (!(buffer instanceof ArrayBuffer) || buffer.byteLength < previewTileHeaderBytes) {
    return;
  }

  const bytes = new Uint8Array(buffer);
  const magic = String.fromCharCode(bytes[0], bytes[1], bytes[2], bytes[3]);
  if (magic !== "RST1") {
    return;
  }

  const view = new DataView(buffer);
  const version = view.getUint16(4, true);
  const kind = view.getUint16(6, true);
  if (version !== 1 || kind !== 1) {
    return;
  }

  const flags = view.getUint32(8, true);
  const generation = view.getInt32(12, true);
  const tileX = view.getInt32(24, true);
  const tileY = view.getInt32(28, true);
  const width = view.getInt32(32, true);
  const height = view.getInt32(36, true);
  const stride = view.getInt32(40, true);
  const payloadBytes = view.getUint32(44, true);

  if (flags & previewTileFlags.reset) {
    clearAtlas();
  }

  if (!preview.session || generation !== preview.session.generation) {
    if (flags & previewTileFlags.present) {
      requestPreviewFrameDraw();
    }
    return;
  }

  if (payloadBytes > 0 && previewTileHeaderBytes + payloadBytes <= buffer.byteLength) {
    putPreviewTile(buffer, previewTileHeaderBytes, payloadBytes, tileX, tileY, width, height, stride);
  }

  if (flags & previewTileFlags.present) {
    requestPreviewFrameDraw();
  }
}

function putPreviewTile(buffer, payloadOffset, payloadBytes, tileX, tileY, width, height, stride) {
  if (!preview.session || width <= 0 || height <= 0) {
    return;
  }
  if (stride < width * 4) {
    return;
  }
  const requiredBytes = stride * height;
  if (requiredBytes <= 0 || payloadBytes < requiredBytes) {
    return;
  }

  ensureAtlasSize(preview.session.width, preview.session.height);
  const destinationX = tileX * preview.session.tileSize;
  const destinationY = tileY * preview.session.tileSize;
  let rgba = null;

  if (stride === width * 4) {
    rgba = new Uint8ClampedArray(buffer, payloadOffset, payloadBytes);
  } else {
    rgba = new Uint8ClampedArray(width * height * 4);
    const source = new Uint8Array(buffer, payloadOffset, payloadBytes);
    for (let row = 0; row < height; row += 1) {
      const sourceOffset = row * stride;
      const targetOffset = row * width * 4;
      rgba.set(source.subarray(sourceOffset, sourceOffset + width * 4), targetOffset);
    }
  }

  const imageData = new ImageData(rgba, width, height);
  preview.atlasCtx.putImageData(imageData, destinationX, destinationY);
}

function stepSimulation() {
  state.pointerX = 2600 + Math.sin(Date.now() / 780) * 1400 + Math.cos(Date.now() / 3100) * 180;
  state.pointerY = 1420 + Math.cos(Date.now() / 580) * 620 + Math.sin(Date.now() / 2800) * 90;

  preview.session = {
    width: state.canvasWidthValue,
    height: state.canvasHeightValue,
    tileSize: 256,
    tilesX: Math.max(1, Math.ceil(state.canvasWidthValue / 256)),
    tilesY: Math.max(1, Math.ceil(state.canvasHeightValue / 256)),
    generation: 1,
    lodMaxDim: computePreviewMaxDim()
  };
  preview.cursor = {
    x: clamp((state.pointerX / Math.max(1, state.canvasWidthValue)) * state.thumbWidthValue, 0, state.thumbWidthValue),
    y: clamp((state.pointerY / Math.max(1, state.canvasHeightValue)) * state.thumbHeightValue, 0, state.thumbHeightValue),
    thumbWidth: state.thumbWidthValue,
    thumbHeight: state.thumbHeightValue,
    attached: state.connected
  };

  if (state.recordingState === "recording") {
    state.frameCount += Number(state.stepInterval || "1");
    state.volumeEstimateMbPerFrame = 26.8 + state.frameCount * 0.04;
    state.volumeRecentMbPerFrame = 24.8 + state.frameCount * 0.03;
    state.volumePreviousMbPerFrame = 23.4 + state.frameCount * 0.02;
    const layout = updatePreviewLayout();
    preview.dots.push({
      x: clamp(layout.drawRect.x + (layout.drawRect.width * Math.random()), layout.drawRect.x + 18, layout.drawRect.x + Math.max(18, layout.drawRect.width - 18)),
      y: clamp(layout.drawRect.y + (layout.drawRect.height * Math.random()), layout.drawRect.y + 18, layout.drawRect.y + Math.max(18, layout.drawRect.height - 18)),
      hue: 18 + (state.frameCount % 100),
      size: 6 + (state.frameCount % 7)
    });
    if (preview.dots.length > 60) {
      preview.dots.shift();
    }
  } else if (preview.dots.length > 24) {
    preview.dots.shift();
  }

  drawPreview();
  renderFields();
}

function applyStatusPayload(data) {
  if (!data) {
    return;
  }

  state.backendAvailable = true;
  state.connected = !!data.attached;
  state.canvasWidthValue = Math.max(0, toNumber(data.canvas_width, state.canvasWidthValue));
  state.canvasHeightValue = Math.max(0, toNumber(data.canvas_height, state.canvasHeightValue));
  state.thumbWidthValue = Math.max(0, toNumber(data.thumb_width, state.thumbWidthValue));
  state.thumbHeightValue = Math.max(0, toNumber(data.thumb_height, state.thumbHeightValue));
  state.canvasSize = formatSize(state.canvasWidthValue, state.canvasHeightValue);
  state.thumbSize = formatSize(state.thumbWidthValue, state.thumbHeightValue);
  state.pointerX = toNumber(data.pointer_x, state.pointerX);
  state.pointerY = toNumber(data.pointer_y, state.pointerY);
  state.processBaseAddress = formatHex(data.base_addr);
  state.processId = toNumber(data.pid, 0) > 0 ? String(Math.trunc(toNumber(data.pid, 0))) : "N";
  state.processName = fileNameFromPath(data.sai_path) || "sai2.exe";
  state.volumeEstimateMbPerFrame = Math.max(0, toNumber(data.volume_estimate_mb_per_frame, state.volumeEstimateMbPerFrame));
  state.volumeRecentMbPerFrame = Math.max(0, toNumber(data.volume_recent_mb_per_frame, state.volumeRecentMbPerFrame));
  state.volumePreviousMbPerFrame = Math.max(0, toNumber(data.volume_previous_mb_per_frame, state.volumePreviousMbPerFrame));
  state.volumeRecentCount = Math.max(0, toNumber(data.volume_recent_count, state.volumeRecentCount));
  state.volumePreviousCount = Math.max(0, toNumber(data.volume_previous_count, state.volumePreviousCount));

  const projectName = typeof data.project_name === "string" ? data.project_name.trim() : "";
  if (projectName) {
    state.currentFile = projectName;
  }
}

function applyRecordPayload(data) {
  if (!data) {
    return;
  }

  state.backendAvailable = true;
  if (typeof data.attached === "boolean") {
    state.connected = data.attached;
  }

  const intervalValue = toNumber(data.history_poll_ms ?? data.interval_ms, 0);
  if (intervalValue > 0) {
    state.historyInterval = String(Math.trunc(intervalValue));
  }
  const stepValue = toNumber(data.step_interval, 0);
  if (stepValue > 0) {
    state.stepInterval = String(Math.trunc(stepValue));
  }
  const qualityValue = toNumber(data.jpeg_quality, 0);
  if (qualityValue > 0) {
    state.quality = String(Math.trunc(qualityValue));
  }
  if (typeof data.save_root === "string") {
    state.savePath = data.save_root.trim();
  }
  if (typeof data.project_name === "string" && data.project_name.trim()) {
    state.currentFile = data.project_name.trim();
  }

  if (data.recording === true) {
    state.recordingState = "recording";
    if (!state.sessionStartedAt) {
      state.sessionStartedAt = Date.now();
    }
    return;
  }

  if (data.recording_desired === true) {
    state.recordingState = "starting";
    return;
  }

  state.recordingState = "idle";
  state.sessionStartedAt = null;
}

function handleBackendUnavailable(message) {
  state.backendAvailable = false;
  state.connected = false;
  state.recordingState = "idle";
  state.sessionStartedAt = null;
  render();
  drawPreview();

  const now = Date.now();
  if (now - runtime.backendErrorLoggedAt >= backendErrorLogThrottleMs) {
    runtime.backendErrorLoggedAt = now;
    addLog(message);
  }
}

async function fetchJson(path, init) {
  let response;
  try {
    response = await fetch(path, {
      cache: "no-store",
      headers: {
        "Content-Type": "application/json"
      },
      ...init
    });
  } catch (error) {
    const wrapped = new Error(error && error.message ? error.message : "Network error");
    wrapped.bridgeUnavailable = true;
    throw wrapped;
  }

  let payload = null;
  try {
    payload = await response.json();
  } catch {
    payload = null;
  }

  if (!response.ok || !payload || payload.ok !== true) {
    const error = payload && payload.error ? payload.error : null;
    const wrapped = new Error(error && error.message ? error.message : `HTTP ${response.status}`);
    wrapped.bridgeUnavailable = false;
    wrapped.status = response.status;
    throw wrapped;
  }

  return payload;
}

function handleSoftApiFailure(message) {
  state.backendAvailable = true;
  render();
  drawPreview();

  const now = Date.now();
  if (now - runtime.backendErrorLoggedAt >= backendErrorLogThrottleMs) {
    runtime.backendErrorLoggedAt = now;
    addLog(message);
  }
}

function createMockProvider() {
  return {
    kind: "mock",
    async init() {
      disposeRuntimePreviewTransport(true);
      preview.dots = [];
      preview.disposed = true;
      addLog("Using file:// mock provider.");
      runtime.mockTimer = window.setInterval(stepSimulation, 120);
      render();
      stepSimulation();
    },
    dispose() {
      if (runtime.mockTimer) {
        window.clearInterval(runtime.mockTimer);
        runtime.mockTimer = 0;
      }
    },
    async toggleRecording() {
      if (!state.connected) {
        addLog("Recording cannot start because SAI2 is not attached.");
        render();
        return;
      }

      if (state.recordingState === "idle") {
        state.recordingState = "starting";
        render();
        addLog(`Recording started: path=${state.savePath}, poll=${state.historyInterval}ms, step=${state.stepInterval}.`);
        window.setTimeout(() => {
          state.recordingState = "recording";
          state.frameCount = 0;
          state.sessionStartedAt = Date.now();
          render();
          drawPreview();
        }, 620);
        return;
      }

      if (state.recordingState === "recording") {
        state.recordingState = "stopping";
        render();
        addLog("Stopping the recording session.");
        window.setTimeout(() => {
          state.recordingState = "idle";
          state.sessionStartedAt = null;
          render();
          drawPreview();
        }, 520);
      }
    },
    async updateRecordConfig(patch, successMessage) {
      if (typeof patch.save_root === "string" && patch.save_root.trim()) {
        state.savePath = patch.save_root.trim();
      }
      if (patch.history_poll_ms) {
        state.historyInterval = String(patch.history_poll_ms);
      }
      if (patch.step_interval) {
        state.stepInterval = String(patch.step_interval);
      }
      if (patch.jpeg_quality) {
        state.quality = String(patch.jpeg_quality);
      }
      addLog(successMessage);
      render();
    },
    simulateDetach() {
      state.connected = !state.connected;
      preview.cursor.attached = state.connected;
      addLog(state.connected ? "Mock provider reattached to SAI2." : "Mock provider detached from SAI2.");
      render();
      drawPreview();
    }
  };
}

function createHttpProvider() {
  return {
    kind: "http",
    async init() {
      preview.disposed = false;
      addLog("Using the local HTTP bridge.");
      await this.refreshAll(true);
      connectRuntimePreviewSocket();
      runtime.statusPollTimer = window.setInterval(() => {
        void this.pollStatusDelta();
      }, statusPollMs);
    },
    dispose() {
      if (runtime.statusPollTimer) {
        window.clearInterval(runtime.statusPollTimer);
        runtime.statusPollTimer = 0;
      }
      disposeRuntimePreviewTransport(false);
    },
    async refreshAll(isInitial) {
      try {
        const [statusResponse, recordResponse] = await Promise.all([
          fetchJson("/api/status"),
          fetchJson("/api/record/status")
        ]);
        applyStatusPayload(statusResponse.data);
        applyRecordPayload(recordResponse.data);
        render();
        drawPreview();
        if (isInitial) {
          addLog("Connected to the local HTTP bridge.");
        }
      } catch (error) {
        if (error.bridgeUnavailable) {
          handleBackendUnavailable(`HTTP bridge unavailable: ${error.message}`);
        } else {
          handleSoftApiFailure(`Initial state fetch failed: ${error.message}`);
        }
      }
    },
    async pollStatusDelta() {
      try {
        const deltaResponse = await fetchJson("/api/status/delta");
        if (!state.backendAvailable) {
          await this.refreshAll(false);
          return;
        }
        state.backendAvailable = true;
        if (deltaResponse.data && deltaResponse.data.changed) {
          applyStatusPayload(deltaResponse.data);
          render();
          requestPreviewOverlayDraw();
        }
      } catch (error) {
        if (error.bridgeUnavailable) {
          handleBackendUnavailable(`HTTP bridge unavailable: ${error.message}`);
        } else {
          handleSoftApiFailure(`Status polling failed: ${error.message}`);
        }
      }
    },
    async toggleRecording() {
      if (runtime.actionInFlight) {
        return;
      }

      if (state.recordingState === "idle") {
        state.recordingState = "starting";
        render();
        setActionInFlight(true);
        try {
          await fetchJson("/api/record/start", {
            method: "POST",
            body: JSON.stringify({
              history_poll_ms: Number(state.historyInterval),
              step_interval: Number(state.stepInterval),
              jpeg_quality: Number(state.quality),
              save_root: state.savePath,
              auto_canvas_name: true
            })
          });
          addLog(`Recording started: path=${state.savePath}, poll=${state.historyInterval}ms, step=${state.stepInterval}.`);
          await this.refreshAll(false);
        } catch (error) {
          if (error.bridgeUnavailable) {
            handleBackendUnavailable(`HTTP bridge unavailable: ${error.message}`);
          } else {
            handleSoftApiFailure(`Failed to start recording: ${error.message}`);
            await this.refreshAll(false);
          }
        } finally {
          setActionInFlight(false);
        }
        return;
      }

      if (state.recordingState === "recording") {
        state.recordingState = "stopping";
        render();
        setActionInFlight(true);
        try {
          await fetchJson("/api/record/stop", {
            method: "POST",
            body: "{}"
          });
          addLog("Stopping the recording session.");
          await this.refreshAll(false);
        } catch (error) {
          if (error.bridgeUnavailable) {
            handleBackendUnavailable(`HTTP bridge unavailable: ${error.message}`);
          } else {
            handleSoftApiFailure(`Failed to stop recording: ${error.message}`);
            await this.refreshAll(false);
          }
        } finally {
          setActionInFlight(false);
        }
      }
    },
    async updateRecordConfig(patch, successMessage) {
      if (runtime.actionInFlight) {
        return;
      }

      setActionInFlight(true);
      try {
        await fetchJson("/api/record/set", {
          method: "POST",
          body: JSON.stringify(patch)
        });
        addLog(successMessage);
        await this.refreshAll(false);
      } catch (error) {
        if (error.bridgeUnavailable) {
          handleBackendUnavailable(`HTTP bridge unavailable: ${error.message}`);
        } else {
          handleSoftApiFailure(`Failed to update recording config: ${error.message}`);
          await this.refreshAll(false);
        }
      } finally {
        setActionInFlight(false);
      }
    },
    simulateDetach() {
      addLog("Detach simulation is not available when using the HTTP bridge.");
    }
  };
}

function bindPreviewSurface() {
  if ("ResizeObserver" in window) {
    preview.resizeObserver = new ResizeObserver(() => {
      drawPreview();
      queuePreviewResizeSend();
    });
    preview.resizeObserver.observe(els.previewScroll);
  }

  window.addEventListener("resize", () => {
    drawPreview();
    queuePreviewResizeSend();
  });
}

function bindControls() {
  els.topRecordButton.addEventListener("click", () => {
    void runtime.provider.toggleRecording();
  });
  els.overlayRecordButton.addEventListener("click", () => {
    void runtime.provider.toggleRecording();
  });
  els.topSidebarButton.addEventListener("click", toggleSidebar);
  els.themeToggleButton.addEventListener("click", toggleThemeMode);
  els.overlaySidebarButton.addEventListener("click", toggleSidebar);
  els.volumeModeButton.addEventListener("click", cycleVolumeMode);
  els.volumeMetricPanel.addEventListener("click", cycleVolumeMode);
  els.volumeMetricPanel.addEventListener("keydown", (event) => {
    if (event.key === "Enter" || event.key === " ") {
      event.preventDefault();
      cycleVolumeMode();
    }
  });

  els.simulateDetachButton.addEventListener("click", () => {
    runtime.provider.simulateDetach();
  });

  els.clearLogButton.addEventListener("click", () => {
    state.activityLog = [];
    renderLog();
  });

  els.savePathInput.addEventListener("change", () => {
    const next = els.savePathInput.value.trim() || defaultState.savePath;
    void runtime.provider.updateRecordConfig({ save_root: next }, `Save path updated to ${next}.`);
  });
  els.historyIntervalSelect.addEventListener("change", () => {
    const next = els.historyIntervalSelect.value;
    void runtime.provider.updateRecordConfig({ history_poll_ms: Number(next) }, `Polling interval changed to ${next}ms.`);
  });
  els.stepIntervalSelect.addEventListener("change", () => {
    const next = els.stepIntervalSelect.value;
    void runtime.provider.updateRecordConfig({ step_interval: Number(next) }, `Step interval changed to ${next}.`);
  });
  els.qualitySelect.addEventListener("change", () => {
    const next = els.qualitySelect.value;
    void runtime.provider.updateRecordConfig({ jpeg_quality: Number(next) }, `JPEG quality changed to ${next}.`);
  });

  els.alwaysOnTopToggle.addEventListener("change", () => {
    state.alwaysOnTop = els.alwaysOnTopToggle.checked;
    addLog(`Always-on-top changed to ${state.alwaysOnTop}.`);
    render();
  });
  els.autoLaunchToggle.addEventListener("change", () => {
    state.autoLaunch = els.autoLaunchToggle.checked;
    addLog(`Auto-launch changed to ${state.autoLaunch}.`);
    render();
  });
  els.navigatorResizeToggle.addEventListener("change", () => {
    state.navigatorAutoResize = els.navigatorResizeToggle.checked;
    addLog(`Navigator auto-resize changed to ${state.navigatorAutoResize}.`);
    render();
  });
  els.updateChannelSelect.addEventListener("change", () => {
    state.updateChannel = els.updateChannelSelect.value;
    addLog(`Update channel changed to ${state.updateChannel}.`);
    render();
  });

  els.browsePathButton.addEventListener("click", () => {
    addLog("Browse path is not wired in the Web UI prototype.");
  });
  els.openFolderButton.addEventListener("click", () => {
    addLog(`Open output folder: ${state.savePath || "(empty)"}.`);
  });
  els.launchSaiButton.addEventListener("click", () => {
    addLog("Launch SAI2 is not wired in the Web UI prototype.");
  });
  els.checkUpdateButton.addEventListener("click", () => {
    addLog(`Manual update check requested on the ${state.updateChannel} channel.`);
  });
  els.diagnosticsButton.addEventListener("click", () => {
    addLog("Diagnostics export is still a placeholder.");
  });
  els.unregisterButton.addEventListener("click", () => {
    addLog("The .recsai unregister action is still a placeholder.");
  });
  els.contactButton.addEventListener("click", () => {
    addLog("Contact and feedback are still placeholders.");
  });
}

async function init() {
  bindControls();
  bindPreviewSurface();
  renderLog();
  render();
  drawPreview();

  runtime.provider = window.location.protocol === "file:" ? createMockProvider() : createHttpProvider();
  await runtime.provider.init();
}

void init();
