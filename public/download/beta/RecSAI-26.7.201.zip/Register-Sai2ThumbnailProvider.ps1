﻿param(
    [string]$DllPath,
    [switch]$Force,
    [switch]$RestartExplorer
)

$ErrorActionPreference = "Stop"

function Confirm-Continue {
    param([string]$Question)
    if ($Force) {
        return $true
    }
    $answer = Read-Host "$Question [y/N]"
    return $answer -match "^(y|yes|是)$"
}

function Confirm-RestartExplorer {
    if ($RestartExplorer) {
        return $true
    }
    if ($Force) {
        return $false
    }
    $answer = Read-Host "要关闭并重启资源管理器以刷新缩略图/图标缓存吗？[y/N]"
    return $answer -match "^(y|yes|是)$"
}

function Get-ThumbnailDllHosts {
    foreach ($process in Get-Process dllhost -ErrorAction SilentlyContinue) {
        $matched = $false
        try {
            foreach ($module in $process.Modules) {
                $name = [System.IO.Path]::GetFileName($module.FileName)
                if ($name -ieq "RecSAI.Sai2ThumbnailProvider.dll" -or $name -ieq "RecSAI.ThumbnailProvider.dll") {
                    $matched = $true
                    break
                }
            }
        } catch {
        }
        if ($matched) {
            $process
        }
    }
}

function Restart-ExplorerForThumbnailRefresh {
    $dllHosts = @(Get-ThumbnailDllHosts)
    if ($dllHosts.Count -gt 0) {
        $dllHosts | Stop-Process -Force -ErrorAction SilentlyContinue
        Write-Host "已关闭 $($dllHosts.Count) 个缩略图 COM Surrogate 进程。"
    }

    $explorers = @(Get-Process explorer -ErrorAction SilentlyContinue)
    if ($explorers.Count -gt 0) {
        $explorers | Stop-Process -Force -ErrorAction SilentlyContinue
        Write-Host "已关闭 $($explorers.Count) 个资源管理器进程。"
    }
    Start-Process explorer.exe
    Write-Host "资源管理器已重新启动。"
}

function Get-EffectiveClassDefaultValue {
    param([string]$KeyPath)

    $userPath = "HKCU:\Software\Classes\$KeyPath"
    if (Test-Path -LiteralPath $userPath) {
        $value = (Get-Item -LiteralPath $userPath).GetValue("")
        if (-not [string]::IsNullOrWhiteSpace($value)) {
            return $value
        }
    }

    $machinePath = "HKLM:\Software\Classes\$KeyPath"
    if (Test-Path -LiteralPath $machinePath) {
        $value = (Get-Item -LiteralPath $machinePath).GetValue("")
        if (-not [string]::IsNullOrWhiteSpace($value)) {
            return $value
        }
    }

    return $null
}

if ([string]::IsNullOrWhiteSpace($DllPath)) {
    $DllPath = Join-Path $PSScriptRoot "RecSAI.Sai2ThumbnailProvider.dll"
}

$resolved = Resolve-Path -LiteralPath $DllPath
$fullPath = $resolved.ProviderPath
$assemblyName = [System.Reflection.AssemblyName]::GetAssemblyName($fullPath)
$assembly = $assemblyName.FullName
$assemblyVersion = $assemblyName.Version.ToString()
$codeBase = (New-Object System.Uri($fullPath)).AbsoluteUri
$runtimeVersion = [System.Runtime.InteropServices.RuntimeEnvironment]::GetSystemVersion()

$clsid = "{3259D2F0-B82C-486D-8304-A8681E50B131}"
$handler = "{E357FCCD-A995-4576-B01F-234630154E96}"
$className = "RecSAI.Sai2ThumbnailProvider.Sai2ThumbnailProvider"
$dotNetComCategory = "{62C8FE65-4EBB-45E7-B440-6E39B2CDBF29}"
$classes = "HKCU:\Software\Classes"
$progId = Get-EffectiveClassDefaultValue ".sai2"
$preferencePath = "$classes\RecSAI"

Write-Host ""
Write-Host "将执行以下操作："
Write-Host "  1. 读取缩略图 Provider DLL：$fullPath"
Write-Host "  2. 在 HKCU\Software\Classes\CLSID\$clsid 注册 .NET COM 组件。"
Write-Host "  3. 将 .sai2 的缩略图处理器设置为 $clsid。"
Write-Host "  4. 将 .sai2 的 DefaultIcon 和 TypeOverlay 设置为 Provider DLL 内置的 sai2-file.ico。"
if (-not [string]::IsNullOrWhiteSpace($progId)) {
    Write-Host "  5. 当前 .sai2 ProgID 为 $progId，会同步覆盖 HKCU\Software\Classes\$progId\DefaultIcon 和 TypeOverlay。"
} else {
    Write-Host "  5. 未发现 .sai2 ProgID，仅写入 .sai2\DefaultIcon 和 TypeOverlay。"
}
Write-Host "  6. 将 RecSAI 的 .sai2 图标偏好设置为 Provider DLL，避免后续自动注册改回外部图标。"
Write-Host "  7. 不修改 .sai2 的默认打开方式。"
Write-Host ""

if (-not (Confirm-Continue "继续注册 .sai2 缩略图支持吗？")) {
    Write-Host "已取消。"
    exit 0
}

$restartExplorerAfterChanges = Confirm-RestartExplorer

New-Item -Path "$classes\CLSID\$clsid\InprocServer32" -Force | Out-Null
Set-Item -Path "$classes\CLSID\$clsid" -Value "RecSAI SAI2 Thumbnail Provider"
Set-Item -Path "$classes\CLSID\$clsid\InprocServer32" -Value "mscoree.dll"
Set-ItemProperty -Path "$classes\CLSID\$clsid\InprocServer32" -Name "ThreadingModel" -Value "Both"
Set-ItemProperty -Path "$classes\CLSID\$clsid\InprocServer32" -Name "Class" -Value $className
Set-ItemProperty -Path "$classes\CLSID\$clsid\InprocServer32" -Name "Assembly" -Value $assembly
Set-ItemProperty -Path "$classes\CLSID\$clsid\InprocServer32" -Name "RuntimeVersion" -Value $runtimeVersion
Set-ItemProperty -Path "$classes\CLSID\$clsid\InprocServer32" -Name "CodeBase" -Value $codeBase
New-Item -Path "$classes\CLSID\$clsid\InprocServer32\$assemblyVersion" -Force | Out-Null
Set-ItemProperty -Path "$classes\CLSID\$clsid\InprocServer32\$assemblyVersion" -Name "Class" -Value $className
Set-ItemProperty -Path "$classes\CLSID\$clsid\InprocServer32\$assemblyVersion" -Name "Assembly" -Value $assembly
Set-ItemProperty -Path "$classes\CLSID\$clsid\InprocServer32\$assemblyVersion" -Name "RuntimeVersion" -Value $runtimeVersion
Set-ItemProperty -Path "$classes\CLSID\$clsid\InprocServer32\$assemblyVersion" -Name "CodeBase" -Value $codeBase
New-Item -Path "$classes\CLSID\$clsid\ProgId" -Force | Out-Null
Set-Item -Path "$classes\CLSID\$clsid\ProgId" -Value $className
New-Item -Path "$classes\CLSID\$clsid\Implemented Categories\$dotNetComCategory" -Force | Out-Null
New-Item -Path "$classes\$className\CLSID" -Force | Out-Null
Set-Item -Path "$classes\$className" -Value $className
Set-Item -Path "$classes\$className\CLSID" -Value $clsid

New-Item -Path "$classes\.sai2\shellex\$handler" -Force | Out-Null
Set-Item -Path "$classes\.sai2\shellex\$handler" -Value $clsid

New-Item -Path "$classes\.sai2" -Force | Out-Null
Set-ItemProperty -Path "$classes\.sai2" -Name "TypeOverlay" -Value "`"$fullPath`",0"
New-Item -Path "$classes\.sai2\DefaultIcon" -Force | Out-Null
Set-Item -Path "$classes\.sai2\DefaultIcon" -Value "`"$fullPath`",0"

if (-not [string]::IsNullOrWhiteSpace($progId)) {
    New-Item -Path "$classes\$progId\shellex\$handler" -Force | Out-Null
    Set-Item -Path "$classes\$progId\shellex\$handler" -Value $clsid
    New-Item -Path "$classes\$progId" -Force | Out-Null
    Set-ItemProperty -Path "$classes\$progId" -Name "TypeOverlay" -Value "`"$fullPath`",0"
    New-Item -Path "$classes\$progId\DefaultIcon" -Force | Out-Null
    Set-Item -Path "$classes\$progId\DefaultIcon" -Value "`"$fullPath`",0"
}

New-Item -Path $preferencePath -Force | Out-Null
New-Item -Path "$preferencePath\Sai2ThumbnailIconPath" -Force | Out-Null
Set-Item -Path "$preferencePath\Sai2ThumbnailIconPath" -Value $fullPath

Write-Host ".sai2 thumbnail provider registered:"
Write-Host $fullPath

if ($restartExplorerAfterChanges) {
    Restart-ExplorerForThumbnailRefresh
} else {
    Write-Host "未重启资源管理器；缩略图/图标可能需要稍后刷新后才会变化。"
}

