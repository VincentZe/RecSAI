﻿const storageKey = "readsai2-webui-state";
const statusPollMs = 250;
const hiddenStatusPollMs = 5000;
const backendErrorLogThrottleMs = 10000;
const previewReconnectMs = 1000;
const previewResizeDebounceMs = 80;
const pageScrollFadeThresholdPx = 3;
const previewTileHeaderBytes = 48;
const previewTileFlags = {
  full: 2,
  present: 4
};

const defaultState = {
  backendAvailable: true,
  connected: true,
  recordingState: "idle",
  savePath: "D:\\Rec\\ReadSAI2\\RuntimeCaptures",
  currentFile: "20260514-143226-runtime-surface.png",
  appVersion: "",
  perfLabel: "",
  processName: "sai2.exe",
  processBaseAddress: "0x00007FF6A1BE0000",
  processId: "18420",
  canvasSize: "5120 x 2880",
  canvasWidthValue: 5120,
  canvasHeightValue: 2880,
  thumbSize: "1280 x 720",
  thumbWidthValue: 1280,
  thumbHeightValue: 720,
  pointerX: 3400,
  pointerY: 1212,
  recordingCodecId: 8,
  recordingCodecMode: "lossless",
  recordingRuntimeRank: "-1",
  recordTargetLongSide: "2048",
  recordingRuntimeLevelLabels: ["L0", "L1", "L2", "L3", "L4", "L5"],
  stepInterval: "1",
  quality: "95",
  recordingPresetConfig: {
    resolution_mode: "highest",
    record_target_long_side: 2048,
    step_interval: 1,
    codec_id: 8,
    jpeg_quality: 80
  },
  recordingPresetSummary: "固定最高 / 无损 / 质量 80 / 间隔 1",
  currentPresetId: "debug-compact",
  currentPresetName: "精简调试",
  recordingPresets: [
    { id: "debug-compact", name: "精简调试", is_builtin: true, is_current: true },
    { id: "debug-lossless", name: "无损留档", is_builtin: true, is_current: false },
    { id: "debug-fast", name: "快速预览", is_builtin: true, is_current: false }
  ],
  previewMode: "fit",
  themePreset: "light",
  themeMode: "light",
  webuiLightThemePreset: "light",
  webuiDarkThemePreset: "dark",
  webuiThemeCustomPresets: [],
  webuiThemeColor: "#4f8cff",
  webuiBackgroundColor: "#f4f6fb",
  webuiMastheadBackgroundPath: "",
  webuiMastheadBackgroundUrl: "",
  webuiMastheadBackgroundScalePercent: 100,
  webuiMastheadBackgroundRotationDeg: 0,
  webuiMastheadBackgroundOffsetX: 0,
  webuiMastheadBackgroundOffsetY: 0,
  webuiMastheadBackgroundTileEnabled: false,
  alwaysOnTop: false,
  webuiAlwaysOnTop: false,
  autoLaunch: false,
  doNotMinimizeToTray: false,
  disableGlobalHotkeys: false,
  commandPalettePassthroughForwarding: true,
  searchCommands: [],
  navigatorAutoResize: false,
  updateChannel: "stable",
  customBrushOverlay: false,
  previewDeveloperMode: false,
  runtimeSurfaceFixedRefresh: false,
  runtimeSurfacePreviewFpsLimit: 0,
  previewDirtyRectVisible: true,
  previewPointerOverlayVisible: true,
  activityLogVisible: false,
  contentCollapsed: false,
  controlRailCollapsed: false,
  controlRailWidth: 292,
  activeContentPage: "dashboard",
  activeSettingsPage: "",
  settingsPageLoadReady: false,
  statusLightGroupVisible: true,
  volumeModeIndex: 0,
  frameCount: 0,
  previewTileCount: 0,
  previewTileBytes: 0,
  previewLastTileAt: 0,
  previewTileIntervalMs: 0,
  previewDirtyTiles: 0,
  previewTickGapMs: 0,
  previewTickGapAvgMs: 0,
  previewTickDurationMs: 0,
  previewTickDurationAvgMs: 0,
  previewTickBusySkips: 0,
  previewReadSendDurationMs: 0,
  previewReadSendSeq: 0,
  previewReadSendSampleAt: 0,
  previewUiFrameDurationMs: 0,
  previewUiFrameSampleAt: 0,
  recordingWriteDurationMs: 0,
  recordingWriteSeq: 0,
  recordingWriteSampleAt: 0,
  sessionStartedAt: null,
  volumeEstimateMbPerFrame: 26.8,
  volumeRecentMbPerFrame: 24.8,
  volumePreviousMbPerFrame: 23.4,
  volumeRecentCount: 100,
  volumePreviousCount: 2000,
  activityLog: []
};

const recordingPresetTagLongSideValues = [1024, 1536, 2048, 2560, 3072, 4096, 6144, 8192];
const recordingPresetTagStepIntervalValues = [1, 2, 3, 4, 5, 6, 8, 10, 12, 15];
const recordingPresetTagQualityValues = [60, 70, 75, 80, 85, 90, 95, 100];
const recordingPresetPrimaryCodecIds = new Set([8, 7]);
const recordingPresetTagCodecOptions = [
  { value: 8, label: "ZstdBGR24v2" },
  { value: 7, label: "Patch JPEG" },
  { value: 5, label: "自适应 JPEG" },
  { value: 6, label: "旧精简" },
  { value: 1, label: "旧 Zstd" },
  { value: 2, label: "Lane Zstd" },
  { value: 3, label: "BGRA 无损" }
];
const recordingPresetTagVolumeOptions = [
  { value: 0, label: "预估" },
  { value: 1, label: "最近" },
  { value: 2, label: "上次" }
];
const themePresetUtils = window.ReadSAI2ThemePresets;
const webUiThemePresetOptions = themePresetUtils.presets;
const webUiThemePresets = themePresetUtils.presetMap;

const els = {
  appShell: document.querySelector(".app-shell"),
  pageScrollRoot: document.getElementById("pageScrollRoot"),
  controlRail: document.getElementById("controlRail"),
  controlRailResizeHandle: document.getElementById("controlRailResizeHandle"),
  contentPageTrack: document.getElementById("contentPageTrack"),
  masthead: document.querySelector(".masthead"),
  perfLabelText: document.getElementById("perfLabelText"),
  connectionBadge: document.getElementById("connectionBadge"),
  statusSubtext: document.getElementById("statusSubtext"),
  topRecordButton: document.getElementById("topRecordButton"),
  contentCollapseButton: document.getElementById("contentCollapseButton"),
  controlRailCollapseButton: document.getElementById("controlRailCollapseButton"),
  controlRailExpandButton: document.getElementById("controlRailExpandButton"),
  contentPageSwitchButton: document.getElementById("contentPageSwitchButton"),
  dashboardPage: document.getElementById("dashboardPage"),
  settingsPage: document.getElementById("settingsPage"),
  settingsPageHeading: document.getElementById("settingsPageHeading"),
  settingsPageKicker: document.getElementById("settingsPageKicker"),
  settingsPageTitle: document.getElementById("settingsPageTitle"),
  settingsPageReturnButton: document.getElementById("settingsPageReturnButton"),
  settingsPageBody: document.getElementById("settingsPageBody"),
  settingsPageEmpty: document.getElementById("settingsPageEmpty"),
  settingsPageInline: document.getElementById("settingsPageInline"),
  settingsPageFrame: document.getElementById("settingsPageFrame"),
  overlayRecordButton: document.getElementById("overlayRecordButton"),
  hostBackdropButton: document.getElementById("hostBackdropButton"),
  closeWindowButton: document.getElementById("closeWindowButton"),
  minimizeWindowButton: document.getElementById("minimizeWindowButton"),
  themeSwitcher: document.getElementById("themeSwitcher"),
  themeToggleButton: document.getElementById("themeToggleButton"),
  themeAutoButton: document.getElementById("themeAutoButton"),
  savePathInput: document.getElementById("savePathInput"),
  currentFileLabel: document.getElementById("currentFileLabel"),
  openedFileNameLabel: document.getElementById("openedFileNameLabel"),
  recordSummaryLabel: document.getElementById("recordSummaryLabel"),
  processNameLabel: document.getElementById("processNameLabel"),
  processBaseAddressLabel: document.getElementById("processBaseAddressLabel"),
  processIdLabel: document.getElementById("processIdLabel"),
  canvasSizeLabel: document.getElementById("canvasSizeLabel"),
  pointerLabel: document.getElementById("pointerLabel"),
  recordingStateLabel: document.getElementById("recordingStateLabel"),
  statusLamp: document.getElementById("statusLamp"),
  statusConnectLamp: document.getElementById("statusConnectLamp"),
  statusCliLamp: document.getElementById("statusCliLamp"),
  statusUiLamp: document.getElementById("statusUiLamp"),
  statusRecordLamp: document.getElementById("statusRecordLamp"),
  recordingPresetSelect: document.getElementById("recordingPresetSelect"),
  webuiAlwaysOnTopToggle: document.getElementById("webuiAlwaysOnTopToggle"),
  autoLaunchToggle: document.getElementById("autoLaunchToggle"),
  doNotMinimizeToTrayToggle: document.getElementById("doNotMinimizeToTrayToggle"),
  navigatorResizeToggle: document.getElementById("navigatorResizeToggle"),
  updateChannelSelect: document.getElementById("updateChannelSelect"),
  customBrushOverlayToggle: document.getElementById("customBrushOverlayToggle"),
  previewDeveloperModeToggle: document.getElementById("previewDeveloperModeToggle"),
  runtimeSurfaceFixedRefreshToggle: document.getElementById("runtimeSurfaceFixedRefreshToggle"),
  previewDirtyRectToggle: document.getElementById("previewDirtyRectToggle"),
  previewPointerOverlayToggle: document.getElementById("previewPointerOverlayToggle"),
  activityLogToggle: document.getElementById("activityLogToggle"),
  statusLightGroupToggle: document.getElementById("statusLightGroupToggle"),
  advancedCard: document.getElementById("advancedCard"),
  activityCard: document.getElementById("activityCard"),
  activityLog: document.getElementById("activityLog"),
  clearLogButton: document.getElementById("clearLogButton"),
  browsePathButton: document.getElementById("browsePathButton"),
  openFolderButton: document.getElementById("openFolderButton"),
  launchSaiButton: document.getElementById("launchSaiButton"),
  quickExportShell: document.getElementById("quickExportShell"),
  quickExportButton: document.getElementById("quickExportButton"),
  quickExportCancelButton: document.getElementById("quickExportCancelButton"),
  quickExportCancelConfirmButton: document.getElementById("quickExportCancelConfirmButton"),
  quickExportCancelDismissButton: document.getElementById("quickExportCancelDismissButton"),
  toggleSettingsButton: document.getElementById("toggleSettingsButton"),
  checkUpdateButton: document.getElementById("checkUpdateButton"),
  volumeModeButton: document.getElementById("volumeModeButton"),
  windowResizeBottomLeftButton: document.getElementById("windowResizeBottomLeftButton"),
  windowResizeBottomRightButton: document.getElementById("windowResizeBottomRightButton"),
  commandLauncherButton: document.getElementById("commandLauncherButton"),
  previewCard: document.querySelector(".preview-card"),
  previewFrame: document.getElementById("previewFrame"),
  previewSavePathWarning: document.getElementById("previewSavePathWarning"),
  previewScroll: document.getElementById("previewScroll"),
  previewStatusGrid: document.getElementById("previewStatusGrid"),
  previewSurface: document.getElementById("previewSurface"),
  previewCustomBrushLayer: document.getElementById("previewCustomBrushLayer"),
  previewCustomBrushImage: document.getElementById("previewCustomBrushImage"),
  displayCanvas: document.getElementById("displayCanvas"),
  overlayCanvas: document.getElementById("overlayCanvas")
};

const runtime = {
  provider: null,
  mockTimer: 0,
  statusPollTimer: 0,
  statusPollProvider: null,
  previewTransportAllowed: false,
  hostBridgeAvailable: !!(window.chrome && window.chrome.webview && typeof window.chrome.webview.postMessage === "function"),
  actionInFlight: false,
  savePathWarningActive: false,
  backendErrorLoggedAt: 0
};

function shouldThrottleRuntimeForHiddenDocument() {
  return document.visibilityState === "hidden" && runtime.hostBridgeAvailable !== true;
}

const themePreferenceQuery = typeof window.matchMedia === "function"
  ? window.matchMedia("(prefers-color-scheme: dark)")
  : null;
let themePreferenceListenerBound = false;

const preview = {
  atlasCanvas: document.createElement("canvas"),
  atlasCtx: null,
  displayCtx: null,
  overlayCtx: null,
  session: null,
  cursor: {
    x: 0,
    y: 0,
    thumbWidth: 0,
    thumbHeight: 0,
    pointerX: Number.NaN,
    pointerY: Number.NaN,
    canvasWidth: 0,
    canvasHeight: 0,
    attached: true
  },
  cursorDisplay: {
    x: 0,
    y: 0,
    thumbWidth: 0,
    thumbHeight: 0,
    pointerX: Number.NaN,
    pointerY: Number.NaN,
    canvasWidth: 0,
    canvasHeight: 0,
    attached: true,
    initialized: false
  },
  cursorMotionRaf: 0,
  cursorMotionLastAt: 0,
  cursorMotionVelocityX: 0,
  cursorMotionVelocityY: 0,
  cursorMotionTargetVelocityX: 0,
  cursorMotionTargetVelocityY: 0,
  cursorMotionTargetLastAt: 0,
  customBrush: {
    activeBrushId: "default",
    brushes: [],
    signature: ""
  },
  dirtyRect: {
    valid: false,
    x: 0,
    y: 0,
    width: 0,
    height: 0,
    limited: false
  },
  dirtyRectDisplay: {
    valid: false,
    x: 0,
    y: 0,
    width: 0,
    height: 0,
    limited: false,
    initialized: false,
    animationStartedAt: 0
  },
  dirtyRectMotionRaf: 0,
  socket: null,
  reconnectTimer: 0,
  resizeSendTimer: 0,
  resizeObserver: null,
  renderQueued: false,
  overlayQueued: false,
  openSent: false,
  lastSentMaxDim: 0,
  lastSentMode: "",
  pendingTileCount: 0,
  pendingTileBytes: 0,
  statusLightRaf: 0,
  statusReveal: 0,
  disposed: true,
  error: null,
  layout: null,
  dots: [],
  lastLogAt: 0
};

const embeddedSettingsPages = {
  blank: {
    title: "预留设置页",
    kicker: "设置",
    url: ""
  },
  recordingPresets: {
    title: "录制预设",
    kicker: "录制规格预设",
    url: "./recording-presets.html?embedded=1"
  },
  customBrush: {
    title: "自定义画笔",
    kicker: "指针画笔",
    url: "./custom-brush.html?embedded=1"
  },
  appSettings: {
    title: "Recsai设置",
    kicker: "偏好设置",
    url: "./app-settings.html?embedded=1"
  },
  updateCenter: {
    title: "更新中心",
    kicker: "更新",
    url: "./update-center.html?embedded=1",
    immersive: true
  },
  helpSupport: {
    title: "帮助与支持",
    kicker: "支持",
    url: "./help-support.html?embedded=1",
    inlineModule: "helpSupport",
    immersive: true
  }
};

preview.atlasCtx = preview.atlasCanvas.getContext("2d");
preview.displayCtx = els.displayCanvas.getContext("2d");
preview.overlayCtx = els.overlayCanvas.getContext("2d");

const customSelects = new Map();
const state = loadState();
let mastheadBackgroundMetricsUrl = "";
let mastheadBackgroundMetricsLayoutKey = "";
let mastheadBackgroundMetrics = null;
let mastheadBackgroundResizeRaf = 0;
let mastheadBackgroundResizeObserver = null;
document.documentElement.dataset.theme = getEffectiveThemeMode(state.themeMode);
document.documentElement.dataset.themeMode = normalizeThemeMode(state.themeMode);
document.documentElement.dataset.themePreset = state.themePreset;
applyWebUiThemeColors();
bindWebUiMastheadBackgroundMetricsResize();
let customSelectIdSeed = 0;
let customSelectDismissBound = false;
let pageScrollFadeRaf = 0;
let pageScrollFadeObserver = null;
let dashboardHostSizeSyncRafs = [];
let dashboardHostSizeSyncTimers = [];
let dashboardHostSizeSyncToken = 0;
let dashboardHostSizeSyncKey = "";
let dashboardContentCollapsedLast = null;
let dashboardExpandedHostHeight = 0;
let dashboardContentExpandedHeight = 0;
let dashboardContentCollapseSettlesAt = 0;
let dashboardHostResizeSuppressUntil = 0;
let dashboardHostManualResizeUntil = 0;

function clearDashboardHostSizeSyncQueue() {
  dashboardHostSizeSyncRafs.forEach((rafId) => window.cancelAnimationFrame(rafId));
  dashboardHostSizeSyncTimers.forEach((timerId) => window.clearTimeout(timerId));
  dashboardHostSizeSyncRafs = [];
  dashboardHostSizeSyncTimers = [];
  dashboardHostSizeSyncToken += 1;
}

window.ReadSAI2WebUi = window.ReadSAI2WebUi || {};
window.ReadSAI2WebUi.state = state;
window.ReadSAI2WebUi.runtime = runtime;
window.ReadSAI2WebUi.preview = preview;

function cloneState(src) {
  return JSON.parse(JSON.stringify(src));
}

function normalizeSearchCommandShortcuts(commands) {
  if (!Array.isArray(commands)) {
    return [];
  }

  return commands
    .filter((command) => command && typeof command === "object")
    .map((command) => ({
      id: typeof command.id === "string" ? command.id.trim() : "",
      shortcut_text: typeof command.shortcut_text === "string" ? command.shortcut_text.trim() : ""
    }))
    .filter((command) => command.id && command.shortcut_text);
}

function setSelectHostCardOpenState(selectEl, isOpen) {
  const hostCard = selectEl.closest(".rail-card");
  if (!hostCard) {
    return;
  }

  hostCard.classList.toggle("has-open-select", isOpen);
}

function closeCustomSelect(selectEl, focusTrigger = false) {
  const meta = customSelects.get(selectEl);
  if (!meta || !meta.shell.classList.contains("is-open")) {
    return;
  }

  meta.shell.classList.remove("is-open");
  meta.trigger.setAttribute("aria-expanded", "false");
  setSelectHostCardOpenState(selectEl, false);
  if (focusTrigger) {
    meta.trigger.focus();
  }
}

function closeAllCustomSelects(exceptSelect = null) {
  customSelects.forEach((_, selectEl) => {
    if (selectEl !== exceptSelect) {
      closeCustomSelect(selectEl);
    }
  });
}

function findEnabledOptionIndex(meta, startIndex, step) {
  const total = meta.optionButtons.length;
  if (total === 0) {
    return -1;
  }

  for (let offset = 0; offset < total; offset += 1) {
    const index = (startIndex + (offset * step) + total) % total;
    const button = meta.optionButtons[index];
    if (button && !button.disabled) {
      return index;
    }
  }

  return -1;
}

function focusCustomSelectOption(selectEl, index) {
  const meta = customSelects.get(selectEl);
  if (!meta) {
    return;
  }

  const button = meta.optionButtons[index];
  if (button && !button.disabled) {
    button.focus();
    moveCustomSelectHoverBlock(meta, button);
  }
}

function getSelectedOptionIndex(selectEl) {
  const selectedIndex = selectEl.selectedIndex;
  if (selectedIndex >= 0) {
    return selectedIndex;
  }
  return selectEl.options.length > 0 ? 0 : -1;
}

function openCustomSelect(selectEl, focusIndex = -1) {
  const meta = customSelects.get(selectEl);
  if (!meta || meta.trigger.disabled) {
    return;
  }

  closeAllCustomSelects(selectEl);
  meta.shell.classList.add("is-open");
  meta.trigger.setAttribute("aria-expanded", "true");
  setSelectHostCardOpenState(selectEl, true);

  const selectedIndex = getSelectedOptionIndex(selectEl);
  const nextIndex = focusIndex >= 0
    ? focusIndex
    : findEnabledOptionIndex(meta, Math.max(0, selectedIndex), 1);
  if (nextIndex >= 0) {
    focusCustomSelectOption(selectEl, nextIndex);
  }
}

function selectCustomSelectOption(selectEl, nextValue, dispatchChange) {
  const previousValue = selectEl.value;
  selectEl.value = nextValue;
  syncCustomSelect(selectEl);
  closeCustomSelect(selectEl);

  if (dispatchChange && previousValue !== nextValue) {
    selectEl.dispatchEvent(new Event("change", { bubbles: true }));
  }
}

function moveCustomSelectHoverBlock(meta, target) {
  if (!meta || !meta.hoverBlock || !(target instanceof HTMLElement)) {
    return;
  }

  const menuRect = meta.menu.getBoundingClientRect();
  const targetRect = target.getBoundingClientRect();
  if (menuRect.width <= 0 || targetRect.width <= 0 || targetRect.height <= 0) {
    return;
  }

  const left = targetRect.left - menuRect.left;
  const top = targetRect.top - menuRect.top;
  meta.menu.classList.add("has-active-hover");
  meta.hoverBlock.style.setProperty("--select-hover-x", `${left.toFixed(1)}px`);
  meta.hoverBlock.style.setProperty("--select-hover-y", `${top.toFixed(1)}px`);
  meta.hoverBlock.style.setProperty("--select-hover-w", `${targetRect.width.toFixed(1)}px`);
  meta.hoverBlock.style.setProperty("--select-hover-h", `${targetRect.height.toFixed(1)}px`);
}

function clearCustomSelectHoverBlock(meta) {
  if (!meta || !meta.hoverBlock) {
    return;
  }

  meta.menu.classList.remove("has-active-hover");
}

function appendRecordingPresetMenuAction(selectEl) {
  const meta = customSelects.get(selectEl);
  if (!meta || selectEl !== els.recordingPresetSelect) {
    return;
  }

  const actionButton = document.createElement("button");
  actionButton.type = "button";
  actionButton.className = "select-option select-option-action recording-preset-settings-option";
  actionButton.textContent = "编辑预设";
  actionButton.dataset.hostDragIgnore = "true";
  actionButton.addEventListener("pointerenter", () => moveCustomSelectHoverBlock(meta, actionButton));
  actionButton.addEventListener("focus", () => moveCustomSelectHoverBlock(meta, actionButton));
  actionButton.addEventListener("click", () => {
    closeCustomSelect(selectEl);
    meta.trigger.focus();
    if (window.ReadSAI2WebUi && typeof window.ReadSAI2WebUi.openSettingsPage === "function") {
      window.ReadSAI2WebUi.openSettingsPage("recordingPresets");
      return;
    }
    postHostCommand("recording-preset-window", null, "Recording preset window is only available in the desktop WebView host.");
  });
  meta.menu.appendChild(actionButton);
}

function syncCustomSelect(selectEl) {
  const meta = customSelects.get(selectEl);
  if (!meta) {
    return;
  }

  const selectedIndex = getSelectedOptionIndex(selectEl);
  const selectedOption = selectedIndex >= 0 ? selectEl.options[selectedIndex] : null;
  meta.trigger.disabled = !!selectEl.disabled;
  meta.trigger.title = selectedOption ? selectedOption.textContent.trim() : "";
  meta.label.textContent = selectedOption ? selectedOption.textContent.trim() : "";

  meta.optionButtons.forEach((button, index) => {
    const isSelected = index === selectedIndex;
    button.classList.toggle("is-selected", isSelected);
    button.setAttribute("aria-selected", isSelected ? "true" : "false");
  });
}

function syncAllCustomSelects() {
  customSelects.forEach((_, selectEl) => {
    syncCustomSelect(selectEl);
  });
}

function createCustomSelectOptionButton(selectEl, option, index, menuId) {
  const optionButton = document.createElement("button");
  optionButton.type = "button";
  optionButton.className = "select-option";
  optionButton.textContent = option.textContent.trim();
  optionButton.dataset.value = option.value;
  optionButton.setAttribute("role", "option");
  optionButton.id = `${menuId}-option-${index}`;
  if (option.disabled) {
    optionButton.disabled = true;
  }
  optionButton.addEventListener("pointerenter", () => {
    if (!option.disabled) {
      const meta = customSelects.get(selectEl);
      moveCustomSelectHoverBlock(meta, optionButton);
    }
  });
  optionButton.addEventListener("focus", () => {
    if (!option.disabled) {
      const meta = customSelects.get(selectEl);
      moveCustomSelectHoverBlock(meta, optionButton);
    }
  });
  optionButton.addEventListener("click", () => {
    if (option.disabled) {
      return;
    }
    selectCustomSelectOption(selectEl, option.value, true);
    const meta = customSelects.get(selectEl);
    if (meta) {
      meta.trigger.focus();
    }
  });
  return optionButton;
}

function repopulateCustomSelectOptions(selectEl) {
  const meta = customSelects.get(selectEl);
  if (!meta) {
    return;
  }

  meta.menu.replaceChildren();
  meta.menu.appendChild(meta.hoverBlock);
  meta.optionButtons = Array.from(selectEl.options).map((option, index) => {
    const optionButton = createCustomSelectOptionButton(selectEl, option, index, meta.menu.id);
    meta.menu.appendChild(optionButton);
    return optionButton;
  });
  appendRecordingPresetMenuAction(selectEl);
  syncCustomSelect(selectEl);
}

function setSelectOptions(selectEl, options, selectedValue) {
  if (!(selectEl instanceof HTMLSelectElement) || !Array.isArray(options) || options.length === 0) {
    return;
  }

  const normalizedOptions = options.map((option) => ({
    value: String(option && option.value != null ? option.value : ""),
    label: String(option && option.label != null ? option.label : option && option.value != null ? option.value : ""),
    disabled: !!(option && option.disabled)
  }));

  const currentSignature = Array.from(selectEl.options)
    .map((option) => `${option.value}\u0001${option.textContent}\u0001${option.disabled ? 1 : 0}`)
    .join("\u0002");
  const nextSignature = normalizedOptions
    .map((option) => `${option.value}\u0001${option.label}\u0001${option.disabled ? 1 : 0}`)
    .join("\u0002");

  if (currentSignature !== nextSignature) {
    selectEl.replaceChildren();
    normalizedOptions.forEach((option) => {
      const nextOption = document.createElement("option");
      nextOption.value = option.value;
      nextOption.textContent = option.label;
      nextOption.disabled = option.disabled;
      selectEl.appendChild(nextOption);
    });
    repopulateCustomSelectOptions(selectEl);
  }

  const preferredValue = String(selectedValue);
  const hasPreferredValue = normalizedOptions.some((option) => option.value === preferredValue);
  if (hasPreferredValue) {
    selectEl.value = preferredValue;
  } else {
    const fallbackOption = normalizedOptions.find((option) => !option.disabled) ?? normalizedOptions[0];
    selectEl.value = fallbackOption ? fallbackOption.value : "";
  }
  syncCustomSelect(selectEl);
}

function normalizeRecordingCodecMode(mode, codecId = state.recordingCodecId) {
  if (mode === "lossless" || mode === "compact") {
    return mode;
  }
  return Number(codecId) === 8 || Number(codecId) === 3 ? "lossless" : "compact";
}

function isLosslessCodecMode() {
  return normalizeRecordingCodecMode(state.recordingCodecMode, state.recordingCodecId) === "lossless";
}

function getCodecIdForMode(mode) {
  const normalizedMode = normalizeRecordingCodecMode(mode, state.recordingCodecId);
  if (normalizedMode === "lossless") {
    return 8;
  }

  const currentCodecId = Number(state.recordingCodecId);
  return currentCodecId > 0 && currentCodecId !== 8 && currentCodecId !== 3 ? currentCodecId : 7;
}

function createRuntimeRankOptions() {
  const labels = Array.isArray(state.recordingRuntimeLevelLabels) && state.recordingRuntimeLevelLabels.length > 0
    ? state.recordingRuntimeLevelLabels
    : defaultState.recordingRuntimeLevelLabels;
  return [
    { value: "-1", label: "自动选择" },
    ...labels.map((_, index) => ({ value: String(index), label: `L${index}` }))
  ];
}

function clamp(value, min, max) {
  return Math.max(min, Math.min(max, value));
}

function toNumber(value, fallback) {
  const numeric = Number(value);
  return Number.isFinite(numeric) ? numeric : fallback;
}

function createRecordTargetLongSideOptions() {
  const currentValue = Math.max(256, toNumber(state.recordTargetLongSide, 2048));
  const values = Array.from(new Set([...recordingPresetTagLongSideValues, currentValue])).sort((left, right) => left - right);
  return values.map((value) => ({
    value: String(value),
    label: String(value)
  }));
}

function createRecordingPresetOptions() {
  if (!Array.isArray(state.recordingPresets) || state.recordingPresets.length <= 0) {
    return [{
      value: state.currentPresetId || "",
      label: normalizeRecordingPresetLabel(state.currentPresetName || "当前预设")
    }];
  }

  return state.recordingPresets.map((item) => ({
    value: String(item && item.id ? item.id : ""),
    label: normalizeRecordingPresetLabel(item && item.name ? item.name : "")
  }));
}

function normalizeRecordingPresetLabel(label) {
  const text = String(label || "").trim();
  return text === "高级" ? "无损" : text;
}

function bindCustomSelectDismiss() {
  if (customSelectDismissBound) {
    return;
  }

  customSelectDismissBound = true;
  document.addEventListener("pointerdown", (event) => {
    customSelects.forEach((meta, selectEl) => {
      if (!meta.shell.contains(event.target)) {
        closeCustomSelect(selectEl);
      }
    });
  });

  window.addEventListener("blur", () => {
    closeAllCustomSelects();
  });
}

function buildCustomSelect(selectEl) {
  if (!(selectEl instanceof HTMLSelectElement) || customSelects.has(selectEl)) {
    return;
  }

  const shell = document.createElement("div");
  shell.className = "select-shell";

  const trigger = document.createElement("button");
  trigger.type = "button";
  trigger.className = "select-trigger";
  trigger.dataset.hostDragIgnore = "true";
  trigger.setAttribute("aria-haspopup", "listbox");
  trigger.setAttribute("aria-expanded", "false");

  const label = document.createElement("span");
  label.className = "select-trigger-label";
  if (selectEl === els.recordingPresetSelect) {
    const inlineLabel = document.createElement("span");
    inlineLabel.className = "select-trigger-kicker";
    inlineLabel.textContent = "录制规格预设";
    trigger.appendChild(inlineLabel);
  }
  trigger.appendChild(label);

  const menu = document.createElement("div");
  menu.className = "select-menu";
  menu.setAttribute("role", "listbox");

  const hoverBlock = document.createElement("span");
  hoverBlock.className = "select-hover-block";
  hoverBlock.setAttribute("aria-hidden", "true");
  menu.appendChild(hoverBlock);

  const menuId = `custom-select-menu-${++customSelectIdSeed}`;
  menu.id = menuId;
  trigger.setAttribute("aria-controls", menuId);

  const optionButtons = Array.from(selectEl.options).map((option, index) => {
    const optionButton = createCustomSelectOptionButton(selectEl, option, index, menuId);
    menu.appendChild(optionButton);
    return optionButton;
  });

  selectEl.classList.add("select-native");
  selectEl.setAttribute("aria-hidden", "true");
  selectEl.tabIndex = -1;

  selectEl.parentNode.insertBefore(shell, selectEl);
  shell.append(selectEl, trigger, menu);

  const meta = {
    shell,
    trigger,
    menu,
    hoverBlock,
    label,
    optionButtons
  };
  customSelects.set(selectEl, meta);
  appendRecordingPresetMenuAction(selectEl);

  trigger.addEventListener("click", () => {
    if (shell.classList.contains("is-open")) {
      closeCustomSelect(selectEl);
      return;
    }
    openCustomSelect(selectEl);
  });

  trigger.addEventListener("keydown", (event) => {
    if (event.key === "ArrowDown" || event.key === "ArrowUp") {
      event.preventDefault();
      const direction = event.key === "ArrowDown" ? 1 : -1;
      const baseIndex = getSelectedOptionIndex(selectEl);
      const focusIndex = findEnabledOptionIndex(meta, Math.max(0, baseIndex), direction);
      openCustomSelect(selectEl, focusIndex);
      return;
    }

    if (event.key === "Enter" || event.key === " ") {
      event.preventDefault();
      if (shell.classList.contains("is-open")) {
        closeCustomSelect(selectEl);
      } else {
        openCustomSelect(selectEl);
      }
      return;
    }

    if (event.key === "Escape") {
      event.preventDefault();
      closeCustomSelect(selectEl);
    }
  });

  menu.addEventListener("keydown", (event) => {
    const currentIndex = meta.optionButtons.indexOf(document.activeElement);
    if (event.key === "ArrowDown" || event.key === "ArrowUp") {
      event.preventDefault();
      const direction = event.key === "ArrowDown" ? 1 : -1;
      const startIndex = currentIndex >= 0
        ? currentIndex + direction
        : getSelectedOptionIndex(selectEl);
      const nextIndex = findEnabledOptionIndex(meta, startIndex, direction);
      if (nextIndex >= 0) {
        focusCustomSelectOption(selectEl, nextIndex);
      }
      return;
    }

    if (event.key === "Home" || event.key === "End") {
      event.preventDefault();
      const nextIndex = event.key === "Home"
        ? findEnabledOptionIndex(meta, 0, 1)
        : findEnabledOptionIndex(meta, meta.optionButtons.length - 1, -1);
      if (nextIndex >= 0) {
        focusCustomSelectOption(selectEl, nextIndex);
      }
      return;
    }

    if (event.key === "Escape") {
      event.preventDefault();
      closeCustomSelect(selectEl, true);
      return;
    }

    if (event.key === "Tab") {
      closeCustomSelect(selectEl);
      return;
    }

    if ((event.key === "Enter" || event.key === " ") && document.activeElement instanceof HTMLButtonElement) {
      event.preventDefault();
      document.activeElement.click();
    }
  });

  shell.addEventListener("focusout", (event) => {
    if (!shell.contains(event.relatedTarget)) {
      closeCustomSelect(selectEl);
    }
  });
  menu.addEventListener("pointerleave", () => {
    clearCustomSelectHoverBlock(meta);
  });

  selectEl.addEventListener("change", () => {
    syncCustomSelect(selectEl);
  });

  syncCustomSelect(selectEl);
}

function initCustomSelects() {
  document.querySelectorAll("select.select-input:not(.recording-hidden-select)").forEach((selectEl) => {
    buildCustomSelect(selectEl);
  });
  bindCustomSelectDismiss();
}

function initCustomSelectsIn(root) {
  if (!root) {
    return;
  }

  root.querySelectorAll("select.select-input:not(.recording-hidden-select)").forEach((selectEl) => {
    buildCustomSelect(selectEl);
  });
  bindCustomSelectDismiss();
}

window.ReadSAI2WebUi.ui = {
  initCustomSelects: initCustomSelectsIn
};

function loadState() {
  try {
    const raw = localStorage.getItem(storageKey);
    if (!raw) {
      return cloneState(defaultState);
    }

    const stored = JSON.parse(raw);
    const parsed = { ...cloneState(defaultState), ...stored };
    parsed.previewMode = "fit";
    parsed.webuiThemeColor = normalizeWebUiThemeColor(parsed.webuiThemeColor);
    parsed.webuiBackgroundColor = normalizeWebUiBackgroundColor(parsed.webuiBackgroundColor);
    parsed.webuiMastheadBackgroundPath = normalizeWebUiMastheadBackgroundPath(parsed.webuiMastheadBackgroundPath);
    parsed.webuiMastheadBackgroundUrl = normalizeWebUiMastheadBackgroundUrl(parsed.webuiMastheadBackgroundUrl);
    parsed.webuiMastheadBackgroundScalePercent = normalizeWebUiMastheadBackgroundScalePercent(parsed.webuiMastheadBackgroundScalePercent);
    parsed.webuiMastheadBackgroundRotationDeg = normalizeWebUiMastheadBackgroundRotationDeg(parsed.webuiMastheadBackgroundRotationDeg);
    parsed.webuiMastheadBackgroundOffsetX = normalizeWebUiMastheadBackgroundOffset(parsed.webuiMastheadBackgroundOffsetX);
    parsed.webuiMastheadBackgroundOffsetY = normalizeWebUiMastheadBackgroundOffset(parsed.webuiMastheadBackgroundOffsetY);
    parsed.webuiMastheadBackgroundTileEnabled = parsed.webuiMastheadBackgroundTileEnabled === true;
    parsed.themeMode = normalizeThemeMode(parsed.themeMode);
    parsed.webuiThemeCustomPresets = normalizeWebUiThemeCustomPresets(parsed.webuiThemeCustomPresets);
    parsed.webuiLightThemePreset = normalizeWebUiThemePresetId(parsed.webuiLightThemePreset, "light");
    parsed.webuiDarkThemePreset = normalizeWebUiThemePresetId(parsed.webuiDarkThemePreset, "dark");
    applyThemePresetForMode(getEffectiveThemeMode(parsed.themeMode), parsed);
    parsed.activeContentPage = "dashboard";
    parsed.activeSettingsPage = "";
    parsed.settingsPageLoadReady = false;
    parsed.contentCollapsed = parsed.contentCollapsed === true;
    parsed.controlRailCollapsed = parsed.controlRailCollapsed === true;
    parsed.controlRailWidth = normalizeControlRailWidth(parsed.controlRailWidth);
    return parsed;
  } catch {
    return cloneState(defaultState);
  }
}

function normalizeControlRailWidth(value) {
  const numeric = Math.trunc(toNumber(value, defaultState.controlRailWidth));
  return clamp(numeric, 100, 520);
}

function normalizeThemeMode(mode) {
  if (mode === "dark" || mode === "auto") {
    return mode;
  }
  return "light";
}

function normalizeWebUiThemePresetId(id, fallback) {
  return themePresetUtils.normalizePresetId(id, fallback);
}

function normalizeWebUiThemeCustomPresets(value) {
  return themePresetUtils.normalizeCustomPresets(value);
}

function getAllWebUiThemePresets(sourceState) {
  const target = sourceState || state;
  return themePresetUtils.getAllPresets(target.webuiThemeCustomPresets);
}

function getWebUiThemePreset(id, sourceState) {
  const target = sourceState || state;
  return themePresetUtils.getPreset(id, target.webuiThemeCustomPresets);
}

function inferWebUiThemePreset(themeColor, backgroundColor, sourceState) {
  const target = sourceState || state;
  return themePresetUtils.inferPreset(themeColor, backgroundColor, target.webuiThemeCustomPresets);
}

function normalizeWebUiThemePreset(value, themeColor, backgroundColor, sourceState) {
  const target = sourceState || state;
  return themePresetUtils.normalizePreset(value, themeColor, backgroundColor, target.webuiThemeCustomPresets);
}

function normalizeWebUiThemeColor(value) {
  return themePresetUtils.normalizeThemeColor(value);
}

function normalizeWebUiBackgroundColor(value) {
  return themePresetUtils.normalizeBackgroundColor(value);
}

function normalizeWebUiMastheadBackgroundPath(value) {
  const text = String(value || "").trim().replace(/\\/g, "/");
  if (!text || text.includes("://") || text.startsWith("/") || text.includes("..")) {
    return "";
  }
  return text
    .split("/")
    .filter(Boolean)
    .join("/");
}

function normalizeWebUiMastheadBackgroundUrl(value) {
  return String(value || "").trim();
}

function normalizeWebUiMastheadBackgroundScalePercent(value) {
  return Math.trunc(clamp(toNumber(value, 100), 10, 1200));
}

function normalizeWebUiMastheadBackgroundRotationDeg(value) {
  let rotation = Math.trunc(toNumber(value, 0)) % 360;
  if (rotation < 0) {
    rotation += 360;
  }
  return rotation;
}

function normalizeWebUiMastheadBackgroundOffset(value) {
  return Math.trunc(clamp(toNumber(value, 0), -4000, 4000));
}

function normalizeHexColor(value, fallback) {
  return themePresetUtils.normalizeHexColor(value, fallback);
}

function setRootColorProperty(name, value) {
  document.documentElement.style.setProperty(name, value);
}

function clearRootColorProperties(names) {
  names.forEach((name) => {
    document.documentElement.style.removeProperty(name);
  });
}

function applyWebUiThemeColors() {
  const effectiveThemeMode = getEffectiveThemeMode(state.themeMode);
  const preset = getThemePresetForMode(effectiveThemeMode);
  const accentHex = normalizeWebUiThemeColor(preset.themeColor);
  const backgroundHex = normalizeWebUiBackgroundColor(preset.backgroundColor);
  const derived = themePresetUtils.deriveColorProperties({
    effectiveThemeMode,
    preset,
    themeColor: accentHex,
    backgroundColor: backgroundHex,
    defaultThemeColor: defaultState.webuiThemeColor,
    defaultBackgroundColor: defaultState.webuiBackgroundColor
  });
  clearRootColorProperties(derived.clearProperties);
  Object.entries(derived.properties).forEach(([name, value]) => {
    setRootColorProperty(name, value);
  });
  applyWebUiMastheadBackground();
}

function applyWebUiMastheadBackground() {
  const url = normalizeWebUiMastheadBackgroundUrl(state.webuiMastheadBackgroundUrl);
  const rootStyle = document.documentElement.style;
  if (!url) {
    rootStyle.removeProperty("--masthead-bg-image");
    rootStyle.removeProperty("--masthead-bg-width");
    rootStyle.removeProperty("--masthead-bg-height");
    rootStyle.removeProperty("--masthead-bg-tile-width");
    rootStyle.removeProperty("--masthead-bg-tile-height");
    rootStyle.removeProperty("--masthead-bg-tile-layer-width");
    rootStyle.removeProperty("--masthead-bg-tile-layer-height");
    rootStyle.removeProperty("--masthead-bg-scale");
    rootStyle.removeProperty("--masthead-bg-rotation");
    rootStyle.removeProperty("--masthead-bg-offset-x");
    rootStyle.removeProperty("--masthead-bg-offset-y");
    document.documentElement.dataset.mastheadBackground = "none";
    document.documentElement.dataset.mastheadBackgroundTile = "false";
    mastheadBackgroundMetricsUrl = "";
    mastheadBackgroundMetricsLayoutKey = "";
    mastheadBackgroundMetrics = null;
    return;
  }

  const scale = normalizeWebUiMastheadBackgroundScalePercent(state.webuiMastheadBackgroundScalePercent) / 100;
  const rotation = normalizeWebUiMastheadBackgroundRotationDeg(state.webuiMastheadBackgroundRotationDeg);
  const offsetX = normalizeWebUiMastheadBackgroundOffset(state.webuiMastheadBackgroundOffsetX);
  const offsetY = normalizeWebUiMastheadBackgroundOffset(state.webuiMastheadBackgroundOffsetY);
  const tileEnabled = state.webuiMastheadBackgroundTileEnabled === true;
  const metrics = getMastheadBackgroundMetrics(url, scale, rotation);
  rootStyle.setProperty("--masthead-bg-image", `url("${url.replace(/"/g, "%22")}")`);
  if (metrics) {
    rootStyle.setProperty("--masthead-bg-width", `${metrics.width}px`);
    rootStyle.setProperty("--masthead-bg-height", `${metrics.height}px`);
    rootStyle.setProperty("--masthead-bg-tile-width", `${metrics.tileWidth}px`);
    rootStyle.setProperty("--masthead-bg-tile-height", `${metrics.tileHeight}px`);
    rootStyle.setProperty("--masthead-bg-tile-layer-width", `${metrics.tileLayerWidth}px`);
    rootStyle.setProperty("--masthead-bg-tile-layer-height", `${metrics.tileLayerHeight}px`);
  } else {
    rootStyle.removeProperty("--masthead-bg-width");
    rootStyle.removeProperty("--masthead-bg-height");
    rootStyle.removeProperty("--masthead-bg-tile-width");
    rootStyle.removeProperty("--masthead-bg-tile-height");
    rootStyle.removeProperty("--masthead-bg-tile-layer-width");
    rootStyle.removeProperty("--masthead-bg-tile-layer-height");
  }
  rootStyle.setProperty("--masthead-bg-scale", String(scale));
  rootStyle.setProperty("--masthead-bg-rotation", `${rotation}deg`);
  rootStyle.setProperty("--masthead-bg-offset-x", `${offsetX}px`);
  rootStyle.setProperty("--masthead-bg-offset-y", `${offsetY}px`);
  document.documentElement.dataset.mastheadBackground = "custom";
  document.documentElement.dataset.mastheadBackgroundTile = tileEnabled ? "true" : "false";
}

function getMastheadBackgroundMetrics(url, scale, rotationDeg) {
  if (!url) {
    mastheadBackgroundMetricsUrl = "";
    mastheadBackgroundMetricsLayoutKey = "";
    mastheadBackgroundMetrics = null;
    return null;
  }

  const mastheadRect = els.masthead
    ? els.masthead.getBoundingClientRect()
    : { width: 1, height: 1 };
  const targetWidth = Math.max(1, mastheadRect.width || 1);
  const targetHeight = Math.max(1, mastheadRect.height || 1);
  const safeScale = Math.max(0.01, Number.isFinite(scale) ? scale : 1);
  const safeRotation = normalizeWebUiMastheadBackgroundRotationDeg(rotationDeg);
  const layoutKey = `${Math.round(targetWidth)}x${Math.round(targetHeight)}@${Math.round(safeScale * 1000)}@${safeRotation}`;
  if (mastheadBackgroundMetricsUrl === url && mastheadBackgroundMetricsLayoutKey === layoutKey) {
    return mastheadBackgroundMetrics;
  }

  if (mastheadBackgroundMetricsUrl === url
    && mastheadBackgroundMetrics
    && mastheadBackgroundMetrics.naturalWidth
    && mastheadBackgroundMetrics.naturalHeight) {
    mastheadBackgroundMetricsLayoutKey = layoutKey;
    mastheadBackgroundMetrics = buildMastheadBackgroundMetrics(
      mastheadBackgroundMetrics.naturalWidth,
      mastheadBackgroundMetrics.naturalHeight,
      targetWidth,
      targetHeight,
      safeScale,
      safeRotation);
    return mastheadBackgroundMetrics;
  }

  mastheadBackgroundMetricsUrl = url;
  mastheadBackgroundMetricsLayoutKey = layoutKey;
  mastheadBackgroundMetrics = null;
  const image = new Image();
  image.onload = () => {
    if (mastheadBackgroundMetricsUrl !== url || mastheadBackgroundMetricsLayoutKey !== layoutKey) {
      return;
    }
    const naturalWidth = Math.max(1, image.naturalWidth || image.width || 1);
    const naturalHeight = Math.max(1, image.naturalHeight || image.height || 1);
    mastheadBackgroundMetrics = buildMastheadBackgroundMetrics(
      naturalWidth,
      naturalHeight,
      targetWidth,
      targetHeight,
      safeScale,
      safeRotation);
    applyWebUiMastheadBackground();
  };
  image.src = url;
  return null;
}

function buildMastheadBackgroundMetrics(naturalWidth, naturalHeight, targetWidth, targetHeight, scale, rotationDeg) {
  const containScale = Math.min(targetWidth / naturalWidth, targetHeight / naturalHeight);
  const tileLayer = getRotatedBounds(targetWidth, targetHeight, rotationDeg);
  const tileScale = getAutoMastheadBackgroundTileScale(naturalWidth, naturalHeight, tileLayer.width, tileLayer.height) * scale;
  return {
    naturalWidth,
    naturalHeight,
    width: Math.max(1, Math.round(naturalWidth * containScale)),
    height: Math.max(1, Math.round(naturalHeight * containScale)),
    tileWidth: Math.max(1, Math.round(naturalWidth * tileScale)),
    tileHeight: Math.max(1, Math.round(naturalHeight * tileScale)),
    tileLayerWidth: Math.max(1, Math.ceil(tileLayer.width + Math.max(targetWidth, targetHeight) * 0.72)),
    tileLayerHeight: Math.max(1, Math.ceil(tileLayer.height + Math.max(targetWidth, targetHeight) * 0.72))
  };
}

function getRotatedBounds(width, height, rotationDeg) {
  const radians = normalizeWebUiMastheadBackgroundRotationDeg(rotationDeg) * Math.PI / 180;
  const sin = Math.abs(Math.sin(radians));
  const cos = Math.abs(Math.cos(radians));
  return {
    width: Math.max(1, width * cos + height * sin),
    height: Math.max(1, width * sin + height * cos)
  };
}

function getAutoMastheadBackgroundTileScale(naturalWidth, naturalHeight, targetWidth, targetHeight) {
  const naturalLongSide = Math.max(1, naturalWidth, naturalHeight);
  const visibleWidth = Math.max(1, targetWidth);
  const visibleHeight = Math.max(1, targetHeight);
  const columnCount = Math.trunc(clamp(visibleWidth / Math.max(visibleHeight * 1.35, 1), 3, 7));
  const widthDrivenLongSide = visibleWidth / Math.max(1, columnCount);
  const minLongSide = clamp(visibleHeight * 0.58, 48, 140);
  const maxLongSide = clamp(visibleHeight * 1.62, minLongSide, 260);
  const tileLongSide = clamp(widthDrivenLongSide, minLongSide, maxLongSide);
  return tileLongSide / naturalLongSide;
}

function queueWebUiMastheadBackgroundMetricsRefresh() {
  if (mastheadBackgroundResizeRaf) {
    return;
  }

  mastheadBackgroundResizeRaf = window.requestAnimationFrame(() => {
    mastheadBackgroundResizeRaf = 0;
    mastheadBackgroundMetricsLayoutKey = "";
    applyWebUiMastheadBackground();
  });
}

function bindWebUiMastheadBackgroundMetricsResize() {
  if (typeof ResizeObserver === "function" && els.masthead) {
    mastheadBackgroundResizeObserver = new ResizeObserver(queueWebUiMastheadBackgroundMetricsRefresh);
    mastheadBackgroundResizeObserver.observe(els.masthead);
    return;
  }

  window.addEventListener("resize", queueWebUiMastheadBackgroundMetricsRefresh);
}

function getThemePresetForMode(mode, sourceState) {
  const target = sourceState || state;
  return themePresetUtils.getPresetForMode(mode, target);
}

function applyThemePresetForMode(mode, targetState) {
  const target = targetState || state;
  return themePresetUtils.applyPresetForMode(mode, target);
}

function getEffectiveThemeMode(mode) {
  const normalized = normalizeThemeMode(mode);
  if (normalized !== "auto") {
    return normalized;
  }
  return themePreferenceQuery && themePreferenceQuery.matches ? "dark" : "light";
}

function getAlternateThemeMode(mode) {
  return getEffectiveThemeMode(mode) === "dark" ? "light" : "dark";
}

function applyThemePresetState(presetId) {
  const preset = getWebUiThemePreset(presetId);
  const nextThemeColor = normalizeWebUiThemeColor(preset.themeColor);
  const nextBackgroundColor = normalizeWebUiBackgroundColor(preset.backgroundColor);
  const changed = state.themePreset !== preset.id
    || normalizeWebUiThemeColor(state.webuiThemeColor) !== nextThemeColor
    || normalizeWebUiBackgroundColor(state.webuiBackgroundColor) !== nextBackgroundColor;

  state.themePreset = preset.id;
  state.webuiThemeColor = nextThemeColor;
  state.webuiBackgroundColor = nextBackgroundColor;
  return changed;
}

function bindThemePreferenceChange() {
  if (themePreferenceListenerBound || !themePreferenceQuery) {
    return;
  }

  themePreferenceListenerBound = true;
  const handleThemePreferenceChange = () => {
    if (state.themeMode !== "auto") {
      return;
    }
    render();
    drawPreview();
  };

  if (typeof themePreferenceQuery.addEventListener === "function") {
    themePreferenceQuery.addEventListener("change", handleThemePreferenceChange);
    return;
  }

  if (typeof themePreferenceQuery.addListener === "function") {
    themePreferenceQuery.addListener(handleThemePreferenceChange);
  }
}

function persistState() {
  const persistent = {
    savePath: state.savePath,
    previewMode: state.previewMode,
    themePreset: state.themePreset,
    themeMode: state.themeMode,
    webuiLightThemePreset: state.webuiLightThemePreset,
    webuiDarkThemePreset: state.webuiDarkThemePreset,
    webuiThemeCustomPresets: state.webuiThemeCustomPresets,
    webuiThemeColor: state.webuiThemeColor,
    webuiBackgroundColor: state.webuiBackgroundColor,
    webuiMastheadBackgroundPath: state.webuiMastheadBackgroundPath,
    webuiMastheadBackgroundUrl: state.webuiMastheadBackgroundUrl,
    webuiMastheadBackgroundScalePercent: state.webuiMastheadBackgroundScalePercent,
    webuiMastheadBackgroundRotationDeg: state.webuiMastheadBackgroundRotationDeg,
    webuiMastheadBackgroundOffsetX: state.webuiMastheadBackgroundOffsetX,
    webuiMastheadBackgroundOffsetY: state.webuiMastheadBackgroundOffsetY,
    webuiMastheadBackgroundTileEnabled: state.webuiMastheadBackgroundTileEnabled,
    alwaysOnTop: state.alwaysOnTop,
    webuiAlwaysOnTop: state.webuiAlwaysOnTop,
    autoLaunch: state.autoLaunch,
    doNotMinimizeToTray: state.doNotMinimizeToTray,
    commandPalettePassthroughForwarding: state.commandPalettePassthroughForwarding,
    navigatorAutoResize: state.navigatorAutoResize,
    updateChannel: state.updateChannel,
    customBrushOverlay: state.customBrushOverlay,
    previewDeveloperMode: state.previewDeveloperMode,
    runtimeSurfaceFixedRefresh: state.runtimeSurfaceFixedRefresh,
    runtimeSurfacePreviewFpsLimit: state.runtimeSurfacePreviewFpsLimit,
    previewDirtyRectVisible: state.previewDirtyRectVisible,
    previewPointerOverlayVisible: state.previewPointerOverlayVisible,
    activityLogVisible: state.activityLogVisible,
    contentCollapsed: state.contentCollapsed,
    controlRailCollapsed: state.controlRailCollapsed,
    controlRailWidth: state.controlRailWidth,
    statusLightGroupVisible: state.statusLightGroupVisible,
    volumeModeIndex: state.volumeModeIndex
  };
  localStorage.setItem(storageKey, JSON.stringify(persistent));
}

