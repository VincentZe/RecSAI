﻿(function () {
  const hostWindowShownMessage = "host:window-shown";
  const hostDragMoveMessage = "host:drag-move";
  const hostCloseWindowMessage = "host:close-window";
  const pageScrollFadeThresholdPx = 3;
  const isEmbedded = new URLSearchParams(window.location.search).get("embedded") === "1";
  const defaultStatusText = "准备就绪";
  const webUiStorageKey = "readsai2-webui-state";
  const startupSyncDelays = [120, 420, 1000];
  const themePreferenceQuery = typeof window.matchMedia === "function"
    ? window.matchMedia("(prefers-color-scheme: dark)")
    : null;
  const autoSaveDelayMs = 220;

  const settingDefaults = {
    main_ui_mode: "webui",
    hide_sidebar: false,
    ui_scale_percent: 100,
    ui_font_percent: 100,
    auto_launch_sai: false,
    do_not_minimize_to_tray: false,
    command_palette_passthrough_forwarding: true,
    webui_theme_preset: "light",
    webui_light_theme_preset: "light",
    webui_dark_theme_preset: "dark",
    webui_theme_custom_presets: [],
    webui_theme_color: "#4f8cff",
    webui_background_color: "#f4f6fb",
    webui_masthead_background_path: "",
    webui_masthead_background_url: "",
    webui_masthead_background_scale_percent: 100,
    webui_masthead_background_rotation_deg: 0,
    webui_masthead_background_offset_x: 0,
    webui_masthead_background_offset_y: 0,
    webui_masthead_background_tile_enabled: false,
    status_light_group_visible: true,
    auto_resize_navigator: true,
    disable_physics_drag: true,
    disable_global_hotkeys: false,
    disable_toasts: false,
    custom_brush_overlay_visible: false,
    preview_developer_mode: false,
    runtime_surface_fixed_refresh: false,
    runtime_surface_preview_fps_limit: 0,
    export_video_encoder: "builtin",
    ffmpeg_path: "",
    ffmpeg_available: false,
    ffmpeg_candidates: [],
    recsai_video_encoder_path: "",
    recsai_video_encoder_available: false,
    recsai_video_encoder_candidates: [],
    detail_diagnostics: false,
    runtime_preview_diagnostics: false,
    perf_log_mode: "Off",
    perf_log_mode_value: 0,
    runtime_surface_perf_log_enabled: false,
    preview_perf_log_enabled: false,
    sai2_thumbnail_provider_registered: false,
    recsai_thumbnail_provider_registered: false,
    recsai_association_registered: false
  };
  const themePresetUtils = window.ReadSAI2ThemePresets;
  const webUiThemePresetOptions = themePresetUtils.presets;
  const webUiThemePresets = themePresetUtils.presetMap;
  const themePresetSettingKeys = {
    customPresets: "webui_theme_custom_presets",
    lightPreset: "webui_light_theme_preset",
    darkPreset: "webui_dark_theme_preset",
    currentPreset: "webui_theme_preset",
    themeColor: "webui_theme_color",
    backgroundColor: "webui_background_color"
  };

  const state = {
    settings: { ...settingDefaults },
    editingThemePresetId: "light",
    startupMainUiMode: "",
    mainUiModeOptions: [
      { value: "webui", label: "WebUI", description: "启动时只显示 WebUI 主窗口" },
      { value: "winform", label: "WinForm", description: "启动时显示桌面主窗口" }
    ],
    perfLogModeOptions: [
      { value: "Off", numeric_value: 0, label: "关闭" },
      { value: "ErrorsOnly", numeric_value: 1, label: "仅错误" },
      { value: "Timing", numeric_value: 2, label: "时序" },
      { value: "Verbose", numeric_value: 3, label: "详细" }
    ],
    exportVideoEncoderOptions: [
      { value: "builtin", label: "内置编码器", description: "默认使用 recsai-video-encoder.exe" },
      { value: "ffmpeg", label: "ffmpeg", description: "兼容性最好，使用 RecSAI 提供的 ffmpeg.exe" }
    ],
    pendingSave: false,
    saving: false,
    saveAgain: false,
    statusText: defaultStatusText,
    statusIsError: false,
    startupSyncTimerIds: []
  };

  const els = {
    appSettingsApp: document.getElementById("appSettingsApp"),
    appSettingsHeader: document.getElementById("appSettingsHeader"),
    pageScrollRoot: document.getElementById("pageScrollRoot"),
    closeWindowButton: document.getElementById("closeWindowButton"),
    refreshSettingsButton: document.getElementById("refreshSettingsButton"),
    statusText: document.getElementById("statusText"),
    mainUiModeOptions: document.getElementById("mainUiModeOptions"),
    webUiThemePresetOptions: document.getElementById("webUiThemePresetOptions"),
    addWebUiThemePresetButton: document.getElementById("addWebUiThemePresetButton"),
    mastheadBackgroundFileInput: document.getElementById("mastheadBackgroundFileInput"),
    chooseMastheadBackgroundButton: document.getElementById("chooseMastheadBackgroundButton"),
    clearMastheadBackgroundButton: document.getElementById("clearMastheadBackgroundButton"),
    resetMastheadBackgroundTransformButton: document.getElementById("resetMastheadBackgroundTransformButton"),
    mastheadBackgroundPreview: document.getElementById("mastheadBackgroundPreview"),
    mastheadBackgroundPreviewImage: document.getElementById("mastheadBackgroundPreviewImage"),
    mastheadBackgroundStatus: document.getElementById("mastheadBackgroundStatus"),
    perfLogModeSelect: document.getElementById("perfLogModeSelect"),
    exportVideoEncoderSelect: document.getElementById("exportVideoEncoderSelect"),
    exportVideoEncoderDetail: document.getElementById("exportVideoEncoderDetail"),
    ffmpegStatusBadge: document.getElementById("ffmpegStatusBadge"),
    ffmpegPathText: document.getElementById("ffmpegPathText"),
    downloadFfmpegButton: document.getElementById("downloadFfmpegButton"),
    maintenanceButtons: Array.from(document.querySelectorAll("[data-maintenance-action]"))
  };

  let statusTimerId = 0;
  let autoSaveTimerId = 0;
  let pageScrollFadeRaf = 0;
  let themePreferenceListenerBound = false;
  let themePresetColorControls = [];
  let pendingDeleteThemePresetId = "";
  let mastheadBackgroundInteraction = null;
  let mastheadBackgroundPreviewMetricsUrl = "";
  let mastheadBackgroundPreviewMetricsLayoutKey = "";
  let mastheadBackgroundPreviewMetrics = null;
  let mastheadBackgroundPreviewResizeRaf = 0;
  let mastheadBackgroundPreviewResizeObserver = null;
  let suppressNextStateSyncedStatus = false;

  function normalizeThemeMode(mode) {
    if (mode === "dark" || mode === "auto") {
      return mode;
    }
    return "light";
  }

  function getSystemThemeMode() {
    return themePreferenceQuery && themePreferenceQuery.matches ? "dark" : "light";
  }

  function getStoredThemeMode() {
    try {
      const raw = window.localStorage ? window.localStorage.getItem(webUiStorageKey) : null;
      if (!raw) {
        return "light";
      }

      const parsed = JSON.parse(raw);
      return normalizeThemeMode(parsed && parsed.themeMode);
    } catch {
      return "light";
    }
  }

  function getParentThemeMode() {
    if (!isEmbedded || !window.parent || window.parent === window) {
      return "";
    }

    try {
      const parentTheme = window.parent.document && window.parent.document.documentElement
        ? window.parent.document.documentElement.dataset.themeMode || window.parent.document.documentElement.dataset.theme
        : "";
      return parentTheme ? normalizeThemeMode(parentTheme) : "";
    } catch {
      return "";
    }
  }

  function getPreferredThemeMode() {
    return getParentThemeMode() || getStoredThemeMode();
  }

  function applyTheme() {
    const themeMode = getPreferredThemeMode();
    const effectiveThemeMode = themeMode === "auto" ? getSystemThemeMode() : normalizeThemeMode(themeMode);
    const preset = getThemePresetForMode(effectiveThemeMode);
    state.settings.webui_theme_preset = preset.id;
    state.settings.webui_theme_color = normalizeHexColor(preset.themeColor);
    state.settings.webui_background_color = normalizeHexColor(preset.backgroundColor, settingDefaults.webui_background_color);
    document.documentElement.dataset.theme = effectiveThemeMode;
    document.documentElement.dataset.themeMode = themeMode;
    document.documentElement.dataset.themePreset = preset.id;
    applyWebUiThemeColors();
  }

  function bindThemePreferenceChange() {
    if (themePreferenceListenerBound || !themePreferenceQuery) {
      return;
    }

    themePreferenceListenerBound = true;
    const handleThemePreferenceChange = () => {
      if (getPreferredThemeMode() === "auto") {
        applyTheme();
      }
    };

    if (typeof themePreferenceQuery.addEventListener === "function") {
      themePreferenceQuery.addEventListener("change", handleThemePreferenceChange);
      return;
    }

    if (typeof themePreferenceQuery.addListener === "function") {
      themePreferenceQuery.addListener(handleThemePreferenceChange);
    }
  }

  function bindThemeStorageChange() {
    window.addEventListener("storage", (event) => {
      if (event.key === webUiStorageKey) {
        applyTheme();
      }
    });
  }

  function getEmbeddedTargetOrigin() {
    return window.location.protocol === "file:" ? "*" : window.location.origin;
  }

  function hasEmbeddedParentHostBridge() {
    if (!isEmbedded || !window.parent || window.parent === window) {
      return false;
    }

    try {
      const parentHost = window.parent.ReadSAI2WebUi && window.parent.ReadSAI2WebUi.host;
      return !!(parentHost && typeof parentHost.hasBridge === "function" && parentHost.hasBridge());
    } catch {
      return false;
    }
  }

  function getHostBridge() {
    if (hasEmbeddedParentHostBridge()) {
      return {
        postMessage(message) {
          window.parent.postMessage({
            kind: "readsai2-embedded-host-message",
            message
          }, getEmbeddedTargetOrigin());
        }
      };
    }

    const bridge = window.chrome && window.chrome.webview;
    if (!bridge || typeof bridge.postMessage !== "function") {
      return null;
    }
    return bridge;
  }

  function hasHostBridge() {
    return !!getHostBridge();
  }

  function postHostMessage(message) {
    const bridge = getHostBridge();
    if (!bridge) {
      return false;
    }
    bridge.postMessage(message);
    return true;
  }

  function buildHostDragMoveMessage(event) {
    return JSON.stringify({
      kind: hostDragMoveMessage,
      screenX: event.screenX,
      screenY: event.screenY,
      clientX: event.clientX,
      clientY: event.clientY
    });
  }

  function postHostCommand(command, payload) {
    if (hasEmbeddedParentHostBridge()) {
      window.parent.postMessage({
        kind: "readsai2-embedded-host-command",
        command,
        payload: payload && typeof payload === "object" ? payload : {}
      }, getEmbeddedTargetOrigin());
      return true;
    }

    const bridge = getHostBridge();
    if (!bridge) {
      return false;
    }
    bridge.postMessage(JSON.stringify({
      kind: "webui-command",
      command,
      payload: payload && typeof payload === "object" ? payload : {}
    }));
    return true;
  }

  function returnEmbeddedPageToDashboard() {
    if (!isEmbedded || !window.parent || window.parent === window) {
      return false;
    }

    window.parent.postMessage({
      kind: "readsai2-embedded-return-dashboard"
    }, getEmbeddedTargetOrigin());
    return true;
  }

  function bindEmbeddedContextReturn() {
    if (!isEmbedded) {
      return;
    }

    let rightPointerStart = null;
    const isReturnBlockedTarget = (target) => target instanceof Element
      && !!target.closest("button, input, select, textarea, a, label, summary, [role='button'], [data-host-drag-ignore='true']");

    window.addEventListener("pointerdown", (event) => {
      if (event.button !== 2) {
        rightPointerStart = null;
        return;
      }

      rightPointerStart = {
        time: performance.now(),
        blocked: isReturnBlockedTarget(event.target)
      };
    }, { capture: true });

    window.addEventListener("contextmenu", (event) => {
      const pointerStart = rightPointerStart;
      rightPointerStart = null;
      if (event.defaultPrevented) {
        return;
      }

      event.preventDefault();
      const hasFreshPointerStart = pointerStart && performance.now() - pointerStart.time < 2500;
      const shouldBlockReturn = hasFreshPointerStart
        ? pointerStart.blocked
        : isReturnBlockedTarget(event.target);
      if (shouldBlockReturn) {
        return;
      }

      returnEmbeddedPageToDashboard();
    });
  }

  function buildSettingIcon(name) {
    const pathMap = {
      reset: '<path d="M3 12a9 9 0 1 0 3-6.7"></path><path d="M3 4v5h5"></path>',
      sun: '<circle cx="12" cy="12" r="4"></circle><path d="M12 2v2"></path><path d="M12 20v2"></path><path d="m4.93 4.93 1.41 1.41"></path><path d="m17.66 17.66 1.41 1.41"></path><path d="M2 12h2"></path><path d="M20 12h2"></path><path d="m6.34 17.66-1.41 1.41"></path><path d="m19.07 4.93-1.41 1.41"></path>',
      moon: '<path d="M20.99 13.27A9 9 0 1 1 10.73 3.01 7 7 0 0 0 20.99 13.27z"></path>',
      x: '<path d="M18 6 6 18"></path><path d="m6 6 12 12"></path>',
      check: '<path d="M20 6 9 17l-5-5"></path>'
    };
    return `<svg class="setting-theme-action-icon" viewBox="0 0 24 24" aria-hidden="true" focusable="false">${pathMap[name] || pathMap.x}</svg>`;
  }

  function setButtonIconText(button, iconName, text) {
    button.innerHTML = `${buildSettingIcon(iconName)}<span>${text}</span>`;
  }

  function clamp(value, min, max) {
    return Math.max(min, Math.min(max, value));
  }

  function toNumber(value, fallback) {
    const numeric = Number(value);
    return Number.isFinite(numeric) ? numeric : fallback;
  }

  function normalizePercent(value) {
    return Math.trunc(clamp(toNumber(value, 100), 40, 200));
  }

  function normalizeRuntimePreviewFpsLimit(value) {
    const numeric = toNumber(value, 0);
    if (numeric < 0) {
      return 0;
    }
    return Math.trunc(clamp(numeric, 0, 240));
  }

  function normalizePerfLogMode(value, numericValue) {
    const text = String(value || "").trim();
    const textMatch = state.perfLogModeOptions.find((item) => item.value.toLowerCase() === text.toLowerCase());
    if (textMatch) {
      return textMatch.value;
    }

    const numeric = Math.trunc(toNumber(numericValue, 0));
    const numericMatch = state.perfLogModeOptions.find((item) => Number(item.numeric_value) === numeric);
    return numericMatch ? numericMatch.value : "Off";
  }

  function normalizeMainUiMode(value) {
    return String(value || "").trim().toLowerCase() === "winform" ? "winform" : "webui";
  }

  function normalizeExportVideoEncoder(value) {
    const text = String(value || "").trim().toLowerCase();
    if (!text) {
      return "builtin";
    }
    return text === "builtin" || text === "recsai" || text === "internal" ? "builtin" : "ffmpeg";
  }

  function normalizePathCandidates(value) {
    if (!Array.isArray(value)) {
      return [];
    }

    return value
      .map((item) => {
        if (typeof item === "string") {
          return {
            path: item.trim(),
            exists: false
          };
        }

        const path = String(item && item.path ? item.path : "").trim();
        return {
          path,
          exists: item && item.exists === true
        };
      })
      .filter((item) => item.path);
  }

  function normalizeMastheadBackgroundPath(value) {
    const text = String(value || "").trim().replace(/\\/g, "/");
    if (!text || text.includes("://") || text.startsWith("/") || text.includes("..")) {
      return "";
    }
    return text
      .split("/")
      .filter(Boolean)
      .join("/");
  }

  function normalizeMastheadBackgroundUrl(value) {
    return String(value || "").trim();
  }

  function normalizeMastheadBackgroundScalePercent(value) {
    return Math.trunc(clamp(toNumber(value, 100), 10, 1200));
  }

  function normalizeMastheadBackgroundRotationDeg(value) {
    let rotation = Math.trunc(toNumber(value, 0)) % 360;
    if (rotation < 0) {
      rotation += 360;
    }
    return rotation;
  }

  function normalizeMastheadBackgroundOffset(value) {
    return Math.trunc(clamp(toNumber(value, 0), -4000, 4000));
  }

  function normalizeWebUiThemePresetId(id, fallback) {
    return themePresetUtils.normalizePresetId(id, fallback);
  }

  function normalizeWebUiThemeCustomPresets(value) {
    return themePresetUtils.normalizeCustomPresets(value);
  }

  function getAllWebUiThemePresets(settings) {
    const source = settings && typeof settings === "object" ? settings : state.settings;
    return themePresetUtils.getAllPresets(source.webui_theme_custom_presets);
  }

  function normalizeWebUiThemePreset(value, themeColor, backgroundColor, settings) {
    const source = settings && typeof settings === "object" ? settings : state.settings;
    return themePresetUtils.normalizePreset(value, themeColor, backgroundColor, source.webui_theme_custom_presets);
  }

  function inferWebUiThemePreset(themeColor, backgroundColor, settings) {
    const source = settings && typeof settings === "object" ? settings : state.settings;
    return themePresetUtils.inferPreset(themeColor, backgroundColor, source.webui_theme_custom_presets);
  }

  function getWebUiThemePreset(id, settings) {
    const source = settings && typeof settings === "object" ? settings : state.settings;
    return themePresetUtils.getPreset(id, source.webui_theme_custom_presets);
  }

  function syncThemePresetColors(settings) {
    const target = settings && typeof settings === "object" ? settings : state.settings;
    themePresetUtils.syncPresetColors(target, themePresetSettingKeys);
  }

  function getThemePresetForMode(mode, settings) {
    const target = settings && typeof settings === "object" ? settings : state.settings;
    return themePresetUtils.getPresetForMode(mode, target, themePresetSettingKeys);
  }

  function setEditingThemePreset(presetId) {
    const preset = getWebUiThemePreset(presetId, state.settings);
    state.editingThemePresetId = preset.id;
    state.settings.webui_theme_preset = preset.id;
    state.settings.webui_theme_color = normalizeHexColor(preset.themeColor);
    state.settings.webui_background_color = normalizeHexColor(preset.backgroundColor, settingDefaults.webui_background_color);
    document.documentElement.dataset.themePreset = preset.id;
    applyWebUiThemeColors();
  }

  function setThemeSlotPreset(mode, presetId) {
    const preset = getWebUiThemePreset(presetId, state.settings);
    if (mode === "dark") {
      state.settings.webui_dark_theme_preset = preset.id;
    } else {
      state.settings.webui_light_theme_preset = preset.id;
    }
    setEditingThemePreset(preset.id);
    applyTheme();
  }

  function updateThemePresetColors(presetId, colors) {
    const preset = getWebUiThemePreset(presetId, state.settings);
    const themeColor = normalizeHexColor(colors && colors.themeColor ? colors.themeColor : preset.themeColor);
    const backgroundColor = normalizeHexColor(colors && colors.backgroundColor ? colors.backgroundColor : preset.backgroundColor, settingDefaults.webui_background_color);
    const customPresets = normalizeWebUiThemeCustomPresets(state.settings.webui_theme_custom_presets);
    const customIndex = customPresets.findIndex((item) => item.id === preset.id);
    let nextPreset = preset;
    if (customIndex >= 0) {
      customPresets[customIndex] = {
        ...customPresets[customIndex],
        themeColor,
        backgroundColor
      };
      nextPreset = customPresets[customIndex];
    } else {
      const nextId = createWebUiThemePresetId();
      nextPreset = {
        id: nextId,
        label: preset.builtIn ? `${preset.label}副本` : preset.label,
        themeColor,
        backgroundColor,
        builtIn: false
      };
      customPresets.push(nextPreset);
      if (state.settings.webui_light_theme_preset === preset.id) {
        state.settings.webui_light_theme_preset = nextId;
      }
      if (state.settings.webui_dark_theme_preset === preset.id) {
        state.settings.webui_dark_theme_preset = nextId;
      }
    }
    state.settings.webui_theme_custom_presets = normalizeWebUiThemeCustomPresets(customPresets);
    setEditingThemePreset(nextPreset.id);
    return nextPreset;
  }

  function createWebUiThemePresetId() {
    const existing = new Set(getAllWebUiThemePresets(state.settings).map((preset) => preset.id));
    let index = state.settings.webui_theme_custom_presets.length + 1;
    let id = `custom-${Date.now().toString(36)}-${index}`;
    while (existing.has(id)) {
      index += 1;
      id = `custom-${Date.now().toString(36)}-${index}`;
    }
    return id;
  }

  function addWebUiThemePreset() {
    const effectiveThemeMode = document.documentElement.dataset.theme === "dark" ? "dark" : "light";
    const basePreset = getThemePresetForMode(effectiveThemeMode);
    const customPresets = normalizeWebUiThemeCustomPresets(state.settings.webui_theme_custom_presets);
    const nextPreset = {
      id: createWebUiThemePresetId(),
      label: `自定义 ${customPresets.length + 1}`,
      themeColor: normalizeHexColor(basePreset.themeColor),
      backgroundColor: normalizeHexColor(basePreset.backgroundColor, settingDefaults.webui_background_color),
      builtIn: false
    };
    customPresets.push(nextPreset);
    state.settings.webui_theme_custom_presets = normalizeWebUiThemeCustomPresets(customPresets);
    if (effectiveThemeMode === "dark") {
      state.settings.webui_dark_theme_preset = nextPreset.id;
    } else {
      state.settings.webui_light_theme_preset = nextPreset.id;
    }
    setEditingThemePreset(nextPreset.id);
    applyTheme();
    render();
    scheduleAutoSave("主题已新增，正在自动保存…");
  }

  function requestThemePresetDelete(presetId) {
    const preset = getWebUiThemePreset(presetId, state.settings);
    if (!preset || preset.builtIn) {
      return;
    }
    pendingDeleteThemePresetId = preset.id;
    render();
  }

  function cancelThemePresetDelete(presetId) {
    if (!presetId || pendingDeleteThemePresetId === presetId) {
      pendingDeleteThemePresetId = "";
      render();
    }
  }

  function deleteThemePreset(presetId) {
    const preset = getWebUiThemePreset(presetId, state.settings);
    if (!preset || preset.builtIn) {
      pendingDeleteThemePresetId = "";
      render();
      return;
    }

    const customPresets = normalizeWebUiThemeCustomPresets(state.settings.webui_theme_custom_presets)
      .filter((item) => item.id !== preset.id);
    const fallbackLight = webUiThemePresets.light.id;
    const fallbackDark = webUiThemePresets.dark.id;
    state.settings.webui_theme_custom_presets = customPresets;
    if (state.settings.webui_light_theme_preset === preset.id) {
      state.settings.webui_light_theme_preset = fallbackLight;
    }
    if (state.settings.webui_dark_theme_preset === preset.id) {
      state.settings.webui_dark_theme_preset = fallbackDark;
    }
    if (state.editingThemePresetId === preset.id || state.settings.webui_theme_preset === preset.id) {
      const effectiveThemeMode = document.documentElement.dataset.theme === "dark" ? "dark" : "light";
      state.editingThemePresetId = effectiveThemeMode === "dark" ? state.settings.webui_dark_theme_preset : state.settings.webui_light_theme_preset;
    }
    pendingDeleteThemePresetId = "";
    applyTheme();
    render();
    scheduleAutoSave("主题已删除，正在自动保存…");
  }

  function resetBuiltInThemePreset(presetId) {
    const preset = webUiThemePresets[presetId];
    if (!preset) {
      return;
    }

    if (preset.themeMode === "dark") {
      state.settings.webui_dark_theme_preset = preset.id;
    } else {
      state.settings.webui_light_theme_preset = preset.id;
    }
    setEditingThemePreset(preset.id);
    applyTheme();
  }

  function normalizeHexColor(value, fallback) {
    return themePresetUtils.normalizeHexColor(value, fallback || settingDefaults.webui_theme_color);
  }

  function rgbToHex(rgb) {
    return themePresetUtils.rgbToHex(rgb);
  }

  function hexToRgb(hex) {
    return themePresetUtils.hexToRgb(hex, settingDefaults.webui_theme_color);
  }

  function setRootColorProperty(name, value) {
    document.documentElement.style.setProperty(name, value);
  }

  function clearRootColorProperties(names) {
    names.forEach((name) => {
      document.documentElement.style.removeProperty(name);
    });
  }

  function applyWebUiThemeColors() {
    const accentHex = normalizeHexColor(state.settings.webui_theme_color, settingDefaults.webui_theme_color);
    const backgroundHex = normalizeHexColor(state.settings.webui_background_color, settingDefaults.webui_background_color);
    const currentPreset = getWebUiThemePreset(state.settings.webui_theme_preset, state.settings);

    const effectiveThemeMode = document.documentElement.dataset.theme === "dark" ? "dark" : "light";
    const derived = themePresetUtils.deriveColorProperties({
      effectiveThemeMode,
      preset: currentPreset,
      themeColor: accentHex,
      backgroundColor: backgroundHex,
      defaultThemeColor: settingDefaults.webui_theme_color,
      defaultBackgroundColor: settingDefaults.webui_background_color
    });
    clearRootColorProperties(derived.clearProperties);
    Object.entries(derived.properties).forEach(([name, value]) => {
      setRootColorProperty(name, value);
    });
  }

  function rgbToHsl(rgb) {
    const r = clamp(rgb.r, 0, 255) / 255;
    const g = clamp(rgb.g, 0, 255) / 255;
    const b = clamp(rgb.b, 0, 255) / 255;
    const max = Math.max(r, g, b);
    const min = Math.min(r, g, b);
    let h = 0;
    let s = 0;
    const l = (max + min) / 2;

    if (max !== min) {
      const d = max - min;
      s = l > 0.5 ? d / (2 - max - min) : d / (max + min);
      if (max === r) {
        h = (g - b) / d + (g < b ? 6 : 0);
      } else if (max === g) {
        h = (b - r) / d + 2;
      } else {
        h = (r - g) / d + 4;
      }
      h *= 60;
    }

    return { h, s: s * 100, l: l * 100 };
  }

  function hueToRgb(p, q, t) {
    let nextT = t;
    if (nextT < 0) {
      nextT += 1;
    }
    if (nextT > 1) {
      nextT -= 1;
    }
    if (nextT < 1 / 6) {
      return p + (q - p) * 6 * nextT;
    }
    if (nextT < 1 / 2) {
      return q;
    }
    if (nextT < 2 / 3) {
      return p + (q - p) * (2 / 3 - nextT) * 6;
    }
    return p;
  }

  function hslToRgb(hsl) {
    const h = ((Number(hsl.h) % 360) + 360) % 360 / 360;
    const s = clamp(Number(hsl.s), 0, 100) / 100;
    const l = clamp(Number(hsl.l), 0, 100) / 100;

    if (s === 0) {
      const gray = l * 255;
      return { r: gray, g: gray, b: gray };
    }

    const q = l < 0.5 ? l * (1 + s) : l + s - l * s;
    const p = 2 * l - q;
    return {
      r: hueToRgb(p, q, h + 1 / 3) * 255,
      g: hueToRgb(p, q, h) * 255,
      b: hueToRgb(p, q, h - 1 / 3) * 255
    };
  }

  function hslToHex(hsl) {
    return rgbToHex(hslToRgb(hsl));
  }

  function normalizeColorHsl(hsl) {
    const source = hsl && typeof hsl === "object" ? hsl : {};
    return {
      h: clamp(toNumber(source.h, 0), 0, 360),
      s: clamp(toNumber(source.s, 0), 0, 100),
      l: clamp(toNumber(source.l, 50), 0, 100)
    };
  }

  function createColorPickerControl(options) {
    const refs = options && typeof options === "object" ? options : {};
    const fallbackColor = normalizeHexColor(refs.fallbackColor, settingDefaults.webui_theme_color);
    let isOpen = false;
    let hslCache = null;
    let interactionActive = false;
    let interactionChanged = false;
    let closeTimerId = 0;

    const getCurrentColor = () => normalizeHexColor(typeof refs.getColor === "function" ? refs.getColor() : "", fallbackColor);

    const getHsl = () => {
      const color = getCurrentColor();
      if (!hslCache || hslCache.color !== color) {
        const nextHsl = rgbToHsl(hexToRgb(color));
        hslCache = {
          color,
          ...normalizeColorHsl(nextHsl)
        };
      }

      return {
        h: hslCache.h,
        s: hslCache.s,
        l: hslCache.l
      };
    };

    const setHslCache = (hsl, color) => {
      hslCache = {
        color: normalizeHexColor(color, fallbackColor),
        ...normalizeColorHsl(hsl)
      };
    };

    const render = () => {
      if (!refs.control) {
        return;
      }

      const color = getCurrentColor();
      const hsl = getHsl();
      refs.control.style.setProperty("--setting-theme-hue", `${hsl.h.toFixed(2)}deg`);
      refs.control.style.setProperty("--setting-theme-color", color);
      refs.control.style.setProperty("--setting-theme-hue-position", (hsl.h / 360 * 100).toFixed(2));
      refs.control.classList.toggle("is-open", isOpen);

      if (refs.popover) {
        refs.popover.hidden = !isOpen;
      }

      if (refs.button) {
        refs.button.setAttribute("aria-expanded", isOpen ? "true" : "false");
      }

      if (refs.slCursor) {
        refs.slCursor.style.left = `${hsl.s.toFixed(2)}%`;
        refs.slCursor.style.top = `${(100 - hsl.l).toFixed(2)}%`;
      }

      [refs.triggerSwatch, refs.preview].filter(Boolean).forEach((swatch) => {
        swatch.style.backgroundColor = color;
      });

      if (refs.hexText) {
        refs.hexText.textContent = color.toUpperCase();
      }

      if (refs.slPicker) {
        refs.slPicker.setAttribute("aria-valuetext", `饱和度 ${Math.round(hsl.s)}%，亮度 ${Math.round(hsl.l)}%`);
      }

      if (refs.hueSlider) {
        refs.hueSlider.setAttribute("aria-valuenow", String(Math.round(hsl.h)));
        refs.hueSlider.setAttribute("aria-valuetext", `色相 ${Math.round(hsl.h)} 度`);
      }
    };

    const setColorFromHsl = (hsl, save) => {
      const nextHsl = normalizeColorHsl(hsl);
      const nextColor = normalizeHexColor(hslToHex(nextHsl), fallbackColor);
      const changed = getCurrentColor() !== nextColor;
      setHslCache(nextHsl, nextColor);
      if (changed && typeof refs.setColor === "function") {
        refs.setColor(nextColor);
        if (interactionActive) {
          interactionChanged = true;
        }
      }

      render();
      if (save && (changed || interactionChanged) && typeof refs.onSave === "function") {
        interactionChanged = false;
        refs.onSave(nextColor);
      }
    };

    const clearCloseTimer = () => {
      if (closeTimerId) {
        window.clearTimeout(closeTimerId);
        closeTimerId = 0;
      }
    };

    const queueCloseOnLeave = () => {
      if (!isOpen) {
        return;
      }

      clearCloseTimer();
      closeTimerId = window.setTimeout(() => {
        closeTimerId = 0;
        if (!isOpen || interactionActive || !refs.control) {
          return;
        }
        if (refs.control.matches(":hover")) {
          return;
        }
        setOpen(false, false);
      }, 140);
    };

    const updateFromSlEvent = (event, save) => {
      if (!refs.slPicker) {
        return;
      }

      const rect = refs.slPicker.getBoundingClientRect();
      if (rect.width <= 0 || rect.height <= 0) {
        return;
      }

      const hsl = getHsl();
      hsl.s = clamp((event.clientX - rect.left) / rect.width * 100, 0, 100);
      hsl.l = clamp(100 - ((event.clientY - rect.top) / rect.height * 100), 0, 100);
      setColorFromHsl(hsl, save);
    };

    const updateFromHueEvent = (event, save) => {
      if (!refs.hueSlider) {
        return;
      }

      const rect = refs.hueSlider.getBoundingClientRect();
      if (rect.width <= 0) {
        return;
      }

      const hsl = getHsl();
      hsl.h = clamp((event.clientX - rect.left) / rect.width * 360, 0, 360);
      setColorFromHsl(hsl, save);
    };

    const bindDrag = (target, update) => {
      if (!target) {
        return;
      }

      target.addEventListener("pointerdown", (event) => {
        if (event.button !== 0 || !event.isPrimary) {
          return;
        }

        event.preventDefault();
        interactionActive = true;
        interactionChanged = false;
        target.setPointerCapture(event.pointerId);
        update(event, false);
      });

      target.addEventListener("pointermove", (event) => {
        if (!interactionActive || !target.hasPointerCapture(event.pointerId)) {
          return;
        }

        event.preventDefault();
        update(event, false);
      });

      const finish = (event) => {
        if (!target.hasPointerCapture(event.pointerId)) {
          return;
        }

        event.preventDefault();
        update(event, true);
        interactionActive = false;
        target.releasePointerCapture(event.pointerId);
        if (refs.control && !refs.control.matches(":hover")) {
          queueCloseOnLeave();
        }
      };

      target.addEventListener("pointerup", finish);
      target.addEventListener("pointercancel", (event) => {
        if (target.hasPointerCapture(event.pointerId)) {
          target.releasePointerCapture(event.pointerId);
        }
        interactionActive = false;
        interactionChanged = false;
      });
    };

    const setOpen = (open, focusPicker) => {
      const nextOpen = !!open;
      if (isOpen === nextOpen) {
        return;
      }

      isOpen = nextOpen;
      if (isOpen) {
        clearCloseTimer();
      }
      render();
      if (!isOpen) {
        clearCloseTimer();
        if (typeof refs.onClose === "function") {
          refs.onClose();
        }
      }
      if (isOpen && focusPicker && refs.slPicker) {
        window.requestAnimationFrame(() => {
          if (isOpen) {
            refs.slPicker.focus({ preventScroll: true });
          }
        });
      }
    };

    const bindPopover = () => {
      if (refs.button) {
        refs.button.addEventListener("click", () => {
          setOpen(!isOpen, true);
        });
      }

      if (refs.control) {
        refs.control.addEventListener("pointerenter", clearCloseTimer);
        refs.control.addEventListener("pointerleave", queueCloseOnLeave);
      }

      document.addEventListener("pointerdown", (event) => {
        if (!isOpen || !refs.control) {
          return;
        }

        if (event.target instanceof Node && refs.control.contains(event.target)) {
          return;
        }

        setOpen(false, false);
      });
    };

    const bindKeyboard = () => {
      const applyHueStep = (delta) => {
        const hsl = getHsl();
        hsl.h = (hsl.h + delta + 360) % 360;
        setColorFromHsl(hsl, true);
      };

      const applySlStep = (axis, delta) => {
        const hsl = getHsl();
        hsl[axis] = clamp(hsl[axis] + delta, 0, 100);
        setColorFromHsl(hsl, true);
      };

      if (refs.hueSlider) {
        refs.hueSlider.addEventListener("keydown", (event) => {
          if (event.key === "ArrowLeft" || event.key === "ArrowDown") {
            event.preventDefault();
            applyHueStep(event.shiftKey ? -15 : -5);
          } else if (event.key === "ArrowRight" || event.key === "ArrowUp") {
            event.preventDefault();
            applyHueStep(event.shiftKey ? 15 : 5);
          }
        });
      }

      if (refs.slPicker) {
        refs.slPicker.addEventListener("keydown", (event) => {
          if (event.key === "ArrowLeft") {
            event.preventDefault();
            applySlStep("s", event.shiftKey ? -10 : -3);
          } else if (event.key === "ArrowRight") {
            event.preventDefault();
            applySlStep("s", event.shiftKey ? 10 : 3);
          } else if (event.key === "ArrowDown") {
            event.preventDefault();
            applySlStep("l", event.shiftKey ? -10 : -3);
          } else if (event.key === "ArrowUp") {
            event.preventDefault();
            applySlStep("l", event.shiftKey ? 10 : 3);
          }
        });
      }

      if (refs.button) {
        refs.button.addEventListener("keydown", (event) => {
          if (event.key === "ArrowDown" || event.key === "Enter" || event.key === " ") {
            event.preventDefault();
            setOpen(true, true);
          }
        });
      }
    };

    return {
      bind() {
        bindDrag(refs.slPicker, updateFromSlEvent);
        bindDrag(refs.hueSlider, updateFromHueEvent);
        bindPopover();
        bindKeyboard();
      },
      close(focusButton) {
        if (!isOpen) {
          return false;
        }
        setOpen(false, false);
        if (focusButton && refs.button) {
          refs.button.focus({ preventScroll: true });
        }
        return true;
      },
      render
    };
  }

  function getSettingControls() {
    return Array.from(document.querySelectorAll("[data-setting-key]"));
  }

  function getPerfLogOption(mode) {
    return state.perfLogModeOptions.find((item) => item.value === mode) || state.perfLogModeOptions[0];
  }

  function setStatus(text, isError, sticky) {
    state.statusText = typeof text === "string" && text.trim() ? text.trim() : defaultStatusText;
    state.statusIsError = !!isError;
    [els.statusText].filter(Boolean).forEach((target) => {
      target.textContent = state.statusText;
      target.style.color = state.statusIsError ? "var(--danger)" : "var(--muted)";
    });

    if (statusTimerId) {
      window.clearTimeout(statusTimerId);
      statusTimerId = 0;
    }

    if (!sticky && !state.statusIsError && state.statusText !== defaultStatusText) {
      statusTimerId = window.setTimeout(() => {
        statusTimerId = 0;
        setStatus(defaultStatusText, false, false);
      }, 1800);
    }
  }

  function normalizeIncomingSettings(payload) {
    const source = payload && typeof payload === "object" ? payload : {};
    const hasThemePreset = Object.prototype.hasOwnProperty.call(source, "webui_theme_preset");
    const hasThemeSlotPreset = Object.prototype.hasOwnProperty.call(source, "webui_light_theme_preset")
      || Object.prototype.hasOwnProperty.call(source, "webui_dark_theme_preset");
    const storedThemeMode = getPreferredThemeMode();
    const next = { ...settingDefaults };
    Object.keys(settingDefaults).forEach((key) => {
      if (Object.prototype.hasOwnProperty.call(source, key)) {
        next[key] = source[key];
      }
    });

    next.ui_scale_percent = normalizePercent(next.ui_scale_percent);
    next.ui_font_percent = normalizePercent(next.ui_font_percent);
    next.runtime_surface_preview_fps_limit = normalizeRuntimePreviewFpsLimit(next.runtime_surface_preview_fps_limit);
    next.export_video_encoder = normalizeExportVideoEncoder(next.export_video_encoder);
    next.ffmpeg_candidates = normalizePathCandidates(next.ffmpeg_candidates);
    next.recsai_video_encoder_candidates = normalizePathCandidates(next.recsai_video_encoder_candidates);
    next.main_ui_mode = normalizeMainUiMode(next.main_ui_mode);
    next.webui_theme_custom_presets = normalizeWebUiThemeCustomPresets(next.webui_theme_custom_presets);
    next.webui_masthead_background_path = normalizeMastheadBackgroundPath(next.webui_masthead_background_path);
    next.webui_masthead_background_url = normalizeMastheadBackgroundUrl(next.webui_masthead_background_url);
    next.webui_masthead_background_scale_percent = normalizeMastheadBackgroundScalePercent(next.webui_masthead_background_scale_percent);
    next.webui_masthead_background_rotation_deg = normalizeMastheadBackgroundRotationDeg(next.webui_masthead_background_rotation_deg);
    next.webui_masthead_background_offset_x = normalizeMastheadBackgroundOffset(next.webui_masthead_background_offset_x);
    next.webui_masthead_background_offset_y = normalizeMastheadBackgroundOffset(next.webui_masthead_background_offset_y);
    next.webui_masthead_background_tile_enabled = next.webui_masthead_background_tile_enabled === true;
    next.webui_light_theme_preset = normalizeWebUiThemePresetId(next.webui_light_theme_preset, "light");
    next.webui_dark_theme_preset = normalizeWebUiThemePresetId(next.webui_dark_theme_preset, "dark");
    next.webui_theme_color = normalizeHexColor(next.webui_theme_color);
    next.webui_background_color = normalizeHexColor(next.webui_background_color, settingDefaults.webui_background_color);
    if (hasThemePreset) {
      next.webui_theme_preset = normalizeWebUiThemePreset(next.webui_theme_preset, next.webui_theme_color, next.webui_background_color, next);
    } else {
      const inferredThemePreset = inferWebUiThemePreset(next.webui_theme_color, next.webui_background_color, next);
      next.webui_theme_preset = inferredThemePreset
        ? inferredThemePreset
        : normalizeThemeMode(storedThemeMode) === "dark" ? "dark" : "light";
    }
    if (!hasThemeSlotPreset && next.webui_theme_preset && next.webui_theme_preset !== "light" && next.webui_theme_preset !== "dark") {
      if (normalizeThemeMode(storedThemeMode) === "dark") {
        next.webui_dark_theme_preset = next.webui_theme_preset;
      } else {
        next.webui_light_theme_preset = next.webui_theme_preset;
      }
    }
    syncThemePresetColors(next);
    next.perf_log_mode = normalizePerfLogMode(next.perf_log_mode, next.perf_log_mode_value);
    next.perf_log_mode_value = Number(getPerfLogOption(next.perf_log_mode).numeric_value) || 0;

    if (next.perf_log_mode === "Off") {
      next.runtime_surface_perf_log_enabled = false;
      next.preview_perf_log_enabled = false;
    }

    Object.keys(next).forEach((key) => {
      if (typeof settingDefaults[key] === "boolean") {
        next[key] = !!next[key];
      }
    });

    return next;
  }

  function applyState(payload) {
    if (payload && Array.isArray(payload.main_ui_mode_options) && payload.main_ui_mode_options.length > 0) {
      state.mainUiModeOptions = payload.main_ui_mode_options
        .map((item) => ({
          value: normalizeMainUiMode(item && item.value),
          label: String(item && item.label ? item.label : item && item.value ? item.value : "").trim(),
          description: String(item && item.description ? item.description : "").trim()
        }))
        .filter((item) => item.value && item.label);
    }

    if (payload && Array.isArray(payload.perf_log_mode_options) && payload.perf_log_mode_options.length > 0) {
      state.perfLogModeOptions = payload.perf_log_mode_options
        .map((item) => ({
          value: String(item && item.value ? item.value : "").trim(),
          numeric_value: Math.trunc(toNumber(item && item.numeric_value, 0)),
          label: String(item && item.label ? item.label : item && item.value ? item.value : "").trim()
        }))
        .filter((item) => item.value && item.label);
    }

    if (payload && Array.isArray(payload.export_video_encoder_options) && payload.export_video_encoder_options.length > 0) {
      state.exportVideoEncoderOptions = payload.export_video_encoder_options
        .map((item) => ({
          value: normalizeExportVideoEncoder(item && item.value),
          label: String(item && item.label ? item.label : item && item.value ? item.value : "").trim(),
          description: String(item && item.description ? item.description : "").trim()
        }))
        .filter((item) => item.value && item.label);
    }

    state.settings = normalizeIncomingSettings(payload);
    state.editingThemePresetId = state.settings.webui_theme_preset;
    applyTheme();
    if (payload && Object.prototype.hasOwnProperty.call(payload, "main_ui_mode_at_startup")) {
      state.startupMainUiMode = normalizeMainUiMode(payload.main_ui_mode_at_startup);
    } else if (!state.startupMainUiMode) {
      state.startupMainUiMode = state.settings.main_ui_mode;
    }
    state.pendingSave = false;
    state.saving = false;
    state.saveAgain = false;
    applyWebUiThemeColors();
    render();
  }

  function applyMockState() {
    applyState({
      ...settingDefaults,
      status_light_group_visible: true,
      auto_resize_navigator: true,
      custom_brush_overlay_visible: true,
      preview_developer_mode: false,
      runtime_surface_fixed_refresh: true,
      runtime_surface_preview_fps_limit: 0,
      main_ui_mode: "webui",
      perf_log_mode: "Timing",
      runtime_surface_perf_log_enabled: true,
      preview_perf_log_enabled: false
    });
    setStatus("使用本地调试数据", false);
  }

  function requestStateSync(silent = false) {
    if (postHostCommand("app-settings-sync")) {
      suppressNextStateSyncedStatus = !!silent;
      if (!silent) {
        setStatus("正在同步设置…", false, true);
      }
      return;
    }

    applyMockState();
  }

  function scheduleStartupStateSyncs() {
    state.startupSyncTimerIds.forEach((timerId) => window.clearTimeout(timerId));
    state.startupSyncTimerIds = startupSyncDelays.map((delay) => window.setTimeout(() => {
      requestStateSync(true);
    }, delay));
  }

  function buildSavePayload() {
    const payload = { ...state.settings };
    payload.ui_scale_percent = normalizePercent(payload.ui_scale_percent);
    payload.ui_font_percent = normalizePercent(payload.ui_font_percent);
    payload.runtime_surface_preview_fps_limit = normalizeRuntimePreviewFpsLimit(payload.runtime_surface_preview_fps_limit);
    payload.export_video_encoder = normalizeExportVideoEncoder(payload.export_video_encoder);
    payload.main_ui_mode = normalizeMainUiMode(payload.main_ui_mode);
    payload.webui_theme_custom_presets = normalizeWebUiThemeCustomPresets(payload.webui_theme_custom_presets);
    payload.webui_masthead_background_path = normalizeMastheadBackgroundPath(payload.webui_masthead_background_path);
    payload.webui_masthead_background_url = normalizeMastheadBackgroundUrl(payload.webui_masthead_background_url);
    payload.webui_masthead_background_scale_percent = normalizeMastheadBackgroundScalePercent(payload.webui_masthead_background_scale_percent);
    payload.webui_masthead_background_rotation_deg = normalizeMastheadBackgroundRotationDeg(payload.webui_masthead_background_rotation_deg);
    payload.webui_masthead_background_offset_x = normalizeMastheadBackgroundOffset(payload.webui_masthead_background_offset_x);
    payload.webui_masthead_background_offset_y = normalizeMastheadBackgroundOffset(payload.webui_masthead_background_offset_y);
    payload.webui_masthead_background_tile_enabled = payload.webui_masthead_background_tile_enabled === true;
    payload.webui_light_theme_preset = normalizeWebUiThemePresetId(payload.webui_light_theme_preset, "light");
    payload.webui_dark_theme_preset = normalizeWebUiThemePresetId(payload.webui_dark_theme_preset, "dark");
    payload.webui_theme_color = normalizeHexColor(payload.webui_theme_color);
    payload.webui_background_color = normalizeHexColor(payload.webui_background_color, settingDefaults.webui_background_color);
    payload.webui_theme_preset = normalizeWebUiThemePreset(payload.webui_theme_preset, payload.webui_theme_color, payload.webui_background_color, payload);
    delete payload.sai2_thumbnail_provider_registered;
    delete payload.recsai_thumbnail_provider_registered;
    delete payload.recsai_association_registered;
    delete payload.ffmpeg_path;
    delete payload.ffmpeg_available;
    delete payload.ffmpeg_candidates;
    delete payload.recsai_video_encoder_path;
    delete payload.recsai_video_encoder_available;
    delete payload.recsai_video_encoder_candidates;
    delete payload.export_video_encoder_options;
    syncThemePresetColors(payload);
    payload.perf_log_mode = normalizePerfLogMode(payload.perf_log_mode, payload.perf_log_mode_value);
    payload.perf_log_mode_value = Number(getPerfLogOption(payload.perf_log_mode).numeric_value) || 0;
    if (payload.perf_log_mode === "Off") {
      payload.runtime_surface_perf_log_enabled = false;
      payload.preview_perf_log_enabled = false;
    }
    return payload;
  }

  function scheduleAutoSave(message) {
    state.pendingSave = true;
    setStatus(message || "正在准备自动保存…", false, true);
    if (autoSaveTimerId) {
      window.clearTimeout(autoSaveTimerId);
    }
    autoSaveTimerId = window.setTimeout(() => {
      autoSaveTimerId = 0;
      saveSettings();
    }, autoSaveDelayMs);
  }

  function saveSettings() {
    if (autoSaveTimerId) {
      window.clearTimeout(autoSaveTimerId);
      autoSaveTimerId = 0;
    }

    if (state.saving) {
      state.saveAgain = true;
      return;
    }

    state.saving = true;
    state.pendingSave = false;
    const payload = buildSavePayload();
    if (!postHostCommand("app-settings-save", payload)) {
      state.settings = payload;
      state.saving = false;
      state.saveAgain = false;
      applyWebUiThemeColors();
      setStatus("浏览器调试模式已应用本地修改", false);
      render();
      return;
    }

    setStatus("正在保存设置…", false, true);
  }

  function requestMastheadBackgroundChoose() {
    if (!els.mastheadBackgroundFileInput) {
      setStatus("文件选择控件不可用", true, true);
      return;
    }

    els.mastheadBackgroundFileInput.value = "";
    els.mastheadBackgroundFileInput.click();
  }

  function importMastheadBackgroundFile(file) {
    if (!file) {
      setStatus(defaultStatusText, false, false);
      return;
    }

    const name = String(file.name || "");
    const lowerName = name.toLowerCase();
    if (!/\.(png|jpe?g|gif|webp|bmp)$/.test(lowerName)) {
      setStatus("仅支持 png、jpg、jpeg、gif、webp 和 bmp 图片", true, true);
      return;
    }

    const reader = new FileReader();
    reader.onload = () => {
      const result = String(reader.result || "");
      const commaIndex = result.indexOf(",");
      const dataBase64 = commaIndex >= 0 ? result.slice(commaIndex + 1) : result;
      if (!dataBase64.trim()) {
        setStatus("图片数据为空", true, true);
        return;
      }

      if (!postHostCommand("webui-masthead-background-import", {
        display_name: name,
        data_base64: dataBase64
      })) {
        setStatus("导入标题栏背景图仅在桌面宿主中可用", true, true);
        return;
      }

      setStatus("正在导入标题栏背景图…", false, true);
    };
    reader.onerror = () => {
      setStatus("读取图片失败", true, true);
    };
    reader.readAsDataURL(file);
  }

  function runMaintenanceCommand(button) {
    if (!(button instanceof HTMLElement)) {
      return;
    }

    const statusKey = button.dataset.maintenanceActionStatusKey || "";
    const registered = statusKey ? !!state.settings[statusKey] : false;
    const command = String((registered ? button.dataset.maintenanceUnregisterCommand : button.dataset.maintenanceRegisterCommand) || "").trim();
    if (!command) {
      return;
    }

    if (!postHostCommand(command)) {
      setStatus("系统集成操作仅在桌面宿主中可用", true, true);
      return;
    }

    const progressText = (registered ? button.dataset.maintenanceUnregisterProgress : button.dataset.maintenanceRegisterProgress)
      || "正在执行系统集成操作…";
    setStatus(progressText, false, true);
  }

  function downloadFfmpeg() {
    if (!postHostCommand("download-ffmpeg")) {
      setStatus("下载 ffmpeg 仅在桌面宿主中可用", true, true);
      return;
    }

    if (els.downloadFfmpegButton) {
      els.downloadFfmpegButton.disabled = true;
    }
    setStatus("正在下载 ffmpeg…", false, true);
  }

  function clearMastheadBackground() {
    if (!state.settings.webui_masthead_background_path && !state.settings.webui_masthead_background_url) {
      return;
    }

    state.settings.webui_masthead_background_path = "";
    state.settings.webui_masthead_background_url = "";
    resetMastheadBackgroundTransform(false);
    renderMastheadBackground();
    scheduleAutoSave("标题栏背景图已清除，正在自动保存…");
  }

  function resetMastheadBackgroundTransform(save = true) {
    state.settings.webui_masthead_background_scale_percent = 100;
    state.settings.webui_masthead_background_rotation_deg = 0;
    state.settings.webui_masthead_background_offset_x = 0;
    state.settings.webui_masthead_background_offset_y = 0;
    renderControls();
    renderMastheadBackground();
    if (save) {
      scheduleAutoSave("标题栏背景图变换已复位，正在自动保存…");
    }
  }

  function updateMastheadBackgroundTransform(nextValues, message, options = {}) {
    state.settings.webui_masthead_background_scale_percent = normalizeMastheadBackgroundScalePercent(
      Object.prototype.hasOwnProperty.call(nextValues, "scale")
        ? nextValues.scale
        : state.settings.webui_masthead_background_scale_percent);
    state.settings.webui_masthead_background_rotation_deg = normalizeMastheadBackgroundRotationDeg(
      Object.prototype.hasOwnProperty.call(nextValues, "rotation")
        ? nextValues.rotation
        : state.settings.webui_masthead_background_rotation_deg);
    state.settings.webui_masthead_background_offset_x = normalizeMastheadBackgroundOffset(
      Object.prototype.hasOwnProperty.call(nextValues, "offsetX")
        ? nextValues.offsetX
        : state.settings.webui_masthead_background_offset_x);
    state.settings.webui_masthead_background_offset_y = normalizeMastheadBackgroundOffset(
      Object.prototype.hasOwnProperty.call(nextValues, "offsetY")
        ? nextValues.offsetY
        : state.settings.webui_masthead_background_offset_y);
    if (options.syncControls !== false) {
      renderControls();
    }
    renderMastheadBackground();
    scheduleAutoSave(message || "标题栏背景图已修改，正在自动保存…");
  }

  function getMastheadBackgroundPreviewMetrics(url, scale, rotationDeg) {
    if (!url || !els.mastheadBackgroundPreview) {
      mastheadBackgroundPreviewMetricsUrl = "";
      mastheadBackgroundPreviewMetricsLayoutKey = "";
      mastheadBackgroundPreviewMetrics = null;
      return null;
    }

    const rect = els.mastheadBackgroundPreview.getBoundingClientRect();
    const targetWidth = Math.max(1, rect.width || 1);
    const targetHeight = Math.max(1, rect.height || 1);
    const safeScale = Math.max(0.01, Number.isFinite(scale) ? scale : 1);
    const safeRotation = normalizeMastheadBackgroundRotationDeg(rotationDeg);
    const layoutKey = `${Math.round(targetWidth)}x${Math.round(targetHeight)}@${Math.round(safeScale * 1000)}@${safeRotation}`;
    if (mastheadBackgroundPreviewMetricsUrl === url && mastheadBackgroundPreviewMetricsLayoutKey === layoutKey) {
      return mastheadBackgroundPreviewMetrics;
    }

    if (mastheadBackgroundPreviewMetricsUrl === url
      && mastheadBackgroundPreviewMetrics
      && mastheadBackgroundPreviewMetrics.naturalWidth
      && mastheadBackgroundPreviewMetrics.naturalHeight) {
      mastheadBackgroundPreviewMetricsLayoutKey = layoutKey;
      mastheadBackgroundPreviewMetrics = buildMastheadBackgroundPreviewMetrics(
        mastheadBackgroundPreviewMetrics.naturalWidth,
        mastheadBackgroundPreviewMetrics.naturalHeight,
        targetWidth,
        targetHeight,
        safeScale,
        safeRotation);
      return mastheadBackgroundPreviewMetrics;
    }

    mastheadBackgroundPreviewMetricsUrl = url;
    mastheadBackgroundPreviewMetricsLayoutKey = layoutKey;
    mastheadBackgroundPreviewMetrics = null;
    const image = new Image();
    image.onload = () => {
      if (mastheadBackgroundPreviewMetricsUrl !== url || mastheadBackgroundPreviewMetricsLayoutKey !== layoutKey) {
        return;
      }
      const naturalWidth = Math.max(1, image.naturalWidth || image.width || 1);
      const naturalHeight = Math.max(1, image.naturalHeight || image.height || 1);
      mastheadBackgroundPreviewMetrics = buildMastheadBackgroundPreviewMetrics(
        naturalWidth,
        naturalHeight,
        targetWidth,
        targetHeight,
        safeScale,
        safeRotation);
      renderMastheadBackground();
    };
    image.src = url;
    return null;
  }

  function buildMastheadBackgroundPreviewMetrics(naturalWidth, naturalHeight, targetWidth, targetHeight, scale, rotationDeg) {
    const containScale = Math.min(targetWidth / naturalWidth, targetHeight / naturalHeight);
    const tileLayer = getRotatedBounds(targetWidth, targetHeight, rotationDeg);
    const tileScale = getAutoMastheadBackgroundTileScale(naturalWidth, naturalHeight, tileLayer.width, tileLayer.height) * scale;
    return {
      naturalWidth,
      naturalHeight,
      width: Math.max(1, Math.round(naturalWidth * containScale)),
      height: Math.max(1, Math.round(naturalHeight * containScale)),
      tileWidth: Math.max(1, Math.round(naturalWidth * tileScale)),
      tileHeight: Math.max(1, Math.round(naturalHeight * tileScale)),
      tileLayerWidth: Math.max(1, Math.ceil(tileLayer.width + Math.max(targetWidth, targetHeight) * 0.72)),
      tileLayerHeight: Math.max(1, Math.ceil(tileLayer.height + Math.max(targetWidth, targetHeight) * 0.72))
    };
  }

  function getRotatedBounds(width, height, rotationDeg) {
    const radians = normalizeMastheadBackgroundRotationDeg(rotationDeg) * Math.PI / 180;
    const sin = Math.abs(Math.sin(radians));
    const cos = Math.abs(Math.cos(radians));
    return {
      width: Math.max(1, width * cos + height * sin),
      height: Math.max(1, width * sin + height * cos)
    };
  }

  function getAutoMastheadBackgroundTileScale(naturalWidth, naturalHeight, targetWidth, targetHeight) {
    const naturalLongSide = Math.max(1, naturalWidth, naturalHeight);
    const visibleWidth = Math.max(1, targetWidth);
    const visibleHeight = Math.max(1, targetHeight);
    const columnCount = Math.trunc(clamp(visibleWidth / Math.max(visibleHeight * 1.35, 1), 3, 7));
    const widthDrivenLongSide = visibleWidth / Math.max(1, columnCount);
    const minLongSide = clamp(visibleHeight * 0.58, 36, 110);
    const maxLongSide = clamp(visibleHeight * 1.62, minLongSide, 200);
    const tileLongSide = clamp(widthDrivenLongSide, minLongSide, maxLongSide);
    return tileLongSide / naturalLongSide;
  }

  function queueMastheadBackgroundPreviewMetricsRefresh() {
    if (mastheadBackgroundPreviewResizeRaf) {
      return;
    }

    mastheadBackgroundPreviewResizeRaf = window.requestAnimationFrame(() => {
      mastheadBackgroundPreviewResizeRaf = 0;
      mastheadBackgroundPreviewMetricsLayoutKey = "";
      renderMastheadBackground();
    });
  }

  function bindMastheadBackgroundPreviewMetricsResize() {
    if (!els.mastheadBackgroundPreview) {
      return;
    }

    if (typeof ResizeObserver === "function") {
      mastheadBackgroundPreviewResizeObserver = new ResizeObserver(queueMastheadBackgroundPreviewMetricsRefresh);
      mastheadBackgroundPreviewResizeObserver.observe(els.mastheadBackgroundPreview);
      return;
    }

    window.addEventListener("resize", queueMastheadBackgroundPreviewMetricsRefresh);
  }

  function renderPerfLogOptions() {
    if (!els.perfLogModeSelect) {
      return;
    }

    const currentValue = els.perfLogModeSelect.value;
    els.perfLogModeSelect.innerHTML = "";
    state.perfLogModeOptions.forEach((item) => {
      const option = document.createElement("option");
      option.value = item.value;
      option.textContent = item.label;
      option.dataset.numericValue = String(item.numeric_value);
      els.perfLogModeSelect.appendChild(option);
    });
    els.perfLogModeSelect.value = state.perfLogModeOptions.some((item) => item.value === currentValue)
      ? currentValue
      : state.settings.perf_log_mode;
  }

  function getExportVideoEncoderOption(value) {
    const normalized = normalizeExportVideoEncoder(value);
    return state.exportVideoEncoderOptions.find((item) => item.value === normalized)
      || state.exportVideoEncoderOptions[0];
  }

  function renderExportVideoEncoderOptions() {
    const selectedValue = normalizeExportVideoEncoder(state.settings.export_video_encoder);
    if (els.exportVideoEncoderSelect) {
      els.exportVideoEncoderSelect.innerHTML = "";
      state.exportVideoEncoderOptions.forEach((item) => {
        const option = document.createElement("option");
        option.value = item.value;
        option.textContent = item.label;
        option.dataset.description = item.description || "";
        els.exportVideoEncoderSelect.appendChild(option);
      });
      els.exportVideoEncoderSelect.value = state.exportVideoEncoderOptions.some((item) => item.value === selectedValue)
        ? selectedValue
        : "builtin";
    }

    const selected = getExportVideoEncoderOption(selectedValue);
    const usingFfmpeg = selectedValue === "ffmpeg";
    const ffmpegAvailable = state.settings.ffmpeg_available === true;
    const builtinAvailable = state.settings.recsai_video_encoder_available === true;
    if (els.exportVideoEncoderDetail) {
      els.exportVideoEncoderDetail.textContent = selected.description || "";
    }
    if (els.ffmpegStatusBadge) {
      const ok = usingFfmpeg ? ffmpegAvailable : builtinAvailable;
      els.ffmpegStatusBadge.textContent = usingFfmpeg
        ? (ffmpegAvailable ? "ffmpeg 已就绪" : "缺少 ffmpeg")
        : (builtinAvailable ? "内置已就绪" : "缺少内置编码器");
      els.ffmpegStatusBadge.classList.toggle("is-registered", ok);
      els.ffmpegStatusBadge.classList.toggle("is-unregistered", !ok);
    }
    if (els.ffmpegPathText) {
      const ffmpegCandidates = normalizePathCandidates(state.settings.ffmpeg_candidates);
      const builtinCandidates = normalizePathCandidates(state.settings.recsai_video_encoder_candidates);
      const missingFfmpegText = ffmpegCandidates.length > 0
        ? `未找到：ffmpeg.exe，已检查 ${ffmpegCandidates.length} 个路径`
        : "未找到：ffmpeg.exe";
      const missingBuiltinText = builtinCandidates.length > 0
        ? `未找到：recsai-video-encoder.exe，已检查 ${builtinCandidates.length} 个路径`
        : "未找到：recsai-video-encoder.exe";
      els.ffmpegPathText.textContent = usingFfmpeg
        ? (state.settings.ffmpeg_path || missingFfmpegText)
        : (state.settings.recsai_video_encoder_path || missingBuiltinText);
      els.ffmpegPathText.title = usingFfmpeg
        ? (state.settings.ffmpeg_path || ffmpegCandidates.map((item) => `${item.exists ? "存在" : "缺失"}：${item.path}`).join("\n"))
        : (state.settings.recsai_video_encoder_path || builtinCandidates.map((item) => `${item.exists ? "存在" : "缺失"}：${item.path}`).join("\n"));
    }
    if (els.downloadFfmpegButton) {
      els.downloadFfmpegButton.hidden = !usingFfmpeg || ffmpegAvailable;
      els.downloadFfmpegButton.disabled = !usingFfmpeg || ffmpegAvailable;
    }
  }

  function renderMainUiModeOptions() {
    if (!els.mainUiModeOptions) {
      return;
    }

    els.mainUiModeOptions.innerHTML = "";
    state.mainUiModeOptions.forEach((item) => {
      const option = document.createElement("button");
      option.className = "setting-mode-option";
      option.type = "button";
      option.dataset.mode = item.value;
      option.setAttribute("aria-pressed", item.value === state.settings.main_ui_mode ? "true" : "false");
      const willApplyNextLaunch = item.value === state.settings.main_ui_mode
        && state.startupMainUiMode
        && item.value !== state.startupMainUiMode;

      const title = document.createElement("strong");
      title.textContent = item.label;
      option.appendChild(title);

      const description = document.createElement("small");
      description.textContent = item.description || "";
      option.appendChild(description);

      if (willApplyNextLaunch) {
        const restartNote = document.createElement("span");
        restartNote.className = "setting-mode-restart-note";
        restartNote.textContent = "下次启动生效";
        option.appendChild(restartNote);
      }

      option.addEventListener("click", () => {
        if (state.settings.main_ui_mode === item.value) {
          return;
        }
        state.settings.main_ui_mode = item.value;
        renderMainUiModeOptions();
        scheduleAutoSave("主界面已修改，正在自动保存…");
      });

      els.mainUiModeOptions.appendChild(option);
    });
  }

  function renderWebUiThemePresetOptions() {
    if (!els.webUiThemePresetOptions) {
      return;
    }

    const presets = getAllWebUiThemePresets(state.settings);
    const currentPreset = getWebUiThemePreset(state.editingThemePresetId, state.settings).id;
    state.editingThemePresetId = currentPreset;
    els.webUiThemePresetOptions.innerHTML = "";
    presets.forEach((preset) => {
      const isLightPreset = state.settings.webui_light_theme_preset === preset.id;
      const isDarkPreset = state.settings.webui_dark_theme_preset === preset.id;
      const isDeletePending = pendingDeleteThemePresetId === preset.id;
      const option = document.createElement("div");
      option.className = "setting-theme-preset";
      option.dataset.themePreset = preset.id;
      option.setAttribute("aria-current", preset.id === currentPreset ? "true" : "false");
      option.classList.toggle("is-delete-pending", isDeletePending);
      const optionThemeColor = normalizeHexColor(preset.themeColor || state.settings.webui_theme_color);
      const optionBackgroundColor = normalizeHexColor(preset.backgroundColor || state.settings.webui_background_color, settingDefaults.webui_background_color);
      option.style.setProperty("--preset-theme-color", optionThemeColor);
      option.style.setProperty("--preset-background-color", optionBackgroundColor);

      const swatches = document.createElement("span");
      swatches.className = "setting-theme-preset-swatches";
      swatches.setAttribute("aria-hidden", "true");
      const backgroundSwatch = document.createElement("span");
      backgroundSwatch.className = "setting-theme-preset-bg";
      const accentSwatch = document.createElement("span");
      accentSwatch.className = "setting-theme-preset-accent";
      swatches.appendChild(backgroundSwatch);
      swatches.appendChild(accentSwatch);
      option.appendChild(swatches);

      const copy = document.createElement("span");
      copy.className = "setting-theme-preset-copy";
      const title = document.createElement("strong");
      title.textContent = preset.label;
      const description = document.createElement("small");
      const roles = [];
      if (isLightPreset) {
        roles.push("亮主题");
      }
      if (isDarkPreset) {
        roles.push("暗主题");
      }
      description.textContent = roles.length > 0 ? roles.join(" / ") : (preset.description || "自定义主题");
      copy.appendChild(title);
      copy.appendChild(description);
      option.appendChild(copy);

      const tools = document.createElement("span");
      tools.className = "setting-theme-preset-tools";
      tools.appendChild(createThemePresetColorControl(preset, "theme", option));
      tools.appendChild(createThemePresetColorControl(preset, "background", option));
      option.appendChild(tools);

      const actions = document.createElement("span");
      actions.className = "setting-theme-preset-actions";
      if (preset.builtIn) {
        const resetButton = document.createElement("button");
        resetButton.type = "button";
        resetButton.className = "setting-theme-action-button";
        setButtonIconText(resetButton, "reset", "复位");
        resetButton.addEventListener("click", () => {
          pendingDeleteThemePresetId = "";
          resetBuiltInThemePreset(preset.id);
          render();
          scheduleAutoSave("内置主题已复位，正在自动保存…");
        });
        actions.appendChild(resetButton);
      }
      const lightButton = document.createElement("button");
      lightButton.type = "button";
      lightButton.className = "setting-theme-action-button";
      lightButton.classList.toggle("is-current-slot", isLightPreset);
      setButtonIconText(lightButton, "sun", isLightPreset ? "当前 亮主题" : "设为亮主题");
      lightButton.setAttribute("aria-pressed", isLightPreset ? "true" : "false");
      lightButton.addEventListener("click", () => {
        if (isLightPreset) {
          return;
        }
        pendingDeleteThemePresetId = "";
        setThemeSlotPreset("light", preset.id);
        render();
        scheduleAutoSave("亮主题预设已修改，正在自动保存…");
      });
      const darkButton = document.createElement("button");
      darkButton.type = "button";
      darkButton.className = "setting-theme-action-button";
      darkButton.classList.toggle("is-current-slot", isDarkPreset);
      setButtonIconText(darkButton, "moon", isDarkPreset ? "当前 暗主题" : "设为暗主题");
      darkButton.setAttribute("aria-pressed", isDarkPreset ? "true" : "false");
      darkButton.addEventListener("click", () => {
        if (isDarkPreset) {
          return;
        }
        pendingDeleteThemePresetId = "";
        setThemeSlotPreset("dark", preset.id);
        render();
        scheduleAutoSave("暗主题预设已修改，正在自动保存…");
      });
      actions.appendChild(lightButton);
      actions.appendChild(darkButton);
      const deleteSlot = document.createElement("span");
      deleteSlot.className = "setting-theme-delete-slot";
      ["click", "dblclick"].forEach((eventName) => {
        deleteSlot.addEventListener(eventName, (event) => {
          event.stopPropagation();
        });
      });
      if (!preset.builtIn) {
        if (isDeletePending) {
          const confirm = document.createElement("span");
          confirm.className = "setting-theme-delete-confirm";
          const confirmText = document.createElement("span");
          confirmText.className = "setting-theme-delete-confirm-text";
          confirmText.textContent = "确认删除?";
          const confirmButton = document.createElement("button");
          confirmButton.type = "button";
          confirmButton.className = "setting-theme-delete-action is-confirm";
          confirmButton.setAttribute("aria-label", `确认删除 ${preset.label}`);
          confirmButton.title = `确认删除 ${preset.label}`;
          confirmButton.innerHTML = buildSettingIcon("check");
          confirmButton.addEventListener("click", (event) => {
            event.stopPropagation();
            deleteThemePreset(preset.id);
          });
          const cancelButton = document.createElement("button");
          cancelButton.type = "button";
          cancelButton.className = "setting-theme-delete-action is-cancel";
          cancelButton.setAttribute("aria-label", `取消删除 ${preset.label}`);
          cancelButton.title = `取消删除 ${preset.label}`;
          cancelButton.innerHTML = buildSettingIcon("x");
          cancelButton.addEventListener("click", (event) => {
            event.stopPropagation();
            cancelThemePresetDelete(preset.id);
          });
          confirm.append(confirmText, confirmButton, cancelButton);
          deleteSlot.appendChild(confirm);
        } else {
          const deleteButton = document.createElement("button");
          deleteButton.type = "button";
          deleteButton.className = "setting-theme-delete-button";
          deleteButton.setAttribute("aria-label", `删除 ${preset.label}`);
          deleteButton.title = `删除 ${preset.label}`;
          deleteButton.innerHTML = buildSettingIcon("x");
          deleteButton.addEventListener("click", (event) => {
            event.stopPropagation();
            requestThemePresetDelete(preset.id);
          });
          deleteSlot.appendChild(deleteButton);
        }
      }
      actions.appendChild(deleteSlot);
      option.appendChild(actions);

      els.webUiThemePresetOptions.appendChild(option);
    });
  }

  function createThemePresetColorControl(preset, colorKind, option) {
    let targetPresetId = preset.id;
    const isBackground = colorKind === "background";
    const colorLabel = isBackground ? "背景色" : "主题色";
    const refs = buildThemePresetColorPickerElements(`${preset.label}${colorLabel}`, isBackground);
    const getPreset = () => getWebUiThemePreset(targetPresetId, state.settings);
    const getColor = () => isBackground
      ? normalizeHexColor(getPreset().backgroundColor, settingDefaults.webui_background_color)
      : normalizeHexColor(getPreset().themeColor);
    const setCardColors = (nextPreset) => {
      option.dataset.themePreset = nextPreset.id;
      option.style.setProperty("--preset-theme-color", normalizeHexColor(nextPreset.themeColor));
      option.style.setProperty("--preset-background-color", normalizeHexColor(nextPreset.backgroundColor, settingDefaults.webui_background_color));
    };
    const control = createColorPickerControl({
      ...refs,
      fallbackColor: isBackground ? settingDefaults.webui_background_color : settingDefaults.webui_theme_color,
      getColor,
      setColor: (color) => {
        const nextPreset = updateThemePresetColors(targetPresetId, isBackground
          ? { backgroundColor: normalizeHexColor(color, settingDefaults.webui_background_color) }
          : { themeColor: normalizeHexColor(color) });
        targetPresetId = nextPreset.id;
        setCardColors(nextPreset);
        applyWebUiThemeColors();
        scheduleAutoSave(`${colorLabel}已修改，正在自动保存…`);
      },
      onSave: () => {
        scheduleAutoSave(`${colorLabel}已修改，正在自动保存…`);
      },
      onClose: () => {
        render();
      }
    });
    control.bind();
    control.render();
    themePresetColorControls.push(control);
    return refs.control;
  }

  function closeThemePresetColorControls(focusButton) {
    let closed = false;
    themePresetColorControls.forEach((control) => {
      if (control && typeof control.close === "function") {
        closed = control.close(focusButton) || closed;
      }
    });
    return closed;
  }

  function buildThemePresetColorPickerElements(label, isBackground) {
    const control = document.createElement("span");
    control.className = "setting-theme-control setting-theme-preset-color-control";
    control.dataset.hostDragIgnore = "true";

    const button = document.createElement("button");
    button.className = `setting-theme-trigger${isBackground ? " setting-theme-preset-bg-button" : ""}`;
    button.type = "button";
    button.setAttribute("aria-label", `选择 ${label}`);
    button.title = `选择 ${label}`;
    button.setAttribute("aria-haspopup", "dialog");
    button.setAttribute("aria-expanded", "false");

    const triggerSwatch = document.createElement("span");
    triggerSwatch.className = "setting-theme-trigger-swatch";
    triggerSwatch.setAttribute("aria-hidden", "true");
    button.appendChild(triggerSwatch);

    const popover = document.createElement("div");
    popover.className = "setting-theme-popover";
    popover.setAttribute("role", "dialog");
    popover.setAttribute("aria-label", label);
    popover.hidden = true;

    const picker = document.createElement("div");
    picker.className = "setting-theme-picker";
    picker.setAttribute("aria-label", label);

    const slPicker = document.createElement("div");
    slPicker.className = "setting-theme-sl";
    slPicker.setAttribute("role", "slider");
    slPicker.setAttribute("aria-label", "饱和度和亮度");
    slPicker.tabIndex = 0;

    const slCursor = document.createElement("span");
    slCursor.className = "setting-theme-cursor";
    slCursor.setAttribute("aria-hidden", "true");
    slPicker.appendChild(slCursor);

    const hueSlider = document.createElement("div");
    hueSlider.className = "setting-theme-hue";
    hueSlider.setAttribute("role", "slider");
    hueSlider.setAttribute("aria-label", "色相");
    hueSlider.setAttribute("aria-valuemin", "0");
    hueSlider.setAttribute("aria-valuemax", "360");
    hueSlider.tabIndex = 0;

    const hueThumb = document.createElement("span");
    hueThumb.className = "setting-theme-hue-thumb";
    hueThumb.setAttribute("aria-hidden", "true");
    hueSlider.appendChild(hueThumb);

    const value = document.createElement("div");
    value.className = "setting-theme-value";
    const preview = document.createElement("span");
    preview.className = "setting-theme-preview";
    preview.setAttribute("aria-hidden", "true");
    const hexText = document.createElement("span");
    hexText.className = "setting-theme-hex";
    value.append(preview, hexText);

    picker.append(slPicker, hueSlider, value);
    popover.appendChild(picker);
    control.append(button, popover);

    return {
      control,
      button,
      popover,
      triggerSwatch,
      slPicker,
      slCursor,
      hueSlider,
      hueThumb,
      preview,
      hexText
    };
  }

  function renderControls() {
    getSettingControls().forEach((control) => {
      const key = control.dataset.settingKey;
      if (!key || !Object.prototype.hasOwnProperty.call(state.settings, key)) {
        return;
      }

      if (control.type === "checkbox") {
        control.checked = !!state.settings[key];
        return;
      }

      control.value = String(state.settings[key]);
    });

    const perfEnabled = state.settings.perf_log_mode !== "Off";
    ["runtime_surface_perf_log_enabled", "preview_perf_log_enabled"].forEach((key) => {
      const control = document.querySelector(`[data-setting-key="${key}"]`);
      if (!control) {
        return;
      }
      control.disabled = !perfEnabled;
      const tile = control.closest(".setting-tile");
      if (tile) {
        tile.classList.toggle("is-disabled", !perfEnabled);
      }
    });
  }

  function renderMaintenanceStatus() {
    document.querySelectorAll("[data-maintenance-status-key]").forEach((badge) => {
      const key = badge.dataset.maintenanceStatusKey;
      const registered = !!state.settings[key];
      badge.textContent = registered ? "已注册" : "未注册";
      badge.classList.toggle("is-registered", registered);
      badge.classList.toggle("is-unregistered", !registered);
    });
    els.maintenanceButtons.forEach((button) => {
      const key = button.dataset.maintenanceActionStatusKey || "";
      const registered = key ? !!state.settings[key] : false;
      button.textContent = registered ? "解除" : "注册";
      button.classList.toggle("is-unregister-action", registered);
      button.dataset.maintenanceCommand = registered ? button.dataset.maintenanceUnregisterCommand || "" : button.dataset.maintenanceRegisterCommand || "";
    });
  }

  function renderMastheadBackground() {
    const path = normalizeMastheadBackgroundPath(state.settings.webui_masthead_background_path);
    const url = normalizeMastheadBackgroundUrl(state.settings.webui_masthead_background_url);
    const scale = normalizeMastheadBackgroundScalePercent(state.settings.webui_masthead_background_scale_percent);
    const rotation = normalizeMastheadBackgroundRotationDeg(state.settings.webui_masthead_background_rotation_deg);
    const offsetX = normalizeMastheadBackgroundOffset(state.settings.webui_masthead_background_offset_x);
    const offsetY = normalizeMastheadBackgroundOffset(state.settings.webui_masthead_background_offset_y);
    const tileEnabled = state.settings.webui_masthead_background_tile_enabled === true;
    if (els.mastheadBackgroundPreview) {
      if (url) {
        const metrics = getMastheadBackgroundPreviewMetrics(url, scale / 100, rotation);
        els.mastheadBackgroundPreview.style.setProperty("--setting-masthead-preview-image", `url("${url.replace(/"/g, "%22")}")`);
        if (metrics) {
          els.mastheadBackgroundPreview.style.setProperty("--setting-masthead-preview-width", `${metrics.width}px`);
          els.mastheadBackgroundPreview.style.setProperty("--setting-masthead-preview-height", `${metrics.height}px`);
          els.mastheadBackgroundPreview.style.setProperty("--setting-masthead-preview-tile-width", `${metrics.tileWidth}px`);
          els.mastheadBackgroundPreview.style.setProperty("--setting-masthead-preview-tile-height", `${metrics.tileHeight}px`);
          els.mastheadBackgroundPreview.style.setProperty("--setting-masthead-preview-tile-layer-width", `${metrics.tileLayerWidth}px`);
          els.mastheadBackgroundPreview.style.setProperty("--setting-masthead-preview-tile-layer-height", `${metrics.tileLayerHeight}px`);
        } else {
          els.mastheadBackgroundPreview.style.removeProperty("--setting-masthead-preview-width");
          els.mastheadBackgroundPreview.style.removeProperty("--setting-masthead-preview-height");
          els.mastheadBackgroundPreview.style.removeProperty("--setting-masthead-preview-tile-width");
          els.mastheadBackgroundPreview.style.removeProperty("--setting-masthead-preview-tile-height");
          els.mastheadBackgroundPreview.style.removeProperty("--setting-masthead-preview-tile-layer-width");
          els.mastheadBackgroundPreview.style.removeProperty("--setting-masthead-preview-tile-layer-height");
        }
        els.mastheadBackgroundPreview.style.setProperty("--setting-masthead-preview-scale", String(scale / 100));
        els.mastheadBackgroundPreview.style.setProperty("--setting-masthead-preview-rotation", `${rotation}deg`);
        els.mastheadBackgroundPreview.style.setProperty("--setting-masthead-preview-offset-x", `${offsetX}px`);
        els.mastheadBackgroundPreview.style.setProperty("--setting-masthead-preview-offset-y", `${offsetY}px`);
        els.mastheadBackgroundPreview.classList.add("has-image");
        els.mastheadBackgroundPreview.classList.toggle("is-tiled", tileEnabled);
      } else {
        els.mastheadBackgroundPreview.style.removeProperty("--setting-masthead-preview-image");
        els.mastheadBackgroundPreview.style.removeProperty("--setting-masthead-preview-width");
        els.mastheadBackgroundPreview.style.removeProperty("--setting-masthead-preview-height");
        els.mastheadBackgroundPreview.style.removeProperty("--setting-masthead-preview-tile-width");
        els.mastheadBackgroundPreview.style.removeProperty("--setting-masthead-preview-tile-height");
        els.mastheadBackgroundPreview.style.removeProperty("--setting-masthead-preview-tile-layer-width");
        els.mastheadBackgroundPreview.style.removeProperty("--setting-masthead-preview-tile-layer-height");
        els.mastheadBackgroundPreview.style.removeProperty("--setting-masthead-preview-scale");
        els.mastheadBackgroundPreview.style.removeProperty("--setting-masthead-preview-rotation");
        els.mastheadBackgroundPreview.style.removeProperty("--setting-masthead-preview-offset-x");
        els.mastheadBackgroundPreview.style.removeProperty("--setting-masthead-preview-offset-y");
        els.mastheadBackgroundPreview.classList.remove("has-image");
        els.mastheadBackgroundPreview.classList.remove("is-tiled");
      }
    }
    if (els.mastheadBackgroundStatus) {
      els.mastheadBackgroundStatus.textContent = path ? path.split("/").pop() : "未设置";
    }
    if (els.clearMastheadBackgroundButton) {
      els.clearMastheadBackgroundButton.disabled = !path && !url;
    }
    if (els.resetMastheadBackgroundTransformButton) {
      els.resetMastheadBackgroundTransformButton.disabled = !path && !url;
    }
  }

  function render() {
    renderMainUiModeOptions();
    themePresetColorControls = [];
    renderWebUiThemePresetOptions();
    renderPerfLogOptions();
    renderControls();
    renderExportVideoEncoderOptions();
    renderMaintenanceStatus();
    renderMastheadBackground();
    queuePageScrollFadeUpdate();
  }

  function updateSettingFromControl(control) {
    const key = control && control.dataset ? control.dataset.settingKey : "";
    if (!key || !Object.prototype.hasOwnProperty.call(state.settings, key)) {
      return;
    }

    if (control.type === "checkbox") {
      state.settings[key] = !!control.checked;
    } else if (control.type === "number") {
      if (key === "runtime_surface_preview_fps_limit") {
        state.settings[key] = normalizeRuntimePreviewFpsLimit(control.value);
        control.value = String(state.settings[key]);
        scheduleAutoSave("设置已修改，正在自动保存…");
        return;
      }
      if (key === "webui_masthead_background_scale_percent") {
        state.settings[key] = normalizeMastheadBackgroundScalePercent(control.value);
      } else if (key === "webui_masthead_background_rotation_deg") {
        state.settings[key] = normalizeMastheadBackgroundRotationDeg(control.value);
      } else if (key === "webui_masthead_background_offset_x" || key === "webui_masthead_background_offset_y") {
        state.settings[key] = normalizeMastheadBackgroundOffset(control.value);
      } else {
        state.settings[key] = normalizePercent(control.value);
      }
      control.value = String(state.settings[key]);
    } else {
      state.settings[key] = control.value;
    }

    if (key === "perf_log_mode") {
      state.settings.perf_log_mode = normalizePerfLogMode(control.value, 0);
      state.settings.perf_log_mode_value = Number(getPerfLogOption(state.settings.perf_log_mode).numeric_value) || 0;
      if (state.settings.perf_log_mode === "Off") {
        state.settings.runtime_surface_perf_log_enabled = false;
        state.settings.preview_perf_log_enabled = false;
      }
      renderControls();
    }

    if (key === "export_video_encoder") {
      state.settings.export_video_encoder = normalizeExportVideoEncoder(control.value);
      renderExportVideoEncoderOptions();
    }

    if (key.startsWith("webui_masthead_background_")) {
      renderMastheadBackground();
    }

    scheduleAutoSave("设置已修改，正在自动保存…");
  }

  function updatePageScrollFade() {
    pageScrollFadeRaf = 0;
    if (!els.pageScrollRoot) {
      return;
    }

    const scrollTop = Math.max(0, els.pageScrollRoot.scrollTop || 0);
    const maxScrollTop = Math.max(0, (els.pageScrollRoot.scrollHeight || 0) - (els.pageScrollRoot.clientHeight || 0));
    const hasTopFade = scrollTop > pageScrollFadeThresholdPx;
    const hasBottomFade = maxScrollTop - scrollTop > pageScrollFadeThresholdPx;

    let nextClass = "scroll-fade-none";
    if (hasTopFade && hasBottomFade) {
      nextClass = "scroll-fade-both";
    } else if (hasTopFade) {
      nextClass = "scroll-fade-top";
    } else if (hasBottomFade) {
      nextClass = "scroll-fade-bottom";
    }

    els.pageScrollRoot.classList.remove("scroll-fade-none", "scroll-fade-top", "scroll-fade-bottom", "scroll-fade-both");
    els.pageScrollRoot.classList.add(nextClass);
  }

  function queuePageScrollFadeUpdate() {
    if (pageScrollFadeRaf) {
      return;
    }
    pageScrollFadeRaf = window.requestAnimationFrame(updatePageScrollFade);
  }

  function bindPageScrollFade() {
    if (!els.pageScrollRoot) {
      return;
    }
    els.pageScrollRoot.addEventListener("scroll", queuePageScrollFadeUpdate, { passive: true });
    window.addEventListener("resize", queuePageScrollFadeUpdate);
    queuePageScrollFadeUpdate();
  }

  function bindDragSurface(el) {
    if (!el) {
      return;
    }

    el.addEventListener("pointerdown", (event) => {
      if (event.button !== 0 || !event.isPrimary) {
        return;
      }

      const interactiveTarget = event.target instanceof Element
        ? event.target.closest("button, input, select, textarea, a, label, summary, [role='button'], [data-host-drag-ignore='true']")
        : null;
      if (interactiveTarget || !hasHostBridge()) {
        return;
      }

      event.preventDefault();
      postHostMessage(buildHostDragMoveMessage(event));
    });
  }

  function bindMastheadBackgroundPreview() {
    if (!els.mastheadBackgroundPreview) {
      return;
    }

    bindMastheadBackgroundPreviewMetricsResize();

    const hasImage = () => !!normalizeMastheadBackgroundUrl(state.settings.webui_masthead_background_url);
    const getLocalPoint = (event) => {
      const rect = els.mastheadBackgroundPreview.getBoundingClientRect();
      return {
        x: event.clientX - rect.left,
        y: event.clientY - rect.top,
        width: Math.max(1, rect.width),
        height: Math.max(1, rect.height)
      };
    };
    const angleDegrees = (centerX, centerY, pointX, pointY) => Math.atan2(pointY - centerY, pointX - centerX) * 180 / Math.PI;
    const normalizeAngleDelta = (angle) => {
      let value = angle;
      while (value <= -180) {
        value += 360;
      }
      while (value > 180) {
        value -= 360;
      }
      return value;
    };

    els.mastheadBackgroundPreview.addEventListener("dblclick", (event) => {
      if (!hasImage()) {
        return;
      }
      event.preventDefault();
      resetMastheadBackgroundTransform(true);
    });

    els.mastheadBackgroundPreview.addEventListener("wheel", (event) => {
      if (!hasImage()) {
        return;
      }
      event.preventDefault();
      const current = normalizeMastheadBackgroundScalePercent(state.settings.webui_masthead_background_scale_percent);
      const step = event.deltaY < 0 ? 5 : -5;
      updateMastheadBackgroundTransform({ scale: current + step }, "标题栏背景图缩放已修改，正在自动保存…", { syncControls: false });
    }, { passive: false });

    els.mastheadBackgroundPreview.addEventListener("contextmenu", (event) => {
      if (hasImage()) {
        event.preventDefault();
      }
    });

    els.mastheadBackgroundPreview.addEventListener("pointerdown", (event) => {
      if (!hasImage() || !event.isPrimary || (event.button !== 0 && event.button !== 2)) {
        return;
      }

      event.preventDefault();
      const point = getLocalPoint(event);
      const isRotate = event.button === 2 || event.altKey;
      mastheadBackgroundInteraction = {
        pointerId: event.pointerId,
        mode: isRotate ? "rotate" : "drag",
        startX: point.x,
        startY: point.y,
        startOffsetX: normalizeMastheadBackgroundOffset(state.settings.webui_masthead_background_offset_x),
        startOffsetY: normalizeMastheadBackgroundOffset(state.settings.webui_masthead_background_offset_y),
        startRotation: normalizeMastheadBackgroundRotationDeg(state.settings.webui_masthead_background_rotation_deg),
        centerX: point.width / 2,
        centerY: point.height / 2,
        startAngle: angleDegrees(point.width / 2, point.height / 2, point.x, point.y)
      };
      els.mastheadBackgroundPreview.classList.toggle("is-dragging", mastheadBackgroundInteraction.mode === "drag");
      els.mastheadBackgroundPreview.classList.toggle("is-rotating", mastheadBackgroundInteraction.mode === "rotate");
      try {
        els.mastheadBackgroundPreview.setPointerCapture(event.pointerId);
      } catch {
      }
    });

    els.mastheadBackgroundPreview.addEventListener("pointermove", (event) => {
      if (!mastheadBackgroundInteraction || mastheadBackgroundInteraction.pointerId !== event.pointerId) {
        return;
      }

      const point = getLocalPoint(event);
      if (mastheadBackgroundInteraction.mode === "rotate") {
        const currentAngle = angleDegrees(
          mastheadBackgroundInteraction.centerX,
          mastheadBackgroundInteraction.centerY,
          point.x,
          point.y);
        updateMastheadBackgroundTransform({
          rotation: mastheadBackgroundInteraction.startRotation + Math.round(normalizeAngleDelta(currentAngle - mastheadBackgroundInteraction.startAngle))
        }, "标题栏背景图旋转已修改，正在自动保存…", { syncControls: false });
        return;
      }

      updateMastheadBackgroundTransform({
        offsetX: mastheadBackgroundInteraction.startOffsetX + Math.round(point.x - mastheadBackgroundInteraction.startX),
        offsetY: mastheadBackgroundInteraction.startOffsetY + Math.round(point.y - mastheadBackgroundInteraction.startY)
      }, "标题栏背景图位置已修改，正在自动保存…", { syncControls: false });
    });

    const stopInteraction = (event) => {
      if (!mastheadBackgroundInteraction || mastheadBackgroundInteraction.pointerId !== event.pointerId) {
        return;
      }
      mastheadBackgroundInteraction = null;
      els.mastheadBackgroundPreview.classList.remove("is-dragging", "is-rotating");
      try {
        els.mastheadBackgroundPreview.releasePointerCapture(event.pointerId);
      } catch {
      }
    };
    els.mastheadBackgroundPreview.addEventListener("pointerup", stopInteraction);
    els.mastheadBackgroundPreview.addEventListener("pointercancel", stopInteraction);
  }

  function bindEvents() {
    bindEmbeddedContextReturn();
    bindDragSurface(els.appSettingsHeader);

    if (els.closeWindowButton) {
      els.closeWindowButton.addEventListener("click", () => {
        postHostMessage(hostCloseWindowMessage);
      });
    }

    [els.refreshSettingsButton].filter(Boolean).forEach((button) => {
      button.addEventListener("click", requestStateSync);
    });

    getSettingControls().forEach((control) => {
      const eventName = control.type === "checkbox" || control.tagName === "SELECT" ? "change" : "change";
      control.addEventListener(eventName, () => updateSettingFromControl(control));
      control.addEventListener("keydown", (event) => {
        if (event.key === "Enter") {
          event.preventDefault();
          control.blur();
        }
      });
    });

    if (els.addWebUiThemePresetButton) {
      els.addWebUiThemePresetButton.addEventListener("click", addWebUiThemePreset);
    }
    if (els.chooseMastheadBackgroundButton) {
      els.chooseMastheadBackgroundButton.addEventListener("click", requestMastheadBackgroundChoose);
    }
    if (els.clearMastheadBackgroundButton) {
      els.clearMastheadBackgroundButton.addEventListener("click", clearMastheadBackground);
    }
    if (els.resetMastheadBackgroundTransformButton) {
      els.resetMastheadBackgroundTransformButton.addEventListener("click", () => resetMastheadBackgroundTransform(true));
    }
    if (els.downloadFfmpegButton) {
      els.downloadFfmpegButton.addEventListener("click", downloadFfmpeg);
    }
    if (els.mastheadBackgroundFileInput) {
      els.mastheadBackgroundFileInput.addEventListener("change", () => {
        importMastheadBackgroundFile(els.mastheadBackgroundFileInput.files && els.mastheadBackgroundFileInput.files[0]);
      });
    }
    els.maintenanceButtons.forEach((button) => {
      button.addEventListener("click", () => runMaintenanceCommand(button));
    });
    bindMastheadBackgroundPreview();

    window.addEventListener("keydown", (event) => {
      if (event.key === "Escape" && closeThemePresetColorControls(true)) {
        event.preventDefault();
        return;
      }
      if (event.key === "Escape" && !isEmbedded) {
        postHostMessage(hostCloseWindowMessage);
      }
      if ((event.ctrlKey || event.metaKey) && event.key.toLowerCase() === "s") {
        event.preventDefault();
        saveSettings();
      }
    });
  }

  function bindHostBridge() {
    if (isEmbedded && window.parent && window.parent !== window) {
      const isTrustedParentMessage = (event) => {
        if (window.location.protocol === "file:") {
          return true;
        }
        return event.origin === window.location.origin;
      };

      window.addEventListener("message", (event) => {
        if (!isTrustedParentMessage(event)) {
          return;
        }

        handleHostBridgeMessage(event.data);
      });
      return;
    }

    const bridge = getHostBridge();
    if (!bridge || typeof bridge.addEventListener !== "function") {
      return;
    }

    bridge.addEventListener("message", (event) => {
      handleHostBridgeMessage(event.data);
    });
  }

  function handleHostBridgeMessage(data) {
    if (typeof data === "string") {
      if (data === hostWindowShownMessage) {
        requestStateSync();
      }
      return;
    }

    if (!data || typeof data !== "object") {
      return;
    }

    if (data.kind === "app-settings-state") {
      if (state.saving || state.pendingSave || state.saveAgain) {
        applyReadOnlyRuntimeState(data.state);
        return;
      }
      applyState(data.state);
      if (suppressNextStateSyncedStatus) {
        suppressNextStateSyncedStatus = false;
      } else {
        setStatus("已同步", false);
      }
      return;
    }

    if (data.kind === "webui-ack") {
      const ackMessage = typeof data.message === "string" && data.message.trim()
        ? data.message.trim()
        : defaultStatusText;
      if (data.command === "webui-masthead-background-import") {
        state.saving = false;
        state.pendingSave = false;
        state.saveAgain = false;
      }
      if (data.command === "app-settings-save") {
        state.saving = false;
        if (data.ok === false) {
          state.pendingSave = true;
          setStatus(ackMessage, true, true);
          return;
        }
        setStatus("已自动保存", false);
        applyWebUiThemeColors();
        if (state.saveAgain) {
          state.saveAgain = false;
          scheduleAutoSave("设置已修改，正在自动保存…");
        }
        return;
      }
      const isMaintenanceCommand = data.command && (
        data.command.includes("thumbnail-provider")
        || data.command === "register-recsai-association"
        || data.command === "unregister-recsai-association"
      );
      if (data.ok !== false && isMaintenanceCommand) {
        requestStateSync(true);
      }
      if (data.command === "download-ffmpeg") {
        if (data.phase === "downloading") {
          return;
        }
        if (data.ok !== false) {
          requestStateSync(true);
        } else if (els.downloadFfmpegButton) {
          els.downloadFfmpegButton.disabled = false;
        }
      }
      if (ackMessage !== defaultStatusText) {
        setStatus(ackMessage, data.ok === false, data.ok === false);
      }
    }
  }

  function applyReadOnlyRuntimeState(payload) {
    if (!payload || typeof payload !== "object") {
      return;
    }

    const readonlyKeys = [
      "ffmpeg_path",
      "ffmpeg_available",
      "ffmpeg_candidates",
      "recsai_video_encoder_path",
      "recsai_video_encoder_available",
      "recsai_video_encoder_candidates",
      "export_video_encoder",
      "export_video_encoder_options"
    ];
    readonlyKeys.forEach((key) => {
      if (Object.prototype.hasOwnProperty.call(payload, key)) {
        state.settings[key] = payload[key];
      }
    });
    state.settings.export_video_encoder = normalizeExportVideoEncoder(state.settings.export_video_encoder);
    state.settings.ffmpeg_candidates = normalizePathCandidates(state.settings.ffmpeg_candidates);
    state.settings.recsai_video_encoder_candidates = normalizePathCandidates(state.settings.recsai_video_encoder_candidates);
    if (Array.isArray(payload.export_video_encoder_options) && payload.export_video_encoder_options.length > 0) {
      state.exportVideoEncoderOptions = payload.export_video_encoder_options
        .map((item) => ({
          value: normalizeExportVideoEncoder(item && item.value),
          label: String(item && item.label ? item.label : item && item.value ? item.value : "").trim(),
          description: String(item && item.description ? item.description : "").trim()
        }))
        .filter((item) => item.value && item.label);
    }
    renderExportVideoEncoderOptions();
  }

  function init() {
    applyTheme();
    bindThemePreferenceChange();
    bindThemeStorageChange();
    if (isEmbedded) {
      document.documentElement.classList.add("is-embedded");
    }
    bindEvents();
    bindHostBridge();
    bindPageScrollFade();
    render();
    requestStateSync();
    scheduleStartupStateSyncs();
  }

  init();
})();
