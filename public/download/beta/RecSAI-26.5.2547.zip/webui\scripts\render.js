﻿function updatePageScrollFade() {
  pageScrollFadeRaf = 0;

  const fadeClasses = ["scroll-fade-none", "scroll-fade-top", "scroll-fade-bottom", "scroll-fade-both"];
  const isDashboardActive = els.pageScrollRoot?.classList.contains("is-dashboard-active") === true;
  const scrollRoot = isDashboardActive && els.controlRail ? els.controlRail : els.pageScrollRoot;
  if (!scrollRoot) {
    return;
  }

  if (els.pageScrollRoot && els.pageScrollRoot !== scrollRoot) {
    els.pageScrollRoot.classList.remove(...fadeClasses);
    els.pageScrollRoot.classList.add("scroll-fade-none");
  }
  if (els.controlRail && els.controlRail !== scrollRoot) {
    els.controlRail.classList.remove(...fadeClasses);
  }

  const scrollTop = Math.max(0, scrollRoot.scrollTop || 0);
  const maxScrollTop = Math.max(0, (scrollRoot.scrollHeight || 0) - (scrollRoot.clientHeight || 0));
  const hasTopFade = scrollTop > pageScrollFadeThresholdPx;
  const hasBottomFade = maxScrollTop - scrollTop > pageScrollFadeThresholdPx;

  let nextFadeClass = "scroll-fade-none";
  if (hasTopFade && hasBottomFade) {
    nextFadeClass = "scroll-fade-both";
  } else if (hasTopFade) {
    nextFadeClass = "scroll-fade-top";
  } else if (hasBottomFade) {
    nextFadeClass = "scroll-fade-bottom";
  }

  if (!scrollRoot.classList.contains(nextFadeClass)) {
    scrollRoot.classList.remove(...fadeClasses);
    scrollRoot.classList.add(nextFadeClass);
  }
}

function queuePageScrollFadeUpdate() {
  if (pageScrollFadeRaf) {
    return;
  }

  pageScrollFadeRaf = window.requestAnimationFrame(updatePageScrollFade);
}

function bindPageScrollFade() {
  if (!els.pageScrollRoot) {
    return;
  }

  els.pageScrollRoot.addEventListener("scroll", queuePageScrollFadeUpdate, { passive: true });
  if (els.controlRail) {
    els.controlRail.addEventListener("scroll", queuePageScrollFadeUpdate, { passive: true });
  }
  els.pageScrollRoot.addEventListener("transitionend", (event) => {
    if (event.target === els.pageScrollRoot && event.propertyName === "max-height") {
      queueDashboardHostSizeSync(state.contentCollapsed === true);
    }
  });
  window.addEventListener("resize", () => {
    if (state.contentCollapsed === true && dashboardHostResizeSuppressUntil > performance.now()) {
      dashboardHostResizeSuppressUntil = Math.max(
        dashboardHostResizeSuppressUntil,
        performance.now() + 220
      );
    }
    queueActiveContentLayoutSync();
    queuePageScrollFadeUpdate();
  });

  if ("ResizeObserver" in window && document.body) {
    pageScrollFadeObserver = new ResizeObserver(() => {
      queueActiveContentLayoutSync();
      queuePageScrollFadeUpdate();
    });
    pageScrollFadeObserver.observe(els.pageScrollRoot);
    if (els.controlRail) {
      pageScrollFadeObserver.observe(els.controlRail);
    }
    if (els.masthead) {
      pageScrollFadeObserver.observe(els.masthead);
    }
    const workspace = document.querySelector(".workspace");
    if (workspace) {
      pageScrollFadeObserver.observe(workspace);
    }
    const dynamicOutlet = document.querySelector("[data-dynamic-page-outlet]");
    if (dynamicOutlet) {
      pageScrollFadeObserver.observe(dynamicOutlet);
    }
  }

  queuePageScrollFadeUpdate();
}

function queueActiveContentLayoutSync() {
  if (activeContentLayoutSyncRaf) {
    return;
  }

  activeContentLayoutSyncRaf = window.requestAnimationFrame(() => {
    activeContentLayoutSyncRaf = 0;
    syncContentExpandedHeight();
    if (typeof postStateToSettingsFrame === "function" && state.activeContentPage === "settings") {
      postStateToSettingsFrame();
    }
    queueDashboardHostSizeSync(state.contentCollapsed === true);
  });
}

function syncPreviewStatusReveal() {
  if (!els.previewScroll) {
    return;
  }

  const reveal = clamp(preview.statusReveal || 0, 0, 1);
  preview.statusReveal = reveal;
  const key = reveal.toFixed(4);
  if (preview.statusRevealKey === key) {
    return;
  }
  preview.statusRevealKey = key;
  const hostCard = els.previewCard || els.previewScroll.closest(".preview-card");
  if (hostCard) {
    hostCard.style.setProperty("--preview-status-reveal", key);
    hostCard.classList.toggle("is-status-open", reveal >= 0.98);
  }
}

function addLog(message) {
  const now = new Date();
  state.activityLog.unshift({
    time: now.toLocaleTimeString("zh-CN", { hour12: false }),
    message
  });
  state.activityLog = state.activityLog.slice(0, 12);
  renderLog();
}

function renderLog() {
  els.activityLog.innerHTML = "";
  if (state.activityLog.length === 0) {
    const empty = document.createElement("li");
    empty.className = "activity-item";
    empty.innerHTML = "<time>--:--:--</time><span>暂无最近活动。</span>";
    els.activityLog.appendChild(empty);
    return;
  }

  state.activityLog.forEach((item) => {
    const li = document.createElement("li");
    li.className = "activity-item";
    li.innerHTML = `<time>${item.time}</time><span>${item.message}</span>`;
    els.activityLog.appendChild(li);
  });
}

function clamp(value, min, max) {
  return Math.max(min, Math.min(max, value));
}

function formatSize(width, height) {
  if (!width || !height || width <= 0 || height <= 0) {
    return "N";
  }
  return `${width} x ${height}`;
}

function formatBytes(bytes) {
  const numeric = Number(bytes);
  if (!Number.isFinite(numeric) || numeric <= 0) {
    return "0 B";
  }
  const units = ["B", "KB", "MB", "GB"];
  let value = numeric;
  let unitIndex = 0;
  while (value >= 1024 && unitIndex < units.length - 1) {
    value /= 1024;
    unitIndex += 1;
  }
  const digits = unitIndex === 0 || value >= 100 ? 0 : 1;
  return `${value.toFixed(digits)} ${units[unitIndex]}`;
}

function formatHex(value) {
  const numeric = Number(value);
  if (!Number.isFinite(numeric) || numeric <= 0) {
    return "N";
  }
  return `0x${Math.trunc(numeric).toString(16).toUpperCase()}`;
}

function fileNameFromPath(path) {
  if (!path) {
    return "";
  }
  const parts = path.split(/[/\\]/);
  return parts[parts.length - 1] || path;
}

function toNumber(value, fallback) {
  const numeric = Number(value);
  return Number.isFinite(numeric) ? numeric : fallback;
}

function isHttpProvider() {
  return runtime.provider && runtime.provider.kind === "http";
}

window.ReadSAI2WebUi = window.ReadSAI2WebUi || {};
window.ReadSAI2WebUi.render = render;
window.ReadSAI2WebUi.renderLog = renderLog;
window.ReadSAI2WebUi.addLog = addLog;

let recordSummaryTagSignature = "";

function setActionInFlight(active) {
  runtime.actionInFlight = active;
  renderButtons();
}

function isRecordingActiveOrStarting() {
  return state.recordingState === "recording"
    || state.recordingState === "starting"
    || state.recordingState === "waiting";
}

function hasSavePath() {
  const savePath = typeof state.savePath === "string" ? state.savePath.trim() : "";
  return !!savePath;
}

function isSavePathMissingWhileRecording() {
  const missing = !hasSavePath();
  if (!missing && runtime.savePathWarningActive === true) {
    runtime.savePathWarningActive = false;
  }
  return missing && (isRecordingActiveOrStarting() || runtime.savePathWarningActive === true);
}

function getRecordingLabel() {
  if (isSavePathMissingWhileRecording()) {
    return "未设置输出目录";
  }
  if (state.recordingState === "recording") {
    return "录制中";
  }
  if (state.recordingState === "starting") {
    return "启动中...";
  }
  if (state.recordingState === "waiting") {
    return "等待 SAI2";
  }
  if (state.recordingState === "stopping") {
    return "停止中...";
  }
  return "启动录制";
}

function getStatusPillText() {
  if (!state.backendAvailable && isHttpProvider()) {
    return "Web API 不可用";
  }
  if (!state.connected) {
    if (state.recordingState === "waiting") {
      return "等待 SAI2";
    }
    return "未连接 SAI2";
  }
  if (state.recordingState === "recording") {
    return "已连接 / 录制中";
  }
  if (state.recordingState === "starting" || state.recordingState === "waiting" || state.recordingState === "stopping") {
    return "正在处理录制";
  }
  return "已连接 SAI2";
}

function getStatusSubtext() {
  if (!state.backendAvailable && isHttpProvider()) {
    return "等待 HTTP bridge 恢复";
  }
  const channel = state.updateChannel === "beta" ? "beta" : "stable";
  if (!state.connected) {
    if (state.recordingState === "waiting") {
      return `等待 SAI2 启动后继续录制，当前更新通道 ${channel}`;
    }
    return `等待附着到 SAI2，当前更新通道 ${channel}`;
  }
  return `录制状态跟随运行时更新，当前更新通道 ${channel}`;
}

function getStatusLightLevel(durationMs, sampleAt, fullScaleMs, staleMs, nowMs) {
  if (!Number.isFinite(durationMs) || durationMs <= 0 || !sampleAt) {
    return 0;
  }
  const ageMs = Math.max(0, nowMs - sampleAt);
  if (ageMs >= staleMs) {
    return 0;
  }
  const magnitude = Math.min(1, durationMs / Math.max(1, fullScaleMs));
  const freshness = 1 - (ageMs / Math.max(1, staleMs));
  return clamp(0.25 + (0.75 * Math.sqrt(magnitude)) * freshness, 0, 1);
}

function setStatusLight(lamp, active, level, label) {
  if (!lamp) {
    return;
  }
  const safeLevel = active ? clamp(level, 0, 1) : 0;
  const levelText = safeLevel.toFixed(3);
  const levelPercent = `${Math.round(safeLevel * 100)}%`;
  const glowSize = `${Math.round(5 + (10 * safeLevel))}px`;
  const glowPercent = `${Math.round(safeLevel * 64)}%`;
  const activeClass = safeLevel > 0.02 ? "1" : "0";
  const key = [levelText, levelPercent, glowSize, glowPercent, activeClass, label || ""].join("|");
  if (lamp.dataset.statusLightKey === key) {
    return;
  }
  lamp.dataset.statusLightKey = key;
  lamp.style.setProperty("--status-light-level", levelText);
  lamp.style.setProperty("--status-light-level-percent", levelPercent);
  lamp.style.setProperty("--status-light-glow-size", glowSize);
  lamp.style.setProperty("--status-light-glow-percent", glowPercent);
  lamp.classList.toggle("is-active", activeClass === "1");
  if (label) {
    lamp.setAttribute("title", label);
    lamp.setAttribute("aria-label", label);
  }
}

function renderStatusLights(scheduleNext = true) {
  const nowMs = Date.now();
  const statusOffline = !state.backendAvailable && isHttpProvider();
  const connected = state.connected && !statusOffline;
  const busy = state.recordingState === "starting" || state.recordingState === "waiting" || state.recordingState === "stopping";
  const recording = state.recordingState === "recording";
  const cliLevel = getStatusLightLevel(state.previewReadSendDurationMs, state.previewReadSendSampleAt, 40, 1200, nowMs);
  const uiLevel = getStatusLightLevel(state.previewUiFrameDurationMs, state.previewUiFrameSampleAt, 40, 1200, nowMs);
  const recordLevel = getStatusLightLevel(state.recordingWriteDurationMs, state.recordingWriteSampleAt, 80, 1800, nowMs);
  setStatusLight(
    els.statusConnectLamp || els.statusLamp,
    connected || busy,
    connected ? 0.82 : busy ? 0.48 : 0,
    connected ? "SAI2 已连接" : busy ? "等待 SAI2" : "SAI2 未连接");
  setStatusLight(
    els.statusCliLamp,
    connected,
    cliLevel,
    state.previewReadSendDurationMs > 0 ? `CLI 读发 ${Math.round(state.previewReadSendDurationMs)}ms` : "CLI 读发");
  setStatusLight(
    els.statusUiLamp,
    connected,
    uiLevel,
    state.previewUiFrameDurationMs > 0 ? `UI 上屏 ${Math.round(state.previewUiFrameDurationMs)}ms` : "UI 上屏");
  setStatusLight(
    els.statusRecordLamp,
    connected && recording,
    recordLevel,
    state.recordingWriteDurationMs > 0 ? `录制写入 ${Math.round(state.recordingWriteDurationMs)}ms` : "录制写入");

  if (!scheduleNext) {
    return;
  }
  const shouldContinue = connected && (cliLevel > 0.02 || uiLevel > 0.02 || recordLevel > 0.02);
  if (!shouldContinue || preview.statusLightRaf) {
    return;
  }
  preview.statusLightRaf = window.requestAnimationFrame(() => {
    preview.statusLightRaf = 0;
    renderStatusLights(true);
  });
}

function getVolumeText() {
  if (state.volumeModeIndex === 1) {
    if (state.volumeRecentCount > 0) {
      return `${state.volumeRecentMbPerFrame.toFixed(1)} MB/帧 近${state.volumeRecentCount}帧`;
    }
    return "暂无最近";
  }
  if (state.volumeModeIndex === 2) {
    if (state.volumePreviousCount > 0) {
      return `${state.volumePreviousMbPerFrame.toFixed(1)} MB/帧 上次${state.volumePreviousCount}帧`;
    }
    return "暂无上次";
  }
  return `${state.volumeEstimateMbPerFrame.toFixed(1)} MB/帧`;
}

function getRecordingSizeSummary() {
  if (state.recordingRuntimeRank === "-1") {
    return `自动 ${formatRecordingPresetLongSideLabel(state.recordTargetLongSide)}`;
  }

  const option = createRuntimeRankOptions().find((item) => item.value === state.recordingRuntimeRank);
  return option ? option.label : `L${state.recordingRuntimeRank}`;
}

function getRecordSummary() {
  if (typeof state.recordingPresetSummary === "string" && state.recordingPresetSummary.trim()) {
    return state.recordingPresetSummary.trim();
  }

  if (isHttpProvider()) {
    if (!state.backendAvailable) {
      return "Waiting for the local HTTP bridge";
    }
    if (state.recordingState === "recording") {
      const lossless = normalizeRecordingCodecMode(state.recordingCodecMode, state.recordingCodecId) === "lossless";
      const modeLabel = lossless ? "无损" : "精简";
      const qualityText = lossless ? "" : ` / 质量=${state.quality}`;
      return `${modeLabel} / ${getRecordingSizeSummary()} / step=${state.stepInterval}${qualityText}`;
    }
    if (state.recordingState === "starting") {
      return "正在准备录制会话";
    }
    if (state.recordingState === "waiting") {
      return "等待 SAI2 启动";
    }
    if (state.recordingState === "stopping") {
      return "正在等待 CLI 停止录制";
    }
    return "待机";
  }

  if (state.recordingState === "recording" && state.sessionStartedAt) {
    const elapsedSeconds = Math.max(1, Math.floor((Date.now() - state.sessionStartedAt) / 1000));
    return `${state.frameCount} frames / ${elapsedSeconds}s / ${getRecordingSizeSummary()} / step=${state.stepInterval}`;
  }
  if (state.recordingState === "starting") {
    return "正在准备录制会话";
  }
  if (state.recordingState === "waiting") {
    return "等待 SAI2 启动";
  }
  if (state.recordingState === "stopping") {
    return "正在停止录制会话";
  }
  return "待机";
}

function getRecordingPresetSummaryTags() {
  const config = state.recordingPresetConfig && typeof state.recordingPresetConfig === "object"
    ? state.recordingPresetConfig
    : null;
  const fallbackParts = parseRecordSummaryText(getRecordSummary());
  const codecId = config ? Number(config.codec_id) : Number(state.recordingCodecId);
  const lossless = codecId === 8 || codecId === 3
    || (!config && normalizeRecordingCodecMode(state.recordingCodecMode, codecId) === "lossless");
  const runtimeRank = config
    ? Math.trunc(toNumber(config.runtime_surface_rank, -1))
    : Math.trunc(toNumber(state.recordingRuntimeRank, -1));
  const resolution = config
    ? getRecordingPresetResolutionSummary(config, runtimeRank)
    : (fallbackParts.resolution || getRecordingSizeSummary());
  const codec = config ? getRecordingCodecSummaryLabel(codecId) : (fallbackParts.codec || getRecordingCodecSummaryLabel(codecId));
  const quality = lossless ? "无损" : (config ? String(config.jpeg_quality) : (fallbackParts.quality || String(state.quality)));
  const interval = config ? String(config.step_interval) : (fallbackParts.interval || String(state.stepInterval));

  return [
    { key: "resolution", label: "分辨率", value: resolution, tone: "resolution" },
    { key: "codec", label: "编码", value: codec, tone: "codec" },
    { key: "quality", label: "质量", value: quality, tone: "quality", slider: !lossless },
    { key: "interval", label: "间隔", value: interval, tone: "interval" },
    { key: "volume", label: "体积", value: getVolumeText(), tone: "volume" }
  ];
}

function getRecordingPresetResolutionSummary(config, runtimeRank) {
  if (runtimeRank >= 0) {
    return getRecordingPresetRuntimeLabel(runtimeRank);
  }
  const longSide = config && config.record_target_long_side
    ? config.record_target_long_side
    : state.recordTargetLongSide;
  return `自动 ${formatRecordingPresetLongSideLabel(longSide)}`;
}

function formatRecordingPresetLongSideLabel(value) {
  const longSide = Math.max(256, Math.trunc(toNumber(value, 2048)));
  return longSide % 1024 === 0
    ? `${longSide / 1024}k`
    : String(longSide);
}

function getRecordingPresetRuntimeLabel(rank) {
  const index = Math.max(0, Math.trunc(toNumber(rank, 0)));
  const option = createRuntimeRankOptions().find((item) => item.value === String(index));
  const levelLabel = option && option.label ? option.label : `L${index}`;
  const runtimeLabels = ["固定最高", "1/2分辨率", "1/4分辨率", "1/8分辨率"];
  return runtimeLabels[index]
    ? `${runtimeLabels[index]} (${levelLabel})`
    : levelLabel;
}

function getCurrentRecordingPresetConfig() {
  const source = state.recordingPresetConfig && typeof state.recordingPresetConfig === "object"
    ? state.recordingPresetConfig
    : {};
  const resolutionMode = source.resolution_mode === "long_side" ? "long_side" : "highest";
  const runtimeRankSource = Object.prototype.hasOwnProperty.call(source, "runtime_surface_rank")
    ? source.runtime_surface_rank
    : state.recordingRuntimeRank;
  return {
    resolution_mode: resolutionMode,
    record_target_long_side: Math.max(256, Math.trunc(toNumber(source.record_target_long_side, state.recordTargetLongSide || 2048))),
    runtime_surface_rank: resolutionMode === "long_side"
      ? -1
      : Math.max(-1, Math.trunc(toNumber(runtimeRankSource, -1))),
    step_interval: Math.max(1, Math.trunc(toNumber(source.step_interval, state.stepInterval || 1))),
    codec_id: Math.max(0, Math.trunc(toNumber(source.codec_id, state.recordingCodecId || 0))),
    jpeg_quality: Math.max(1, Math.min(100, Math.trunc(toNumber(source.jpeg_quality, state.quality || 95))))
  };
}

function getRecordingPresetTagOptions(item) {
  const config = getCurrentRecordingPresetConfig();
  if (!item || !item.key) {
    return [];
  }

  if (item.key === "resolution") {
    const longSideValues = [1024, 2048, 3072, 4096];
    const runtimeRankOptions = createRuntimeRankOptions()
      .filter((option) => {
        const rank = Math.trunc(toNumber(option.value, -1));
        return rank >= 0 && rank <= 3;
      })
      .map((option) => Math.trunc(toNumber(option.value, -1)));
    return [
      ...longSideValues.map((value) => ({
        value: `long_side:${value}`,
        label: `自动 ${formatRecordingPresetLongSideLabel(value)}`,
        direction: "up"
      })),
      ...runtimeRankOptions.map((rank) => ({
        value: `runtime:${rank}`,
        label: getRecordingPresetRuntimeLabel(rank),
        direction: "down"
      }))
    ];
  }

  if (item.key === "codec") {
    const currentCodecId = Number(config.codec_id);
    const options = state.previewDeveloperMode
      ? recordingPresetTagCodecOptions.slice()
      : recordingPresetTagCodecOptions.filter((option) => recordingPresetPrimaryCodecIds.has(Number(option.value)));
    if (currentCodecId > 0 && !options.some((option) => option.value === currentCodecId)) {
      options.push({ value: currentCodecId, label: getRecordingCodecSummaryLabel(currentCodecId) });
    }
    return options.map((option) => ({
      value: String(option.value),
      label: option.label
    }));
  }

  if (item.key === "quality") {
    const currentQuality = Math.max(1, Math.min(100, config.jpeg_quality));
    return Array.from(new Set([...recordingPresetTagQualityValues, currentQuality]))
      .sort((left, right) => left - right)
      .map((value) => ({
        value: String(value),
        label: String(value)
      }));
  }

  if (item.key === "interval") {
    const currentInterval = Math.max(1, config.step_interval);
    return Array.from(new Set([...recordingPresetTagStepIntervalValues, currentInterval]))
      .sort((left, right) => left - right)
      .map((value) => ({
        value: String(value),
        label: String(value)
      }));
  }

  if (item.key === "volume") {
    return recordingPresetTagVolumeOptions.map((option) => ({
      value: String(option.value),
      label: option.label
    }));
  }

  return [];
}

function getRecordingPresetTagCurrentValue(item) {
  const config = getCurrentRecordingPresetConfig();
  if (!item || !item.key) {
    return "";
  }

  if (item.key === "resolution") {
    const runtimeRank = Math.trunc(toNumber(config.runtime_surface_rank, state.recordingRuntimeRank || -1));
    if (runtimeRank >= 0) {
      return `runtime:${runtimeRank}`;
    }
    return `long_side:${config.record_target_long_side}`;
  }
  if (item.key === "codec") {
    return String(config.codec_id);
  }
  if (item.key === "quality") {
    return String(config.jpeg_quality);
  }
  if (item.key === "interval") {
    return String(config.step_interval);
  }
  if (item.key === "volume") {
    return String(clamp(Math.trunc(toNumber(state.volumeModeIndex, 0)), 0, 2));
  }
  return "";
}

function parseRecordSummaryText(text) {
  const parts = String(text || "").split("/").map((part) => part.trim()).filter(Boolean);
  const result = {};
  parts.forEach((part) => {
    if (/^(质量|quality)/i.test(part)) {
      result.quality = part.replace(/^(质量|quality)\s*[=:]?\s*/i, "").trim();
    } else if (/^(间隔|step)/i.test(part)) {
      result.interval = part.replace(/^(间隔|step)\s*[=:]?\s*/i, "").trim();
    } else if (!result.resolution) {
      result.resolution = part;
    } else if (!result.codec) {
      result.codec = part;
    }
  });
  return result;
}

function getRecordingCodecSummaryLabel(codecId) {
  switch (Number(codecId)) {
    case 8:
      return "无损";
    case 3:
      return "BGRA 无损";
    case 7:
      return "Patch JPEG";
    case 6:
      return "旧精简";
    case 5:
      return "自适应 JPEG";
    case 2:
      return "Lane Zstd";
    case 1:
      return "旧 Zstd";
    default:
      return Number(codecId) === 8 || Number(codecId) === 3 ? "无损" : "精简";
  }
}

function getOrderedRecordingPresetTagOptions(item, options, currentValue) {
  if (item && item.key === "resolution") {
    const directionCounts = { up: 0, down: 0 };
    return options
      .filter((option) => option.value !== currentValue)
      .map((option) => {
        const direction = option.direction === "down" ? "down" : "up";
        const directionIndex = directionCounts[direction] || 0;
        directionCounts[direction] = directionIndex + 1;
        return {
          ...option,
          direction,
          directionIndex
        };
      });
  }

  const currentIndex = Math.max(0, options.findIndex((option) => option.value === currentValue));
  const orderedOptions = [
    ...options.slice(0, currentIndex).reverse().map((option) => ({ ...option, direction: "up" })),
    ...options.slice(currentIndex + 1).map((option) => ({ ...option, direction: "down" }))
  ];
  const directionCounts = { up: 0, down: 0 };
  return orderedOptions.map((option) => {
    const directionIndex = directionCounts[option.direction] || 0;
    directionCounts[option.direction] = directionIndex + 1;
    return {
      ...option,
      directionIndex
    };
  });
}

function getWebUiPerfSummary() {
  const session = preview.session && preview.session.width > 0 && preview.session.height > 0
    ? preview.session
    : null;
  const previewLabel = session
    ? `${formatSize(session.width, session.height)} / ${session.tilesX}x${session.tilesY} tiles`
    : "预览等待";
  const tileText = state.previewTileCount > 0
    ? `${state.previewTileCount} tiles ${formatBytes(state.previewTileBytes)}`
    : "tiles 0";
  const parts = [previewLabel, tileText];
  const latencyParts = [];

  if (state.previewReadSendDurationMs > 0) {
    latencyParts.push(`读发 ${Math.round(state.previewReadSendDurationMs)}ms`);
  }
  if (state.previewTileIntervalMs > 0) {
    latencyParts.push(`到达 ${Math.round(state.previewTileIntervalMs)}ms`);
  }
  if (state.previewTickGapMs > 0 || state.previewTickDurationMs > 0) {
    const gap = Math.max(0, Math.round(state.previewTickGapMs || 0));
    const duration = Math.max(0, Math.round(state.previewTickDurationMs || 0));
    latencyParts.push(`tick ${gap}/${duration}ms`);
  }
  if (state.recordingWriteDurationMs > 0 && state.recordingState !== "idle") {
    latencyParts.push(`写入 ${Math.round(state.recordingWriteDurationMs)}ms`);
  }
  if (latencyParts.length > 0) {
    parts.push(latencyParts.join(" / "));
  }

  if (state.recordingState === "recording") {
    parts.push(`${state.frameCount} frames`);
  }

  return parts.join(" | ");
}

function renderRecordSummaryTags() {
  if (!els.recordSummaryLabel) {
    return;
  }

  const items = getRecordingPresetSummaryTags();
  const signature = JSON.stringify(items.map((item) => ({
    key: item.key,
    value: item.value,
    current: getRecordingPresetTagCurrentValue(item),
    options: getRecordingPresetTagOptions(item).map((option) => ({
      value: option.value,
      label: option.label,
      direction: option.direction || ""
    }))
  })));
  if (recordSummaryTagSignature === signature) {
    return;
  }
  if (els.recordSummaryLabel.querySelector(".record-preset-tag-shell:hover, .record-preset-tag-shell.is-menu-open")) {
    return;
  }
  recordSummaryTagSignature = signature;

  els.recordSummaryLabel.replaceChildren();
  items.forEach((item) => {
    const options = getRecordingPresetTagOptions(item);
    const currentValue = getRecordingPresetTagCurrentValue(item);

    const shell = document.createElement("span");
    shell.className = `record-preset-tag-shell is-${item.tone}`;
    shell.dataset.presetTagShell = item.key;

    const tag = document.createElement("button");
    tag.className = `record-preset-tag is-${item.tone}`;
    tag.type = "button";
    tag.dataset.presetTag = item.key;
    tag.dataset.currentValue = currentValue;
    tag.dataset.hostDragIgnore = "true";
    tag.setAttribute("aria-haspopup", "menu");
    tag.setAttribute("aria-expanded", "false");
    tag.setAttribute("title", `${item.label} ${item.value || "-"}`);

    const key = document.createElement("span");
    key.className = "record-preset-tag-key";
    key.textContent = item.label;

    const value = document.createElement("span");
    value.className = "record-preset-tag-value";
    value.textContent = item.value || "-";

    tag.append(key, value);
    shell.appendChild(tag);

    if (options.length > 0) {
      const menu = document.createElement("span");
      menu.className = "record-preset-tag-menu";
      menu.dataset.hostDragIgnore = "true";
      menu.setAttribute("role", "menu");
      menu.setAttribute("aria-label", item.label);

      if (item.key === "quality" && item.slider) {
        menu.classList.add("has-quality-slider");
        const sliderWrap = document.createElement("span");
        sliderWrap.className = "record-preset-quality-slider";

        const slider = document.createElement("input");
        slider.className = "record-preset-quality-input";
        slider.type = "range";
        slider.min = "60";
        slider.max = "100";
        slider.step = "5";
        slider.value = currentValue;
        slider.setAttribute("orient", "vertical");
        slider.setAttribute("aria-label", "质量");
        slider.dataset.presetTagInput = "quality";

        const ticks = document.createElement("span");
        ticks.className = "record-preset-quality-ticks";
        options.slice().reverse().forEach((option) => {
          const optionValue = Math.max(60, Math.min(100, Number(option.value)));
          const tick = document.createElement("span");
          tick.className = "record-preset-quality-tick";
          tick.textContent = option.label;
          tick.dataset.value = option.value;
          tick.dataset.hostDragIgnore = "true";
          tick.style.setProperty("--quality-tick-position", `${((optionValue - 60) / 40) * 100}%`);
          tick.classList.toggle("is-current", option.value === currentValue);
          tick.tabIndex = 0;
          ticks.appendChild(tick);
        });

        sliderWrap.append(slider, ticks);
        menu.appendChild(sliderWrap);
      } else {
        menu.classList.add("has-discrete-options");
        const orderedTagOptions = getOrderedRecordingPresetTagOptions(item, options, currentValue);
        const tagOptionCounts = orderedTagOptions.reduce((counts, option) => {
          const direction = option.direction === "down" ? "down" : "up";
          counts[direction] += 1;
          return counts;
        }, { up: 0, down: 0 });
        menu.style.setProperty("--tag-up-count", String(tagOptionCounts.up));
        menu.style.setProperty("--tag-down-count", String(tagOptionCounts.down));
        menu.classList.toggle("has-up-options", tagOptionCounts.up > 0);
        menu.classList.toggle("has-down-options", tagOptionCounts.down > 0);
        orderedTagOptions.forEach((option) => {
          const optionButton = document.createElement("span");
          optionButton.className = `record-preset-tag-option is-${option.direction}`;
          optionButton.dataset.value = option.value;
          optionButton.dataset.hostDragIgnore = "true";
          optionButton.tabIndex = 0;
          optionButton.setAttribute("role", "menuitem");
          optionButton.textContent = option.label;
          optionButton.style.setProperty("--tag-option-index", String(option.directionIndex || 0));
          menu.appendChild(optionButton);
        });
      }

      shell.appendChild(menu);
    }

    els.recordSummaryLabel.appendChild(shell);
  });
}

function renderButtons() {
  const label = getRecordingLabel();
  const missingSavePath = isSavePathMissingWhileRecording();
  const key = [
    label,
    runtime.actionInFlight ? 1 : 0,
    state.recordingState,
    missingSavePath ? 1 : 0
  ].join("|");
  if (renderCache.buttonsKey === key) {
    return;
  }
  renderCache.buttonsKey = key;
  [els.topRecordButton, els.overlayRecordButton].filter(Boolean).forEach((button) => {
    button.textContent = label;
    button.disabled = runtime.actionInFlight;
    button.classList.toggle("is-recording", state.recordingState === "recording");
    button.classList.toggle("is-warning", missingSavePath);
  });
}

function renderHeader() {
  if (els.perfLabelText) {
    const webUiPerfText = getWebUiPerfSummary();
    const fallbackText = typeof state.perfLabel === "string" && state.perfLabel.trim()
      ? state.perfLabel.trim()
      : "";
    const perfText = webUiPerfText || fallbackText || "WebUI 待机";
    if (renderCache.headerText === perfText) {
      return;
    }
    renderCache.headerText = perfText;
    els.perfLabelText.textContent = perfText;
  }
}

function getDashboardContentTargetSize(collapsed) {
  const root = document.documentElement;
  const appShell = els.appShell;
  if (!root || !appShell) {
    return null;
  }

  const currentHeight = Math.max(root.clientHeight || 0, window.innerHeight || 0);
  const computedStyle = window.getComputedStyle(appShell);
  const paddingTop = parseFloat(computedStyle.paddingTop) || 0;
  const paddingBottom = parseFloat(computedStyle.paddingBottom) || 0;
  const mastheadHeight = els.masthead
    ? Math.ceil(els.masthead.offsetHeight || els.masthead.getBoundingClientRect().height || 0)
    : 0;
  const targetHeight = collapsed
    ? Math.ceil(paddingTop + mastheadHeight + paddingBottom)
    : Math.ceil(currentHeight);

  return {
    width: Math.ceil(Math.max(root.clientWidth || 0, window.innerWidth || 0)),
    height: Math.max(1, targetHeight),
    viewportHeight: Math.ceil(currentHeight),
    devicePixelRatio: window.devicePixelRatio || 1,
    collapsed
  };
}

function syncContentExpandedHeight() {
  if (!els.pageScrollRoot) {
    return;
  }

  const root = document.documentElement;
  const appShell = els.appShell;
  const viewportHeight = Math.max(root ? root.clientHeight || 0 : 0, window.innerHeight || 0);
  if (!appShell || viewportHeight <= 0) {
    return;
  }

  const computedStyle = window.getComputedStyle(appShell);
  const paddingTop = parseFloat(computedStyle.paddingTop) || 0;
  const paddingBottom = parseFloat(computedStyle.paddingBottom) || 0;
  const gap = state.contentCollapsed === true ? 0 : parseFloat(computedStyle.rowGap || computedStyle.gap) || 0;
  const mastheadHeight = els.masthead
    ? Math.ceil(els.masthead.offsetHeight || els.masthead.getBoundingClientRect().height || 0)
    : 0;
  const availableHeight = Math.max(1, Math.floor(viewportHeight - paddingTop - paddingBottom - mastheadHeight - gap));
  dashboardContentExpandedHeight = availableHeight;
  els.pageScrollRoot.style.setProperty("--content-expanded-height", `${availableHeight}px`);
}

function queueDashboardHostSizeSync(collapsed) {
  if (typeof postHostCommand !== "function") {
    return;
  }
  if (collapsed && dashboardHostManualResizeUntil > performance.now()) {
    return;
  }
  if (collapsed && dashboardHostResizeSuppressUntil > performance.now()) {
    return;
  }

  clearDashboardHostSizeSyncQueue();

  const token = ++dashboardHostSizeSyncToken;
  const changed = dashboardContentCollapsedLast !== null && dashboardContentCollapsedLast !== collapsed;
  dashboardContentCollapsedLast = collapsed;
  if (changed && collapsed) {
    dashboardContentCollapseSettlesAt = performance.now() + 560;
  } else if (!collapsed) {
    dashboardContentCollapseSettlesAt = 0;
  }

  const now = performance.now();
  const remainingCollapseMs = collapsed && dashboardContentCollapseSettlesAt > now
    ? Math.max(0, Math.ceil(dashboardContentCollapseSettlesAt - now))
    : 0;
  const delays = changed
    ? (collapsed ? [460, 560] : [0, 90, 220, 460, 560])
    : (remainingCollapseMs > 0 ? [remainingCollapseMs] : [0, 180]);

  const sync = (phase) => {
    const rafId = window.requestAnimationFrame(() => {
      dashboardHostSizeSyncRafs = dashboardHostSizeSyncRafs.filter((id) => id !== rafId);
      if (token !== dashboardHostSizeSyncToken) {
        return;
      }
      const size = getDashboardContentTargetSize(collapsed);
      if (!size) {
        return;
      }

      if (!collapsed) {
        dashboardExpandedHostHeight = size.height;
      } else {
        if (dashboardExpandedHostHeight <= 0 && size.viewportHeight > size.height) {
          dashboardExpandedHostHeight = size.viewportHeight;
        }
        if (dashboardExpandedHostHeight > 0) {
          size.expandedHeight = dashboardExpandedHostHeight;
        }
      }

      const key = `${size.width}x${size.height}:${collapsed ? 1 : 0}:${size.expandedHeight || 0}`;
      if (key === dashboardHostSizeSyncKey) {
        return;
      }

      dashboardHostSizeSyncKey = key;
      postHostCommand("sync-dashboard-content-size", size);
    });
    dashboardHostSizeSyncRafs.push(rafId);
  };

  delays.forEach((delay, index) => {
    const phase = index === 0 ? "initial" : "settle";
    if (delay <= 0) {
      sync(phase);
      return;
    }

    const timerId = window.setTimeout(() => {
      dashboardHostSizeSyncTimers = dashboardHostSizeSyncTimers.filter((id) => id !== timerId);
      if (token === dashboardHostSizeSyncToken) {
        sync(phase);
      }
    }, delay);
    dashboardHostSizeSyncTimers.push(timerId);
  });
}

function renderContentNavigation() {
  const activePage = state.activeContentPage === "settings" ? "settings" : "dashboard";
  state.activeContentPage = activePage;
  const collapsed = state.contentCollapsed === true;
  const settingsContentVisible = activePage === "settings";
  const settingsPageLoadReady = state.settingsPageLoadReady === true;
  const activeSettingsKey = Object.prototype.hasOwnProperty.call(embeddedSettingsPages, state.activeSettingsPage)
    ? state.activeSettingsPage
    : "";
  const activeSettingsSpec = activeSettingsKey
    ? embeddedSettingsPages[activeSettingsKey]
    : embeddedSettingsPages.blank;
  const loadedSettingsSpec = settingsPageLoadReady ? activeSettingsSpec : embeddedSettingsPages.blank;
  const hasInlineSettingsContent = !!(settingsPageLoadReady && loadedSettingsSpec.inlineModule);
  const isImmersiveSettings = settingsContentVisible && loadedSettingsSpec.immersive === true && !hasInlineSettingsContent;
  const key = [
    activePage,
    collapsed ? 1 : 0,
    state.controlRailCollapsed === true ? 1 : 0,
    settingsPageLoadReady ? 1 : 0,
    activeSettingsKey,
    loadedSettingsSpec.url || "",
    loadedSettingsSpec.inlineModule || "",
    isImmersiveSettings ? 1 : 0
  ].join("|");
  if (renderCache.contentNavigationKey === key) {
    return;
  }
  renderCache.contentNavigationKey = key;
  const setPanelState = (panel, panelName) => {
    if (!panel) {
      return;
    }

    const isActive = activePage === panelName;
    panel.hidden = false;
    panel.inert = collapsed || !isActive;
    panel.classList.toggle("is-active", isActive);
    panel.setAttribute("aria-hidden", !collapsed && isActive ? "false" : "true");
  };

  if (els.pageScrollRoot) {
    const dashboardActive = !collapsed && activePage === "dashboard";
    els.pageScrollRoot.hidden = false;
    els.pageScrollRoot.inert = collapsed;
    els.pageScrollRoot.classList.toggle("is-collapsed", collapsed);
    els.pageScrollRoot.classList.toggle("is-dashboard-active", dashboardActive);
    if (dashboardActive && els.pageScrollRoot.scrollTop !== 0) {
      els.pageScrollRoot.scrollTop = 0;
    }
    els.pageScrollRoot.setAttribute("aria-hidden", collapsed ? "true" : "false");
  }
  if (els.appShell) {
    els.appShell.classList.toggle("is-content-collapsed", collapsed);
    els.appShell.classList.toggle("is-control-rail-collapsed", state.controlRailCollapsed === true);
  }
  syncContentExpandedHeight();

  if (els.contentCollapseButton) {
    const contentCollapseLabel = collapsed ? "展开主界面" : "折叠主界面";
    const label = els.contentCollapseButton.querySelector(".content-collapse-label");
    if (label) {
      label.textContent = collapsed ? "展开" : "折叠";
    } else {
      els.contentCollapseButton.textContent = collapsed ? "展开" : "折叠";
    }
    els.contentCollapseButton.setAttribute("aria-expanded", collapsed ? "false" : "true");
    els.contentCollapseButton.setAttribute("aria-label", contentCollapseLabel);
    els.contentCollapseButton.title = contentCollapseLabel;
  }

  if (els.controlRailCollapseButton) {
    els.controlRailCollapseButton.setAttribute("aria-expanded", state.controlRailCollapsed === true ? "false" : "true");
    els.controlRailCollapseButton.setAttribute("aria-label", "收起侧面板");
    els.controlRailCollapseButton.title = "收起侧面板";
    els.controlRailCollapseButton.tabIndex = state.controlRailCollapsed === true ? -1 : 0;
  }

  if (els.controlRailExpandButton) {
    els.controlRailExpandButton.setAttribute("aria-expanded", state.controlRailCollapsed === true ? "false" : "true");
    els.controlRailExpandButton.setAttribute("aria-label", "展开侧面板");
    els.controlRailExpandButton.title = "展开侧面板";
    els.controlRailExpandButton.tabIndex = state.controlRailCollapsed === true ? 0 : -1;
  }

  if (els.contentPageTrack) {
    els.contentPageTrack.dataset.activePage = activePage;
    els.contentPageTrack.style.setProperty("--content-page-index", activePage === "settings" ? "1" : "0");
  }

  setPanelState(els.dashboardPage, "dashboard");
  setPanelState(els.settingsPage, "settings");
  if (els.settingsPage) {
    els.settingsPage.classList.toggle("is-immersive-settings", isImmersiveSettings);
  }

  if (els.settingsPageHeading) {
    els.settingsPageHeading.hidden = settingsContentVisible && settingsPageLoadReady && activeSettingsKey === "customBrush";
  }

  if (els.settingsPageKicker) {
    els.settingsPageKicker.textContent = activeSettingsSpec.kicker || "设置";
  }

  if (els.settingsPageTitle) {
    els.settingsPageTitle.textContent = activeSettingsSpec.title || "预留设置页";
  }

  if (els.settingsPageEmpty) {
    els.settingsPageEmpty.hidden = !settingsContentVisible || !settingsPageLoadReady || hasInlineSettingsContent || !!loadedSettingsSpec.url;
  }

  if (els.settingsPageInline) {
    els.settingsPageInline.hidden = !hasInlineSettingsContent;
  }

  if (els.settingsPageFrame) {
    const nextUrl = settingsPageLoadReady && activeSettingsKey && !hasInlineSettingsContent ? loadedSettingsSpec.url || "" : "";
    els.settingsPageFrame.hidden = !nextUrl;
    if (nextUrl && els.settingsPageFrame.getAttribute("src") !== nextUrl) {
      els.settingsPageFrame.setAttribute("src", nextUrl);
    } else if (!nextUrl && els.settingsPageFrame.hasAttribute("src")) {
      els.settingsPageFrame.removeAttribute("src");
    }
  }

  if (els.contentPageSwitchButton) {
    els.contentPageSwitchButton.textContent = "切换内容页";
    els.contentPageSwitchButton.setAttribute("aria-pressed", activePage === "settings" ? "true" : "false");
  }

  queueActiveContentLayoutSync();
}

function renderStatus() {
  const key = [
    state.backendAvailable ? 1 : 0,
    state.connected ? 1 : 0,
    state.recordingState,
    state.savePath || "",
    runtime.savePathWarningActive ? 1 : 0
  ].join("|");
  if (renderCache.statusKey === key) {
    return;
  }
  renderCache.statusKey = key;
  els.connectionBadge.textContent = getStatusPillText();
  els.connectionBadge.classList.toggle("is-offline", !state.connected || (!state.backendAvailable && isHttpProvider()));
  els.connectionBadge.classList.toggle("is-busy", state.recordingState === "starting" || state.recordingState === "waiting" || state.recordingState === "stopping");
  if (els.statusSubtext) {
    els.statusSubtext.textContent = getStatusSubtext();
  }
  els.recordingStateLabel.textContent = state.recordingState === "idle" ? "待机" : getRecordingLabel();
  renderStatusLights(true);
}

function renderRecordingFields() {
  if (!els.recordingPresetSelect) {
    return;
  }

  const options = createRecordingPresetOptions();
  const key = `${state.currentPresetId || ""}|${JSON.stringify(options)}`;
  if (renderCache.recordingFieldsKey === key) {
    return;
  }
  renderCache.recordingFieldsKey = key;
  setSelectOptions(els.recordingPresetSelect, options, state.currentPresetId || "");
  state.currentPresetId = els.recordingPresetSelect.value;
}

function renderPathField() {
  const savePath = state.savePath || "";
  const key = `${savePath}|${runtime.savePathWarningActive ? 1 : 0}`;
  if (renderCache.pathFieldKey === key) {
    return;
  }
  renderCache.pathFieldKey = key;
  els.savePathInput.value = savePath;
  if (els.browsePathButton) {
    const savePathLabel = typeof savePath === "string" ? savePath.trim() : "";
    const pathLabel = els.browsePathButton.querySelector(".recording-path-label");
    if (pathLabel) {
      pathLabel.textContent = savePathLabel || "输出目录";
    }
    els.browsePathButton.title = savePathLabel || "输出目录";
  }
}

function renderCurrentFileField() {
  const currentFileLabel = state.connected ? state.currentFile : "未连接 SAI2";
  const key = [
    state.connected ? 1 : 0,
    currentFileLabel || "",
    state.recordingPresetSummary || "",
    JSON.stringify(state.recordingPresetConfig || null),
    state.recordingRuntimeRank,
    state.recordTargetLongSide,
    state.stepInterval,
    state.recordingCodecId,
    state.quality,
    state.volumeModeIndex,
    state.volumeEstimateMbPerFrame,
    state.volumeRecentMbPerFrame,
    state.volumePreviousMbPerFrame,
    state.volumeRecentCount,
    state.volumePreviousCount
  ].join("|");
  if (renderCache.currentFileKey === key) {
    return;
  }
  renderCache.currentFileKey = key;
  const currentFileTitle = els.currentFileLabel ? els.currentFileLabel.closest(".current-file-title") : null;
  els.currentFileLabel.textContent = currentFileLabel;
  if (currentFileTitle) {
    currentFileTitle.classList.toggle("is-offline", !state.connected);
  }
  if (window.ReadSAI2WebUi && typeof window.ReadSAI2WebUi.refreshCurrentFileTitleOverflow === "function") {
    window.ReadSAI2WebUi.refreshCurrentFileTitleOverflow();
  }
  if (els.openedFileNameLabel) {
    els.openedFileNameLabel.textContent = currentFileLabel;
  }
  if (els.recordSummaryLabel) {
    renderRecordSummaryTags();
  }
}

function renderProcessFields() {
  const pointerText = state.connected ? `${Math.round(state.pointerX)}, ${Math.round(state.pointerY)}` : "N";
  const statusOffline = !state.backendAvailable && isHttpProvider();
  const key = [
    state.backendAvailable ? 1 : 0,
    state.connected ? 1 : 0,
    state.processName || "",
    state.processBaseAddress || "",
    state.processId || "",
    state.canvasSize || "",
    pointerText,
    statusOffline ? 1 : 0
  ].join("|");
  if (renderCache.processFieldsKey === key) {
    return;
  }
  renderCache.processFieldsKey = key;
  if (statusOffline) {
    els.processNameLabel.textContent = "Web API 不可用";
    els.processBaseAddressLabel.textContent = "N";
    els.processIdLabel.textContent = "N";
    els.canvasSizeLabel.textContent = "N";
    els.pointerLabel.textContent = "N";
  } else {
    els.processNameLabel.textContent = state.connected ? state.processName : "SAI2 未连接";
    els.processBaseAddressLabel.textContent = state.connected ? state.processBaseAddress : "N";
    els.processIdLabel.textContent = state.connected ? state.processId : "N";
    els.canvasSizeLabel.textContent = state.connected ? state.canvasSize : "N";
    els.pointerLabel.textContent = pointerText;
  }
}

function renderToggleFields() {
  const key = [
    state.webuiAlwaysOnTop ? 1 : 0,
    state.autoLaunch ? 1 : 0,
    state.doNotMinimizeToTray ? 1 : 0,
    state.navigatorAutoResize ? 1 : 0,
    state.updateChannel,
    state.customBrushOverlay ? 1 : 0,
    state.previewDeveloperMode ? 1 : 0,
    state.runtimeSurfaceFixedRefresh ? 1 : 0,
    state.previewDirtyRectVisible ? 1 : 0,
    state.previewPointerOverlayVisible ? 1 : 0,
    state.activityLogVisible ? 1 : 0,
    state.statusLightGroupVisible ? 1 : 0,
  ].join("|");
  if (renderCache.toggleFieldsKey === key) {
    return;
  }
  renderCache.toggleFieldsKey = key;
  if (els.webuiAlwaysOnTopToggle) {
    els.webuiAlwaysOnTopToggle.checked = state.webuiAlwaysOnTop;
    if (els.masthead) {
      els.masthead.classList.toggle("is-webui-pinned", state.webuiAlwaysOnTop);
    }
    const mastheadPinToggle = els.webuiAlwaysOnTopToggle.closest(".masthead-pin-toggle");
    if (mastheadPinToggle) {
      const pinTitle = state.webuiAlwaysOnTop ? "取消 WebUI 置顶" : "WebUI 置顶";
      mastheadPinToggle.title = pinTitle;
      mastheadPinToggle.setAttribute("aria-label", pinTitle);
    }
  }
  els.autoLaunchToggle.checked = state.autoLaunch;
  els.doNotMinimizeToTrayToggle.checked = state.doNotMinimizeToTray;
  if (els.navigatorResizeToggle) {
    els.navigatorResizeToggle.checked = state.navigatorAutoResize;
  }
  els.updateChannelSelect.value = state.updateChannel;
  els.customBrushOverlayToggle.checked = state.customBrushOverlay;
  els.previewDeveloperModeToggle.checked = state.previewDeveloperMode;
  if (els.advancedCard) {
    const showAdvancedCard = state.previewDeveloperMode === true;
    els.advancedCard.hidden = !showAdvancedCard;
    els.advancedCard.inert = !showAdvancedCard;
  }
  if (els.hostBackdropButton) {
    const showHostBackdropButton = state.previewDeveloperMode === true;
    els.hostBackdropButton.hidden = !showHostBackdropButton;
    els.hostBackdropButton.inert = !showHostBackdropButton;
    if (!els.hostBackdropButton.title) {
      els.hostBackdropButton.title = "切换窗口背景效果";
      els.hostBackdropButton.setAttribute("aria-label", "切换窗口背景效果");
    }
  }
  els.runtimeSurfaceFixedRefreshToggle.checked = state.runtimeSurfaceFixedRefresh;
  els.previewDirtyRectToggle.checked = state.previewDirtyRectVisible;
  if (els.previewPointerOverlayToggle) {
    els.previewPointerOverlayToggle.checked = state.previewPointerOverlayVisible;
  }
  els.activityLogToggle.checked = state.activityLogVisible;
  if (els.activityCard) {
    els.activityCard.hidden = !state.activityLogVisible;
  }
  els.statusLightGroupToggle.checked = state.statusLightGroupVisible;
  syncAllCustomSelects();
}

function renderFields() {
  renderRecordingFields();
  renderPathField();
  renderCurrentFileField();
  renderProcessFields();
  renderToggleFields();
}

const themeIconSvg = {
  theme: `
    <span class="theme-mode-icon theme-icon-stack" aria-hidden="true">
      <svg class="theme-lucide-icon theme-symbol theme-symbol-sun" xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
          <circle cx="12" cy="12" r="4"></circle>
          <path d="M12 2v2"></path>
          <path d="M12 20v2"></path>
          <path d="m4.93 4.93 1.41 1.41"></path>
          <path d="m17.66 17.66 1.41 1.41"></path>
          <path d="M2 12h2"></path>
          <path d="M20 12h2"></path>
          <path d="m6.34 17.66-1.41 1.41"></path>
          <path d="m19.07 4.93-1.41 1.41"></path>
      </svg>
      <svg class="theme-lucide-icon theme-symbol theme-symbol-moon" xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
          <path d="M12 3a6 6 0 0 0 9 9 9 9 0 1 1-9-9Z"></path>
      </svg>
    </span>`,
  auto: `
    <svg class="theme-mode-icon" xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">
      <path d="M12 17v4"></path>
      <path d="m14.305 7.53.923-.382"></path>
      <path d="m15.228 4.852-.923-.383"></path>
      <path d="m16.852 3.228-.383-.924"></path>
      <path d="m16.852 8.772-.383.923"></path>
      <path d="m19.148 3.228.383-.924"></path>
      <path d="m19.53 9.696-.382-.924"></path>
      <path d="m20.772 4.852.924-.383"></path>
      <path d="m20.772 7.148.924.383"></path>
      <path d="M22 13v2a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h7"></path>
      <path d="M8 21h8"></path>
      <circle cx="18" cy="6" r="3"></circle>
    </svg>`
};

function getThemeLabel(mode) {
  if (mode === "dark") {
    return "暗色";
  }
  if (mode === "auto") {
    return "自动";
  }
  return "亮色";
}

function getThemeIconType(iconMode) {
  return iconMode === "auto" ? "auto" : "theme";
}

function setThemeModeButton(button, iconMode, label, targetMode, pressed) {
  if (!button) {
    return;
  }

  const iconType = getThemeIconType(iconMode);
  if (button.dataset.themeIconType !== iconType || !button.querySelector(".theme-mode-label")) {
    button.innerHTML = `${themeIconSvg[iconType]}<span class="theme-mode-label">${label}</span>`;
    button.dataset.themeIconType = iconType;
  } else {
    const labelEl = button.querySelector(".theme-mode-label");
    if (labelEl) {
      labelEl.textContent = label;
    }
  }

  button.dataset.themeMode = targetMode;
  button.dataset.themeIcon = iconMode;
  button.dataset.themeOption = targetMode;
  button.title = targetMode === "auto" ? "自动：跟随系统" : `${label}预设`;
  button.setAttribute("aria-label", button.title);
  button.setAttribute("aria-pressed", pressed ? "true" : "false");
  button.classList.toggle("is-active", pressed);
}

function renderTheme() {
  const themeMode = normalizeThemeMode(state.themeMode);
  const effectiveThemeMode = getEffectiveThemeMode(themeMode);
  const alternateThemeMode = getAlternateThemeMode(themeMode);
  const key = [
    themeMode,
    effectiveThemeMode,
    alternateThemeMode,
    state.themePreset,
    state.webuiThemeColor,
    state.webuiBackgroundColor,
    JSON.stringify(state.webuiThemeCustomPresets || []),
    state.webuiMastheadBackgroundUrl || "",
    state.webuiMastheadBackgroundScalePercent,
    state.webuiMastheadBackgroundRotationDeg,
    state.webuiMastheadBackgroundOffsetX,
    state.webuiMastheadBackgroundOffsetY,
    state.webuiMastheadBackgroundTileEnabled ? 1 : 0
  ].join("|");
  if (renderCache.themeKey === key) {
    return;
  }
  renderCache.themeKey = key;
  applyThemePresetForMode(effectiveThemeMode);
  document.documentElement.dataset.theme = effectiveThemeMode;
  document.documentElement.dataset.themeMode = themeMode;
  document.documentElement.dataset.themePreset = state.themePreset;
  preview.paletteKey = "";
  preview.backdropKey = "";
  applyWebUiThemeColors();

  if (els.themeToggleButton) {
    setThemeModeButton(
      els.themeToggleButton,
      effectiveThemeMode,
      getThemeLabel(effectiveThemeMode),
      effectiveThemeMode,
      themeMode === effectiveThemeMode
    );
    els.themeToggleButton.setAttribute("aria-label", `当前${getThemeLabel(effectiveThemeMode)}主题，点击切换${getThemeLabel(alternateThemeMode)}主题`);
    els.themeToggleButton.title = `当前${getThemeLabel(effectiveThemeMode)}主题，点击切换${getThemeLabel(alternateThemeMode)}主题`;
  }

  if (els.themeAutoButton) {
    setThemeModeButton(
      els.themeAutoButton,
      "auto",
      "自动",
      "auto",
      themeMode === "auto"
    );
  }
}

function renderPreviewChrome() {
  const hasPreviewIssue = (!!preview.error && isHttpProvider()) || (!state.connected && isHttpProvider()) || (!state.backendAvailable && isHttpProvider());
  const missingSavePath = isSavePathMissingWhileRecording();
  const reveal = clamp(preview.statusReveal || 0, 0, 1).toFixed(4);
  const key = [
    isRecordingActiveOrStarting() ? 1 : 0,
    hasPreviewIssue ? 1 : 0,
    missingSavePath ? 1 : 0,
    reveal
  ].join("|");
  if (renderCache.previewChromeKey === key) {
    syncPreviewStatusReveal();
    return;
  }
  renderCache.previewChromeKey = key;
  els.previewFrame.classList.toggle("is-recording", isRecordingActiveOrStarting());
  els.previewFrame.classList.toggle("is-offline", hasPreviewIssue);
  els.previewFrame.classList.toggle("is-missing-save-path", missingSavePath);
  if (els.previewSavePathWarning) {
    els.previewSavePathWarning.hidden = !missingSavePath;
  }
  els.previewScroll.classList.add("is-fit");
  els.previewScroll.classList.remove("is-actual");
  syncPreviewStatusReveal();
}

function render() {
  renderTheme();
  renderHeader();
  renderContentNavigation();
  syncRuntimePreviewTransport();
  renderStatus();
  renderButtons();
  renderFields();
  renderPreviewChrome();
  persistState();
  const pageScrollFadeKey = [
    state.activeContentPage,
    state.contentCollapsed ? 1 : 0,
    state.controlRailCollapsed ? 1 : 0,
    state.activityLogVisible ? 1 : 0,
    state.previewDeveloperMode ? 1 : 0
  ].join("|");
  if (renderCache.pageScrollFadeKey !== pageScrollFadeKey) {
    renderCache.pageScrollFadeKey = pageScrollFadeKey;
    queuePageScrollFadeUpdate();
  }
}

