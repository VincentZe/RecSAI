﻿function stepSimulation() {
  state.pointerX = 2600 + Math.sin(Date.now() / 780) * 1400 + Math.cos(Date.now() / 3100) * 180;
  state.pointerY = 1420 + Math.cos(Date.now() / 580) * 620 + Math.sin(Date.now() / 2800) * 90;

  preview.session = {
    width: state.canvasWidthValue,
    height: state.canvasHeightValue,
    tileSize: 256,
    tilesX: Math.max(1, Math.ceil(state.canvasWidthValue / 256)),
    tilesY: Math.max(1, Math.ceil(state.canvasHeightValue / 256)),
    generation: 1,
    lodMaxDim: computePreviewMaxDim()
  };
  setPreviewCursorTarget({
    x: clamp((state.pointerX / Math.max(1, state.canvasWidthValue)) * state.thumbWidthValue, 0, state.thumbWidthValue),
    y: clamp((state.pointerY / Math.max(1, state.canvasHeightValue)) * state.thumbHeightValue, 0, state.thumbHeightValue),
    thumbWidth: state.thumbWidthValue,
    thumbHeight: state.thumbHeightValue,
    pointerX: state.pointerX,
    pointerY: state.pointerY,
    canvasWidth: state.canvasWidthValue,
    canvasHeight: state.canvasHeightValue,
    attached: state.connected
  });

  if (state.recordingState === "recording") {
    state.frameCount += Number(state.stepInterval || "1");
    state.volumeEstimateMbPerFrame = 26.8 + state.frameCount * 0.04;
    state.volumeRecentMbPerFrame = 24.8 + state.frameCount * 0.03;
    state.volumePreviousMbPerFrame = 23.4 + state.frameCount * 0.02;
    const layout = updatePreviewLayout();
    preview.dots.push({
      x: clamp(layout.drawRect.x + (layout.drawRect.width * Math.random()), layout.drawRect.x + 18, layout.drawRect.x + Math.max(18, layout.drawRect.width - 18)),
      y: clamp(layout.drawRect.y + (layout.drawRect.height * Math.random()), layout.drawRect.y + 18, layout.drawRect.y + Math.max(18, layout.drawRect.height - 18)),
      hue: 18 + (state.frameCount % 100),
      size: 6 + (state.frameCount % 7)
    });
    if (preview.dots.length > 60) {
      preview.dots.shift();
    }
  } else if (preview.dots.length > 24) {
    preview.dots.shift();
  }

  drawPreview();
  renderFields();
  renderHeader();
}

function applyRecordingConfigState(data, allowRuntimeSurfaceRankFallback = false) {
  if (!data || typeof data !== "object") {
    return;
  }

  const codecId = toNumber(data.recording_codec_id ?? data.codec_id, 0);
  if (codecId > 0) {
    state.recordingCodecId = Math.trunc(codecId);
    state.recordingCodecMode = normalizeRecordingCodecMode(data.recording_codec_mode, state.recordingCodecId);
  } else if (typeof data.recording_codec_mode === "string") {
    state.recordingCodecMode = normalizeRecordingCodecMode(data.recording_codec_mode, state.recordingCodecId);
  }

  const runtimeRank = toNumber(
    Object.prototype.hasOwnProperty.call(data, "recording_runtime_rank")
      ? data.recording_runtime_rank
      : (allowRuntimeSurfaceRankFallback ? data.runtime_surface_rank : Number.NaN),
    Number.NaN);
  if (Number.isFinite(runtimeRank) && runtimeRank >= -1) {
    state.recordingRuntimeRank = String(Math.trunc(runtimeRank));
  }

  const recordTargetLongSide = toNumber(data.record_target_long_side, 0);
  if (recordTargetLongSide >= 256) {
    state.recordTargetLongSide = String(Math.trunc(recordTargetLongSide));
  }

  const runtimeLabels = data.recording_runtime_level_labels;
  if (Array.isArray(runtimeLabels) && runtimeLabels.length > 0) {
    const nextLabels = runtimeLabels
      .map((label) => (typeof label === "string" ? label.trim() : ""))
      .filter((label) => !!label);
    if (nextLabels.length > 0) {
      state.recordingRuntimeLevelLabels = nextLabels;
    }
  }
}

function applyStatusPayload(data) {
  if (!data) {
    return;
  }

  state.backendAvailable = true;
  applyRecordingConfigState(data);
  if (typeof data.version === "string") {
    state.appVersion = data.version.trim();
  }
  state.connected = !!data.attached;
  state.canvasWidthValue = Math.max(0, toNumber(data.canvas_width, state.canvasWidthValue));
  state.canvasHeightValue = Math.max(0, toNumber(data.canvas_height, state.canvasHeightValue));
  state.thumbWidthValue = Math.max(0, toNumber(data.thumb_width, state.thumbWidthValue));
  state.thumbHeightValue = Math.max(0, toNumber(data.thumb_height, state.thumbHeightValue));
  state.canvasSize = formatSize(state.canvasWidthValue, state.canvasHeightValue);
  state.thumbSize = formatSize(state.thumbWidthValue, state.thumbHeightValue);
  state.pointerX = toNumber(data.pointer_x, state.pointerX);
  state.pointerY = toNumber(data.pointer_y, state.pointerY);
  state.processBaseAddress = formatHex(data.base_addr);
  state.processId = toNumber(data.pid, 0) > 0 ? String(Math.trunc(toNumber(data.pid, 0))) : "N";
  state.processName = fileNameFromPath(data.sai_path) || "sai2.exe";
  state.volumeEstimateMbPerFrame = Math.max(0, toNumber(data.volume_estimate_mb_per_frame, state.volumeEstimateMbPerFrame));
  state.volumeRecentMbPerFrame = Math.max(0, toNumber(data.volume_recent_mb_per_frame, state.volumeRecentMbPerFrame));
  state.volumePreviousMbPerFrame = Math.max(0, toNumber(data.volume_previous_mb_per_frame, state.volumePreviousMbPerFrame));
  state.volumeRecentCount = Math.max(0, toNumber(data.volume_recent_count, state.volumeRecentCount));
  state.volumePreviousCount = Math.max(0, toNumber(data.volume_previous_count, state.volumePreviousCount));
  state.previewDirtyTiles = Math.max(0, toNumber(data.preview_dirty_tiles, state.previewDirtyTiles));
  state.previewTickGapMs = Math.max(0, toNumber(data.preview_tick_gap_ms, state.previewTickGapMs));
  state.previewTickGapAvgMs = Math.max(0, toNumber(data.preview_tick_gap_avg_ms, state.previewTickGapAvgMs));
  state.previewTickDurationMs = Math.max(0, toNumber(data.preview_tick_duration_ms, state.previewTickDurationMs));
  state.previewTickDurationAvgMs = Math.max(0, toNumber(data.preview_tick_duration_avg_ms, state.previewTickDurationAvgMs));
  state.previewTickBusySkips = Math.max(0, toNumber(data.preview_tick_busy_skips, state.previewTickBusySkips));
  const previousPreviewReadSendSeq = state.previewReadSendSeq;
  state.previewReadSendDurationMs = Math.max(0, toNumber(data.preview_read_send_duration_ms, state.previewReadSendDurationMs));
  state.previewReadSendSeq = Math.max(0, toNumber(data.preview_read_send_seq, state.previewReadSendSeq));
  if (state.previewReadSendDurationMs > 0 && state.previewReadSendSeq !== previousPreviewReadSendSeq) {
    state.previewReadSendSampleAt = Date.now();
    renderStatusLights(true);
  }
  if (typeof data.preview_fps_limit === "number") {
    state.runtimeSurfacePreviewFpsLimit = Math.max(0, Math.min(240, Math.trunc(data.preview_fps_limit)));
  }
  const previousRecordingWriteSeq = state.recordingWriteSeq;
  state.recordingWriteDurationMs = Math.max(0, toNumber(data.recording_write_duration_ms, state.recordingWriteDurationMs));
  state.recordingWriteSeq = Math.max(0, toNumber(data.recording_write_seq, state.recordingWriteSeq));
  if (state.recordingWriteDurationMs > 0 && state.recordingWriteSeq !== previousRecordingWriteSeq) {
    state.recordingWriteSampleAt = Date.now();
    renderStatusLights(true);
  }
  applyRecordingRuntimeState(data);

  const projectName = typeof data.project_name === "string" ? data.project_name.trim() : "";
  if (projectName) {
    state.currentFile = projectName;
  }

  if (preview) {
    const nextDirtyRect = parsePreviewDirtyRect(data, "preview_");
    if (!samePreviewDirtyRect(preview.dirtyRect, nextDirtyRect)) {
      preview.dirtyRect = nextDirtyRect;
      requestPreviewOverlayDraw();
    }
  }
}

function applyRecordPayload(data) {
  if (!data) {
    return;
  }

  state.backendAvailable = true;
  applyRecordingConfigState(data, true);
  if (typeof data.attached === "boolean") {
    state.connected = data.attached;
  }

  if (!hasHostBridge()) {
    const intervalValue = toNumber(data.history_poll_ms ?? data.interval_ms, 0);
    if (intervalValue > 0) {
      state.historyInterval = String(Math.trunc(intervalValue));
    }
    const stepValue = toNumber(data.step_interval, 0);
    if (stepValue > 0) {
      state.stepInterval = String(Math.trunc(stepValue));
    }
    const qualityValue = toNumber(data.jpeg_quality, 0);
    if (qualityValue > 0) {
      state.quality = String(Math.trunc(qualityValue));
    }
    if (typeof data.save_root === "string") {
      state.savePath = data.save_root.trim();
    }
  }
  if (typeof data.project_name === "string" && data.project_name.trim()) {
    state.currentFile = data.project_name.trim();
  }
  if (typeof data.current_preset_id === "string") {
    state.currentPresetId = data.current_preset_id.trim();
  }
  if (typeof data.current_preset_name === "string") {
    state.currentPresetName = data.current_preset_name.trim();
  }

  applyRecordingRuntimeState(data);
}

function applyRecordingRuntimeState(data) {
  if (!data || typeof data !== "object") {
    return false;
  }

  const hasRecordingState = Object.prototype.hasOwnProperty.call(data, "recording")
    || Object.prototype.hasOwnProperty.call(data, "recording_desired");
  if (!hasRecordingState) {
    return false;
  }

  const attached = typeof data.attached === "boolean" ? data.attached : state.connected;
  if (data.recording === true) {
    state.recordingState = "recording";
    if (!state.sessionStartedAt) {
      state.sessionStartedAt = Date.now();
    }
    return true;
  }

  if (data.recording_desired === true) {
    state.recordingState = attached ? "starting" : "waiting";
    state.sessionStartedAt = null;
    return true;
  }

  state.recordingState = "idle";
  state.sessionStartedAt = null;
  return true;
}

function applyRecordingPresetState(data) {
  if (!data || typeof data !== "object") {
    return;
  }

  if (typeof data.current_preset_id === "string") {
    state.currentPresetId = data.current_preset_id.trim();
  }
  if (typeof data.current_preset_name === "string") {
    state.currentPresetName = data.current_preset_name.trim();
  }
  if (typeof data.recording_preset_summary === "string") {
    state.recordingPresetSummary = data.recording_preset_summary.trim() || "-";
  }
  if (data.current_preset_config && typeof data.current_preset_config === "object") {
    state.recordingPresetConfig = normalizeRecordingPresetConfig(data.current_preset_config);
  }

  const presets = Array.isArray(data.recording_presets)
    ? data.recording_presets
    : Array.isArray(data.presets) ? data.presets : [];
  state.recordingPresets = presets
    .filter((item) => item && typeof item === "object")
    .map((item) => ({
      id: typeof item.id === "string" ? item.id : "",
      name: typeof item.name === "string" ? item.name : "",
      is_builtin: !!item.is_builtin,
      is_current: !!item.is_current,
      config: normalizeRecordingPresetConfig(item.config)
    }))
    .filter((item) => item.id && item.name);

  const currentPreset = state.recordingPresets.find((item) => item.id === state.currentPresetId);
  if (currentPreset && currentPreset.config) {
    state.recordingPresetConfig = currentPreset.config;
  }
}

function normalizeRecordingPresetConfig(config) {
  if (!config || typeof config !== "object") {
    return null;
  }

  const resolutionMode = config.resolution_mode === "long_side" ? "long_side" : "highest";
  const runtimeRankSource = Object.prototype.hasOwnProperty.call(config, "runtime_surface_rank")
    ? config.runtime_surface_rank
    : state.recordingRuntimeRank;
  return {
    resolution_mode: resolutionMode,
    record_target_long_side: Math.max(256, Math.trunc(toNumber(config.record_target_long_side, state.recordTargetLongSide || 2048))),
    runtime_surface_rank: resolutionMode === "long_side"
      ? -1
      : Math.max(-1, Math.trunc(toNumber(runtimeRankSource, state.recordingRuntimeRank || -1))),
    step_interval: Math.max(1, Math.trunc(toNumber(config.step_interval, state.stepInterval || 1))),
    codec_id: Math.max(0, Math.trunc(toNumber(config.codec_id, state.recordingCodecId || 0))),
    jpeg_quality: Math.max(1, Math.min(100, Math.trunc(toNumber(config.jpeg_quality, state.quality || 95))))
  };
}

function handleBackendUnavailable(message) {
  state.backendAvailable = false;
  state.connected = false;
  state.recordingState = "idle";
  state.sessionStartedAt = null;
  render();
  drawPreview();

  const now = Date.now();
  if (now - runtime.backendErrorLoggedAt >= backendErrorLogThrottleMs) {
    runtime.backendErrorLoggedAt = now;
    addLog(message);
  }
}

async function fetchJson(path, init) {
  let response;
  try {
    response = await fetch(path, {
      cache: "no-store",
      headers: {
        "Content-Type": "application/json"
      },
      ...init
    });
  } catch (error) {
    const wrapped = new Error(error && error.message ? error.message : "Network error");
    wrapped.bridgeUnavailable = true;
    throw wrapped;
  }

  let payload = null;
  try {
    payload = await response.json();
  } catch {
    payload = null;
  }

  if (!response.ok || !payload || payload.ok !== true) {
    const error = payload && payload.error ? payload.error : null;
    const wrapped = new Error(error && error.message ? error.message : `HTTP ${response.status}`);
    wrapped.bridgeUnavailable = false;
    wrapped.status = response.status;
    throw wrapped;
  }

  return payload;
}

function handleSoftApiFailure(message) {
  state.backendAvailable = true;
  render();
  drawPreview();

  const now = Date.now();
  if (now - runtime.backendErrorLoggedAt >= backendErrorLogThrottleMs) {
    runtime.backendErrorLoggedAt = now;
    addLog(message);
  }
}

function stopMockSimulation() {
  if (runtime.mockTimer) {
    window.clearInterval(runtime.mockTimer);
    runtime.mockTimer = 0;
  }
}

function startMockSimulation() {
  if (runtime.mockTimer || shouldThrottleRuntimeForHiddenDocument()) {
    return;
  }

  runtime.mockTimer = window.setInterval(stepSimulation, 120);
}

function stopStatusPolling() {
  runtime.statusPollProvider = null;
  if (runtime.statusPollTimer) {
    window.clearTimeout(runtime.statusPollTimer);
    runtime.statusPollTimer = 0;
  }
}

function scheduleStatusPolling(provider) {
  if (runtime.statusPollTimer) {
    window.clearTimeout(runtime.statusPollTimer);
    runtime.statusPollTimer = 0;
  }
  if (!provider || runtime.provider !== provider) {
    return;
  }
  runtime.statusPollProvider = provider;

  const hidden = shouldThrottleRuntimeForHiddenDocument();
  const interval = hidden ? hiddenStatusPollMs : statusPollMs;
  runtime.statusPollTimer = window.setTimeout(async () => {
    runtime.statusPollTimer = 0;
    try {
      await provider.pollStatusDelta();
    } finally {
      if (runtime.statusPollProvider === provider) {
        scheduleStatusPolling(provider);
      }
    }
  }, interval);
}

function startStatusPolling(provider) {
  if (!provider) {
    return;
  }

  runtime.statusPollProvider = provider;
  scheduleStatusPolling(provider);
}

function handleRuntimeVisibilityChange() {
  if (runtime.provider && runtime.provider.kind === "mock") {
    if (shouldThrottleRuntimeForHiddenDocument()) {
      stopMockSimulation();
    } else {
      startMockSimulation();
      stepSimulation();
    }
    return;
  }

  if (isHttpProvider()) {
    syncRuntimePreviewTransport();
    if (document.visibilityState !== "hidden") {
      void runtime.provider.refreshAll(false);
    }
    if (runtime.provider) {
      scheduleStatusPolling(runtime.provider);
    }
  }
}

function createMockProvider() {
  return {
    kind: "mock",
    async init() {
      disposeRuntimePreviewTransport(true);
      preview.dots = [];
      preview.disposed = true;
      addLog("Using file:// mock provider.");
      startMockSimulation();
      render();
      stepSimulation();
    },
    dispose() {
      stopMockSimulation();
    },
    async toggleRecording() {
      if (!state.connected) {
        addLog("Recording cannot start because SAI2 is not attached.");
        render();
        return;
      }

      if (state.recordingState === "idle") {
        state.recordingState = "starting";
        render();
        addLog(`Recording started: path=${state.savePath}, poll=${state.historyInterval}ms, step=${state.stepInterval}.`);
        window.setTimeout(() => {
          state.recordingState = "recording";
          state.frameCount = 0;
          resetPreviewTileStats();
          state.sessionStartedAt = Date.now();
          render();
          drawPreview();
        }, 620);
        return;
      }

      if (state.recordingState === "recording" || state.recordingState === "starting" || state.recordingState === "waiting") {
        state.recordingState = "stopping";
        render();
        addLog("Stopping the recording session.");
        window.setTimeout(() => {
          state.recordingState = "idle";
          state.sessionStartedAt = null;
          render();
          drawPreview();
        }, 520);
      }
    },
    async updateRecordConfig(patch, successMessage) {
      if (typeof patch.save_root === "string" && patch.save_root.trim()) {
        state.savePath = patch.save_root.trim();
      }
      if (patch.codec_id) {
        state.recordingCodecId = Math.trunc(patch.codec_id);
        state.recordingCodecMode = normalizeRecordingCodecMode("", state.recordingCodecId);
      }
      if (typeof patch.runtime_surface_rank === "number" && patch.runtime_surface_rank >= -1) {
        state.recordingRuntimeRank = String(Math.trunc(patch.runtime_surface_rank));
      }
      if (patch.record_target_long_side) {
        state.recordTargetLongSide = String(Math.trunc(patch.record_target_long_side));
      }
      if (patch.history_poll_ms) {
        state.historyInterval = String(patch.history_poll_ms);
      }
      if (patch.step_interval) {
        state.stepInterval = String(patch.step_interval);
      }
      if (patch.jpeg_quality) {
        state.quality = String(patch.jpeg_quality);
      }
      addLog(successMessage);
      render();
    },
    simulateDetach() {
      state.connected = !state.connected;
      setPreviewCursorTarget({
        ...preview.cursor,
        attached: state.connected
      }, true);
      addLog(state.connected ? "Mock provider reattached to SAI2." : "Mock provider detached from SAI2.");
      render();
      drawPreview();
    }
  };
}

function createHttpProvider() {
  return {
    kind: "http",
    async init() {
      preview.disposed = false;
      runtime.hostBridgeAvailable = hasHostBridge();
      addLog("Using the local HTTP bridge.");
      await this.refreshAll(true);
      setRuntimePreviewTransportAllowed(true);
      startStatusPolling(this);
    },
    dispose() {
      stopStatusPolling();
      setRuntimePreviewTransportAllowed(false);
      disposeRuntimePreviewTransport(false);
    },
    async refreshAll(isInitial) {
      try {
        const [statusResponse, recordResponse, presetResponse] = await Promise.all([
          fetchJson("/api/status"),
          fetchJson("/api/record/status"),
          fetchJson("/api/record/presets")
        ]);
        applyStatusPayload(statusResponse.data);
        applyRecordPayload(recordResponse.data);
        applyRecordingPresetState(presetResponse.data);
        render();
        drawPreview();
        if (isInitial) {
          addLog("Connected to the local HTTP bridge.");
        }
      } catch (error) {
        if (error.bridgeUnavailable) {
          handleBackendUnavailable(`HTTP bridge unavailable: ${error.message}`);
        } else {
          handleSoftApiFailure(`Initial state fetch failed: ${error.message}`);
        }
      }
    },
    async pollStatusDelta() {
      try {
        const deltaResponse = await fetchJson("/api/status/delta");
        if (!state.backendAvailable) {
          await this.refreshAll(false);
          return;
        }
        state.backendAvailable = true;
        if (deltaResponse.data && deltaResponse.data.changed) {
          applyStatusPayload(deltaResponse.data);
          render();
          requestPreviewOverlayDraw();
        }
      } catch (error) {
        if (error.bridgeUnavailable) {
          handleBackendUnavailable(`HTTP bridge unavailable: ${error.message}`);
        } else {
          handleSoftApiFailure(`Status polling failed: ${error.message}`);
        }
      }
    },
    async toggleRecording() {
      if (runtime.actionInFlight) {
        return;
      }

      if (state.recordingState === "idle") {
        state.recordingState = "starting";
        render();
        setActionInFlight(true);
        try {
          await fetchJson("/api/record/start", {
            method: "POST",
            body: JSON.stringify({
              history_poll_ms: Number(state.historyInterval),
              step_interval: Number(state.stepInterval),
              jpeg_quality: Number(state.quality),
              save_root: state.savePath,
              auto_canvas_name: true
            })
          });
          addLog(`Recording started: path=${state.savePath}, poll=${state.historyInterval}ms, step=${state.stepInterval}.`);
          await this.refreshAll(false);
        } catch (error) {
          if (error.bridgeUnavailable) {
            handleBackendUnavailable(`HTTP bridge unavailable: ${error.message}`);
          } else {
            handleSoftApiFailure(`Failed to start recording: ${error.message}`);
            await this.refreshAll(false);
          }
        } finally {
          setActionInFlight(false);
        }
        return;
      }

      if (state.recordingState === "recording" || state.recordingState === "starting" || state.recordingState === "waiting") {
        state.recordingState = "stopping";
        render();
        setActionInFlight(true);
        try {
          await fetchJson("/api/record/stop", {
            method: "POST",
            body: "{}"
          });
          addLog("Stopping the recording session.");
          await this.refreshAll(false);
        } catch (error) {
          if (error.bridgeUnavailable) {
            handleBackendUnavailable(`HTTP bridge unavailable: ${error.message}`);
          } else {
            handleSoftApiFailure(`Failed to stop recording: ${error.message}`);
            await this.refreshAll(false);
          }
        } finally {
          setActionInFlight(false);
        }
      }
    },
    async updateRecordConfig(patch, successMessage) {
      if (runtime.actionInFlight) {
        return;
      }

      setActionInFlight(true);
      try {
        await fetchJson("/api/record/set", {
          method: "POST",
          body: JSON.stringify(patch)
        });
        addLog(successMessage);
        await this.refreshAll(false);
      } catch (error) {
        if (error.bridgeUnavailable) {
          handleBackendUnavailable(`HTTP bridge unavailable: ${error.message}`);
        } else {
          handleSoftApiFailure(`Failed to update recording config: ${error.message}`);
          await this.refreshAll(false);
        }
      } finally {
        setActionInFlight(false);
      }
    },
    async activateRecordingPreset(presetId) {
      if (runtime.actionInFlight || !presetId) {
        return;
      }

      setActionInFlight(true);
      try {
        const response = await fetchJson("/api/record/presets/activate", {
          method: "POST",
          body: JSON.stringify({ preset_id: presetId })
        });
        applyRecordingPresetState(response.data);
        addLog(`Recording preset changed to ${state.currentPresetName || presetId}.`);
        await this.refreshAll(false);
      } catch (error) {
        if (error.bridgeUnavailable) {
          handleBackendUnavailable(`HTTP bridge unavailable: ${error.message}`);
        } else {
          handleSoftApiFailure(`Failed to activate recording preset: ${error.message}`);
          await this.refreshAll(false);
        }
      } finally {
        setActionInFlight(false);
      }
    },
    simulateDetach() {
      addLog("Detach simulation is not available when using the HTTP bridge.");
    }
  };
}

function bindPreviewSurface() {
  const previewScrollTarget = els.previewCard || els.previewScroll;
  const getPreviewStatusRevealSpan = () => {
    if (!els.previewStatusGrid) {
      return 1;
    }

    return Math.max(120, els.previewStatusGrid.offsetHeight + 28);
  };

  const consumePreviewStatusRevealDelta = (deltaY) => {
    if (!Number.isFinite(deltaY) || Math.abs(deltaY) < 0.5) {
      return 0;
    }

    const revealSpan = getPreviewStatusRevealSpan();
    const currentReveal = clamp(preview.statusReveal || 0, 0, 1);
    const nextReveal = clamp(currentReveal + deltaY / revealSpan, 0, 1);
    const consumed = (nextReveal - currentReveal) * revealSpan;
    if (Math.abs(consumed) < 0.5) {
      return 0;
    }

    preview.statusReveal = nextReveal;
    syncPreviewStatusReveal();
    return consumed;
  };

  const scrollPageFromPreview = (deltaY) => {
    if (!els.pageScrollRoot || !Number.isFinite(deltaY) || Math.abs(deltaY) < 0.5) {
      return;
    }
    if (state.activeContentPage === "dashboard") {
      return;
    }

    els.pageScrollRoot.scrollBy({
      top: deltaY,
      left: 0,
      behavior: "auto"
    });
  };

  previewScrollTarget.addEventListener("wheel", (event) => {
    if (Math.abs(event.deltaY) <= Math.abs(event.deltaX)) {
      return;
    }

    event.preventDefault();
    const consumed = consumePreviewStatusRevealDelta(event.deltaY);
    scrollPageFromPreview(event.deltaY - consumed);
  }, { passive: false });

  if ("ResizeObserver" in window) {
    preview.resizeObserver = new ResizeObserver(() => {
      if (updatePreviewViewportSize()) {
        drawPreview();
        queuePreviewResizeSend();
      }
    });
    preview.resizeObserver.observe(els.previewScroll);
  }

  window.addEventListener("resize", () => {
    updatePreviewViewportSize();
    drawPreview();
    queuePreviewResizeSend();
  });

  document.addEventListener("visibilitychange", handleRuntimeVisibilityChange);
}

function getHostBridge() {
  const bridge = window.chrome && window.chrome.webview;
  if (!bridge || typeof bridge.postMessage !== "function") {
    return null;
  }

  return bridge;
}

function postHostMessage(message, unavailableLog) {
  const bridge = getHostBridge();
  if (!bridge) {
    if (unavailableLog) {
      addLog(unavailableLog);
    }
    return false;
  }

  bridge.postMessage(message);
  return true;
}

function hasHostBridge() {
  return !!getHostBridge();
}

function postHostCommand(command, payload = null, unavailableLog = "") {
  const bridge = getHostBridge();
  if (!bridge) {
    if (unavailableLog) {
      addLog(unavailableLog);
    }
    return false;
  }

  bridge.postMessage(JSON.stringify({
    kind: "webui-command",
    command,
    payload: payload && typeof payload === "object" ? payload : {}
  }));
  return true;
}

window.ReadSAI2WebUi = window.ReadSAI2WebUi || {};
window.ReadSAI2WebUi.host = {
  getBridge: getHostBridge,
  hasBridge: hasHostBridge,
  postMessage: postHostMessage,
  postCommand: postHostCommand
};

function applyHostState(data) {
  if (!data || typeof data !== "object") {
    return;
  }

  if (typeof data.app_version === "string") {
    state.appVersion = data.app_version.trim();
  }

  if (typeof data.save_path === "string") {
    state.savePath = data.save_path.trim();
  }

  if (typeof data.perf_label === "string") {
    state.perfLabel = data.perf_label.trim() || defaultState.perfLabel;
  }
  applyRecordingConfigState(data, true);
  applyRecordingPresetState(data);

  const historyInterval = toNumber(data.history_interval, 0);
  if (historyInterval > 0) {
    state.historyInterval = String(Math.trunc(historyInterval));
  }

  const stepInterval = toNumber(data.step_interval, 0);
  if (stepInterval > 0) {
    state.stepInterval = String(Math.trunc(stepInterval));
  }

  const quality = toNumber(data.quality, 0);
  if (quality > 0) {
    state.quality = String(Math.trunc(quality));
  }

  if (typeof data.always_on_top === "boolean") {
    state.alwaysOnTop = data.always_on_top;
  }
  if (typeof data.webui_always_on_top === "boolean") {
    state.webuiAlwaysOnTop = data.webui_always_on_top;
  }
  if (typeof data.auto_launch_sai === "boolean") {
    state.autoLaunch = data.auto_launch_sai;
  }
  if (typeof data.do_not_minimize_to_tray === "boolean") {
    state.doNotMinimizeToTray = data.do_not_minimize_to_tray;
  }
  if (typeof data.disable_global_hotkeys === "boolean") {
    state.disableGlobalHotkeys = data.disable_global_hotkeys;
  }
  if (typeof data.command_palette_passthrough_forwarding === "boolean") {
    state.commandPalettePassthroughForwarding = data.command_palette_passthrough_forwarding;
  }
  if (Array.isArray(data.search_commands)) {
    state.searchCommands = normalizeSearchCommandShortcuts(data.search_commands);
  }
  if (typeof data.navigator_auto_resize === "boolean") {
    state.navigatorAutoResize = data.navigator_auto_resize;
  }
  if (typeof data.update_channel === "string") {
    state.updateChannel = data.update_channel === "beta" ? "beta" : "stable";
  }
  const hasThemeSlotPreset = Object.prototype.hasOwnProperty.call(data, "webui_light_theme_preset")
    || Object.prototype.hasOwnProperty.call(data, "webui_dark_theme_preset");
  if (Array.isArray(data.webui_theme_custom_presets)) {
    state.webuiThemeCustomPresets = normalizeWebUiThemeCustomPresets(data.webui_theme_custom_presets);
  }
  if (typeof data.webui_light_theme_preset === "string") {
    state.webuiLightThemePreset = normalizeWebUiThemePresetId(data.webui_light_theme_preset, "light");
  }
  if (typeof data.webui_dark_theme_preset === "string") {
    state.webuiDarkThemePreset = normalizeWebUiThemePresetId(data.webui_dark_theme_preset, "dark");
  }
  if (typeof data.webui_theme_color === "string") {
    state.webuiThemeColor = normalizeWebUiThemeColor(data.webui_theme_color);
  }
  if (typeof data.webui_background_color === "string") {
    state.webuiBackgroundColor = normalizeWebUiBackgroundColor(data.webui_background_color);
  }
  if (typeof data.webui_masthead_background_path === "string") {
    state.webuiMastheadBackgroundPath = normalizeWebUiMastheadBackgroundPath(data.webui_masthead_background_path);
  }
  if (typeof data.webui_masthead_background_url === "string") {
    state.webuiMastheadBackgroundUrl = normalizeWebUiMastheadBackgroundUrl(data.webui_masthead_background_url);
  } else if (!state.webuiMastheadBackgroundPath) {
    state.webuiMastheadBackgroundUrl = "";
  }
  if (typeof data.webui_masthead_background_scale_percent === "number") {
    state.webuiMastheadBackgroundScalePercent = normalizeWebUiMastheadBackgroundScalePercent(data.webui_masthead_background_scale_percent);
  }
  if (typeof data.webui_masthead_background_rotation_deg === "number") {
    state.webuiMastheadBackgroundRotationDeg = normalizeWebUiMastheadBackgroundRotationDeg(data.webui_masthead_background_rotation_deg);
  }
  if (typeof data.webui_masthead_background_offset_x === "number") {
    state.webuiMastheadBackgroundOffsetX = normalizeWebUiMastheadBackgroundOffset(data.webui_masthead_background_offset_x);
  }
  if (typeof data.webui_masthead_background_offset_y === "number") {
    state.webuiMastheadBackgroundOffsetY = normalizeWebUiMastheadBackgroundOffset(data.webui_masthead_background_offset_y);
  }
  if (typeof data.webui_masthead_background_tile_enabled === "boolean") {
    state.webuiMastheadBackgroundTileEnabled = data.webui_masthead_background_tile_enabled;
  }
  if (typeof data.webui_theme_preset === "string") {
    const legacyPreset = normalizeWebUiThemePreset(data.webui_theme_preset, state.webuiThemeColor, state.webuiBackgroundColor, state);
    if (!hasThemeSlotPreset && legacyPreset && legacyPreset !== "light" && legacyPreset !== "dark") {
      const effectiveThemeMode = getEffectiveThemeMode(state.themeMode);
      if (effectiveThemeMode === "dark") {
        state.webuiDarkThemePreset = legacyPreset;
      } else {
        state.webuiLightThemePreset = legacyPreset;
      }
    }
  }
  applyThemePresetForMode(getEffectiveThemeMode(state.themeMode));
  if (typeof data.custom_brush_overlay === "boolean") {
    state.customBrushOverlay = data.custom_brush_overlay;
  }
  if (typeof data.preview_developer_mode === "boolean") {
    state.previewDeveloperMode = data.preview_developer_mode;
  }
  if (typeof data.runtime_surface_fixed_refresh === "boolean") {
    state.runtimeSurfaceFixedRefresh = data.runtime_surface_fixed_refresh;
  }
  if (typeof data.runtime_surface_preview_fps_limit === "number") {
    state.runtimeSurfacePreviewFpsLimit = Math.max(0, Math.min(240, Math.trunc(data.runtime_surface_preview_fps_limit)));
  }
  if (typeof data.status_light_group_visible === "boolean") {
    state.statusLightGroupVisible = data.status_light_group_visible;
  }
}

