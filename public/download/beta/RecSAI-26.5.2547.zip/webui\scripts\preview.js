﻿function cycleVolumeMode() {
  setVolumeMode((state.volumeModeIndex + 1) % 3);
}

function setVolumeMode(modeIndex) {
  const nextModeIndex = clamp(Math.trunc(toNumber(modeIndex, 0)), 0, 2);
  if (state.volumeModeIndex === nextModeIndex) {
    return;
  }

  state.volumeModeIndex = nextModeIndex;
  addLog(`体积显示已切换为 ${state.volumeModeIndex + 1}。`);
  render();
}

function toggleThemeMode() {
  setThemeMode(getAlternateThemeMode(state.themeMode));
}

function setThemeMode(mode, options) {
  const nextThemeMode = normalizeThemeMode(mode);
  const shouldSyncPreset = !!(options && options.syncPreset);
  const previousThemeMode = state.themeMode;
  const previousThemePreset = state.themePreset;
  let changed = state.themeMode !== nextThemeMode;
  if (changed) {
    state.themeMode = nextThemeMode;
  }

  const preset = applyThemePresetForMode(getEffectiveThemeMode(nextThemeMode));
  changed = changed || previousThemePreset !== preset.id;
  if (!changed) {
    return;
  }

  addLog(`Theme changed to ${state.themeMode}.`);
  render();
  if (shouldSyncPreset && (nextThemeMode === "light" || nextThemeMode === "dark") && previousThemeMode !== nextThemeMode) {
    postHostCommand("set-webui-theme-preset", { value: state.themePreset });
  }
  drawPreview();
}

function getPreviewDeviceScale() {
  return clamp(window.devicePixelRatio || 1, 1, 2);
}

function getPreviewViewportSize() {
  if (preview.viewportWidth > 0 && preview.viewportHeight > 0) {
    return {
      width: preview.viewportWidth,
      height: preview.viewportHeight
    };
  }
  return {
    width: Math.max(1, els.previewScroll.clientWidth || 0),
    height: Math.max(1, els.previewScroll.clientHeight || 0)
  };
}

function updatePreviewViewportSize() {
  if (!els.previewScroll) {
    return false;
  }

  const width = Math.max(1, Math.round(els.previewScroll.clientWidth || 0));
  const height = Math.max(1, Math.round(els.previewScroll.clientHeight || 0));
  if (preview.viewportWidth === width && preview.viewportHeight === height) {
    return false;
  }

  preview.viewportWidth = width;
  preview.viewportHeight = height;
  preview.layout = null;
  return true;
}

function setCanvasSize(canvas, cssWidth, cssHeight, pixelWidth, pixelHeight) {
  const nextWidth = Math.max(1, Math.round(pixelWidth));
  const nextHeight = Math.max(1, Math.round(pixelHeight));
  if (canvas.width !== nextWidth) {
    canvas.width = nextWidth;
  }
  if (canvas.height !== nextHeight) {
    canvas.height = nextHeight;
  }
  canvas.style.width = `${Math.max(1, cssWidth)}px`;
  canvas.style.height = `${Math.max(1, cssHeight)}px`;
}

function ensureAtlasSize(width, height) {
  const safeWidth = Math.max(1, Math.round(width || 1));
  const safeHeight = Math.max(1, Math.round(height || 1));
  if (preview.atlasCanvas.width !== safeWidth) {
    preview.atlasCanvas.width = safeWidth;
  }
  if (preview.atlasCanvas.height !== safeHeight) {
    preview.atlasCanvas.height = safeHeight;
  }
}

function clearAtlas() {
  ensureAtlasSize(preview.session ? preview.session.width : 1, preview.session ? preview.session.height : 1);
  preview.atlasCtx.clearRect(0, 0, preview.atlasCanvas.width, preview.atlasCanvas.height);
}

function resetPreviewTileStats() {
  preview.pendingTileCount = 0;
  preview.pendingTileBytes = 0;
  state.previewTileCount = 0;
  state.previewTileBytes = 0;
  state.previewLastTileAt = 0;
  state.previewTileIntervalMs = 0;
}

function commitPreviewTileStats() {
  const now = Date.now();
  state.previewTileCount = Math.max(0, preview.pendingTileCount);
  state.previewTileBytes = Math.max(0, preview.pendingTileBytes);
  if (state.previewLastTileAt > 0) {
    state.previewTileIntervalMs = Math.max(0, now - state.previewLastTileAt);
  }
  state.previewLastTileAt = now;
  preview.pendingTileCount = 0;
  preview.pendingTileBytes = 0;
  renderHeader();
}

function computeContainRect(sourceWidth, sourceHeight, targetWidth, targetHeight) {
  if (sourceWidth <= 0 || sourceHeight <= 0 || targetWidth <= 0 || targetHeight <= 0) {
    return { x: 0, y: 0, width: Math.max(0, targetWidth), height: Math.max(0, targetHeight) };
  }

  const sourceRatio = sourceWidth / sourceHeight;
  const targetRatio = targetWidth / targetHeight;
  let width = targetWidth;
  let height = targetHeight;
  if (sourceRatio > targetRatio) {
    height = width / sourceRatio;
  } else {
    width = height * sourceRatio;
  }

  return {
    x: Math.round((targetWidth - width) * 0.5),
    y: Math.round((targetHeight - height) * 0.5),
    width: Math.round(width),
    height: Math.round(height)
  };
}

function updatePreviewAspectRatio(width, height) {
  const safeWidth = Math.max(1, toNumber(width, 1280));
  const safeHeight = Math.max(1, toNumber(height, 720));
  const ratio = clamp(safeWidth / safeHeight, 0.35, 4);
  const key = ratio.toFixed(4);
  if (preview.aspectRatioKey === key) {
    return;
  }
  preview.aspectRatioKey = key;
  els.previewScroll.style.setProperty("--preview-aspect-ratio", key);
}

function updatePreviewLayout() {
  const sessionWidth = preview.session && preview.session.width > 0 ? preview.session.width : 1280;
  const sessionHeight = preview.session && preview.session.height > 0 ? preview.session.height : 720;
  const canUseActual = false;
  updatePreviewAspectRatio(sessionWidth, sessionHeight);
  const viewport = getPreviewViewportSize();

  let cssWidth;
  let cssHeight;
  let pixelWidth;
  let pixelHeight;
  let drawRect;

  if (canUseActual) {
    cssWidth = sessionWidth;
    cssHeight = sessionHeight;
    pixelWidth = sessionWidth;
    pixelHeight = sessionHeight;
    drawRect = { x: 0, y: 0, width: pixelWidth, height: pixelHeight };
  } else {
    const scale = getPreviewDeviceScale();
    cssWidth = viewport.width;
    cssHeight = viewport.height;
    pixelWidth = Math.max(1, Math.round(cssWidth * scale));
    pixelHeight = Math.max(1, Math.round(cssHeight * scale));
    drawRect = computeContainRect(sessionWidth, sessionHeight, pixelWidth, pixelHeight);
  }

  setCanvasSize(els.displayCanvas, cssWidth, cssHeight, pixelWidth, pixelHeight);
  setCanvasSize(els.overlayCanvas, cssWidth, cssHeight, pixelWidth, pixelHeight);
  els.previewSurface.style.width = `${Math.max(1, cssWidth)}px`;
  els.previewSurface.style.height = `${Math.max(1, cssHeight)}px`;

  preview.layout = {
    viewportWidth: viewport.width,
    viewportHeight: viewport.height,
    cssWidth,
    cssHeight,
    pixelWidth,
    pixelHeight,
    sessionWidth,
    sessionHeight,
    drawRect,
    mode: canUseActual ? "actual" : "fit"
  };
  renderPreviewChrome();
  return preview.layout;
}

function getPreviewPlaceholderLines() {
  if (isHttpProvider() && !state.backendAvailable) {
    return ["等待 HTTP bridge", "本地 bridge 恢复后会自动重连预览 socket"];
  }
  if (preview.error && preview.error.message) {
    return ["预览连接异常", preview.error.message];
  }
  if (isHttpProvider()) {
    return ["等待预览会话", "连接 /ws/preview/runtime 后会接收 hello/session 消息"];
  }
  return ["模拟预览模式", "当前页面运行在本地文件模式，使用内置模拟数据"];
}

function parsePreviewColor(value, fallback) {
  const text = String(value || "").trim();
  const fallbackColor = fallback || { r: 79, g: 140, b: 255, a: 1 };
  const hexMatch = /^#([0-9a-fA-F]{6})$/.exec(text);
  if (hexMatch) {
    const hex = hexMatch[1];
    return {
      r: parseInt(hex.slice(0, 2), 16),
      g: parseInt(hex.slice(2, 4), 16),
      b: parseInt(hex.slice(4, 6), 16),
      a: 1
    };
  }

  const rgbMatch = /^rgba?\(([^)]+)\)$/.exec(text);
  if (rgbMatch) {
    const parts = rgbMatch[1].split(",").map((part) => part.trim());
    if (parts.length >= 3) {
      return {
        r: clamp(toNumber(parts[0], fallbackColor.r), 0, 255),
        g: clamp(toNumber(parts[1], fallbackColor.g), 0, 255),
        b: clamp(toNumber(parts[2], fallbackColor.b), 0, 255),
        a: parts.length >= 4 ? clamp(toNumber(parts[3], fallbackColor.a), 0, 1) : 1
      };
    }
  }

  return fallbackColor;
}

function getPreviewCssColor(styles, name, fallback) {
  return parsePreviewColor(styles.getPropertyValue(name), fallback);
}

function mixPreviewColor(a, b, amount) {
  const t = clamp(amount, 0, 1);
  return {
    r: a.r + (b.r - a.r) * t,
    g: a.g + (b.g - a.g) * t,
    b: a.b + (b.b - a.b) * t,
    a: a.a + (b.a - a.a) * t
  };
}

function previewRgba(color, alpha) {
  const effectiveAlpha = typeof alpha === "number" ? alpha : color.a;
  return `rgba(${Math.round(clamp(color.r, 0, 255))}, ${Math.round(clamp(color.g, 0, 255))}, ${Math.round(clamp(color.b, 0, 255))}, ${clamp(effectiveAlpha, 0, 1).toFixed(3)})`;
}

function getPreviewPalette() {
  const isDark = document.documentElement.dataset.theme === "dark";
  const key = [
    document.documentElement.dataset.theme || "",
    document.documentElement.dataset.themePreset || "",
    state.webuiThemeColor || "",
    state.webuiBackgroundColor || ""
  ].join("|");
  if (preview.palette && preview.paletteKey === key) {
    return preview.palette;
  }

  const styles = getComputedStyle(document.documentElement);
  const bg = getPreviewCssColor(styles, "--bg", isDark ? { r: 14, g: 15, b: 19, a: 1 } : { r: 244, g: 246, b: 251, a: 1 });
  const card = getPreviewCssColor(styles, "--card-bg", bg);
  const accent = getPreviewCssColor(styles, "--accent", isDark ? { r: 83, g: 209, b: 182, a: 1 } : { r: 79, g: 140, b: 255, a: 1 });
  const text = getPreviewCssColor(styles, "--text", isDark ? { r: 238, g: 241, b: 245, a: 1 } : { r: 16, g: 20, b: 28, a: 1 });
  const muted = getPreviewCssColor(styles, "--muted", text);
  const danger = getPreviewCssColor(styles, "--danger", { r: 225, g: 99, b: 99, a: 1 });
  const accentSurface = mixPreviewColor(bg, accent, isDark ? 0.2 : 0.12);
  const raisedSurface = mixPreviewColor(bg, card, isDark ? 0.42 : 0.5);
  preview.paletteKey = key;
  preview.palette = {
    backdropStops: [
      previewRgba(mixPreviewColor(bg, card, isDark ? 0.18 : 0.36), 1),
      previewRgba(accentSurface, 1),
      previewRgba(mixPreviewColor(bg, text, isDark ? 0.1 : 0.04), 1)
    ],
    grid: previewRgba(mixPreviewColor(muted, accent, 0.12), isDark ? 0.1 : 0.12),
    placeholderFill: previewRgba(accent, isDark ? 0.13 : 0.1),
    placeholderTitle: previewRgba(text, 1),
    placeholderText: previewRgba(muted, 0.82),
    mockFrameFill: previewRgba(raisedSurface, isDark ? 0.58 : 0.5),
    mockDotFill: accent,
    overlayScrim: previewRgba(mixPreviewColor(bg, card, isDark ? 0.08 : 0.58), isDark ? 0.58 : 0.7),
    overlayText: previewRgba(text, 1),
    recordingBadge: previewRgba(mixPreviewColor(bg, card, isDark ? 0.16 : 0.82), isDark ? 0.86 : 0.9),
    recordingText: previewRgba(danger, 1),
    syncStroke: previewRgba(accent, 0.92),
    pointerStroke: previewRgba(mixPreviewColor(card, text, isDark ? 0.72 : 0.2), 0.94),
    pointerFill: previewRgba(accent, 0.98),
    dirtyRectInnerStroke: previewRgba(mixPreviewColor(card, text, isDark ? 0.72 : 0.16), isDark ? 0.74 : 0.86)
  };
  return preview.palette;
}

function ensurePreviewBackdrop(width, height) {
  const palette = getPreviewPalette();
  const safeWidth = Math.max(1, Math.round(width || 1));
  const safeHeight = Math.max(1, Math.round(height || 1));
  const key = [
    safeWidth,
    safeHeight,
    palette.backdropStops.join(","),
    palette.grid
  ].join("|");
  if (preview.backdropKey === key
    && preview.backdropCanvas.width === safeWidth
    && preview.backdropCanvas.height === safeHeight) {
    return preview.backdropCanvas;
  }

  preview.backdropKey = key;
  preview.backdropCanvas.width = safeWidth;
  preview.backdropCanvas.height = safeHeight;
  const ctx = preview.backdropCtx;
  if (!ctx) {
    return preview.backdropCanvas;
  }
  ctx.clearRect(0, 0, safeWidth, safeHeight);
  const bg = ctx.createLinearGradient(0, 0, safeWidth, safeHeight);
  bg.addColorStop(0, palette.backdropStops[0]);
  bg.addColorStop(0.45, palette.backdropStops[1]);
  bg.addColorStop(1, palette.backdropStops[2]);
  ctx.fillStyle = bg;
  ctx.fillRect(0, 0, safeWidth, safeHeight);

  ctx.strokeStyle = palette.grid;
  ctx.lineWidth = 1;
  for (let x = 60; x < safeWidth; x += 60) {
    ctx.beginPath();
    ctx.moveTo(x, 0);
    ctx.lineTo(x, safeHeight);
    ctx.stroke();
  }
  for (let y = 60; y < safeHeight; y += 60) {
    ctx.beginPath();
    ctx.moveTo(0, y);
    ctx.lineTo(safeWidth, y);
    ctx.stroke();
  }
  return preview.backdropCanvas;
}

function drawPreviewBackdrop(ctx, width, height) {
  ctx.clearRect(0, 0, width, height);
  ctx.drawImage(ensurePreviewBackdrop(width, height), 0, 0);
}

function drawPreviewPlaceholder(ctx, width, height) {
  const palette = getPreviewPalette();
  const lines = getPreviewPlaceholderLines();
  ctx.fillStyle = palette.placeholderFill;
  ctx.fillRect(40, 48, Math.max(0, width - 80), Math.max(0, height - 96));
  ctx.fillStyle = palette.placeholderTitle;
  ctx.font = "700 30px Georgia";
  ctx.fillText(lines[0], 56, Math.max(74, height - 92));
  ctx.fillStyle = palette.placeholderText;
  ctx.font = "16px Segoe UI Variable Display";
  ctx.fillText(lines[1], 56, Math.max(98, height - 60));
}

function drawRuntimePreviewFrame(ctx, layout) {
  drawPreviewBackdrop(ctx, layout.pixelWidth, layout.pixelHeight);
  if (!preview.session) {
    drawPreviewPlaceholder(ctx, layout.pixelWidth, layout.pixelHeight);
    return;
  }

  const rect = layout.drawRect;
  ctx.imageSmoothingEnabled = true;
  ctx.drawImage(
    preview.atlasCanvas,
    0,
    0,
    preview.session.width,
    preview.session.height,
    rect.x,
    rect.y,
    rect.width,
    rect.height
  );
}

function drawMockPreviewFrame(ctx, layout) {
  const palette = getPreviewPalette();
  drawPreviewBackdrop(ctx, layout.pixelWidth, layout.pixelHeight);
  const rect = layout.drawRect;
  ctx.fillStyle = palette.mockFrameFill;
  ctx.fillRect(rect.x, rect.y, rect.width, rect.height);

  preview.dots.forEach((dot, index) => {
    const alpha = (index + 1) / Math.max(1, preview.dots.length);
    ctx.beginPath();
    ctx.fillStyle = previewRgba(palette.mockDotFill, alpha * 0.72);
    ctx.arc(dot.x, dot.y, dot.size, 0, Math.PI * 2);
    ctx.fill();
  });
}

function drawPreviewFrameNow() {
  const startedAt = performance.now();
  const layout = updatePreviewLayout();
  if (!preview.displayCtx || !layout) {
    return;
  }

  if (runtime.provider && runtime.provider.kind === "mock") {
    drawMockPreviewFrame(preview.displayCtx, layout);
  } else {
    drawRuntimePreviewFrame(preview.displayCtx, layout);
  }
  state.previewUiFrameDurationMs = Math.max(1, Math.round(performance.now() - startedAt));
  state.previewUiFrameSampleAt = Date.now();
  renderStatusLights(true);
}

function normalizePreviewBrushScale(value) {
  return Math.trunc(clamp(toNumber(value, 100), 10, 400));
}

function normalizePreviewBrushRotation(value) {
  let rotation = Math.trunc(toNumber(value, 0)) % 360;
  if (rotation < 0) {
    rotation += 360;
  }
  return rotation;
}

function normalizePreviewBrush(item) {
  if (!item || typeof item !== "object") {
    return null;
  }

  const isDefault = !!item.is_default || item.id === "default";
  const id = isDefault ? "default" : String(item.id || "").trim();
  if (!id) {
    return null;
  }

  return {
    id,
    displayName: String(item.display_name || (isDefault ? "系统默认指针" : id)).trim(),
    assetUrl: String(item.asset_url || "").trim(),
    format: String(item.format || (isDefault ? "default" : "")).trim().toLowerCase(),
    scalePercent: normalizePreviewBrushScale(item.scale_percent),
    rotationDeg: normalizePreviewBrushRotation(item.rotation_deg),
    offsetX: Math.trunc(toNumber(item.offset_x, 0)),
    offsetY: Math.trunc(toNumber(item.offset_y, 0)),
    width: Math.max(0, Math.trunc(toNumber(item.width, 0))),
    height: Math.max(0, Math.trunc(toNumber(item.height, 0))),
    isDefault,
    isActive: !!item.is_active,
    isAnimated: !!item.is_animated,
    previewDataUrl: String(item.preview_data_url || "")
  };
}

function getDefaultPreviewBrush() {
  return {
    id: "default",
    displayName: "系统默认指针",
    assetUrl: "",
    format: "default",
    scalePercent: 100,
    rotationDeg: 0,
    offsetX: 0,
    offsetY: 0,
    width: 0,
    height: 0,
    isDefault: true,
    isActive: preview.customBrush.activeBrushId === "default",
    isAnimated: false,
    previewDataUrl: ""
  };
}

function applyCustomBrushState(payload) {
  const normalizedBrushes = Array.isArray(payload && payload.brushes)
    ? payload.brushes.map(normalizePreviewBrush).filter(Boolean)
    : [];
  const activeBrushId = String(payload && payload.active_brush_id ? payload.active_brush_id : "default").trim() || "default";
  const hasDefault = normalizedBrushes.some((brush) => brush.id === "default");
  const brushes = hasDefault ? normalizedBrushes : [getDefaultPreviewBrush(), ...normalizedBrushes];
  const activeExists = brushes.some((brush) => brush.id === activeBrushId);

  preview.customBrush.activeBrushId = activeExists ? activeBrushId : "default";
  preview.customBrush.brushes = brushes.map((brush) => ({
    ...brush,
    isActive: brush.id === preview.customBrush.activeBrushId
  }));
  const nextSignature = JSON.stringify(preview.customBrush.brushes.map((brush) => [
    brush.id,
    brush.isAnimated,
    brush.previewDataUrl.length,
    brush.assetUrl
  ]));
  if (preview.customBrush.signature !== nextSignature) {
    preview.customBrush.signature = nextSignature;
  }
  updatePreviewCustomBrushElement();
  requestPreviewOverlayDraw();
}

function getActivePreviewBrush() {
  if (!preview.customBrush || !Array.isArray(preview.customBrush.brushes)) {
    return getDefaultPreviewBrush();
  }

  return preview.customBrush.brushes.find((brush) => brush.id === preview.customBrush.activeBrushId)
    || preview.customBrush.brushes.find((brush) => brush.id === "default")
    || getDefaultPreviewBrush();
}

function getPreviewBrushImageSource(brush) {
  if (!brush) {
    return "";
  }

  return brush.assetUrl || brush.previewDataUrl || "";
}

function stopPreviewCursorMotion() {
  if (preview.cursorMotionRaf) {
    window.cancelAnimationFrame(preview.cursorMotionRaf);
    preview.cursorMotionRaf = 0;
  }
  preview.cursorMotionLastAt = 0;
  preview.cursorMotionVelocityX = 0;
  preview.cursorMotionVelocityY = 0;
  preview.cursorMotionTargetVelocityX = 0;
  preview.cursorMotionTargetVelocityY = 0;
  preview.cursorMotionTargetLastAt = 0;
}

function copyPreviewCursorToDisplay(cursor) {
  preview.cursorMotionLastAt = 0;
  preview.cursorMotionVelocityX = 0;
  preview.cursorMotionVelocityY = 0;
  preview.cursorMotionTargetVelocityX = 0;
  preview.cursorMotionTargetVelocityY = 0;
  preview.cursorMotionTargetLastAt = 0;
  preview.cursorDisplay = {
    x: cursor.x,
    y: cursor.y,
    thumbWidth: cursor.thumbWidth,
    thumbHeight: cursor.thumbHeight,
    pointerX: cursor.pointerX,
    pointerY: cursor.pointerY,
    canvasWidth: cursor.canvasWidth,
    canvasHeight: cursor.canvasHeight,
    attached: cursor.attached,
    initialized: true
  };
}

function animatePreviewCursor() {
  preview.cursorMotionRaf = 0;

  const target = preview.cursor;
  const display = preview.cursorDisplay;
  const now = performance.now();
  if (!display.initialized
    || display.attached !== target.attached
    || display.thumbWidth !== target.thumbWidth
    || display.thumbHeight !== target.thumbHeight
    || display.canvasWidth !== target.canvasWidth
    || display.canvasHeight !== target.canvasHeight) {
    copyPreviewCursorToDisplay(target);
    requestPreviewOverlayDraw();
    return;
  }

  const elapsedMs = preview.cursorMotionLastAt > 0 ? clamp(now - preview.cursorMotionLastAt, 1, 50) : 16.7;
  preview.cursorMotionLastAt = now;
  const dt = elapsedMs / 1000;
  const staleMs = preview.cursorMotionTargetLastAt > 0 ? Math.max(0, now - preview.cursorMotionTargetLastAt) : 0;
  const targetVelocityDecay = Math.exp(-Math.max(0, staleMs - 35) / 140);
  const targetVelocityX = preview.cursorMotionTargetVelocityX * targetVelocityDecay;
  const targetVelocityY = preview.cursorMotionTargetVelocityY * targetVelocityDecay;
  const targetSpeed = Math.hypot(targetVelocityX, targetVelocityY);
  const leadTime = clamp(0.035 + targetSpeed / 8000, 0.035, 0.085);
  const predictedX = target.x + targetVelocityX * leadTime;
  const predictedY = target.y + targetVelocityY * leadTime;
  const targetDistance = Math.hypot(target.x - display.x, target.y - display.y);
  const stiffness = clamp(150 + targetDistance * 1.15 + targetSpeed * 0.045, 150, 520);
  const damping = 2 * Math.sqrt(stiffness) * 1.05;
  const accelerationX = (predictedX - display.x) * stiffness - preview.cursorMotionVelocityX * damping;
  const accelerationY = (predictedY - display.y) * stiffness - preview.cursorMotionVelocityY * damping;
  preview.cursorMotionVelocityX += accelerationX * dt;
  preview.cursorMotionVelocityY += accelerationY * dt;
  display.x += preview.cursorMotionVelocityX * dt;
  display.y += preview.cursorMotionVelocityY * dt;
  if (target.canvasWidth > 0 && target.canvasHeight > 0) {
    const ratioX = target.thumbWidth > 0 ? display.x / target.thumbWidth : target.pointerX / target.canvasWidth;
    const ratioY = target.thumbHeight > 0 ? display.y / target.thumbHeight : target.pointerY / target.canvasHeight;
    display.pointerX = clamp(ratioX * target.canvasWidth, 0, Math.max(0, target.canvasWidth - 1));
    display.pointerY = clamp(ratioY * target.canvasHeight, 0, Math.max(0, target.canvasHeight - 1));
  } else {
    display.pointerX = Number.NaN;
    display.pointerY = Number.NaN;
  }

  const remainingDistance = Math.hypot(target.x - display.x, target.y - display.y);
  const displaySpeed = Math.hypot(preview.cursorMotionVelocityX, preview.cursorMotionVelocityY);
  if (remainingDistance < 0.04 && displaySpeed < 3 && targetSpeed < 1) {
    display.x = target.x;
    display.y = target.y;
    display.pointerX = target.pointerX;
    display.pointerY = target.pointerY;
    preview.cursorMotionVelocityX = 0;
    preview.cursorMotionVelocityY = 0;
    requestPreviewOverlayDraw();
    return;
  }

  requestPreviewOverlayDraw();
  preview.cursorMotionRaf = window.requestAnimationFrame(animatePreviewCursor);
}

function setPreviewCursorTarget(cursor, immediate = false) {
  const now = performance.now();
  const previousTarget = preview.cursor;
  const pointerX = toNumber(cursor && cursor.pointerX, Number.NaN);
  const pointerY = toNumber(cursor && cursor.pointerY, Number.NaN);
  const canvasWidth = Math.max(0, toNumber(cursor && cursor.canvasWidth, 0));
  const canvasHeight = Math.max(0, toNumber(cursor && cursor.canvasHeight, 0));
  let thumbX = toNumber(cursor && cursor.x, 0);
  let thumbY = toNumber(cursor && cursor.y, 0);
  const thumbWidth = Math.max(0, toNumber(cursor && cursor.thumbWidth, 0));
  const thumbHeight = Math.max(0, toNumber(cursor && cursor.thumbHeight, 0));
  if (Number.isFinite(pointerX) && Number.isFinite(pointerY) && canvasWidth > 0 && canvasHeight > 0) {
    if (thumbWidth > 0) {
      thumbX = clamp((pointerX / canvasWidth) * thumbWidth, 0, thumbWidth);
    }
    if (thumbHeight > 0) {
      thumbY = clamp((pointerY / canvasHeight) * thumbHeight, 0, thumbHeight);
    }
  }
  const nextCursor = {
    x: thumbX,
    y: thumbY,
    thumbWidth,
    thumbHeight,
    pointerX,
    pointerY,
    canvasWidth,
    canvasHeight,
    attached: !!(cursor && cursor.attached)
  };
  const previousDisplay = preview.cursorDisplay;

  const shouldSnap = immediate
    || !previousDisplay.initialized
    || previousDisplay.attached !== nextCursor.attached
    || previousDisplay.thumbWidth !== nextCursor.thumbWidth
    || previousDisplay.thumbHeight !== nextCursor.thumbHeight
    || previousDisplay.canvasWidth !== nextCursor.canvasWidth
    || previousDisplay.canvasHeight !== nextCursor.canvasHeight;
  const targetContinuity = previousTarget
    && previousTarget.attached === nextCursor.attached
    && previousTarget.thumbWidth === nextCursor.thumbWidth
    && previousTarget.thumbHeight === nextCursor.thumbHeight
    && previousTarget.canvasWidth === nextCursor.canvasWidth
    && previousTarget.canvasHeight === nextCursor.canvasHeight;
  preview.cursor = nextCursor;

  if (shouldSnap) {
    stopPreviewCursorMotion();
    copyPreviewCursorToDisplay(nextCursor);
    requestPreviewOverlayDraw();
    return;
  }

  const targetElapsedMs = preview.cursorMotionTargetLastAt > 0 ? clamp(now - preview.cursorMotionTargetLastAt, 1, 120) : 0;
  if (targetContinuity && targetElapsedMs > 0) {
    const targetDt = targetElapsedMs / 1000;
    const rawVelocityX = (nextCursor.x - previousTarget.x) / targetDt;
    const rawVelocityY = (nextCursor.y - previousTarget.y) / targetDt;
    preview.cursorMotionTargetVelocityX += (rawVelocityX - preview.cursorMotionTargetVelocityX) * 0.42;
    preview.cursorMotionTargetVelocityY += (rawVelocityY - preview.cursorMotionTargetVelocityY) * 0.42;
  } else {
    preview.cursorMotionTargetVelocityX = 0;
    preview.cursorMotionTargetVelocityY = 0;
  }
  preview.cursorMotionTargetLastAt = now;

  if (!preview.cursorMotionRaf) {
    if (preview.cursorMotionLastAt <= 0) {
      preview.cursorMotionLastAt = now;
    }
    preview.cursorMotionRaf = window.requestAnimationFrame(animatePreviewCursor);
  }
}

function getPreviewCursorPoint() {
  const cursor = preview.cursorDisplay.initialized ? preview.cursorDisplay : preview.cursor;
  if (!preview.layout || !preview.session || !cursor.attached) {
    return null;
  }

  let ratioX = Number.NaN;
  let ratioY = Number.NaN;
  if (cursor.canvasWidth > 0
    && cursor.canvasHeight > 0
    && Number.isFinite(cursor.pointerX)
    && Number.isFinite(cursor.pointerY)) {
    ratioX = cursor.pointerX / cursor.canvasWidth;
    ratioY = cursor.pointerY / cursor.canvasHeight;
  } else if (cursor.thumbWidth > 0 && cursor.thumbHeight > 0) {
    ratioX = cursor.x / cursor.thumbWidth;
    ratioY = cursor.y / cursor.thumbHeight;
  }
  if (!Number.isFinite(ratioX) || !Number.isFinite(ratioY)) {
    return null;
  }

  ratioX = clamp(ratioX, 0, 1);
  ratioY = clamp(ratioY, 0, 1);
  const rect = preview.layout.drawRect;
  return {
    x: rect.x + (rect.width * ratioX),
    y: rect.y + (rect.height * ratioY)
  };
}

function drawRoundedRectPath(ctx, x, y, width, height, radius) {
  const safeWidth = Math.max(0, width);
  const safeHeight = Math.max(0, height);
  const safeRadius = Math.max(0, Math.min(radius, safeWidth * 0.5, safeHeight * 0.5));
  ctx.beginPath();
  ctx.moveTo(x + safeRadius, y);
  ctx.lineTo(x + safeWidth - safeRadius, y);
  ctx.quadraticCurveTo(x + safeWidth, y, x + safeWidth, y + safeRadius);
  ctx.lineTo(x + safeWidth, y + safeHeight - safeRadius);
  ctx.quadraticCurveTo(x + safeWidth, y + safeHeight, x + safeWidth - safeRadius, y + safeHeight);
  ctx.lineTo(x + safeRadius, y + safeHeight);
  ctx.quadraticCurveTo(x, y + safeHeight, x, y + safeHeight - safeRadius);
  ctx.lineTo(x, y + safeRadius);
  ctx.quadraticCurveTo(x, y, x + safeRadius, y);
  ctx.closePath();
}

function drawPreviewRecordingOverlay(ctx, rect) {
  if (state.recordingState !== "recording"
    && state.recordingState !== "starting"
    && state.recordingState !== "waiting"
    && state.recordingState !== "stopping") {
    return;
  }

  ctx.save();
  const palette = getPreviewPalette();
  ctx.strokeStyle = state.recordingState === "recording" ? "rgba(255, 110, 99, 0.92)" : palette.syncStroke;
  ctx.lineWidth = 4;
  drawRoundedRectPath(ctx, rect.x + 2, rect.y + 2, Math.max(0, rect.width - 4), Math.max(0, rect.height - 4), 16);
  ctx.stroke();
  ctx.fillStyle = palette.recordingBadge;
  drawRoundedRectPath(ctx, rect.x + 16, rect.y + 16, 82, 34, 10);
  ctx.fill();
  ctx.fillStyle = palette.recordingText;
  ctx.font = "700 16px Segoe UI Variable Display";
  ctx.fillText(state.recordingState === "recording" ? "REC" : "SYNC", rect.x + 34, rect.y + 38);
  ctx.restore();
}

function drawPreviewOfflineOverlay(ctx, rect) {
  const offline = (!state.backendAvailable && isHttpProvider()) || !preview.cursor.attached || !!preview.error;
  if (!offline) {
    return;
  }

  ctx.save();
  const palette = getPreviewPalette();
  ctx.fillStyle = palette.overlayScrim;
  ctx.fillRect(rect.x, rect.y, rect.width, rect.height);
  ctx.fillStyle = palette.overlayText;
  ctx.font = "700 20px Georgia";
  ctx.fillText(preview.error ? "连接异常" : "等待数据", rect.x + 24, rect.y + 36);
  ctx.restore();
}

function drawDefaultPreviewPointer(ctx, point) {
  ctx.save();
  const palette = getPreviewPalette();
  ctx.strokeStyle = palette.pointerStroke;
  ctx.lineWidth = 2;
  ctx.beginPath();
  ctx.moveTo(point.x - 24, point.y);
  ctx.lineTo(point.x + 24, point.y);
  ctx.moveTo(point.x, point.y - 24);
  ctx.lineTo(point.x, point.y + 24);
  ctx.stroke();
  ctx.beginPath();
  ctx.fillStyle = palette.pointerFill;
  ctx.arc(point.x, point.y, 6, 0, Math.PI * 2);
  ctx.fill();
  ctx.restore();
}

function drawPreviewPointerOverlay(ctx) {
  updatePreviewCustomBrushElement();
  if (!state.previewPointerOverlayVisible) {
    return;
  }

  const point = getPreviewCursorPoint();
  if (!point) {
    return;
  }

  const brush = getActivePreviewBrush();
  if (state.customBrushOverlay && brush && !brush.isDefault) {
    return;
  }

  drawDefaultPreviewPointer(ctx, point);
}

function updatePreviewCustomBrushElement() {
  const image = els.previewCustomBrushImage;
  const layer = els.previewCustomBrushLayer;
  if (!image || !layer) {
    return;
  }

  const brush = getActivePreviewBrush();
  const point = getPreviewCursorPoint();
  const source = getPreviewBrushImageSource(brush);
  if (!state.customBrushOverlay
    || !brush
    || brush.isDefault
    || !point
    || !source) {
    layer.hidden = true;
    image.removeAttribute("src");
    return;
  }

  const layout = preview.layout;
  const canvasToCssX = layout && layout.pixelWidth > 0 ? layout.cssWidth / layout.pixelWidth : 1;
  const canvasToCssY = layout && layout.pixelHeight > 0 ? layout.cssHeight / layout.pixelHeight : 1;
  const deviceScale = getPreviewDeviceScale();
  const scale = clamp(brush.scalePercent / 100, 0.1, 4);
  const sourceWidth = brush.width > 0 ? brush.width : 96;
  const sourceHeight = brush.height > 0 ? brush.height : 96;
  const width = Math.max(1, sourceWidth * scale * deviceScale * canvasToCssX);
  const height = Math.max(1, sourceHeight * scale * deviceScale * canvasToCssY);
  const centerX = (point.x + brush.offsetX * deviceScale) * canvasToCssX;
  const centerY = (point.y + brush.offsetY * deviceScale) * canvasToCssY;

  if (image.getAttribute("src") !== source) {
    image.src = source;
  }
  layer.hidden = false;
  image.style.left = `${centerX}px`;
  image.style.top = `${centerY}px`;
  image.style.width = `${width}px`;
  image.style.height = `${height}px`;
  image.style.transform = `translate(-50%, -50%) rotate(${brush.rotationDeg || 0}deg)`;
}

function parsePreviewDirtyRect(source, prefix) {
  if (!source || typeof source !== "object") {
    return { valid: false, x: 0, y: 0, width: 0, height: 0, limited: false };
  }

  const keyPrefix = typeof prefix === "string" ? prefix : "";
  const valid = !!source[`${keyPrefix}dirty_rect_valid`];
  const x = Math.max(0, Math.trunc(toNumber(source[`${keyPrefix}dirty_rect_x`], 0)));
  const y = Math.max(0, Math.trunc(toNumber(source[`${keyPrefix}dirty_rect_y`], 0)));
  const width = Math.max(0, Math.trunc(toNumber(source[`${keyPrefix}dirty_rect_width`], 0)));
  const height = Math.max(0, Math.trunc(toNumber(source[`${keyPrefix}dirty_rect_height`], 0)));
  return {
    valid: valid && width > 0 && height > 0,
    x,
    y,
    width,
    height,
    limited: !!source[`${keyPrefix}dirty_rect_limited`]
  };
}

function samePreviewDirtyRect(a, b) {
  if (!a || !b) {
    return false;
  }
  return a.valid === b.valid
    && a.x === b.x
    && a.y === b.y
    && a.width === b.width
    && a.height === b.height
    && a.limited === b.limited;
}

function copyPreviewDirtyRectToDisplay(rect) {
  preview.dirtyRectDisplay = {
    valid: !!(rect && rect.valid),
    x: rect ? rect.x : 0,
    y: rect ? rect.y : 0,
    width: rect ? rect.width : 0,
    height: rect ? rect.height : 0,
    limited: !!(rect && rect.limited),
    initialized: true,
    animationStartedAt: performance.now()
  };
}

function stopPreviewDirtyRectMotion() {
  if (preview.dirtyRectMotionRaf) {
    window.cancelAnimationFrame(preview.dirtyRectMotionRaf);
    preview.dirtyRectMotionRaf = 0;
  }
}

function animatePreviewDirtyRect() {
  preview.dirtyRectMotionRaf = 0;

  const target = preview.dirtyRect;
  const display = preview.dirtyRectDisplay;
  if (!target || !target.valid) {
    display.valid = false;
    display.initialized = true;
    requestPreviewOverlayDraw();
    return;
  }

  if (!display.initialized || !display.valid || display.limited !== target.limited) {
    copyPreviewDirtyRectToDisplay(target);
    requestPreviewOverlayDraw();
    return;
  }

  const fields = ["x", "y", "width", "height"];
  let maxDelta = 0;
  fields.forEach((field) => {
    const delta = target[field] - display[field];
    maxDelta = Math.max(maxDelta, Math.abs(delta));
    display[field] += delta * 0.24;
  });
  display.limited = target.limited;
  display.valid = true;
  requestPreviewOverlayDraw();

  if (maxDelta <= 0.35) {
    display.x = target.x;
    display.y = target.y;
    display.width = target.width;
    display.height = target.height;
    requestPreviewOverlayDraw();
    return;
  }

  preview.dirtyRectMotionRaf = window.requestAnimationFrame(animatePreviewDirtyRect);
}

function setPreviewDirtyRectTarget(rect, immediate = false) {
  const nextRect = rect && typeof rect === "object"
    ? {
      valid: !!rect.valid,
      x: Math.max(0, toNumber(rect.x, 0)),
      y: Math.max(0, toNumber(rect.y, 0)),
      width: Math.max(0, toNumber(rect.width, 0)),
      height: Math.max(0, toNumber(rect.height, 0)),
      limited: !!rect.limited
    }
    : { valid: false, x: 0, y: 0, width: 0, height: 0, limited: false };

  if (samePreviewDirtyRect(preview.dirtyRect, nextRect)) {
    return;
  }

  preview.dirtyRect = nextRect;
  if (immediate || !preview.dirtyRectDisplay.initialized || preview.dirtyRectDisplay.valid !== nextRect.valid) {
    stopPreviewDirtyRectMotion();
    copyPreviewDirtyRectToDisplay(nextRect);
    requestPreviewOverlayDraw();
    return;
  }

  preview.dirtyRectDisplay.animationStartedAt = performance.now();
  if (!preview.dirtyRectMotionRaf) {
    preview.dirtyRectMotionRaf = window.requestAnimationFrame(animatePreviewDirtyRect);
  }
}

function drawPreviewDirtyRectOverlay(ctx) {
  if (!state.previewDirtyRectVisible) {
    return;
  }

  const source = preview.dirtyRectDisplay && preview.dirtyRectDisplay.initialized
    ? preview.dirtyRectDisplay
    : preview.dirtyRect;
  if (!preview.layout || !preview.session || !source || !source.valid) {
    return;
  }
  if (preview.session.width <= 0 || preview.session.height <= 0) {
    return;
  }

  const frame = preview.layout.drawRect;
  const lineWidth = Math.max(2, Math.round(getPreviewDeviceScale() * 1.5));
  const minVisibleSize = Math.max(12, lineWidth * 5);
  let left = frame.x + (source.x / preview.session.width) * frame.width;
  let top = frame.y + (source.y / preview.session.height) * frame.height;
  let right = frame.x + ((source.x + source.width) / preview.session.width) * frame.width;
  let bottom = frame.y + ((source.y + source.height) / preview.session.height) * frame.height;
  if (right - left < minVisibleSize) {
    const center = (left + right) * 0.5;
    left = center - minVisibleSize * 0.5;
    right = center + minVisibleSize * 0.5;
  }
  if (bottom - top < minVisibleSize) {
    const center = (top + bottom) * 0.5;
    top = center - minVisibleSize * 0.5;
    bottom = center + minVisibleSize * 0.5;
  }
  left = clamp(left, frame.x, frame.x + Math.max(0, frame.width - minVisibleSize));
  top = clamp(top, frame.y, frame.y + Math.max(0, frame.height - minVisibleSize));
  right = clamp(right, left + 1, frame.x + frame.width);
  bottom = clamp(bottom, top + 1, frame.y + frame.height);
  const width = Math.max(1, right - left);
  const height = Math.max(1, bottom - top);

  ctx.save();
  ctx.strokeStyle = source.limited ? "rgba(255, 193, 84, 0.96)" : "rgba(255, 97, 160, 0.92)";
  ctx.lineWidth = lineWidth;
  ctx.setLineDash([Math.max(8, lineWidth * 4), Math.max(5, lineWidth * 2)]);
  ctx.lineDashOffset = -((performance.now() - (source.animationStartedAt || 0)) * 0.018) % Math.max(12, lineWidth * 6);
  ctx.strokeRect(left + lineWidth * 0.5, top + lineWidth * 0.5, Math.max(1, width - lineWidth), Math.max(1, height - lineWidth));
  ctx.setLineDash([]);
  ctx.strokeStyle = getPreviewPalette().dirtyRectInnerStroke;
  ctx.lineWidth = Math.max(1, lineWidth - 1);
  ctx.strokeRect(left + lineWidth * 1.5, top + lineWidth * 1.5, Math.max(1, width - lineWidth * 3), Math.max(1, height - lineWidth * 3));
  ctx.restore();
}

function drawPreviewOverlayNow() {
  const layout = preview.layout || updatePreviewLayout();
  if (!preview.overlayCtx || !layout) {
    return;
  }

  preview.overlayCtx.clearRect(0, 0, layout.pixelWidth, layout.pixelHeight);
  drawPreviewRecordingOverlay(preview.overlayCtx, layout.drawRect);
  drawPreviewOfflineOverlay(preview.overlayCtx, layout.drawRect);
  drawPreviewDirtyRectOverlay(preview.overlayCtx);
  drawPreviewPointerOverlay(preview.overlayCtx);
}

function requestPreviewFrameDraw() {
  if (preview.renderQueued) {
    return;
  }
  preview.renderQueued = true;
  window.requestAnimationFrame(() => {
    preview.renderQueued = false;
    drawPreviewFrameNow();
  });
}

function requestPreviewOverlayDraw() {
  if (preview.overlayQueued) {
    return;
  }
  preview.overlayQueued = true;
  window.requestAnimationFrame(() => {
    preview.overlayQueued = false;
    drawPreviewOverlayNow();
  });
}

function drawPreview() {
  requestPreviewFrameDraw();
  requestPreviewOverlayDraw();
}

function computePreviewMaxDim() {
  const viewport = getPreviewViewportSize();
  const longestCssPx = Math.max(viewport.width, viewport.height);
  const scale = getPreviewDeviceScale();
  return clamp(Math.round(longestCssPx * scale), 1024, 3072);
}

function logPreviewEventThrottled(message) {
  const now = Date.now();
  if (now - preview.lastLogAt < 2000) {
    return;
  }
  preview.lastLogAt = now;
  addLog(message);
}

function sendPreviewControlMessage(type) {
  if (!preview.socket || preview.socket.readyState !== WebSocket.OPEN) {
    return;
  }

  const maxDim = computePreviewMaxDim();
  const mode = "fit";
  if (type === "resize" && preview.lastSentMaxDim === maxDim && preview.lastSentMode === mode) {
    return;
  }

  preview.socket.send(JSON.stringify({
    type,
    max_dim: maxDim,
    mode
  }));
  preview.openSent = true;
  preview.lastSentMaxDim = maxDim;
  preview.lastSentMode = mode;
}

function queuePreviewResizeSend() {
  if (!isHttpProvider() || preview.disposed || !isRuntimePreviewTransportAllowed()) {
    return;
  }
  if (preview.resizeSendTimer) {
    window.clearTimeout(preview.resizeSendTimer);
  }
  preview.resizeSendTimer = window.setTimeout(() => {
    preview.resizeSendTimer = 0;
    sendPreviewControlMessage(preview.openSent ? "resize" : "open");
  }, previewResizeDebounceMs);
}

function disposeRuntimePreviewTransport(resetSession) {
  preview.disposed = true;
  if (preview.statusLightRaf) {
    window.cancelAnimationFrame(preview.statusLightRaf);
    preview.statusLightRaf = 0;
  }
  stopPreviewCursorMotion();
  stopPreviewDirtyRectMotion();
  updatePreviewCustomBrushElement();
  if (preview.resizeSendTimer) {
    window.clearTimeout(preview.resizeSendTimer);
    preview.resizeSendTimer = 0;
  }
  if (preview.reconnectTimer) {
    window.clearTimeout(preview.reconnectTimer);
    preview.reconnectTimer = 0;
  }
  if (preview.socket) {
    try {
      preview.socket.close();
    } catch {
    }
    preview.socket = null;
  }
  preview.openSent = false;
  preview.lastSentMaxDim = 0;
  preview.lastSentMode = "";
  preview.layout = null;
  if (resetSession) {
    preview.session = null;
    preview.error = null;
    preview.cursorDisplay.initialized = false;
    preview.dirtyRectDisplay.initialized = false;
    clearAtlas();
  }
}

function schedulePreviewReconnect() {
  if (preview.disposed || preview.reconnectTimer || !isRuntimePreviewTransportAllowed()) {
    return;
  }
  preview.reconnectTimer = window.setTimeout(() => {
    preview.reconnectTimer = 0;
    connectRuntimePreviewSocket();
  }, previewReconnectMs);
}

function connectRuntimePreviewSocket() {
  if (!isHttpProvider() || preview.disposed || preview.socket || !isRuntimePreviewTransportAllowed()) {
    return;
  }

  const protocol = window.location.protocol === "https:" ? "wss:" : "ws:";
  const url = `${protocol}//${window.location.host}/ws/preview/runtime`;
  const socket = new WebSocket(url);
  socket.binaryType = "arraybuffer";
  preview.socket = socket;
  preview.error = null;
  preview.openSent = false;
  preview.lastSentMaxDim = 0;
  preview.lastSentMode = "";

  socket.addEventListener("open", () => {
    if (preview.socket !== socket) {
      return;
    }
    preview.error = null;
    sendPreviewControlMessage("open");
    requestPreviewOverlayDraw();
  });

  socket.addEventListener("message", (event) => {
    if (typeof event.data === "string") {
      handlePreviewTextMessage(event.data);
      return;
    }
    if (event.data instanceof ArrayBuffer) {
      applyPreviewTilePacket(event.data);
      return;
    }
    if (event.data instanceof Blob) {
      void event.data.arrayBuffer().then(applyPreviewTilePacket).catch(() => {
      });
    }
  });

  socket.addEventListener("error", () => {
    logPreviewEventThrottled("Preview websocket error.");
  });

  socket.addEventListener("close", () => {
    if (preview.socket === socket) {
      preview.socket = null;
      preview.openSent = false;
      preview.lastSentMaxDim = 0;
      preview.lastSentMode = "";
      if (!preview.error) {
        preview.error = {
          code: "preview_socket_closed",
          message: "The preview socket closed.",
          retryable: true
        };
      }
      if (!preview.session) {
        requestPreviewFrameDraw();
      }
      requestPreviewOverlayDraw();
      schedulePreviewReconnect();
    }
  });
}

function isRuntimePreviewTransportAllowed() {
  return runtime.previewTransportAllowed === true
    && !shouldThrottleRuntimeForHiddenDocument()
    && state.contentCollapsed !== true
    && state.activeContentPage !== "settings";
}

function syncRuntimePreviewTransport() {
  if (!isHttpProvider() || preview.disposed) {
    return;
  }

  if (isRuntimePreviewTransportAllowed()) {
    connectRuntimePreviewSocket();
    queuePreviewResizeSend();
    return;
  }

  disposeRuntimePreviewTransport(false);
  preview.disposed = false;
  preview.error = null;
  requestPreviewOverlayDraw();
}

function setRuntimePreviewTransportAllowed(allowed) {
  runtime.previewTransportAllowed = allowed === true;
  syncRuntimePreviewTransport();
}

function handlePreviewTextMessage(text) {
  let message;
  try {
    message = JSON.parse(text);
  } catch {
    return;
  }

  if (!message || typeof message.type !== "string") {
    return;
  }

  if (message.type === "hello") {
    preview.error = null;
    requestPreviewOverlayDraw();
    return;
  }
  if (message.type === "session") {
    preview.error = null;
    const previousSession = preview.session;
    preview.session = {
      width: Math.max(1, toNumber(message.width, 1)),
      height: Math.max(1, toNumber(message.height, 1)),
      tileSize: Math.max(1, toNumber(message.tile_size, 256)),
      tilesX: Math.max(1, toNumber(message.tiles_x, 1)),
      tilesY: Math.max(1, toNumber(message.tiles_y, 1)),
      generation: toNumber(message.generation, 0),
      lodMaxDim: Math.max(0, toNumber(message.lod_max_dim, 0))
    };
    setPreviewDirtyRectTarget(parsePreviewDirtyRect(message, ""), true);
    resetPreviewTileStats();
    preview.layout = null;
    ensureAtlasSize(preview.session.width, preview.session.height);
    if (message.reset) {
      clearAtlas();
      requestPreviewFrameDraw();
    }
    if (!message.reset && (!previousSession
      || previousSession.width !== preview.session.width
      || previousSession.height !== preview.session.height
      || previousSession.tileSize !== preview.session.tileSize
      || previousSession.generation !== preview.session.generation)) {
      requestPreviewFrameDraw();
    }
    requestPreviewOverlayDraw();
    renderHeader();
    return;
  }
  if (message.type === "cursor") {
    const previousAttached = state.connected;
    const nextAttached = !!message.attached;
    const nextCursor = {
      x: toNumber(message.x, 0),
      y: toNumber(message.y, 0),
      thumbWidth: Math.max(0, toNumber(message.thumb_width, 0)),
      thumbHeight: Math.max(0, toNumber(message.thumb_height, 0)),
      pointerX: toNumber(message.pointer_x, Number.NaN),
      pointerY: toNumber(message.pointer_y, Number.NaN),
      canvasWidth: Math.max(0, toNumber(message.canvas_width, 0)),
      canvasHeight: Math.max(0, toNumber(message.canvas_height, 0)),
      attached: nextAttached
    };
    setPreviewCursorTarget(nextCursor);
    setPreviewDirtyRectTarget(parsePreviewDirtyRect(message, ""));
    state.connected = nextAttached;
    if (preview.cursor.thumbWidth > 0 && preview.cursor.thumbHeight > 0) {
      state.thumbWidthValue = preview.cursor.thumbWidth;
      state.thumbHeightValue = preview.cursor.thumbHeight;
      state.thumbSize = formatSize(state.thumbWidthValue, state.thumbHeightValue);
    }
    if (previousAttached !== nextAttached) {
      renderStatus();
      renderFields();
      renderPreviewChrome();
    }
    requestPreviewOverlayDraw();
    renderHeader();
    return;
  }
  if (message.type === "error") {
    preview.error = {
      code: message.code || "preview_error",
      message: message.message || "Preview error.",
      retryable: message.retryable !== false
    };
    logPreviewEventThrottled(preview.error.message);
    if (!preview.session) {
      requestPreviewFrameDraw();
    }
    requestPreviewOverlayDraw();
  }
}

function applyPreviewTilePacket(buffer) {
  if (!(buffer instanceof ArrayBuffer) || buffer.byteLength < previewTileHeaderBytes) {
    return;
  }

  const bytes = new Uint8Array(buffer);
  const magic = String.fromCharCode(bytes[0], bytes[1], bytes[2], bytes[3]);
  if (magic !== "RST1") {
    return;
  }

  const view = new DataView(buffer);
  const version = view.getUint16(4, true);
  const kind = view.getUint16(6, true);
  if (version !== 1 || kind !== 1) {
    return;
  }

  const flags = view.getUint32(8, true);
  const generation = view.getInt32(12, true);
  const tileX = view.getInt32(24, true);
  const tileY = view.getInt32(28, true);
  const width = view.getInt32(32, true);
  const height = view.getInt32(36, true);
  const stride = view.getInt32(40, true);
  const payloadBytes = view.getUint32(44, true);

  if (!preview.session || generation !== preview.session.generation) {
    if (flags & previewTileFlags.present) {
      requestPreviewFrameDraw();
    }
    return;
  }

  let appliedTile = false;
  if (payloadBytes > 0 && previewTileHeaderBytes + payloadBytes <= buffer.byteLength) {
    putPreviewTile(buffer, previewTileHeaderBytes, payloadBytes, tileX, tileY, width, height, stride);
    appliedTile = true;
  }

  if (appliedTile) {
    preview.pendingTileCount += 1;
    preview.pendingTileBytes += Math.max(0, payloadBytes);
    requestPreviewFrameDraw();
  }
  if (flags & previewTileFlags.present) {
    commitPreviewTileStats();
    requestPreviewFrameDraw();
  }
}

function putPreviewTile(buffer, payloadOffset, payloadBytes, tileX, tileY, width, height, stride) {
  if (!preview.session || width <= 0 || height <= 0) {
    return;
  }
  if (stride < width * 4) {
    return;
  }
  const requiredBytes = stride * height;
  if (requiredBytes <= 0 || payloadBytes < requiredBytes) {
    return;
  }

  ensureAtlasSize(preview.session.width, preview.session.height);
  const destinationX = tileX * preview.session.tileSize;
  const destinationY = tileY * preview.session.tileSize;
  let rgba = null;

  if (stride === width * 4) {
    rgba = new Uint8ClampedArray(buffer, payloadOffset, payloadBytes);
  } else {
    rgba = new Uint8ClampedArray(width * height * 4);
    const source = new Uint8Array(buffer, payloadOffset, payloadBytes);
    for (let row = 0; row < height; row += 1) {
      const sourceOffset = row * stride;
      const targetOffset = row * width * 4;
      rgba.set(source.subarray(sourceOffset, sourceOffset + width * 4), targetOffset);
    }
  }

  const imageData = new ImageData(rgba, width, height);
  preview.atlasCtx.putImageData(imageData, destinationX, destinationY);
}

