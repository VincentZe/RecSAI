﻿(function () {
  const hostWindowShownMessage = "host:window-shown";
  const hostDragMoveMessage = "host:drag-move";
  const hostCloseWindowMessage = "host:close-window";
  const pageScrollFadeThresholdPx = 3;
  const isEmbedded = new URLSearchParams(window.location.search).get("embedded") === "1";
  const defaultStatusText = "准备就绪";

  const state = {
    channel: "stable",
    currentVersion: "",
    sourceName: "",
    sourceBaseUrl: "",
    updateCenterUrl: "",
    errorMessage: "",
    isSuccess: false,
    items: [],
    loading: false,
    statusText: defaultStatusText,
    statusIsError: false
  };

  const els = {
    updateApp: document.getElementById("updateApp"),
    updateHeader: document.getElementById("updateHeader"),
    pageScrollRoot: document.getElementById("pageScrollRoot"),
    closeWindowButton: document.getElementById("closeWindowButton"),
    refreshButton: document.getElementById("refreshButton"),
    checkButton: document.getElementById("checkButton"),
    openCenterButton: document.getElementById("openCenterButton"),
    updateList: document.getElementById("updateList"),
    versionText: document.getElementById("versionText"),
    sourceText: document.getElementById("sourceText"),
    statusText: document.getElementById("statusText")
  };

  let statusTimerId = 0;
  let pageScrollFadeRaf = 0;
  let cardScroller = null;

  function getEmbeddedTargetOrigin() {
    return window.location.protocol === "file:" ? "*" : window.location.origin;
  }

  function hasEmbeddedParentHostBridge() {
    if (!isEmbedded || !window.parent || window.parent === window) {
      return false;
    }

    try {
      const parentHost = window.parent.ReadSAI2WebUi && window.parent.ReadSAI2WebUi.host;
      return !!(parentHost && typeof parentHost.hasBridge === "function" && parentHost.hasBridge());
    } catch {
      return false;
    }
  }

  function getHostBridge() {
    if (hasEmbeddedParentHostBridge()) {
      return {
        postMessage(message) {
          window.parent.postMessage({
            kind: "readsai2-embedded-host-message",
            message
          }, getEmbeddedTargetOrigin());
        }
      };
    }

    const bridge = window.chrome && window.chrome.webview;
    if (!bridge || typeof bridge.postMessage !== "function") {
      return null;
    }
    return bridge;
  }

  function hasHostBridge() {
    return !!getHostBridge();
  }

  function postHostMessage(message) {
    const bridge = getHostBridge();
    if (!bridge) {
      return false;
    }
    bridge.postMessage(message);
    return true;
  }

  function buildHostDragMoveMessage(event) {
    return JSON.stringify({
      kind: hostDragMoveMessage,
      screenX: event.screenX,
      screenY: event.screenY,
      clientX: event.clientX,
      clientY: event.clientY
    });
  }

  function returnEmbeddedPageToDashboard() {
    if (!isEmbedded || !window.parent || window.parent === window) {
      return false;
    }

    window.parent.postMessage({
      kind: "readsai2-embedded-return-dashboard"
    }, getEmbeddedTargetOrigin());
    return true;
  }

  function bindEmbeddedContextReturn() {
    if (!isEmbedded) {
      return;
    }

    let rightPointerStart = null;
    const isReturnBlockedTarget = (target) => target instanceof Element
      && !!target.closest("button, input, select, textarea, a, label, summary, [role='button'], [data-host-drag-ignore='true']");

    window.addEventListener("pointerdown", (event) => {
      if (event.button !== 2) {
        rightPointerStart = null;
        return;
      }

      rightPointerStart = {
        time: performance.now(),
        blocked: isReturnBlockedTarget(event.target)
      };
    }, { capture: true });

    window.addEventListener("contextmenu", (event) => {
      const pointerStart = rightPointerStart;
      rightPointerStart = null;
      if (event.defaultPrevented) {
        return;
      }

      event.preventDefault();
      const hasFreshPointerStart = pointerStart && performance.now() - pointerStart.time < 2500;
      const shouldBlockReturn = hasFreshPointerStart
        ? pointerStart.blocked
        : isReturnBlockedTarget(event.target);
      if (shouldBlockReturn) {
        return;
      }

      returnEmbeddedPageToDashboard();
    });
  }

  function postHostCommand(command, payload) {
    if (hasEmbeddedParentHostBridge()) {
      window.parent.postMessage({
        kind: "readsai2-embedded-host-command",
        command,
        payload: payload && typeof payload === "object" ? payload : {}
      }, getEmbeddedTargetOrigin());
      return true;
    }

    const bridge = getHostBridge();
    if (!bridge) {
      return false;
    }
    bridge.postMessage(JSON.stringify({
      kind: "webui-command",
      command,
      payload: payload && typeof payload === "object" ? payload : {}
    }));
    return true;
  }

  function normalizeChannel(channel) {
    return String(channel || "").toLowerCase() === "beta" ? "beta" : "stable";
  }

  function getChannelLabel(channel) {
    return normalizeChannel(channel) === "beta" ? "Beta" : "Stable";
  }

  function setStatus(text, isError, sticky) {
    state.statusText = typeof text === "string" && text.trim() ? text.trim() : defaultStatusText;
    state.statusIsError = !!isError;
    if (els.statusText) {
      els.statusText.textContent = state.statusText;
      els.statusText.style.color = state.statusIsError ? "var(--danger)" : "var(--muted)";
    }

    if (statusTimerId) {
      window.clearTimeout(statusTimerId);
      statusTimerId = 0;
    }

    if (!sticky && !state.statusIsError && state.statusText !== defaultStatusText) {
      statusTimerId = window.setTimeout(() => {
        statusTimerId = 0;
        setStatus(defaultStatusText, false, false);
      }, 1800);
    }
  }

  function requestStateSync(channel) {
    state.loading = true;
    render();
    const nextChannel = normalizeChannel(channel || state.channel);
    if (postHostCommand("update-center-sync", { channel: nextChannel })) {
      setStatus("正在同步更新目录…", false, true);
      return;
    }

    applyMockState(nextChannel);
  }

  function applyState(payload) {
    const source = payload && typeof payload === "object" ? payload : {};
    state.channel = normalizeChannel(source.channel);
    state.currentVersion = String(source.current_version || "");
    state.sourceName = String(source.source_name || "");
    state.sourceBaseUrl = String(source.source_base_url || "");
    state.updateCenterUrl = String(source.update_center_url || "");
    state.errorMessage = String(source.error_message || "");
    state.isSuccess = source.is_success === true;
    state.items = Array.isArray(source.items) ? source.items.map(normalizeItem).filter(Boolean) : [];
    state.loading = false;
    render();
  }

  function normalizeItem(item) {
    if (!item || typeof item !== "object") {
      return null;
    }

    return {
      version: String(item.version || ""),
      date: String(item.date || ""),
      title: String(item.title || "版本更新"),
      body: String(item.body || ""),
      packageName: String(item.package_name || ""),
      packageUrl: String(item.package_url || ""),
      manifestUrl: String(item.manifest_url || ""),
      badgeText: String(item.badge_text || ""),
      actionKind: String(item.action_kind || "none"),
      actionText: String(item.action_text || ""),
      actionTarget: String(item.action_target || ""),
      actionEnabled: item.action_enabled === true,
      isLatest: item.is_latest === true,
      isCurrent: item.is_current_version === true
    };
  }

  function applyMockState(channel) {
    applyState({
      channel,
      current_version: "0.0.0-dev",
      source_name: "本地调试",
      source_base_url: "",
      update_center_url: "",
      is_success: true,
      items: [
        {
          version: "0.0.0-dev",
          date: "2026-05-15",
          title: "本地调试版本",
          body: "- 更新中心 WebUI 页面\n- 支持 Stable/Beta 切换\n- 支持版本动作按钮",
          badge_text: "当前",
          action_kind: "current",
          action_text: "当前版本",
          action_enabled: false,
          is_latest: true,
          is_current_version: true
        },
        {
          version: "0.0.1-dev",
          date: "2026-05-14",
          title: "录制流程整理",
          body: "## 变化\n- 调整命令入口\n- 整合 WebUI 设置页\n- 优化嵌入页面布局\n\n## 备注\n用于本地观察更新中心三列卡片效果。",
          badge_text: "",
          action_kind: "rollback",
          action_text: "回退到此版本",
          action_enabled: true,
          package_name: "RecSAI-debug.zip",
          package_url: "https://example.invalid/RecSAI-debug.zip",
          manifest_url: "https://example.invalid/manifest.0.0.1-dev.json"
        },
        {
          version: "0.0.2-dev",
          date: "2026-05-13",
          title: "界面布局试验",
          body: "- 预览页支持横向内容切换\n- 设置页改成 iframe 动态加载\n- 帮助与支持页面接入 WebUI\n- 更新中心页面接入 WebUI",
          badge_text: "最新",
          action_kind: "install",
          action_text: "安装此版本",
          action_enabled: true,
          manifest_url: "https://example.invalid/update.json"
        },
        {
          version: "0.0.3-dev",
          date: "2026-05-12",
          title: "横向滚动验证",
          body: "- 用于本地验证滚轮横移\n- 拖拽结束后吸附到最近卡片\n- 卡片正文仍保留独立纵向滚动",
          badge_text: "",
          action_kind: "none",
          action_text: "仅调试",
          action_enabled: false
        }
      ]
    });
    setStatus("使用本地调试数据", false);
  }

  function parseMarkdownLines(text) {
    return String(text || "")
      .split(/\r?\n/)
      .map((line) => line.trimEnd())
      .filter((line, index, lines) => line.trim() || index < lines.length - 1);
  }

  function renderMarkdownText(target, text) {
    target.replaceChildren();
    const lines = parseMarkdownLines(text);
    if (lines.length === 0) {
      const p = document.createElement("p");
      p.className = "update-card-empty";
      p.textContent = "暂无日志内容。";
      target.appendChild(p);
      return;
    }

    lines.forEach((line) => {
      const trimmed = line.trim();
      const p = document.createElement(trimmed.startsWith("#") ? "h4" : "p");
      if (trimmed.startsWith("- ")) {
        p.className = "update-card-bullet";
        p.textContent = trimmed;
      } else if (trimmed.startsWith("## ")) {
        p.textContent = trimmed.slice(3).trim();
      } else if (trimmed.startsWith("# ")) {
        p.textContent = trimmed.slice(2).trim();
      } else if (!trimmed) {
        p.className = "update-card-gap";
        p.textContent = "";
      } else {
        p.textContent = trimmed;
      }
      target.appendChild(p);
    });
  }

  function render() {
    document.querySelectorAll("[data-channel]").forEach((button) => {
      const active = normalizeChannel(button.dataset.channel) === state.channel;
      button.classList.toggle("is-active", active);
      button.setAttribute("aria-pressed", active ? "true" : "false");
    });

    if (els.versionText) {
      els.versionText.textContent = state.currentVersion ? `当前版本 ${state.currentVersion}` : "当前版本 -";
    }
    if (els.sourceText) {
      const channelText = `${getChannelLabel(state.channel)} 频道`;
      els.sourceText.textContent = state.sourceName
        ? `${channelText} · 来源 ${state.sourceName}`
        : (state.loading ? `正在加载 ${channelText} 更新目录...` : channelText);
    }
    if (els.openCenterButton) {
      els.openCenterButton.disabled = !state.updateCenterUrl;
    }

    renderList();
    queuePageScrollFadeUpdate();
  }

  function renderList() {
    if (!els.updateList) {
      return;
    }

    els.updateList.replaceChildren();
    if (state.loading) {
      els.updateList.appendChild(createEmptyState("正在加载更新目录", "请稍候。"));
      queueCardScrollerRefresh();
      return;
    }

    if (state.items.length === 0) {
      els.updateList.appendChild(createEmptyState("未能加载更新目录", state.errorMessage || "请稍后刷新重试。"));
      queueCardScrollerRefresh();
      return;
    }

    state.items.forEach((item) => {
      els.updateList.appendChild(createUpdateCard(item));
    });
    queueCardScrollerRefresh();
  }

  function createEmptyState(title, body) {
    const box = document.createElement("article");
    box.className = "update-empty";
    const h = document.createElement("h3");
    h.textContent = title;
    const p = document.createElement("p");
    p.textContent = body || "";
    box.append(h, p);
    return box;
  }

  function buildCardMetaText(item, headerTitle) {
    if (!item) {
      return "";
    }

    const versionText = item.version ? `v${item.version}` : "";
    const hasVersion = versionText && String(headerTitle || "").trim().toLowerCase() !== versionText.toLowerCase();
    if (!hasVersion) {
      return item.date || "";
    }
    if (!item.date) {
      return versionText;
    }
    return `${versionText}  ${item.date}`;
  }

  function createUpdateCard(item) {
    const card = document.createElement("article");
    card.className = "update-card";
    card.classList.toggle("is-current", item.isCurrent);
    card.classList.toggle("is-latest", item.isLatest);

    const head = document.createElement("div");
    head.className = "update-card-head";

    const titleBox = document.createElement("div");
    titleBox.className = "update-card-title";
    const title = document.createElement("strong");
    title.textContent = item.title || "版本更新";
    const version = document.createElement("span");
    version.textContent = buildCardMetaText(item, title.textContent);
    titleBox.append(title, version);

    const meta = document.createElement("div");
    meta.className = "update-card-meta";
    if (item.date) {
      const date = document.createElement("span");
      date.textContent = item.date;
      meta.appendChild(date);
    }
    if (item.badgeText) {
      const badge = document.createElement("span");
      badge.className = "update-card-badge";
      badge.textContent = item.badgeText;
      meta.appendChild(badge);
    }

    head.append(titleBox, meta);

    const body = document.createElement("div");
    body.className = "update-card-body";
    renderMarkdownText(body, item.body);

    const foot = document.createElement("div");
    foot.className = "update-card-foot";
    const packageText = document.createElement("span");
    packageText.textContent = item.packageName || item.packageUrl || item.manifestUrl || " ";
    const action = document.createElement("button");
    action.className = "button button-secondary update-card-action";
    action.type = "button";
    action.disabled = !item.actionEnabled;
    action.textContent = item.actionText || "下载不可用";
    action.addEventListener("click", () => executeCardAction(item));
    foot.append(packageText, action);

    card.append(head, body, foot);
    return card;
  }

  function executeCardAction(item) {
    if (!item || !item.actionEnabled) {
      return;
    }

    if (item.actionKind === "install" || item.actionKind === "rollback") {
      const actionText = item.actionKind === "rollback" ? "回退" : "安装";
      if (postHostCommand("update-center-install-version", {
        channel: state.channel,
        version: item.version,
        manifest_url: item.manifestUrl || item.actionTarget
      })) {
        setStatus(`正在准备${actionText} ${item.version || "目标版本"}...`, false, true);
      } else {
        setStatus("当前环境无法直接安装版本。", true, true);
      }
      return;
    }

    if (item.actionTarget) {
      postHostCommand("update-center-open-target", { target: item.actionTarget });
      setStatus("已请求打开目标", false);
    }
  }

  function updatePageScrollFade() {
    pageScrollFadeRaf = 0;
    if (!els.pageScrollRoot) {
      return;
    }

    const scrollTop = Math.max(0, els.pageScrollRoot.scrollTop || 0);
    const maxScrollTop = Math.max(0, (els.pageScrollRoot.scrollHeight || 0) - (els.pageScrollRoot.clientHeight || 0));
    const hasTopFade = scrollTop > pageScrollFadeThresholdPx;
    const hasBottomFade = maxScrollTop - scrollTop > pageScrollFadeThresholdPx;

    let nextClass = "scroll-fade-none";
    if (hasTopFade && hasBottomFade) {
      nextClass = "scroll-fade-both";
    } else if (hasTopFade) {
      nextClass = "scroll-fade-top";
    } else if (hasBottomFade) {
      nextClass = "scroll-fade-bottom";
    }

    els.pageScrollRoot.classList.remove("scroll-fade-none", "scroll-fade-top", "scroll-fade-bottom", "scroll-fade-both");
    els.pageScrollRoot.classList.add(nextClass);
  }

  function queuePageScrollFadeUpdate() {
    if (pageScrollFadeRaf) {
      return;
    }
    pageScrollFadeRaf = window.requestAnimationFrame(updatePageScrollFade);
  }

  function queueCardScrollerRefresh() {
    if (!cardScroller || typeof cardScroller.refresh !== "function") {
      return;
    }

    window.requestAnimationFrame(() => {
      cardScroller.refresh();
    });
  }

  function bindDragSurface(el) {
    if (!el) {
      return;
    }

    el.addEventListener("pointerdown", (event) => {
      if (event.button !== 0 || !event.isPrimary) {
        return;
      }

      const interactiveTarget = event.target instanceof Element
        ? event.target.closest("button, input, select, textarea, a, label, summary, [role='button'], [data-host-drag-ignore='true']")
        : null;
      if (interactiveTarget || !hasHostBridge()) {
        return;
      }

      event.preventDefault();
      postHostMessage(buildHostDragMoveMessage(event));
    });
  }

  function bindEvents() {
    bindEmbeddedContextReturn();
    bindDragSurface(els.updateHeader);
    if (window.ReadSAI2HorizontalCards && typeof window.ReadSAI2HorizontalCards.bind === "function") {
      cardScroller = window.ReadSAI2HorizontalCards.bind({
        root: els.pageScrollRoot,
        list: els.updateList,
        verticalScrollSelector: ".update-card-body",
        draggingClassName: "is-update-card-dragging"
      });
    }
    if (els.pageScrollRoot) {
      els.pageScrollRoot.addEventListener("scroll", queuePageScrollFadeUpdate, { passive: true });
    }
    window.addEventListener("resize", queuePageScrollFadeUpdate);

    if (els.closeWindowButton) {
      els.closeWindowButton.addEventListener("click", () => {
        if (!returnEmbeddedPageToDashboard()) {
          postHostMessage(hostCloseWindowMessage);
        }
      });
    }
    if (els.refreshButton) {
      els.refreshButton.addEventListener("click", () => requestStateSync(state.channel));
    }
    if (els.checkButton) {
      els.checkButton.addEventListener("click", () => {
        postHostCommand("update-center-check", { channel: state.channel });
        setStatus("已请求检查更新", false);
      });
    }
    if (els.openCenterButton) {
      els.openCenterButton.addEventListener("click", () => {
        if (state.updateCenterUrl) {
          postHostCommand("update-center-open-target", { target: state.updateCenterUrl });
        }
      });
    }
    document.querySelectorAll("[data-channel]").forEach((button) => {
      button.addEventListener("click", () => {
        requestStateSync(button.dataset.channel);
      });
    });

    window.addEventListener("keydown", (event) => {
      if (event.key === "Escape") {
        if (!returnEmbeddedPageToDashboard()) {
          postHostMessage(hostCloseWindowMessage);
        }
      }
    });
  }

  function bindHostBridge() {
    if (isEmbedded && window.parent && window.parent !== window) {
      const isTrustedParentMessage = (event) => {
        if (window.location.protocol === "file:") {
          return true;
        }
        return event.origin === window.location.origin;
      };

      window.addEventListener("message", (event) => {
        if (!isTrustedParentMessage(event)) {
          return;
        }
        handleHostBridgeMessage(event.data);
      });
      return;
    }

    const bridge = getHostBridge();
    if (!bridge || typeof bridge.addEventListener !== "function") {
      return;
    }

    bridge.addEventListener("message", (event) => {
      handleHostBridgeMessage(event.data);
    });
  }

  function handleHostBridgeMessage(data) {
    if (typeof data === "string") {
      if (data === hostWindowShownMessage) {
        requestStateSync(state.channel);
      }
      return;
    }

    if (!data || typeof data !== "object") {
      return;
    }

    if (data.kind === "update-center-state") {
      applyState(data.state);
      setStatus(state.errorMessage ? state.errorMessage : "已同步", !!state.errorMessage, !!state.errorMessage);
      return;
    }

    if (data.kind === "webui-ack" && typeof data.message === "string" && data.message.trim()) {
      setStatus(data.message.trim(), data.ok === false, data.ok === false);
    }
  }

  function init() {
    if (isEmbedded) {
      document.documentElement.classList.add("is-embedded");
    }
    bindEvents();
    bindHostBridge();
    render();
    requestStateSync(state.channel);
  }

  init();
})();
