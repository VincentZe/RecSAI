﻿(function () {
  const defaultInteractiveSelector = [
    "button",
    "input",
    "select",
    "textarea",
    "a",
    "label",
    "summary",
    "[role='button']",
    "[data-host-drag-ignore='true']"
  ].join(", ");

  function clamp(value, min, max) {
    return Math.min(max, Math.max(min, value));
  }

  function getMaxScrollLeft(root) {
    if (!root) {
      return 0;
    }
    return Math.max(0, root.scrollWidth - root.clientWidth);
  }

  function setScrollLeftNow(root, left) {
    if (!root) {
      return;
    }

    const previousScrollBehavior = root.style.scrollBehavior;
    root.style.scrollBehavior = "auto";
    root.scrollLeft = left;
    root.style.scrollBehavior = previousScrollBehavior;
  }

  function normalizeWheelDelta(event, root) {
    const scale = event.deltaMode === 1
      ? 44
      : (event.deltaMode === 2 ? Math.max(1, root.clientWidth) : 1);
    const deltaX = event.deltaX * scale;
    const deltaY = event.deltaY * scale;
    return Math.abs(deltaX) > Math.abs(deltaY) ? deltaX : deltaY;
  }

  function easeOutCubic(t) {
    const n = clamp(t, 0, 1);
    return 1 - Math.pow(1 - n, 3);
  }

  function canScrollVertically(element, deltaY) {
    if (!element) {
      return false;
    }

    const maxScrollTop = Math.max(0, element.scrollHeight - element.clientHeight);
    if (maxScrollTop <= 1 || Math.abs(deltaY) <= 0.1) {
      return false;
    }

    if (deltaY < 0) {
      return element.scrollTop > 1;
    }
    return element.scrollTop < maxScrollTop - 1;
  }

  function shouldIgnorePointerTarget(root, target, selector) {
    if (!(target instanceof Element) || !root.contains(target)) {
      return true;
    }
    return !!target.closest(selector || defaultInteractiveSelector);
  }

  function bind(options) {
    const root = options && options.root;
    const list = options && options.list;
    if (!root || !list) {
      return null;
    }

    const interactiveSelector = options.interactiveSelector || defaultInteractiveSelector;
    const verticalScrollSelector = options.verticalScrollSelector || "";
    const draggingClassName = options.draggingClassName || "is-card-dragging";
    const snapDurationMs = Math.max(1, Number(options.snapDurationMs) || 180);
    const prefersReducedMotion = window.matchMedia
      && window.matchMedia("(prefers-reduced-motion: reduce)").matches;

    let wheelSnapTimer = 0;
    let resizeSnapTimer = 0;
    let snapAnimationFrame = 0;
    let dragState = null;
    let suppressNextClick = false;

    function getCards() {
      return Array.from(list.children).filter((child) => child instanceof HTMLElement && child.offsetWidth > 0);
    }

    function getSnapStep() {
      const cards = getCards();
      if (cards.length >= 2) {
        const first = cards[0].getBoundingClientRect();
        const second = cards[1].getBoundingClientRect();
        const step = Math.abs(second.left - first.left);
        if (step > 1) {
          return step;
        }
      }
      if (cards.length === 1) {
        const rect = cards[0].getBoundingClientRect();
        if (rect.width > 1) {
          return rect.width;
        }
      }
      return Math.max(1, root.clientWidth);
    }

    function getWheelScrollDelta(event) {
      const rawDelta = normalizeWheelDelta(event, root);
      if (Math.abs(rawDelta) <= 0.1) {
        return 0;
      }

      const step = getSnapStep();
      const amount = Math.min(1, Math.max(0.08, Math.abs(rawDelta) / 120));
      return Math.sign(rawDelta) * step * amount;
    }

    function cancelSnapAnimation() {
      if (!snapAnimationFrame) {
        return;
      }
      window.cancelAnimationFrame(snapAnimationFrame);
      snapAnimationFrame = 0;
    }

    function animateScrollTo(left) {
      cancelSnapAnimation();
      const maxScrollLeft = getMaxScrollLeft(root);
      const targetLeft = clamp(left, 0, maxScrollLeft);
      const startLeft = root.scrollLeft;
      const distance = targetLeft - startLeft;
      if (Math.abs(distance) <= 0.5 || prefersReducedMotion) {
        setScrollLeftNow(root, targetLeft);
        return;
      }

      const startTime = performance.now();
      const tick = (now) => {
        const progress = clamp((now - startTime) / snapDurationMs, 0, 1);
        setScrollLeftNow(root, startLeft + distance * easeOutCubic(progress));
        if (progress < 1) {
          snapAnimationFrame = window.requestAnimationFrame(tick);
          return;
        }
        snapAnimationFrame = 0;
        setScrollLeftNow(root, targetLeft);
      };
      snapAnimationFrame = window.requestAnimationFrame(tick);
    }

    function getNearestSnapLeft() {
      const maxScrollLeft = getMaxScrollLeft(root);
      if (maxScrollLeft <= 1) {
        return 0;
      }

      const cards = getCards();
      if (cards.length === 0) {
        return clamp(root.scrollLeft, 0, maxScrollLeft);
      }

      const rootRect = root.getBoundingClientRect();
      const currentLeft = root.scrollLeft;
      let nearestLeft = currentLeft;
      let nearestDistance = Number.POSITIVE_INFINITY;

      cards.forEach((card) => {
        const cardRect = card.getBoundingClientRect();
        const left = clamp(currentLeft + cardRect.left - rootRect.left, 0, maxScrollLeft);
        const distance = Math.abs(left - currentLeft);
        if (distance < nearestDistance) {
          nearestDistance = distance;
          nearestLeft = left;
        }
      });

      return clamp(nearestLeft, 0, maxScrollLeft);
    }

    function snapToNearest(behavior) {
      const left = getNearestSnapLeft();
      cancelSnapAnimation();
      if (Math.abs(left - root.scrollLeft) <= 0.5) {
        setScrollLeftNow(root, left);
        return;
      }

      if (behavior === "auto" || prefersReducedMotion) {
        setScrollLeftNow(root, left);
        return;
      }

      animateScrollTo(left);
    }

    function scheduleSnap(delayMs) {
      if (wheelSnapTimer) {
        window.clearTimeout(wheelSnapTimer);
      }
      wheelSnapTimer = window.setTimeout(() => {
        wheelSnapTimer = 0;
        snapToNearest();
      }, Math.max(0, delayMs == null ? 120 : delayMs));
    }

    function refresh() {
      cancelSnapAnimation();
      const maxScrollLeft = getMaxScrollLeft(root);
      if (maxScrollLeft <= 1) {
        setScrollLeftNow(root, 0);
        return;
      }
      setScrollLeftNow(root, clamp(root.scrollLeft, 0, maxScrollLeft));
    }

    root.addEventListener("wheel", (event) => {
      const maxScrollLeft = getMaxScrollLeft(root);
      if (maxScrollLeft <= 1) {
        return;
      }

      const target = event.target instanceof Element ? event.target : null;
      const verticalScroller = verticalScrollSelector && target
        ? target.closest(verticalScrollSelector)
        : null;
      if (verticalScroller && root.contains(verticalScroller) && canScrollVertically(verticalScroller, event.deltaY)) {
        return;
      }

      const delta = getWheelScrollDelta(event);
      if (Math.abs(delta) <= 0.1) {
        return;
      }

      const nextLeft = clamp(root.scrollLeft + delta, 0, maxScrollLeft);
      if (Math.abs(nextLeft - root.scrollLeft) <= 0.1) {
        return;
      }

      event.preventDefault();
      cancelSnapAnimation();
      setScrollLeftNow(root, nextLeft);
      scheduleSnap(150);
    }, { passive: false });

    root.addEventListener("pointerdown", (event) => {
      if (event.button !== 0 || !event.isPrimary || shouldIgnorePointerTarget(root, event.target, interactiveSelector)) {
        return;
      }

      const maxScrollLeft = getMaxScrollLeft(root);
      if (maxScrollLeft <= 1) {
        return;
      }

      cancelSnapAnimation();
      dragState = {
        pointerId: event.pointerId,
        startX: event.clientX,
        startY: event.clientY,
        startLeft: root.scrollLeft,
        active: false
      };
      root.setPointerCapture(event.pointerId);
    });

    root.addEventListener("pointermove", (event) => {
      if (!dragState || event.pointerId !== dragState.pointerId) {
        return;
      }

      const deltaX = event.clientX - dragState.startX;
      const deltaY = event.clientY - dragState.startY;
      if (!dragState.active) {
        if (Math.abs(deltaX) < 5 || Math.abs(deltaX) < Math.abs(deltaY)) {
          return;
        }
        dragState.active = true;
        suppressNextClick = true;
        root.classList.add(draggingClassName);
        list.classList.add(draggingClassName);
      }

      event.preventDefault();
      setScrollLeftNow(root, clamp(dragState.startLeft - deltaX, 0, getMaxScrollLeft(root)));
    });

    function endDrag(event) {
      if (!dragState || event.pointerId !== dragState.pointerId) {
        return;
      }

      const shouldSnap = dragState.active;
      root.classList.remove(draggingClassName);
      list.classList.remove(draggingClassName);
      try {
        root.releasePointerCapture(event.pointerId);
      } catch {
        // Pointer capture can already be released by the browser.
      }
      dragState = null;
      if (shouldSnap) {
        scheduleSnap(0);
      }
    }

    root.addEventListener("pointerup", endDrag);
    root.addEventListener("pointercancel", endDrag);
    root.addEventListener("click", (event) => {
      if (!suppressNextClick) {
        return;
      }
      suppressNextClick = false;
      event.preventDefault();
      event.stopPropagation();
    }, true);
    window.addEventListener("resize", () => {
      if (resizeSnapTimer) {
        window.clearTimeout(resizeSnapTimer);
      }
      resizeSnapTimer = window.setTimeout(() => {
        resizeSnapTimer = 0;
        refresh();
        snapToNearest("auto");
      }, 80);
    });

    return {
      refresh,
      snapToNearest
    };
  }

  window.ReadSAI2HorizontalCards = {
    bind
  };
})();
