﻿(() => {
  const defaultStatusText = "准备就绪";

  const defaultState = {
    title: "支持与反馈",
    subtitle: "从这里获得支持 或者 支持作者",
    cards: [],
    statusText: defaultStatusText,
    statusIsError: false
  };

  function normalizeCard(card) {
    if (!card || typeof card !== "object") {
      return null;
    }

    return {
      title: String(card.title || ""),
      subtitle: String(card.subtitle || ""),
      note: String(card.note || ""),
      body: String(card.body || ""),
      foot: String(card.foot || ""),
      imageUrl: String(card.image_url || ""),
      targetUrl: String(card.target_url || ""),
      tone: String(card.tone || "default")
    };
  }

  function getMockState() {
    return {
      title: "支持与反馈",
      subtitle: "从这里获得支持 或者 支持作者",
      cards: [
        {
          title: "赞助入口",
          subtitle: " ",
          note: "使用支付宝 [扫一扫]",
          body: "感觉用的人不多\n不过随便了",
          foot: "我恰饭",
          image_url: "./assets/support/QRcode%201.jpg",
          tone: "sponsor"
        },
        {
          title: "RecSAI反馈群",
          subtitle: "群号：825116351",
          note: "扫一扫二维码 加入QQ群聊",
          body: "☆☆☆☆☆☆\nBug出率提高50%↑↑↑",
          foot: "我码字",
          image_url: "./assets/support/QRcode%202.jpg",
          tone: "feedback"
        },
        {
          title: "开发不易，欢迎支持",
          subtitle: "五年开发 三年摸鱼",
          note: " ",
          body: "我的频道：\nhttps://space.bilibili.com/10543701",
          foot: "BB空间 什么都发 谨慎关注",
          image_url: "./assets/support/bg_1.jpg",
          target_url: "https://space.bilibili.com/10543701",
          tone: "channel"
        }
      ]
    };
  }

  function resolveAssetUrl(url) {
    const raw = String(url || "").trim();
    if (!raw) {
      return "";
    }

    try {
      return new URL(raw, window.location.href).href;
    } catch {
      return raw;
    }
  }

  function createSupportCard(card, openTarget) {
    const article = document.createElement("article");
    article.className = `support-card is-${card.tone}`;
    if (card.targetUrl) {
      article.classList.add("has-target");
      article.tabIndex = 0;
      article.addEventListener("click", () => openTarget(card.targetUrl));
      article.addEventListener("keydown", (event) => {
        if (event.key === "Enter" || event.key === " ") {
          event.preventDefault();
          openTarget(card.targetUrl);
        }
      });
    }

    const media = document.createElement("div");
    media.className = "support-card-media";
    const imageUrl = resolveAssetUrl(card.imageUrl);
    if (imageUrl && card.tone === "channel") {
      article.style.setProperty("--support-card-image", `url("${imageUrl.replace(/"/g, "%22")}")`);
    }
    if (imageUrl) {
      const img = document.createElement("img");
      img.src = imageUrl;
      img.alt = "";
      img.loading = "lazy";
      media.appendChild(img);
    }

    const copy = document.createElement("div");
    copy.className = "support-card-copy";
    const header = document.createElement("div");
    header.className = "support-card-header";
    const title = document.createElement("h2");
    title.textContent = card.title;
    const subtitle = document.createElement("p");
    subtitle.textContent = card.subtitle.trim() || " ";
    header.append(title, subtitle);

    const note = document.createElement("p");
    note.className = "support-card-note";
    note.textContent = card.note.trim() || " ";

    const body = document.createElement("div");
    body.className = "support-card-body";
    String(card.body || "").split(/\r?\n/).forEach((line) => {
      const p = document.createElement("p");
      p.textContent = line || " ";
      body.appendChild(p);
    });

    const foot = document.createElement("p");
    foot.className = "support-card-foot";
    foot.textContent = card.foot;

    copy.append(header, media, note, body, foot);
    article.append(copy);
    return article;
  }

  function mount(root, options = {}) {
    const state = { ...defaultState };
    let statusTimerId = 0;
    let disposed = false;
    const host = options.host || null;

    root.replaceChildren();

    const app = document.createElement("div");
    app.className = "support-app is-inline-support";

    const header = document.createElement("header");
    header.className = "masthead support-header";
    const headerMain = document.createElement("div");
    headerMain.className = "support-header-main";
    const titleBlock = document.createElement("div");
    titleBlock.className = "support-title-block";
    const titleText = document.createElement("h1");
    const subtitleText = document.createElement("p");
    titleBlock.append(titleText, subtitleText);
    headerMain.append(titleBlock);
    header.appendChild(headerMain);

    const scrollRoot = document.createElement("div");
    scrollRoot.className = "page-scroll-root content-shell support-scroll-root scroll-fade-none";
    const cardsRoot = document.createElement("main");
    cardsRoot.className = "support-workspace";
    cardsRoot.setAttribute("aria-label", "支持与反馈");
    scrollRoot.appendChild(cardsRoot);

    app.append(header, scrollRoot);
    root.appendChild(app);

    function setStatus(text, isError, sticky) {
      state.statusText = typeof text === "string" && text.trim() ? text.trim() : defaultStatusText;
      state.statusIsError = !!isError;

      if (statusTimerId) {
        window.clearTimeout(statusTimerId);
        statusTimerId = 0;
      }

      if (!sticky && !state.statusIsError && state.statusText !== defaultStatusText) {
        statusTimerId = window.setTimeout(() => {
          statusTimerId = 0;
          setStatus(defaultStatusText, false, false);
        }, 1800);
      }
    }

    function applyState(payload) {
      if (disposed) {
        return;
      }

      const source = payload && typeof payload === "object" ? payload : {};
      state.title = String(source.title || "支持与反馈");
      state.subtitle = String(source.subtitle || "从这里获得支持 或者 支持作者");
      state.cards = Array.isArray(source.cards) ? source.cards.map(normalizeCard).filter(Boolean) : [];
      render();
    }

    function openTarget(targetUrl) {
      if (!targetUrl) {
        return;
      }

      const sent = host && typeof host.postCommand === "function"
        ? host.postCommand("help-support-open-target", { target: targetUrl })
        : false;
      if (!sent) {
        window.open(targetUrl, "_blank", "noopener");
      }
      setStatus("已请求打开链接", false);
    }

    function render() {
      titleText.textContent = state.title || "支持与反馈";
      subtitleText.textContent = state.subtitle;
      cardsRoot.replaceChildren();
      state.cards.forEach((card) => {
        cardsRoot.appendChild(createSupportCard(card, openTarget));
      });
    }

    function requestStateSync() {
      const sent = host && typeof host.postCommand === "function"
        ? host.postCommand("help-support-sync")
        : false;
      if (!sent) {
        applyState(getMockState());
        setStatus("使用本地调试数据", false);
        return;
      }
      setStatus("正在同步支持信息…", false, true);
    }

    const handleMessage = (data) => {
      if (!data || typeof data !== "object") {
        return;
      }

      if (data.kind === "help-support-state") {
        applyState(data.state);
        setStatus("已同步", false);
        return;
      }

      if (data.kind === "webui-ack" && typeof data.message === "string" && data.message.trim()) {
        setStatus(data.message.trim(), data.ok === false, data.ok === false);
      }
    };

    applyState(defaultState);
    requestStateSync();

    return {
      handleMessage,
      unmount() {
        disposed = true;
        if (statusTimerId) {
          window.clearTimeout(statusTimerId);
          statusTimerId = 0;
        }
        root.replaceChildren();
      }
    };
  }

  window.ReadSAI2HelpSupport = {
    mount
  };
})();
