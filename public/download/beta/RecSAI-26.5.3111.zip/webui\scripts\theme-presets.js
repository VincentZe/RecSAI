﻿(function (global) {
  const defaultThemeColor = "#4f8cff";
  const defaultBackgroundColor = "#f4f6fb";
  const darkBackgroundColor = "#0e0f13";
  const builtInPresets = Object.freeze([
    { id: "light", label: "亮色", description: "原亮色皮肤", themeMode: "light", themeColor: defaultThemeColor, backgroundColor: defaultBackgroundColor, builtIn: true },
    { id: "dark", label: "暗色", description: "原暗色皮肤", themeMode: "dark", themeColor: "#53d1b6", backgroundColor: darkBackgroundColor, builtIn: true }
  ]);
  const builtInPresetMap = Object.freeze(builtInPresets.reduce((map, preset) => {
    map[preset.id] = preset;
    return map;
  }, {}));
  const derivedColorProperties = Object.freeze([
    "--user-accent",
    "--user-bg",
    "--bg",
    "--bg-elevated",
    "--card-bg",
    "--panel-border",
    "--panel-glow",
    "--panel-glow-core",
    "--panel-glow-mid",
    "--text",
    "--muted",
    "--accent",
    "--accent-2",
    "--accent-strong",
    "--accent-soft",
    "--accent-soft-core",
    "--accent-soft-mid",
    "--record-button-start",
    "--record-button-end",
    "--record-button-text",
    "--record-button-glow",
    "--record-button-ring",
    "--record-button-recording-start",
    "--record-button-recording-end",
    "--record-button-recording-glow",
    "--record-button-recording-ring",
    "--ok",
    "--scope-host",
    "--scope-webui",
    "--scope-runtime",
    "--scope-tag-text",
    "--surface-tint-start",
    "--surface-tint-end",
    "--shadow",
    "--surface-hover-shadow",
    "--surface-raised-shadow",
    "--control-idle-bg",
    "--control-thumb-bg",
    "--control-thumb-shadow",
    "--focus-ring",
    "--accent-glow"
  ]);

  const defaultStateKeys = Object.freeze({
    customPresets: "webuiThemeCustomPresets",
    lightPreset: "webuiLightThemePreset",
    darkPreset: "webuiDarkThemePreset",
    currentPreset: "themePreset",
    themeColor: "webuiThemeColor",
    backgroundColor: "webuiBackgroundColor"
  });

  function clamp(value, min, max) {
    return Math.max(min, Math.min(max, value));
  }

  function normalizeHexColor(value, fallback) {
    const text = String(value || "").trim();
    const fallbackColor = typeof fallback === "string" && fallback.trim() ? fallback : defaultThemeColor;
    return /^#[0-9a-fA-F]{6}$/.test(text) ? text.toLowerCase() : fallbackColor;
  }

  function normalizeThemeColor(value) {
    return normalizeHexColor(value, defaultThemeColor);
  }

  function normalizeBackgroundColor(value) {
    return normalizeHexColor(value, defaultBackgroundColor);
  }

  function normalizePresetId(id, fallback) {
    const text = String(id || "").trim();
    if (!text) {
      return fallback || "light";
    }
    if (Object.prototype.hasOwnProperty.call(builtInPresetMap, text.toLowerCase())) {
      return text.toLowerCase();
    }
    return text.slice(0, 64);
  }

  function normalizeCustomPreset(input) {
    const item = input && typeof input === "object" ? input : {};
    const id = normalizePresetId(item.id, "");
    if (!id || Object.prototype.hasOwnProperty.call(builtInPresetMap, id)) {
      return null;
    }

    return {
      id,
      label: String(item.label || "自定义主题").trim().slice(0, 24) || "自定义主题",
      themeColor: normalizeThemeColor(item.themeColor || item.theme_color),
      backgroundColor: normalizeBackgroundColor(item.backgroundColor || item.background_color),
      builtIn: false
    };
  }

  function normalizeCustomPresets(value) {
    const source = Array.isArray(value) ? value : [];
    const result = [];
    const seen = new Set(Object.keys(builtInPresetMap));
    source.forEach((item) => {
      const preset = normalizeCustomPreset(item);
      if (!preset || seen.has(preset.id)) {
        return;
      }
      seen.add(preset.id);
      result.push(preset);
    });
    return result.slice(0, 12);
  }

  function getAllPresets(customPresets) {
    return builtInPresets.concat(normalizeCustomPresets(customPresets));
  }

  function getPreset(id, customPresets) {
    const normalizedId = normalizePresetId(id, "");
    const presets = getAllPresets(customPresets);
    return presets.find((preset) => preset.id === normalizedId) || builtInPresetMap.light;
  }

  function inferPreset(themeColor, backgroundColor, customPresets) {
    const normalizedThemeColor = normalizeThemeColor(themeColor);
    const normalizedBackgroundColor = normalizeBackgroundColor(backgroundColor);
    const matchedPreset = getAllPresets(customPresets).find((preset) => (
      normalizeThemeColor(preset.themeColor) === normalizedThemeColor
        && normalizeBackgroundColor(preset.backgroundColor) === normalizedBackgroundColor
    ));
    return matchedPreset ? matchedPreset.id : "";
  }

  function normalizePreset(value, themeColor, backgroundColor, customPresets) {
    const text = normalizePresetId(value, "");
    if (text && getPreset(text, customPresets).id === text) {
      return text;
    }
    return inferPreset(themeColor, backgroundColor, customPresets);
  }

  function getKeys(keys) {
    return { ...defaultStateKeys, ...(keys || {}) };
  }

  function getPresetForMode(mode, sourceState, keys) {
    const resolvedKeys = getKeys(keys);
    const source = sourceState && typeof sourceState === "object" ? sourceState : {};
    const effectiveMode = mode === "dark" ? "dark" : "light";
    const presetId = effectiveMode === "dark" ? source[resolvedKeys.darkPreset] : source[resolvedKeys.lightPreset];
    return getPreset(presetId, source[resolvedKeys.customPresets]);
  }

  function applyPresetForMode(mode, targetState, keys) {
    const resolvedKeys = getKeys(keys);
    const target = targetState && typeof targetState === "object" ? targetState : {};
    const preset = getPresetForMode(mode, target, resolvedKeys);
    target[resolvedKeys.currentPreset] = preset.id;
    target[resolvedKeys.themeColor] = normalizeThemeColor(preset.themeColor);
    target[resolvedKeys.backgroundColor] = normalizeBackgroundColor(preset.backgroundColor);
    return preset;
  }

  function syncPresetColors(targetState, keys) {
    const resolvedKeys = getKeys(keys);
    const target = targetState && typeof targetState === "object" ? targetState : {};
    const preset = getPreset(target[resolvedKeys.currentPreset], target[resolvedKeys.customPresets]);
    target[resolvedKeys.currentPreset] = preset.id;
    target[resolvedKeys.themeColor] = normalizeThemeColor(preset.themeColor);
    target[resolvedKeys.backgroundColor] = normalizeBackgroundColor(preset.backgroundColor);
    return preset;
  }

  function componentToHex(value) {
    return Math.round(clamp(value, 0, 255)).toString(16).padStart(2, "0");
  }

  function rgbToHex(rgb) {
    return `#${componentToHex(rgb.r)}${componentToHex(rgb.g)}${componentToHex(rgb.b)}`;
  }

  function hexToRgb(hex, fallback) {
    const normalized = normalizeHexColor(hex, fallback || defaultThemeColor);
    return {
      r: parseInt(normalized.slice(1, 3), 16),
      g: parseInt(normalized.slice(3, 5), 16),
      b: parseInt(normalized.slice(5, 7), 16)
    };
  }

  function mixRgbColors(a, b, amount) {
    const t = clamp(amount, 0, 1);
    return {
      r: a.r + (b.r - a.r) * t,
      g: a.g + (b.g - a.g) * t,
      b: a.b + (b.b - a.b) * t
    };
  }

  function getRgbLuminance(rgb) {
    const channel = (value) => {
      const normalized = clamp(value, 0, 255) / 255;
      return normalized <= 0.03928
        ? normalized / 12.92
        : Math.pow((normalized + 0.055) / 1.055, 2.4);
    };
    return 0.2126 * channel(rgb.r) + 0.7152 * channel(rgb.g) + 0.0722 * channel(rgb.b);
  }

  function rgbToHsl(rgb) {
    const r = clamp(rgb.r, 0, 255) / 255;
    const g = clamp(rgb.g, 0, 255) / 255;
    const b = clamp(rgb.b, 0, 255) / 255;
    const max = Math.max(r, g, b);
    const min = Math.min(r, g, b);
    const lightness = (max + min) / 2;
    if (max === min) {
      return { h: 0, s: 0, l: lightness };
    }

    const delta = max - min;
    const saturation = lightness > 0.5
      ? delta / (2 - max - min)
      : delta / (max + min);
    let hue = 0;
    if (max === r) {
      hue = (g - b) / delta + (g < b ? 6 : 0);
    } else if (max === g) {
      hue = (b - r) / delta + 2;
    } else {
      hue = (r - g) / delta + 4;
    }
    return { h: hue * 60, s: saturation, l: lightness };
  }

  function hslToRgb(hsl) {
    const h = ((hsl.h % 360) + 360) % 360 / 360;
    const s = clamp(hsl.s, 0, 1);
    const l = clamp(hsl.l, 0, 1);
    if (s === 0) {
      const value = l * 255;
      return { r: value, g: value, b: value };
    }

    const hueToRgb = (p, q, t) => {
      let value = t;
      if (value < 0) {
        value += 1;
      }
      if (value > 1) {
        value -= 1;
      }
      if (value < 1 / 6) {
        return p + (q - p) * 6 * value;
      }
      if (value < 1 / 2) {
        return q;
      }
      if (value < 2 / 3) {
        return p + (q - p) * (2 / 3 - value) * 6;
      }
      return p;
    };

    const q = l < 0.5 ? l * (1 + s) : l + s - l * s;
    const p = 2 * l - q;
    return {
      r: hueToRgb(p, q, h + 1 / 3) * 255,
      g: hueToRgb(p, q, h) * 255,
      b: hueToRgb(p, q, h - 1 / 3) * 255
    };
  }

  function adjustRgbTone(rgb, saturationDelta, lightnessDelta) {
    const hsl = rgbToHsl(rgb);
    return hslToRgb({
      h: hsl.h,
      s: clamp(hsl.s + saturationDelta, 0, 1),
      l: clamp(hsl.l + lightnessDelta, 0.08, 0.92)
    });
  }

  function shiftRgbHue(rgb, hueDelta, saturationDelta, lightnessDelta) {
    const hsl = rgbToHsl(rgb);
    return hslToRgb({
      h: hsl.h + hueDelta,
      s: clamp(hsl.s + saturationDelta, 0, 1),
      l: clamp(hsl.l + lightnessDelta, 0.08, 0.92)
    });
  }

  function normalizeHue(value) {
    return ((value % 360) + 360) % 360;
  }

  function smoothstep(edge0, edge1, value) {
    const t = clamp((value - edge0) / (edge1 - edge0), 0, 1);
    return t * t * (3 - (2 * t));
  }

  function getNearestHueDelta(delta, referenceDelta) {
    let adjusted = delta;
    while (adjusted - referenceDelta > 180) {
      adjusted -= 360;
    }
    while (adjusted - referenceDelta < -180) {
      adjusted += 360;
    }
    return adjusted;
  }

  function getRecordingHueDelta(rgb, fallbackDelta) {
    const hue = normalizeHue(rgbToHsl(rgb).h);
    const magentaStart = 300;
    const magentaEnd = 334;
    const magentaFeather = 12;
    const magentaTargetHue = 92;
    const magentaCyanTargetHue = 156;
    const magentaCyanWeight = smoothstep(316, 324, hue);
    const magentaWeight = smoothstep(magentaStart - magentaFeather, magentaStart, hue)
      * (1 - smoothstep(magentaEnd, magentaEnd + magentaFeather, hue));

    if (magentaWeight <= 0) {
      return fallbackDelta;
    }

    const targetHue = magentaTargetHue + ((magentaCyanTargetHue - magentaTargetHue) * magentaCyanWeight);
    const targetDelta = getNearestHueDelta(targetHue - hue, fallbackDelta);
    return fallbackDelta + ((targetDelta - fallbackDelta) * magentaWeight);
  }

  function rgbaColor(rgb, alpha) {
    return `rgba(${Math.round(clamp(rgb.r, 0, 255))}, ${Math.round(clamp(rgb.g, 0, 255))}, ${Math.round(clamp(rgb.b, 0, 255))}, ${clamp(alpha, 0, 1).toFixed(3)})`;
  }

  function deriveColorProperties(options) {
    const source = options && typeof options === "object" ? options : {};
    const effectiveThemeMode = source.effectiveThemeMode === "dark" ? "dark" : "light";
    const preset = source.preset && typeof source.preset === "object" ? source.preset : builtInPresetMap[effectiveThemeMode];
    const fallbackThemeColor = source.defaultThemeColor || defaultThemeColor;
    const fallbackBackgroundColor = source.defaultBackgroundColor || defaultBackgroundColor;
    const accentHex = normalizeHexColor(source.themeColor || preset.themeColor, fallbackThemeColor);
    const backgroundHex = normalizeHexColor(source.backgroundColor || preset.backgroundColor, fallbackBackgroundColor);
    const clearProperties = Array.from(derivedColorProperties);

    const hasCustomAccent = accentHex !== fallbackThemeColor;
    const hasCustomBackground = backgroundHex !== fallbackBackgroundColor;
    if (preset.builtIn && !hasCustomAccent && !hasCustomBackground) {
      return { clearProperties, properties: {} };
    }
    if (!hasCustomAccent && !hasCustomBackground) {
      return { clearProperties, properties: {} };
    }

    const baseBgHex = hasCustomBackground
      ? backgroundHex
      : effectiveThemeMode === "dark"
        ? darkBackgroundColor
        : fallbackBackgroundColor;
    const accent = hexToRgb(accentHex, fallbackThemeColor);
    const background = hexToRgb(baseBgHex, fallbackBackgroundColor);
    const isDarkTheme = effectiveThemeMode === "dark";
    const backgroundIsLight = getRgbLuminance(background) >= 0.5;
    const textRgb = backgroundIsLight ? { r: 16, g: 20, b: 28 } : { r: 238, g: 241, b: 245 };
    const elevatedTarget = backgroundIsLight ? { r: 255, g: 255, b: 255 } : { r: 238, g: 241, b: 245 };
    const borderTarget = backgroundIsLight ? textRgb : { r: 255, g: 255, b: 255 };
    const elevatedMix = backgroundIsLight ? 0.16 : 0.08;
    const borderMix = backgroundIsLight ? 0.15 : 0.24;
    const tintStartMix = isDarkTheme ? 0.12 : 0.08;
    const tintEndMix = backgroundIsLight ? 0.12 : 0.08;
    const shadowRgb = backgroundIsLight ? mixRgbColors(background, textRgb, 0.74) : { r: 0, g: 0, b: 0 };
    const controlBgRgb = mixRgbColors(background, textRgb, backgroundIsLight ? 0.08 : 0.1);
    const thumbRgb = mixRgbColors(background, elevatedTarget, backgroundIsLight ? 0.28 : 0.78);
    const tagCodec = adjustRgbTone(accent, 0.04, backgroundIsLight ? 0.08 : 0.12);
    const tagInterval = adjustRgbTone(accent, -0.16, backgroundIsLight ? 0.02 : 0.18);
    const tagVolume = adjustRgbTone(accent, -0.28, backgroundIsLight ? -0.12 : 0.12);
    const recordButtonEnd = shiftRgbHue(accent, isDarkTheme ? 48 : -22, 0.06, isDarkTheme ? 0.08 : 0.04);
    const recordButtonLuminance = (getRgbLuminance(accent) + getRgbLuminance(recordButtonEnd)) / 2;
    const recordingHueDelta = getRecordingHueDelta(accent, 154);
    const recordingButtonStart = shiftRgbHue(accent, recordingHueDelta, 0.07, isDarkTheme ? 0.08 : 0.07);
    const recordingButtonEnd = shiftRgbHue(recordButtonEnd, recordingHueDelta, -0.02, isDarkTheme ? 0.02 : 0.04);

    return {
      clearProperties,
      properties: {
        "--user-accent": accentHex,
        "--user-bg": backgroundHex,
        "--bg": baseBgHex,
        "--bg-elevated": rgbaColor(mixRgbColors(background, elevatedTarget, elevatedMix), 0.96),
        "--card-bg": rgbaColor(mixRgbColors(background, elevatedTarget, elevatedMix), 0.96),
        "--panel-border": rgbToHex(mixRgbColors(background, borderTarget, borderMix)),
        "--panel-glow": rgbaColor(accent, isDarkTheme ? 0.14 : 0.16),
        "--panel-glow-core": rgbaColor(accent, isDarkTheme ? 0.32 : 0.42),
        "--panel-glow-mid": rgbaColor(accent, isDarkTheme ? 0.16 : 0.2),
        "--text": rgbToHex(textRgb),
        "--muted": rgbToHex(mixRgbColors(background, textRgb, backgroundIsLight ? 0.58 : 0.68)),
        "--accent": accentHex,
        "--accent-2": rgbToHex(tagCodec),
        "--accent-strong": accentHex,
        "--accent-soft": rgbaColor(accent, isDarkTheme ? 0.14 : 0.16),
        "--accent-soft-core": rgbaColor(accent, isDarkTheme ? 0.28 : 0.34),
        "--accent-soft-mid": rgbaColor(accent, isDarkTheme ? 0.14 : 0.17),
        "--record-button-start": accentHex,
        "--record-button-end": rgbToHex(recordButtonEnd),
        "--record-button-text": recordButtonLuminance > 0.36 ? "#081118" : "#fff7f5",
        "--record-button-glow": rgbaColor(accent, backgroundIsLight ? 0.32 : 0.34),
        "--record-button-ring": rgbaColor(recordButtonEnd, 0.34),
        "--record-button-recording-start": rgbToHex(recordingButtonStart),
        "--record-button-recording-end": rgbToHex(recordingButtonEnd),
        "--record-button-recording-glow": rgbaColor(recordingButtonStart, backgroundIsLight ? 0.3 : 0.32),
        "--record-button-recording-ring": rgbaColor(recordingButtonEnd, backgroundIsLight ? 0.28 : 0.3),
        "--ok": rgbToHex(tagInterval),
        "--scope-host": rgbToHex(tagCodec),
        "--scope-webui": accentHex,
        "--scope-runtime": rgbToHex(tagVolume),
        "--scope-tag-text": rgbToHex(mixRgbColors(background, textRgb, backgroundIsLight ? 0.72 : 0.82)),
        "--surface-tint-start": rgbaColor(mixRgbColors(background, accent, tintStartMix), 0.76),
        "--surface-tint-end": rgbaColor(mixRgbColors(background, elevatedTarget, tintEndMix), 0.78),
        "--shadow": `0 ${backgroundIsLight ? 8 : 10}px ${backgroundIsLight ? 18 : 22}px ${rgbaColor(shadowRgb, backgroundIsLight ? 0.12 : 0.32)}`,
        "--surface-hover-shadow": `0 12px 22px ${rgbaColor(shadowRgb, backgroundIsLight ? 0.13 : 0.36)}`,
        "--surface-raised-shadow": `0 14px 28px ${rgbaColor(shadowRgb, backgroundIsLight ? 0.16 : 0.34)}`,
        "--control-idle-bg": rgbaColor(controlBgRgb, backgroundIsLight ? 0.1 : 0.16),
        "--control-thumb-bg": rgbaColor(thumbRgb, 0.96),
        "--control-thumb-shadow": `0 2px 6px ${rgbaColor(shadowRgb, backgroundIsLight ? 0.2 : 0.36)}`,
        "--focus-ring": rgbaColor(accent, backgroundIsLight ? 0.42 : 0.5),
        "--accent-glow": rgbaColor(accent, backgroundIsLight ? 0.46 : 0.54)
      }
    };
  }

  global.ReadSAI2ThemePresets = Object.freeze({
    presets: builtInPresets,
    presetMap: builtInPresetMap,
    defaultThemeColor,
    defaultBackgroundColor,
    darkBackgroundColor,
    derivedColorProperties,
    normalizeHexColor,
    normalizeThemeColor,
    normalizeBackgroundColor,
    normalizePresetId,
    normalizeCustomPreset,
    normalizeCustomPresets,
    getAllPresets,
    getPreset,
    inferPreset,
    normalizePreset,
    getPresetForMode,
    applyPresetForMode,
    syncPresetColors,
    hexToRgb,
    rgbToHex,
    deriveColorProperties
  });
})(window);
