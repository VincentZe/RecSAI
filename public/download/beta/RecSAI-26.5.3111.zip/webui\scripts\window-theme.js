﻿(function (global) {
  const storageKey = "readsai2-webui-state";

  function normalizeThemeMode(mode) {
    return mode === "dark" || mode === "auto" ? mode : "light";
  }

  function readStoredThemeState() {
    try {
      const raw = global.localStorage ? global.localStorage.getItem(storageKey) : "";
      const stored = raw ? JSON.parse(raw) : null;
      return stored && typeof stored === "object" ? stored : null;
    } catch {
      return null;
    }
  }

  function cloneObject(value) {
    return JSON.parse(JSON.stringify(value));
  }

  function createController() {
    const themeUtils = global.ReadSAI2ThemePresets;
    const themePreferenceQuery = global.matchMedia ? global.matchMedia("(prefers-color-scheme: dark)") : null;
    const state = {
      themeMode: "light",
      webuiLightThemePreset: "light",
      webuiDarkThemePreset: "dark",
      webuiThemeCustomPresets: [],
      webuiThemeColor: themeUtils ? themeUtils.defaultThemeColor : "#4f8cff",
      webuiBackgroundColor: themeUtils ? themeUtils.defaultBackgroundColor : "#f4f6fb"
    };

    function getEffectiveThemeMode(mode) {
      const normalized = normalizeThemeMode(mode);
      if (normalized !== "auto") {
        return normalized;
      }
      return themePreferenceQuery && themePreferenceQuery.matches ? "dark" : "light";
    }

    function applyStoredState() {
      const storedTheme = readStoredThemeState();
      if (!storedTheme || !themeUtils) {
        return;
      }

      state.themeMode = normalizeThemeMode(storedTheme.themeMode);
      if (typeof storedTheme.webuiLightThemePreset === "string") {
        state.webuiLightThemePreset = themeUtils.normalizePresetId(storedTheme.webuiLightThemePreset, "light");
      }
      if (typeof storedTheme.webuiDarkThemePreset === "string") {
        state.webuiDarkThemePreset = themeUtils.normalizePresetId(storedTheme.webuiDarkThemePreset, "dark");
      }
      if (Array.isArray(storedTheme.webuiThemeCustomPresets)) {
        state.webuiThemeCustomPresets = themeUtils.normalizeCustomPresets(storedTheme.webuiThemeCustomPresets);
      }
      if (typeof storedTheme.webuiThemeColor === "string") {
        state.webuiThemeColor = themeUtils.normalizeThemeColor(storedTheme.webuiThemeColor);
      }
      if (typeof storedTheme.webuiBackgroundColor === "string") {
        state.webuiBackgroundColor = themeUtils.normalizeBackgroundColor(storedTheme.webuiBackgroundColor);
      }
    }

    function applyPayload(payload) {
      const source = payload && typeof payload === "object" ? payload : {};
      if (!themeUtils) {
        return;
      }

      if (typeof source.theme_mode === "string") {
        state.themeMode = normalizeThemeMode(source.theme_mode);
      }
      const hasThemeSlotPreset = Object.prototype.hasOwnProperty.call(source, "webui_light_theme_preset")
        || Object.prototype.hasOwnProperty.call(source, "webui_dark_theme_preset");
      if (typeof source.webui_light_theme_preset === "string") {
        state.webuiLightThemePreset = themeUtils.normalizePresetId(source.webui_light_theme_preset, "light");
      }
      if (typeof source.webui_dark_theme_preset === "string") {
        state.webuiDarkThemePreset = themeUtils.normalizePresetId(source.webui_dark_theme_preset, "dark");
      }
      if (Array.isArray(source.webui_theme_custom_presets)) {
        state.webuiThemeCustomPresets = themeUtils.normalizeCustomPresets(source.webui_theme_custom_presets);
      }
      if (typeof source.webui_theme_color === "string") {
        state.webuiThemeColor = themeUtils.normalizeThemeColor(source.webui_theme_color);
      }
      if (typeof source.webui_background_color === "string") {
        state.webuiBackgroundColor = themeUtils.normalizeBackgroundColor(source.webui_background_color);
      }
      if (typeof source.webui_theme_preset === "string") {
        const legacyPreset = themeUtils.normalizePreset(
          source.webui_theme_preset,
          state.webuiThemeColor,
          state.webuiBackgroundColor,
          state.webuiThemeCustomPresets);
        if (!hasThemeSlotPreset && legacyPreset && legacyPreset !== "light" && legacyPreset !== "dark") {
          if (getEffectiveThemeMode(state.themeMode) === "dark") {
            state.webuiDarkThemePreset = legacyPreset;
          } else {
            state.webuiLightThemePreset = legacyPreset;
          }
        }
      }
    }

    function apply(payload) {
      applyStoredState();
      applyPayload(payload);

      const effectiveThemeMode = getEffectiveThemeMode(state.themeMode);
      document.documentElement.dataset.theme = effectiveThemeMode;
      document.documentElement.dataset.themeMode = normalizeThemeMode(state.themeMode);

      if (!themeUtils) {
        return;
      }

      const themeState = {
        webuiThemeCustomPresets: cloneObject(state.webuiThemeCustomPresets),
        webuiLightThemePreset: state.webuiLightThemePreset,
        webuiDarkThemePreset: state.webuiDarkThemePreset,
        webuiThemeColor: state.webuiThemeColor,
        webuiBackgroundColor: state.webuiBackgroundColor
      };
      const preset = themeUtils.getPresetForMode(effectiveThemeMode, themeState);
      const accentHex = themeUtils.normalizeThemeColor(preset.themeColor);
      const backgroundHex = themeUtils.normalizeBackgroundColor(preset.backgroundColor);
      const derived = themeUtils.deriveColorProperties({
        effectiveThemeMode,
        preset,
        themeColor: accentHex,
        backgroundColor: backgroundHex,
        defaultThemeColor: themeUtils.defaultThemeColor,
        defaultBackgroundColor: themeUtils.defaultBackgroundColor
      });

      derived.clearProperties.forEach((name) => {
        document.documentElement.style.removeProperty(name);
      });
      Object.entries(derived.properties).forEach(([name, value]) => {
        document.documentElement.style.setProperty(name, value);
      });
      document.documentElement.dataset.themePreset = preset.id;
    }

    if (global.addEventListener) {
      global.addEventListener("storage", (event) => {
        if (event.key === storageKey) {
          apply(null);
        }
      });
    }

    if (themePreferenceQuery) {
      const handlePreferenceChange = () => {
        if (state.themeMode === "auto") {
          apply(null);
        }
      };

      if (typeof themePreferenceQuery.addEventListener === "function") {
        themePreferenceQuery.addEventListener("change", handlePreferenceChange);
      } else if (typeof themePreferenceQuery.addListener === "function") {
        themePreferenceQuery.addListener(handlePreferenceChange);
      }
    }

    return {
      apply
    };
  }

  global.ReadSAI2WindowTheme = Object.freeze({
    createController
  });
})(window);
