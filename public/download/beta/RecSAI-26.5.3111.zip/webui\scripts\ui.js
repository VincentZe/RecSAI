﻿function bindHostResizeGrip(el, message) {
  if (!el) {
    return;
  }

  el.addEventListener("pointerdown", (event) => {
    if (event.button !== 0 || !event.isPrimary) {
      return;
    }

    event.preventDefault();
    const collapsedMessage = el.dataset.collapsedResizeMessage || "";
    const nextMessage = state.contentCollapsed === true && collapsedMessage
      ? collapsedMessage
      : message;
    if (state.contentCollapsed === true) {
      dashboardHostManualResizeUntil = performance.now() + 2000;
      dashboardHostResizeSuppressUntil = dashboardHostManualResizeUntil;
      clearDashboardHostSizeSyncQueue();
    }
    postHostMessage(nextMessage, "Window resize grips are only available in the desktop WebView host.");
  });
}

const dashboardCloseAnimationDurationMs = 330;
const dashboardMinimizeAnimationDurationMs = 360;
const dashboardRestoreAnimationDurationMs = 320;
const mastheadRestoreMotionDurationMs = 900;
const dashboardResizeGripMoveDelayMs = 90;
const dashboardResizeGripSwitchDurationMs = 540;
const contentPageSwitchFallbackMs = 460;
const hostRequestCloseWindowMessage = "host:request-close-window";
const hostWindowShownMessage = "host:window-shown";
const hostCloseWindowMessage = "host:close-window";
const hostMinimizeWindowMessage = "host:minimize-window";
let dashboardCloseTimer = 0;
let dashboardMinimizeTimer = 0;
let dashboardRestoreTimer = 0;
let mastheadRestoreTimer = 0;
let dashboardResizeGripMoveTimer = 0;
let dashboardResizeGripSwitchTimer = 0;
let contentPageSwitchTimer = 0;
let contentPageSwitchToken = 0;
let activeInlineSettingsPage = "";
let activeInlineSettingsController = null;
let recordPresetTagMenuPortal = null;
let recordPresetTagMenuShell = null;
let recordPresetTagMenuSource = null;
let recordPresetTagMenuCloseTimer = 0;
let controlRailResizeInteraction = null;
let quickExportResetTimer = 0;
let quickExportActive = false;
let quickExportCancelPending = false;

function beginDashboardCloseSequence() {
  if (dashboardCloseTimer) {
    return;
  }

  if (!els.appShell) {
    postHostMessage(hostCloseWindowMessage, "Window close is only available in the desktop WebView host.");
    return;
  }

  clearMastheadRestoreMotion();
  els.appShell.classList.add("is-window-closing");
  dashboardCloseTimer = window.setTimeout(() => {
    dashboardCloseTimer = 0;
    if (!postHostMessage(hostCloseWindowMessage, "Window close is only available in the desktop WebView host.")) {
      els.appShell.classList.remove("is-window-closing");
    }
  }, dashboardCloseAnimationDurationMs);
}

function clearDashboardMinimizeSequence() {
  if (dashboardMinimizeTimer) {
    window.clearTimeout(dashboardMinimizeTimer);
    dashboardMinimizeTimer = 0;
  }
  if (els.appShell) {
    els.appShell.classList.remove("is-window-minimizing");
  }
}

function beginDashboardMinimizeSequence() {
  if (dashboardMinimizeTimer) {
    return;
  }

  if (!els.appShell) {
    postHostMessage(hostMinimizeWindowMessage, "Window minimize is only available in the desktop WebView host.");
    return;
  }

  clearMastheadRestoreMotion();
  els.appShell.classList.remove("is-window-restoring");
  els.appShell.classList.add("is-window-minimizing");
  dashboardMinimizeTimer = window.setTimeout(() => {
    dashboardMinimizeTimer = 0;
    if (!postHostMessage(hostMinimizeWindowMessage, "Window minimize is only available in the desktop WebView host.")) {
      els.appShell.classList.remove("is-window-minimizing");
    }
  }, dashboardMinimizeAnimationDurationMs);
}

function clearMastheadRestoreMotion() {
  if (mastheadRestoreTimer) {
    window.clearTimeout(mastheadRestoreTimer);
    mastheadRestoreTimer = 0;
  }
  if (els.masthead) {
    els.masthead.classList.remove("is-masthead-restoring");
  }
}

function playMastheadRestoreMotion() {
  if (!els.masthead) {
    return;
  }

  clearMastheadRestoreMotion();
  void els.masthead.offsetWidth;
  els.masthead.classList.add("is-masthead-restoring");
  mastheadRestoreTimer = window.setTimeout(() => {
    mastheadRestoreTimer = 0;
    if (els.masthead) {
      els.masthead.classList.remove("is-masthead-restoring");
    }
  }, mastheadRestoreMotionDurationMs);
}

function beginDashboardRestoreSequence() {
  if (!els.appShell) {
    return;
  }

  clearDashboardMinimizeSequence();
  els.appShell.classList.remove("is-window-closing");
  playMastheadRestoreMotion();
  els.appShell.classList.add("is-window-restoring");
  if (dashboardRestoreTimer) {
    window.clearTimeout(dashboardRestoreTimer);
  }
  dashboardRestoreTimer = window.setTimeout(() => {
    dashboardRestoreTimer = 0;
    if (els.appShell) {
      els.appShell.classList.remove("is-window-restoring");
    }
  }, dashboardRestoreAnimationDurationMs);
}

function getAckProgress(data) {
  if (!data || typeof data !== "object") {
    return null;
  }

  const numericProgress = Number(data.progress);
  if (Number.isFinite(numericProgress)) {
    return clamp(numericProgress, 0, 1);
  }

  const processed = Number(data.processed);
  const total = Number(data.total);
  if (Number.isFinite(processed) && Number.isFinite(total) && total > 0) {
    return clamp(processed / total, 0, 1);
  }
  return null;
}

function setQuickExportButtonProgress(progress, active) {
  if (!els.quickExportButton) {
    return;
  }

  const safeProgress = clamp(toNumber(progress, 0), 0, 1);
  quickExportActive = !!active;
  if (!quickExportActive) {
    quickExportCancelPending = false;
  }

  els.quickExportButton.style.setProperty("--quick-export-progress", safeProgress.toFixed(4));
  els.quickExportButton.style.setProperty("--quick-export-progress-percent", `${(safeProgress * 100).toFixed(1)}%`);
  els.quickExportButton.classList.toggle("is-quick-exporting", !!active);
  els.quickExportButton.setAttribute("aria-busy", active ? "true" : "false");
  if (els.quickExportCancelButton) {
    els.quickExportCancelButton.disabled = !quickExportActive;
  }
  if (els.quickExportCancelConfirmButton) {
    els.quickExportCancelConfirmButton.disabled = !(quickExportActive && quickExportCancelPending);
  }
  if (els.quickExportCancelDismissButton) {
    els.quickExportCancelDismissButton.disabled = !(quickExportActive && quickExportCancelPending);
  }
  if (els.quickExportShell) {
    els.quickExportShell.classList.toggle("is-quick-exporting", quickExportActive);
    els.quickExportShell.classList.toggle("is-cancel-pending", quickExportActive && quickExportCancelPending);
  }
}

function setQuickExportCancelPending(pending) {
  quickExportCancelPending = quickExportActive && !!pending;
  if (els.quickExportCancelConfirmButton) {
    els.quickExportCancelConfirmButton.disabled = !quickExportCancelPending;
  }
  if (els.quickExportCancelDismissButton) {
    els.quickExportCancelDismissButton.disabled = !quickExportCancelPending;
  }
  if (els.quickExportShell) {
    els.quickExportShell.classList.toggle("is-cancel-pending", quickExportCancelPending);
  }
}

function handleQuickExportAck(data) {
  if (!data || (data.command !== "quick-export" && data.command !== "quick-export-cancel")) {
    return false;
  }

  if (data.command === "quick-export-cancel") {
    if (data.ok === true) {
      setQuickExportCancelPending(false);
    } else {
      setQuickExportButtonProgress(0, false);
    }
    return true;
  }

  if (quickExportResetTimer) {
    window.clearTimeout(quickExportResetTimer);
    quickExportResetTimer = 0;
  }

  const progress = getAckProgress(data);
  const phase = typeof data.phase === "string" ? data.phase : "";
  const isTerminal = phase === "complete" || phase === "error" || data.ok === false;
  if (progress !== null) {
    setQuickExportButtonProgress(progress, !isTerminal);
  } else if (!isTerminal) {
    setQuickExportButtonProgress(0, true);
  }

  if (isTerminal) {
    setQuickExportButtonProgress(data.ok === false ? 0 : 1, false);
    quickExportResetTimer = window.setTimeout(() => {
      quickExportResetTimer = 0;
      setQuickExportButtonProgress(0, false);
    }, 1200);
  }
  return true;
}

function bindMastheadIntroMotion() {
  if (!els.masthead || !els.masthead.classList.contains("reveal")) {
    return;
  }

  let completed = false;
  const finish = () => {
    if (completed) {
      return;
    }

    completed = true;
    els.masthead.classList.remove("reveal");
  };

  window.setTimeout(finish, 900);
}

function prepareControlRailPanelMotion() {
  if (!els.controlRail) {
    return;
  }

  els.controlRail.classList.remove("reveal", "delay-3");
}

function getDefaultControlRailWidth() {
  const rootStyle = getComputedStyle(document.documentElement);
  return Math.trunc(toNumber(rootStyle.getPropertyValue("--rail-width"), defaultState.controlRailWidth));
}

function getControlRailWidthBounds() {
  const workspaceRect = els.dashboardPage
    ? els.dashboardPage.getBoundingClientRect()
    : { width: window.innerWidth || 0 };
  const workspaceWidth = Math.max(0, workspaceRect.width || window.innerWidth || 0);
  const minWidth = 100;
  const maxWidth = Math.max(minWidth, Math.min(520, workspaceWidth - 180));
  return { minWidth, maxWidth };
}

function applyControlRailWidth() {
  if (!els.appShell) {
    return;
  }

  const bounds = getControlRailWidthBounds();
  const width = Math.trunc(clamp(toNumber(state.controlRailWidth, getDefaultControlRailWidth()), bounds.minWidth, bounds.maxWidth));
  els.appShell.style.setProperty("--rail-width", `${width}px`);
  els.appShell.classList.toggle("is-control-rail-narrow", width < 180);
  els.appShell.classList.toggle("is-control-rail-tiny", width < 132);
}

function setControlRailWidth(width, persist = true) {
  const bounds = getControlRailWidthBounds();
  state.controlRailWidth = Math.trunc(clamp(normalizeControlRailWidth(width), bounds.minWidth, bounds.maxWidth));
  applyControlRailWidth();
  if (persist) {
    persistState();
  }
}

function bindControlRailPanelMotion() {
  if (!els.controlRail) {
    return;
  }

  els.controlRail.addEventListener("animationend", prepareControlRailPanelMotion, { once: true });
}

function switchResizeGripThen(applyStateChange) {
  const runStateChange = typeof applyStateChange === "function" ? applyStateChange : () => {};
  if (!els.appShell) {
    runStateChange();
    return;
  }

  els.appShell.classList.add("is-resize-grip-switching");
  if (dashboardResizeGripMoveTimer) {
    window.clearTimeout(dashboardResizeGripMoveTimer);
  }
  if (dashboardResizeGripSwitchTimer) {
    window.clearTimeout(dashboardResizeGripSwitchTimer);
  }

  dashboardResizeGripMoveTimer = window.setTimeout(() => {
    dashboardResizeGripMoveTimer = 0;
    runStateChange();
  }, dashboardResizeGripMoveDelayMs);

  dashboardResizeGripSwitchTimer = window.setTimeout(() => {
    dashboardResizeGripSwitchTimer = 0;
    if (els.appShell) {
      els.appShell.classList.remove("is-resize-grip-switching");
    }
  }, dashboardResizeGripSwitchDurationMs);
}

function bindControlRailResizeHandle() {
  if (!els.controlRailResizeHandle) {
    return;
  }

  const finishResize = (event) => {
    if (!controlRailResizeInteraction) {
      return;
    }

    if (event && event.type === "pointerup") {
      persistState();
    }

    try {
      els.controlRailResizeHandle.releasePointerCapture(controlRailResizeInteraction.pointerId);
    } catch {
    }
    controlRailResizeInteraction = null;
    if (els.appShell) {
      els.appShell.classList.remove("is-control-rail-resizing");
    }
  };

  els.controlRailResizeHandle.addEventListener("dblclick", (event) => {
    event.preventDefault();
    setControlRailWidth(getDefaultControlRailWidth(), true);
  });

  els.controlRailResizeHandle.addEventListener("pointerdown", (event) => {
    if (event.button !== 0 || !event.isPrimary || state.controlRailCollapsed === true || state.contentCollapsed === true) {
      return;
    }

    event.preventDefault();
    const currentWidth = normalizeControlRailWidth(state.controlRailWidth);
    controlRailResizeInteraction = {
      pointerId: event.pointerId,
      startX: event.clientX,
      startWidth: currentWidth
    };
    if (els.appShell) {
      els.appShell.classList.add("is-control-rail-resizing");
    }
    try {
      els.controlRailResizeHandle.setPointerCapture(event.pointerId);
    } catch {
    }
  });

  els.controlRailResizeHandle.addEventListener("pointermove", (event) => {
    if (!controlRailResizeInteraction || controlRailResizeInteraction.pointerId !== event.pointerId) {
      return;
    }

    event.preventDefault();
    setControlRailWidth(controlRailResizeInteraction.startWidth - (event.clientX - controlRailResizeInteraction.startX), false);
  });

  els.controlRailResizeHandle.addEventListener("pointerup", finishResize);
  els.controlRailResizeHandle.addEventListener("pointercancel", finishResize);
  window.addEventListener("resize", () => {
    applyControlRailWidth();
  });
}

function normalizeRecordPresetTagConfig(config) {
  const source = config && typeof config === "object" ? config : {};
  const resolutionMode = source.resolution_mode === "long_side" ? "long_side" : "highest";
  const runtimeRank = Object.prototype.hasOwnProperty.call(source, "runtime_surface_rank")
    ? source.runtime_surface_rank
    : state.recordingRuntimeRank;
  return {
    resolution_mode: resolutionMode,
    record_target_long_side: Math.max(256, Math.trunc(toNumber(source.record_target_long_side, state.recordTargetLongSide || 2048))),
    runtime_surface_rank: resolutionMode === "long_side"
      ? -1
      : Math.max(-1, Math.trunc(toNumber(runtimeRank, -1))),
    step_interval: Math.max(1, Math.trunc(toNumber(source.step_interval, state.stepInterval || 1))),
    codec_id: Math.max(0, Math.trunc(toNumber(source.codec_id, state.recordingCodecId || 0))),
    jpeg_quality: Math.max(1, Math.min(100, Math.trunc(toNumber(source.jpeg_quality, state.quality || 95))))
  };
}

function getRecordPresetUpdateName() {
  const currentPreset = Array.isArray(state.recordingPresets)
    ? state.recordingPresets.find((item) => item && item.id === state.currentPresetId)
    : null;
  return currentPreset && currentPreset.name
    ? currentPreset.name
    : (state.currentPresetName || "");
}

function applyRecordPresetConfigLocally(config) {
  const normalized = normalizeRecordPresetTagConfig(config);
  state.recordingPresetConfig = normalized;
  state.recordingRuntimeRank = String(normalized.runtime_surface_rank);
  state.recordTargetLongSide = String(normalized.record_target_long_side);
  state.stepInterval = String(normalized.step_interval);
  state.recordingCodecId = normalized.codec_id;
  state.recordingCodecMode = normalizeRecordingCodecMode("", normalized.codec_id);
  state.quality = String(normalized.jpeg_quality);

  if (Array.isArray(state.recordingPresets)) {
    state.recordingPresets = state.recordingPresets.map((item) => {
      if (!item || item.id !== state.currentPresetId) {
        return item;
      }
      return {
        ...item,
        config: { ...normalized }
      };
    });
  }
}

function isSearchCommandPureModifierKey(event) {
  return event.key === "Control"
    || event.key === "Shift"
    || event.key === "Alt"
    || event.key === "Meta";
}

function normalizeSearchCommandShortcutKey(event) {
  const key = event.key || "";
  const code = event.code || "";
  const keyMap = {
    Escape: "Esc",
    " ": "Space",
    Spacebar: "Space",
    ArrowUp: "Up",
    ArrowDown: "Down",
    ArrowLeft: "Left",
    ArrowRight: "Right",
    PageUp: "PageUp",
    PageDown: "PageDown",
    Insert: "Insert",
    Home: "Home",
    End: "End",
    Enter: "Enter",
    Tab: "Tab",
    Backspace: "Back",
    Delete: "Delete"
  };
  if (keyMap[key]) {
    return keyMap[key];
  }
  if (key.length === 1) {
    return key.toUpperCase();
  }
  if (/^Key[A-Z]$/.test(code)) {
    return code.slice(3);
  }
  if (/^Digit[0-9]$/.test(code)) {
    return code.slice(5);
  }
  if (/^Numpad[0-9]$/.test(code)) {
    return "NumPad" + code.slice(6);
  }
  if (/^F([1-9]|1[0-9]|2[0-4])$/.test(key)) {
    return key.toUpperCase();
  }

  return key;
}

function formatSearchCommandShortcutFromEvent(event) {
  const keyToken = normalizeSearchCommandShortcutKey(event);
  if (!keyToken || isSearchCommandPureModifierKey(event) || event.metaKey) {
    return "";
  }

  const parts = [];
  if (event.ctrlKey) {
    parts.push("Ctrl");
  }
  if (event.shiftKey) {
    parts.push("Shift");
  }
  if (event.altKey) {
    parts.push("Alt");
  }
  parts.push(keyToken);
  return parts.join("+");
}

function findSearchCommandByShortcut(shortcutText) {
  if (!shortcutText || !Array.isArray(state.searchCommands)) {
    return null;
  }

  const normalizedShortcut = shortcutText.trim().toLowerCase();
  return state.searchCommands.find((command) => (
    command
    && typeof command.shortcut_text === "string"
    && command.shortcut_text.trim().toLowerCase() === normalizedShortcut
  )) || null;
}

function consumeSearchCommandShortcut(event, commandId) {
  event.preventDefault();
  event.stopPropagation();
  if (typeof event.stopImmediatePropagation === "function") {
    event.stopImmediatePropagation();
  }
  postHostCommand("search-command-execute", { value: commandId });
}

function handleSearchCommandShortcutKeydown(event) {
  if (state.disableGlobalHotkeys) {
    return;
  }

  const shortcutText = formatSearchCommandShortcutFromEvent(event);
  const command = findSearchCommandByShortcut(shortcutText);
  if (!command) {
    return;
  }

  consumeSearchCommandShortcut(event, command.id);
}

function bindSearchCommandShortcuts() {
  window.addEventListener("keydown", handleSearchCommandShortcutKeydown, true);
}

async function persistRecordPresetConfig(config, successMessage) {
  const normalized = normalizeRecordPresetTagConfig(config);
  applyRecordPresetConfigLocally(normalized);
  render();

  const payload = {
    preset_id: state.currentPresetId,
    name: getRecordPresetUpdateName(),
    resolution_mode: normalized.resolution_mode,
    record_target_long_side: normalized.record_target_long_side,
    runtime_surface_rank: normalized.runtime_surface_rank,
    step_interval: normalized.step_interval,
    codec_id: normalized.codec_id,
    jpeg_quality: normalized.jpeg_quality
  };

  if (postHostCommand("recording-preset-customize", payload)) {
    addLog(successMessage);
    return;
  }

  if (isHttpProvider()) {
    if (runtime.actionInFlight) {
      return;
    }

    setActionInFlight(true);
    try {
      const response = await fetchJson("/api/record/presets/customize", {
        method: "POST",
        body: JSON.stringify(payload)
      });
      applyRecordingPresetState(response.data);
      addLog(successMessage);
      await runtime.provider.refreshAll(false);
    } catch (error) {
      if (error.bridgeUnavailable) {
        handleBackendUnavailable(`HTTP bridge unavailable: ${error.message}`);
      } else {
        handleSoftApiFailure(`Failed to update recording preset: ${error.message}`);
        await runtime.provider.refreshAll(false);
      }
    } finally {
      setActionInFlight(false);
    }
    return;
  }

  if (runtime.provider && typeof runtime.provider.updateRecordConfig === "function") {
    await runtime.provider.updateRecordConfig({
      runtime_surface_rank: normalized.runtime_surface_rank,
      record_target_long_side: normalized.record_target_long_side,
      step_interval: normalized.step_interval,
      codec_id: normalized.codec_id,
      jpeg_quality: normalized.jpeg_quality
    }, successMessage);
    return;
  }

  addLog(successMessage);
}

function getRecordPresetTagOptionValue(target) {
  const option = target instanceof Element
    ? target.closest(".record-preset-tag-option, .record-preset-quality-tick")
    : null;
  return option instanceof HTMLElement ? option.dataset.value || "" : "";
}

function updateRecordPresetQualityVisual(shell, value) {
  if (!shell) {
    return;
  }

  shell.querySelectorAll(".record-preset-quality-tick").forEach((tick) => {
    tick.classList.toggle("is-current", tick instanceof HTMLElement && tick.dataset.value === String(value));
  });
}

function snapRecordPresetQuality(value) {
  const numeric = clamp(Math.trunc(toNumber(value, 95)), 1, 100);
  let snapped = recordingPresetTagQualityValues[0];
  let bestDistance = Math.abs(numeric - snapped);
  recordingPresetTagQualityValues.forEach((candidate) => {
    const distance = Math.abs(numeric - candidate);
    if (distance < bestDistance) {
      snapped = candidate;
      bestDistance = distance;
    }
  });
  return snapped;
}

function buildRecordPresetConfigPatch(tagKey, value) {
  const config = normalizeRecordPresetTagConfig(state.recordingPresetConfig);
  if (tagKey === "resolution") {
    const runtimeMatch = /^runtime:(-?\d+)$/.exec(String(value));
    if (runtimeMatch) {
      config.resolution_mode = "highest";
      config.runtime_surface_rank = Math.max(-1, Math.trunc(toNumber(runtimeMatch[1], -1)));
      return config;
    }

    const match = /^long_side:(\d+)$/.exec(String(value));
    if (match) {
      config.resolution_mode = "long_side";
      config.record_target_long_side = Math.max(256, Math.trunc(toNumber(match[1], config.record_target_long_side)));
      config.runtime_surface_rank = -1;
    }
    return config;
  }

  if (tagKey === "codec") {
    config.codec_id = Math.max(1, Math.trunc(toNumber(value, config.codec_id)));
    return config;
  }

  if (tagKey === "quality") {
    config.jpeg_quality = snapRecordPresetQuality(value);
    return config;
  }

  if (tagKey === "interval") {
    config.step_interval = Math.max(1, Math.trunc(toNumber(value, config.step_interval)));
    return config;
  }

  return config;
}

function getRecordPresetTagLogLabel(tagKey) {
  switch (tagKey) {
    case "resolution":
      return "Recording resolution preset updated.";
    case "codec":
      return "Recording codec preset updated.";
    case "quality":
      return "Recording quality preset updated.";
    case "interval":
      return "Recording interval preset updated.";
    default:
      return "Recording preset updated.";
  }
}

function commitRecordPresetTagValue(tagKey, value) {
  if (!tagKey || !value) {
    return;
  }

  if (tagKey === "volume") {
    setVolumeMode(value);
    return;
  }

  const nextConfig = buildRecordPresetConfigPatch(tagKey, value);
  const successMessage = getRecordPresetTagLogLabel(tagKey);
  void persistRecordPresetConfig(nextConfig, successMessage);
}

function commitRecordPresetTagChoice(target) {
  const value = getRecordPresetTagOptionValue(target);
  if (!value) {
    return false;
  }

  const shell = target instanceof Element
    ? target.closest(".record-preset-tag-shell")
    : null;
  const portal = target instanceof Element
    ? target.closest(".record-preset-tag-menu-portal")
    : null;
  const tagKey = shell instanceof HTMLElement
    ? shell.dataset.presetTagShell || ""
    : portal instanceof HTMLElement ? portal.dataset.presetTagShell || "" : "";
  const input = shell ? shell.querySelector(".record-preset-quality-input") : null;
  const qualityScope = shell || portal;
  if (tagKey === "quality") {
    const snappedValue = String(snapRecordPresetQuality(value));
    if (input instanceof HTMLInputElement) {
      input.value = snappedValue;
    }
    updateRecordPresetQualityVisual(qualityScope, snappedValue);
  }
  commitRecordPresetTagValue(tagKey, value);
  return true;
}

function clearRecordPresetTagMenuCloseTimer() {
  if (!recordPresetTagMenuCloseTimer) {
    return;
  }

  window.clearTimeout(recordPresetTagMenuCloseTimer);
  recordPresetTagMenuCloseTimer = 0;
}

function setRecordPresetTagShellExpanded(shell, expanded) {
  if (!(shell instanceof HTMLElement)) {
    return;
  }

  shell.classList.toggle("is-menu-open", expanded);
  const button = shell.querySelector(".record-preset-tag");
  if (button) {
    button.setAttribute("aria-expanded", expanded ? "true" : "false");
  }
}

function destroyRecordPresetTagMenuPortal() {
  clearRecordPresetTagMenuCloseTimer();
  setRecordPresetTagShellExpanded(recordPresetTagMenuShell, false);
  if (recordPresetTagMenuPortal) {
    recordPresetTagMenuPortal.remove();
  }
  recordPresetTagMenuPortal = null;
  recordPresetTagMenuShell = null;
  recordPresetTagMenuSource = null;
}

function ensureRecordPresetTagMenuPortal() {
  if (recordPresetTagMenuPortal) {
    return recordPresetTagMenuPortal;
  }

  const portal = document.createElement("span");
  portal.className = "record-preset-tag-menu-portal";
  portal.dataset.hostDragIgnore = "true";
  portal.addEventListener("pointerenter", () => {
    clearRecordPresetTagMenuCloseTimer();
  });
  portal.addEventListener("pointerdown", (event) => {
    if (event.button !== 0 || !event.isPrimary) {
      return;
    }

    if (commitRecordPresetTagChoice(event.target)) {
      event.preventDefault();
      closeRecordPresetTagMenuPortal(false);
      return;
    }

    const menu = event.target instanceof Element
      ? event.target.closest(".record-preset-tag-menu")
      : null;
    if (menu && event.target === menu) {
      event.preventDefault();
      closeRecordPresetTagMenuPortal(false);
    }
  });
  portal.addEventListener("input", (event) => {
    const input = event.target;
    if (!(input instanceof HTMLInputElement) || input.dataset.presetTagInput !== "quality") {
      return;
    }

    const snapped = snapRecordPresetQuality(input.value);
    input.value = String(snapped);
    updateRecordPresetQualityVisual(portal, snapped);
  });
  portal.addEventListener("change", (event) => {
    const input = event.target;
    if (!(input instanceof HTMLInputElement) || input.dataset.presetTagInput !== "quality") {
      return;
    }

    commitRecordPresetTagValue("quality", input.value);
    closeRecordPresetTagMenuPortal(false);
  });
  portal.addEventListener("keydown", (event) => {
    if (event.key !== "Enter" && event.key !== " ") {
      return;
    }

    if (commitRecordPresetTagChoice(event.target)) {
      event.preventDefault();
      closeRecordPresetTagMenuPortal(false);
    }
  });

  document.body.appendChild(portal);
  recordPresetTagMenuPortal = portal;
  return portal;
}

function positionRecordPresetTagMenuPortal(shell, portal) {
  const tag = shell ? shell.querySelector(".record-preset-tag") : null;
  if (!(tag instanceof HTMLElement)) {
    return;
  }

  const rect = tag.getBoundingClientRect();
  portal.style.setProperty("--tag-portal-left", `${rect.left.toFixed(1)}px`);
  portal.style.setProperty("--tag-portal-top", `${rect.top.toFixed(1)}px`);
  portal.style.setProperty("--tag-portal-bottom", `${rect.bottom.toFixed(1)}px`);
  portal.style.setProperty("--tag-portal-width", `${rect.width.toFixed(1)}px`);
  portal.style.setProperty("--tag-portal-height", `${rect.height.toFixed(1)}px`);
}

function openRecordPresetTagMenuPortal(shell) {
  if (!(shell instanceof HTMLElement)) {
    return;
  }

  const menu = shell.querySelector(".record-preset-tag-menu");
  if (!menu) {
    closeRecordPresetTagMenuPortal(false);
    return;
  }

  clearRecordPresetTagMenuCloseTimer();
  if (recordPresetTagMenuShell && recordPresetTagMenuShell !== shell) {
    setRecordPresetTagShellExpanded(recordPresetTagMenuShell, false);
  }
  const portal = ensureRecordPresetTagMenuPortal();
  if (recordPresetTagMenuSource !== menu) {
    portal.replaceChildren();
    portal.appendChild(menu.cloneNode(true));
  }
  recordPresetTagMenuShell = shell;
  recordPresetTagMenuSource = menu;
  portal.className = "record-preset-tag-menu-portal";
  shell.classList.forEach((className) => {
    if (className.startsWith("is-")) {
      portal.classList.add(className);
    }
  });
  portal.dataset.presetTagShell = shell.dataset.presetTagShell || "";
  positionRecordPresetTagMenuPortal(shell, portal);
  setRecordPresetTagShellExpanded(shell, true);
  portal.classList.add("is-open");
}

function closeRecordPresetTagMenuPortal(delay) {
  clearRecordPresetTagMenuCloseTimer();
  const close = () => {
    setRecordPresetTagShellExpanded(recordPresetTagMenuShell, false);
    if (recordPresetTagMenuPortal) {
      recordPresetTagMenuPortal.classList.remove("is-open");
      recordPresetTagMenuPortal.replaceChildren();
    }
    recordPresetTagMenuShell = null;
    recordPresetTagMenuSource = null;
    if (typeof renderRecordSummaryTags === "function") {
      renderRecordSummaryTags();
    }
  };

  if (delay) {
    recordPresetTagMenuCloseTimer = window.setTimeout(() => {
      recordPresetTagMenuCloseTimer = 0;
      close();
    }, 60);
    return;
  }

  close();
}

function bindRecordPresetTagMenus() {
  if (!els.recordSummaryLabel) {
    return;
  }

  els.recordSummaryLabel.addEventListener("click", (event) => {
    const tag = event.target instanceof Element
      ? event.target.closest(".record-preset-tag")
      : null;
    const shell = tag ? tag.closest(".record-preset-tag-shell") : null;
    if (!(shell instanceof HTMLElement)) {
      return;
    }

    event.preventDefault();
    if (recordPresetTagMenuShell === shell && recordPresetTagMenuPortal?.classList.contains("is-open")) {
      closeRecordPresetTagMenuPortal(false);
      return;
    }
    openRecordPresetTagMenuPortal(shell);
  });

  els.recordSummaryLabel.addEventListener("input", (event) => {
    const input = event.target;
    if (!(input instanceof HTMLInputElement) || input.dataset.presetTagInput !== "quality") {
      return;
    }

    const snapped = snapRecordPresetQuality(input.value);
    input.value = String(snapped);
    const shell = input.closest(".record-preset-tag-shell");
    updateRecordPresetQualityVisual(shell, snapped);
  });

  els.recordSummaryLabel.addEventListener("change", (event) => {
    const input = event.target;
    if (!(input instanceof HTMLInputElement) || input.dataset.presetTagInput !== "quality") {
      return;
    }

    commitRecordPresetTagValue("quality", input.value);
    closeRecordPresetTagMenuPortal(false);
  });

  els.recordSummaryLabel.addEventListener("keydown", (event) => {
    if (event.key !== "Enter" && event.key !== " ") {
      return;
    }

    const value = getRecordPresetTagOptionValue(event.target);
    if (!value) {
      return;
    }

    event.preventDefault();
    commitRecordPresetTagChoice(event.target);
    closeRecordPresetTagMenuPortal(false);
  });

  document.addEventListener("pointerdown", (event) => {
    const target = event.target;
    if (!(target instanceof Node)) {
      return;
    }

    const clickedTagShell = target instanceof Element
      ? target.closest(".record-preset-tag-shell")
      : null;
    if (clickedTagShell || recordPresetTagMenuPortal?.contains(target)) {
      return;
    }

    closeRecordPresetTagMenuPortal(false);
  });

  window.addEventListener("keydown", (event) => {
    if (event.key === "Escape") {
      closeRecordPresetTagMenuPortal(false);
    }
  });

  window.addEventListener("scroll", () => {
    if (recordPresetTagMenuShell && recordPresetTagMenuPortal) {
      positionRecordPresetTagMenuPortal(recordPresetTagMenuShell, recordPresetTagMenuPortal);
    }
  }, true);
  window.addEventListener("resize", () => {
    if (recordPresetTagMenuShell && recordPresetTagMenuPortal) {
      positionRecordPresetTagMenuPortal(recordPresetTagMenuShell, recordPresetTagMenuPortal);
    }
  });
}

function syncHostZoomPageKey() {
  postHostCommand("set-webui-zoom-page-key", { key: "dashboard" });
}

function getEmbeddedTargetOrigin() {
  return window.location.protocol === "file:" ? "*" : window.location.origin;
}

function normalizeEmbeddedSettingsPage(settingsPage) {
  return Object.prototype.hasOwnProperty.call(embeddedSettingsPages, settingsPage)
    ? settingsPage
    : "blank";
}

function unmountInlineSettingsPage() {
  if (activeInlineSettingsController && typeof activeInlineSettingsController.unmount === "function") {
    activeInlineSettingsController.unmount();
  }
  activeInlineSettingsController = null;
  activeInlineSettingsPage = "";
  if (els.settingsPageInline) {
    els.settingsPageInline.replaceChildren();
  }
}

function syncInlineSettingsPage() {
  const activeKey = state.settingsPageLoadReady === true
    ? normalizeEmbeddedSettingsPage(state.activeSettingsPage)
    : "";
  const activeSpec = activeKey ? embeddedSettingsPages[activeKey] : null;
  const inlineModule = activeSpec && activeSpec.inlineModule ? String(activeSpec.inlineModule) : "";

  if (!inlineModule || !els.settingsPageInline) {
    unmountInlineSettingsPage();
    return;
  }

  if (activeInlineSettingsPage === activeKey) {
    return;
  }

  unmountInlineSettingsPage();

  if (inlineModule === "helpSupport" && window.ReadSAI2HelpSupport && typeof window.ReadSAI2HelpSupport.mount === "function") {
    activeInlineSettingsController = window.ReadSAI2HelpSupport.mount(els.settingsPageInline, {
      host: window.ReadSAI2WebUi && window.ReadSAI2WebUi.host,
      returnToDashboard,
      addLog,
      embedded: true
    });
    activeInlineSettingsPage = activeKey;
  }
}

function dispatchInlineSettingsMessage(data) {
  if (!activeInlineSettingsController || !data || typeof data !== "object") {
    return;
  }

  if (typeof activeInlineSettingsController.handleMessage === "function") {
    activeInlineSettingsController.handleMessage(data);
  }
}

function cancelDeferredSettingsPageLoad() {
  contentPageSwitchToken += 1;
  if (contentPageSwitchTimer) {
    window.clearTimeout(contentPageSwitchTimer);
    contentPageSwitchTimer = 0;
  }
}

function afterContentPageSwitch(callback) {
  cancelDeferredSettingsPageLoad();
  const token = contentPageSwitchToken;
  let completed = false;
  const finish = () => {
    if (completed || token !== contentPageSwitchToken) {
      return;
    }

    completed = true;
    if (contentPageSwitchTimer) {
      window.clearTimeout(contentPageSwitchTimer);
      contentPageSwitchTimer = 0;
    }
    callback();
  };

  const track = els.contentPageTrack;
  if (!track) {
    window.requestAnimationFrame(finish);
    return;
  }

  const onTransitionEnd = (event) => {
    if (event.target === track && event.propertyName === "transform") {
      track.removeEventListener("transitionend", onTransitionEnd);
      finish();
    }
  };

  track.addEventListener("transitionend", onTransitionEnd);
  contentPageSwitchTimer = window.setTimeout(() => {
    track.removeEventListener("transitionend", onTransitionEnd);
    finish();
  }, contentPageSwitchFallbackMs);
}

function afterContentPageFirstPaint(callback) {
  cancelDeferredSettingsPageLoad();
  const token = contentPageSwitchToken;
  window.requestAnimationFrame(() => {
    window.requestAnimationFrame(() => {
      if (token !== contentPageSwitchToken) {
        return;
      }

      callback();
    });
  });
}

function renderContentPageSwitchShell() {
  const activePage = state.activeContentPage === "settings" ? "settings" : "dashboard";
  const collapsed = state.contentCollapsed === true;
  const settingsContentVisible = activePage === "settings";
  const settingsPageLoadReady = state.settingsPageLoadReady === true;
  const activeSettingsKey = normalizeEmbeddedSettingsPage(state.activeSettingsPage);
  const activeSettingsSpec = activeSettingsKey ? embeddedSettingsPages[activeSettingsKey] : embeddedSettingsPages.blank;
  const loadedSettingsSpec = settingsPageLoadReady ? activeSettingsSpec : embeddedSettingsPages.blank;
  const hasInlineSettingsContent = !!(settingsPageLoadReady && loadedSettingsSpec.inlineModule);
  const isImmersiveSettings = settingsContentVisible && loadedSettingsSpec.immersive === true && !hasInlineSettingsContent;
  const setPanelState = (panel, panelName) => {
    if (!panel) {
      return;
    }

    const isActive = activePage === panelName;
    panel.hidden = false;
    panel.inert = collapsed || !isActive;
    panel.classList.toggle("is-active", isActive);
    panel.setAttribute("aria-hidden", !collapsed && isActive ? "false" : "true");
  };

  applyControlRailWidth();
  if (els.pageScrollRoot) {
    els.pageScrollRoot.hidden = false;
    els.pageScrollRoot.inert = collapsed;
    els.pageScrollRoot.classList.toggle("is-collapsed", collapsed);
    els.pageScrollRoot.classList.toggle("is-dashboard-active", !collapsed && activePage === "dashboard");
    els.pageScrollRoot.setAttribute("aria-hidden", collapsed ? "true" : "false");
  }
  if (els.appShell) {
    els.appShell.classList.toggle("is-content-collapsed", collapsed);
    els.appShell.classList.toggle("is-control-rail-collapsed", state.controlRailCollapsed === true);
  }
  if (els.contentPageTrack) {
    els.contentPageTrack.dataset.activePage = activePage;
    els.contentPageTrack.style.setProperty("--content-page-index", activePage === "settings" ? "1" : "0");
  }

  setPanelState(els.dashboardPage, "dashboard");
  setPanelState(els.settingsPage, "settings");

  if (els.settingsPage) {
    els.settingsPage.classList.toggle("is-immersive-settings", isImmersiveSettings);
  }
  if (els.settingsPageHeading) {
    els.settingsPageHeading.hidden = settingsContentVisible && settingsPageLoadReady && activeSettingsKey === "customBrush";
  }
  if (els.settingsPageKicker) {
    els.settingsPageKicker.textContent = activeSettingsSpec.kicker || "设置";
  }
  if (els.settingsPageTitle) {
    els.settingsPageTitle.textContent = activeSettingsSpec.title || "预留设置页";
  }
  if (els.settingsPageEmpty) {
    els.settingsPageEmpty.hidden = true;
  }
  if (els.settingsPageInline) {
    els.settingsPageInline.hidden = true;
  }
  if (els.settingsPageFrame && !settingsPageLoadReady) {
    els.settingsPageFrame.hidden = true;
  }
  if (els.contentPageSwitchButton) {
    els.contentPageSwitchButton.setAttribute("aria-pressed", activePage === "settings" ? "true" : "false");
  }
}

function openSettingsPage(settingsPage = "blank") {
  const nextSettingsPage = normalizeEmbeddedSettingsPage(settingsPage);
  const shouldDeferLoad = nextSettingsPage !== "blank"
    && (
      state.activeContentPage !== "settings"
      || state.settingsPageLoadReady !== true
    );

  state.activeSettingsPage = nextSettingsPage;
  state.activeContentPage = "settings";
  state.settingsPageLoadReady = !shouldDeferLoad;
  state.contentCollapsed = false;
  state.controlRailCollapsed = false;
  if (els.pageScrollRoot) {
    els.pageScrollRoot.scrollTop = 0;
  }
  renderContentPageSwitchShell();

  if (!shouldDeferLoad) {
    cancelDeferredSettingsPageLoad();
    afterContentPageFirstPaint(() => {
      if (state.activeContentPage !== "settings" || state.activeSettingsPage !== nextSettingsPage) {
        return;
      }

      render();
      syncInlineSettingsPage();
    });
    return;
  }

  afterContentPageFirstPaint(() => {
    if (state.activeContentPage !== "settings" || state.activeSettingsPage !== nextSettingsPage) {
      return;
    }

    state.settingsPageLoadReady = true;
    if (els.pageScrollRoot) {
      els.pageScrollRoot.scrollTop = 0;
    }
    render();
    syncInlineSettingsPage();
  });
}

function returnToDashboard() {
  cancelDeferredSettingsPageLoad();
  state.activeContentPage = "dashboard";
  state.contentCollapsed = false;
  state.controlRailCollapsed = false;
  if (els.pageScrollRoot) {
    els.pageScrollRoot.scrollTop = 0;
  }
  renderContentPageSwitchShell();

  afterContentPageSwitch(() => {
    if (state.activeContentPage !== "dashboard") {
      return;
    }

    state.activeSettingsPage = "";
    state.settingsPageLoadReady = false;
    render();
    syncInlineSettingsPage();
  });
}

function handleContentPageContextMenu(event) {
  if (state.activeContentPage !== "settings" || event.defaultPrevented) {
    return;
  }

  event.preventDefault();
  returnToDashboard();
}

function postStateToSettingsFrame() {
  const settingsFrame = els.settingsPageFrame;
  if (!settingsFrame || !settingsFrame.contentWindow) {
    return;
  }

  const frameRect = settingsFrame.getBoundingClientRect();
  const frameWidth = Math.max(0, Math.round(frameRect.width || 0));
  const frameHeight = Math.max(0, Math.round(frameRect.height || 0));

  settingsFrame.contentWindow.postMessage({
    kind: state.activeSettingsPage === "appSettings" ? "app-settings-state" : "webui-state",
    state: {
      version: 1,
      current_preset_id: state.currentPresetId,
      current_preset_name: state.currentPresetName,
      recording_presets: state.recordingPresets,
      recording_runtime_rank: Math.trunc(toNumber(state.recordingRuntimeRank, -1)),
      preview_developer_mode: state.previewDeveloperMode,
      main_ui_mode: "webui",
      hide_sidebar: state.contentCollapsed,
      do_not_minimize_to_tray: state.doNotMinimizeToTray,
      command_palette_passthrough_forwarding: state.commandPalettePassthroughForwarding !== false,
      webui_theme_preset: state.themePreset,
      webui_light_theme_preset: state.webuiLightThemePreset,
      webui_dark_theme_preset: state.webuiDarkThemePreset,
      webui_theme_color: state.webuiThemeColor,
      webui_background_color: state.webuiBackgroundColor,
      webui_theme_custom_presets: state.webuiThemeCustomPresets,
      webui_masthead_background_path: state.webuiMastheadBackgroundPath,
      webui_masthead_background_url: state.webuiMastheadBackgroundUrl,
      webui_masthead_background_scale_percent: state.webuiMastheadBackgroundScalePercent,
      webui_masthead_background_rotation_deg: state.webuiMastheadBackgroundRotationDeg,
      webui_masthead_background_offset_x: state.webuiMastheadBackgroundOffsetX,
      webui_masthead_background_offset_y: state.webuiMastheadBackgroundOffsetY,
      webui_masthead_background_tile_enabled: state.webuiMastheadBackgroundTileEnabled,
      auto_launch_sai: state.autoLaunch,
      status_light_group_visible: state.statusLightGroupVisible,
      auto_resize_navigator: state.navigatorAutoResize,
      custom_brush_overlay_visible: state.customBrushOverlay,
      runtime_surface_fixed_refresh: state.runtimeSurfaceFixedRefresh,
      runtime_surface_preview_fps_limit: state.runtimeSurfacePreviewFpsLimit,
      viewport_width: frameWidth,
      viewport_height: frameHeight
    }
  }, getEmbeddedTargetOrigin());
}

function bindCurrentFileTitlePan() {
  const titleText = els.currentFileLabel;
  if (!titleText) {
    return;
  }

  const titleBox = titleText.closest(".current-file-title");
  if (!titleBox) {
    return;
  }

  let raf = 0;
  let returnTimer = 0;
  let currentOffset = 0;
  const updateOverflowFade = (offset = currentOffset) => {
    const overflow = titleText.scrollWidth - titleBox.clientWidth;
    if (overflow <= 1) {
      titleBox.classList.remove("has-overflow-start", "has-overflow-end");
      return;
    }

    const leftHidden = Math.max(0, -offset);
    const rightHidden = Math.max(0, overflow + offset);
    titleBox.classList.toggle("has-overflow-start", leftHidden > 1);
    titleBox.classList.toggle("has-overflow-end", rightHidden > 1);
  };
  const clearReturnTimer = () => {
    if (returnTimer) {
      window.clearTimeout(returnTimer);
      returnTimer = 0;
    }
  };
  const reset = () => {
    if (raf) {
      window.cancelAnimationFrame(raf);
      raf = 0;
    }
    clearReturnTimer();
    titleBox.classList.add("is-returning");
    currentOffset = 0;
    updateOverflowFade(0);
    titleText.style.setProperty("--file-title-offset", "0px");
    returnTimer = window.setTimeout(() => {
      returnTimer = 0;
      titleBox.classList.remove("is-panning");
      titleBox.classList.remove("is-returning");
    }, 1850);
  };

  titleText.addEventListener("transitionend", (event) => {
    if (event.propertyName !== "transform" || !titleBox.classList.contains("is-returning")) {
      return;
    }

    clearReturnTimer();
    titleBox.classList.remove("is-panning");
    titleBox.classList.remove("is-returning");
    currentOffset = 0;
    updateOverflowFade(0);
  });

  titleBox.addEventListener("pointermove", (event) => {
    if (event.pointerType && event.pointerType !== "mouse" && event.pointerType !== "pen") {
      return;
    }
    if (raf) {
      return;
    }

    raf = window.requestAnimationFrame(() => {
      raf = 0;
      clearReturnTimer();
      const overflow = titleText.scrollWidth - titleBox.clientWidth;
      if (overflow <= 1) {
        reset();
        return;
      }

      const rect = titleBox.getBoundingClientRect();
      const rawRatio = rect.width > 0
        ? clamp((event.clientX - rect.left) / rect.width, 0, 1)
        : 0;
      const deadZone = 0.24;
      const liveRatio = clamp((rawRatio - deadZone) / (1 - (deadZone * 2)), 0, 1);
      const ratio = liveRatio * liveRatio * (3 - (2 * liveRatio));
      titleBox.classList.remove("is-returning");
      titleBox.classList.add("is-panning");
      currentOffset = -overflow * ratio;
      updateOverflowFade(currentOffset);
      titleText.style.setProperty("--file-title-offset", `${currentOffset.toFixed(1)}px`);
    });
  });
  titleBox.addEventListener("pointerleave", reset);
  titleBox.addEventListener("pointercancel", reset);
  window.addEventListener("resize", () => updateOverflowFade());
  window.ReadSAI2WebUi.refreshCurrentFileTitleOverflow = () => {
    window.requestAnimationFrame(() => {
      currentOffset = 0;
      titleText.style.setProperty("--file-title-offset", "0px");
      updateOverflowFade(0);
    });
  };
  updateOverflowFade(0);
}

function bindControls() {
  const buildHostDragMoveMessage = (event) => JSON.stringify({
    kind: "host:drag-move",
    screenX: event.screenX,
    screenY: event.screenY,
    clientX: event.clientX,
    clientY: event.clientY
  });

  const bindHostDragHandle = (el) => {
    if (!el) {
      return;
    }

    el.addEventListener("pointerdown", (event) => {
      if (event.button !== 0 || !event.isPrimary) {
        return;
      }

      const interactiveTarget = event.target instanceof Element
        ? event.target.closest("button, input, select, textarea, a, label, summary, [role='button'], [data-host-drag-ignore='true']")
        : null;
      if (interactiveTarget) {
        return;
      }

      const bridge = getHostBridge();
      if (!bridge) {
        return;
      }

      event.preventDefault();
      bridge.postMessage(buildHostDragMoveMessage(event));
    });
  };

  bindHostDragHandle(els.masthead);
  document.querySelectorAll(".card").forEach((card) => {
    bindHostDragHandle(card);
  });
  bindCurrentFileTitlePan();

  const handleRecordToggle = () => {
    if (state.recordingState === "idle" && !hasSavePath()) {
      runtime.savePathWarningActive = true;
      addLog("Recording cannot start because the output folder is empty.");
      render();
      return;
    }

    runtime.savePathWarningActive = false;
    void runtime.provider.toggleRecording();
  };

  els.topRecordButton.addEventListener("click", () => {
    handleRecordToggle();
  });
  if (els.overlayRecordButton) {
    els.overlayRecordButton.addEventListener("click", () => {
      handleRecordToggle();
    });
  }
  if (els.hostBackdropButton) {
    els.hostBackdropButton.addEventListener("click", () => {
      postHostMessage("host:cycle-backdrop-mode", "Host backdrop switching is only available in the desktop WebView host.");
    });
  }
  if (els.closeWindowButton) {
    els.closeWindowButton.addEventListener("click", () => {
      beginDashboardCloseSequence();
    });
  }
  if (els.minimizeWindowButton) {
    els.minimizeWindowButton.addEventListener("click", () => {
      beginDashboardMinimizeSequence();
    });
  }
  if (els.commandLauncherButton) {
    els.commandLauncherButton.addEventListener("click", () => {
      const rect = els.commandLauncherButton.getBoundingClientRect();
      postHostCommand("open-search-command-window", {
        anchorRect: {
          left: rect.left,
          top: rect.top,
          right: rect.right,
          bottom: rect.bottom,
          width: rect.width,
          height: rect.height
        }
      }, "Search commands are only available in the desktop WebView host.");
    });
  }
  const openAnchoredWindow = (command, el, unavailableLog) => {
    if (!el) {
      return false;
    }

    const rect = el.getBoundingClientRect();
    return postHostCommand(command, {
      anchorRect: {
        left: rect.left,
        top: rect.top,
        right: rect.right,
        bottom: rect.bottom,
        width: rect.width,
        height: rect.height
      }
    }, unavailableLog);
  };
  if (els.windowResizeBottomLeftButton) {
    els.windowResizeBottomLeftButton.dataset.collapsedResizeMessage = "host:resize-left";
  }
  if (els.windowResizeBottomRightButton) {
    els.windowResizeBottomRightButton.dataset.collapsedResizeMessage = "host:resize-right";
  }
  bindHostResizeGrip(els.windowResizeBottomLeftButton, "host:resize-bottom-left");
  bindHostResizeGrip(els.windowResizeBottomRightButton, "host:resize-bottom-right");
  bindControlRailResizeHandle();
  if (els.themeToggleButton) {
    els.themeToggleButton.addEventListener("click", () => {
      setThemeMode(getAlternateThemeMode(state.themeMode));
    });
  }
  if (els.themeAutoButton) {
    els.themeAutoButton.addEventListener("click", () => {
      setThemeMode("auto");
    });
  }
  if (els.volumeModeButton) {
    els.volumeModeButton.addEventListener("click", cycleVolumeMode);
  }
  const initialSettingsPage = new URLSearchParams(window.location.search).get("settingsPage");
  window.ReadSAI2WebUi.openSettingsPage = openSettingsPage;
  window.ReadSAI2WebUi.returnToDashboard = returnToDashboard;
  if (els.contentCollapseButton) {
    els.contentCollapseButton.addEventListener("click", () => {
      switchResizeGripThen(() => {
        state.contentCollapsed = !state.contentCollapsed;
        render();
      });
    });
  }
  if (els.controlRailCollapseButton) {
    els.controlRailCollapseButton.addEventListener("click", () => {
      prepareControlRailPanelMotion();
      state.controlRailCollapsed = true;
      render();
    });
  }
  if (els.controlRailExpandButton) {
    els.controlRailExpandButton.addEventListener("click", () => {
      prepareControlRailPanelMotion();
      state.controlRailCollapsed = false;
      render();
    });
  }
  if (els.contentPageSwitchButton) {
    els.contentPageSwitchButton.addEventListener("click", () => {
      openSettingsPage(els.contentPageSwitchButton.dataset.settingsPage || "blank");
    });
  }
  document.querySelectorAll("[data-settings-page]").forEach((button) => {
    if (button === els.contentPageSwitchButton) {
      return;
    }

    button.addEventListener("click", () => {
      openSettingsPage(button.dataset.settingsPage || "blank");
    });
  });
  if (els.settingsPageReturnButton) {
    els.settingsPageReturnButton.addEventListener("click", () => {
      returnToDashboard();
    });
  }
  if (els.settingsPage) {
    els.settingsPage.addEventListener("contextmenu", handleContentPageContextMenu);
  }
  if (els.settingsPageFrame) {
    els.settingsPageFrame.addEventListener("load", () => {
      queueActiveContentLayoutSync();
    });
  }
  if (initialSettingsPage && Object.prototype.hasOwnProperty.call(embeddedSettingsPages, initialSettingsPage)) {
    window.requestAnimationFrame(() => {
      openSettingsPage(initialSettingsPage);
      if (window.history && typeof window.history.replaceState === "function") {
        window.history.replaceState(null, document.title, window.location.pathname);
      }
    });
  }
  els.clearLogButton.addEventListener("click", () => {
    state.activityLog = [];
    renderLog();
  });

  const applyHostSetting = (command, value, applyState) => {
    if (!postHostCommand(command, { value })) {
      return false;
    }

    applyState(value);
    render();
    return true;
  };

  els.savePathInput.addEventListener("change", () => {
    const next = els.savePathInput.value.trim() || state.savePath || defaultState.savePath;
    if (applyHostSetting("set-save-root", next, (resolvedValue) => {
      state.savePath = resolvedValue;
      runtime.savePathWarningActive = !hasSavePath();
    })) {
      return;
    }
    runtime.savePathWarningActive = false;
    void runtime.provider.updateRecordConfig({ save_root: next }, `Save path updated to ${next}.`);
  });
  if (els.recordingPresetSelect) {
    els.recordingPresetSelect.addEventListener("change", () => {
      const next = els.recordingPresetSelect.value;
      if (!next) {
        return;
      }

      if (postHostCommand("recording-preset-activate", { preset_id: next })) {
        state.currentPresetId = next;
        render();
        return;
      }

      void runtime.provider.activateRecordingPreset(next);
    });
  }

  if (els.webuiAlwaysOnTopToggle) {
    els.webuiAlwaysOnTopToggle.addEventListener("change", () => {
      if (applyHostSetting("set-webui-always-on-top", els.webuiAlwaysOnTopToggle.checked, (resolvedValue) => {
        state.webuiAlwaysOnTop = resolvedValue;
      })) {
        return;
      }
      state.webuiAlwaysOnTop = els.webuiAlwaysOnTopToggle.checked;
      addLog(`WebUI always-on-top changed to ${state.webuiAlwaysOnTop}.`);
      render();
    });
  }
  els.autoLaunchToggle.addEventListener("change", () => {
    if (applyHostSetting("set-auto-launch-sai", els.autoLaunchToggle.checked, (resolvedValue) => {
      state.autoLaunch = resolvedValue;
    })) {
      return;
    }
    state.autoLaunch = els.autoLaunchToggle.checked;
    addLog(`Auto-launch changed to ${state.autoLaunch}.`);
    render();
  });
  els.doNotMinimizeToTrayToggle.addEventListener("change", () => {
    if (applyHostSetting("set-webui-do-not-minimize-to-tray", els.doNotMinimizeToTrayToggle.checked, (resolvedValue) => {
      state.doNotMinimizeToTray = resolvedValue;
    })) {
      return;
    }
    state.doNotMinimizeToTray = els.doNotMinimizeToTrayToggle.checked;
    addLog(`Do-not-minimize changed to ${state.doNotMinimizeToTray}.`);
    render();
  });
  if (els.navigatorResizeToggle) {
    els.navigatorResizeToggle.addEventListener("change", () => {
      if (applyHostSetting("set-navigator-auto-resize", els.navigatorResizeToggle.checked, (resolvedValue) => {
        state.navigatorAutoResize = resolvedValue;
      })) {
        return;
      }
      state.navigatorAutoResize = els.navigatorResizeToggle.checked;
      addLog(`Navigator auto-resize changed to ${state.navigatorAutoResize}.`);
      render();
    });
  }
  els.updateChannelSelect.addEventListener("change", () => {
    if (applyHostSetting("set-update-channel", els.updateChannelSelect.value, (resolvedValue) => {
      state.updateChannel = resolvedValue === "beta" ? "beta" : "stable";
    })) {
      return;
    }
    state.updateChannel = els.updateChannelSelect.value;
    addLog(`Update channel changed to ${state.updateChannel}.`);
    render();
  });
  els.customBrushOverlayToggle.addEventListener("change", () => {
    if (applyHostSetting("set-custom-brush-overlay", els.customBrushOverlayToggle.checked, (resolvedValue) => {
      state.customBrushOverlay = resolvedValue;
      if (resolvedValue) {
        postHostCommand("custom-brush-sync");
      }
      requestPreviewOverlayDraw();
    })) {
      return;
    }
    state.customBrushOverlay = els.customBrushOverlayToggle.checked;
    if (state.customBrushOverlay) {
      postHostCommand("custom-brush-sync");
    }
    addLog(`Custom brush overlay changed to ${state.customBrushOverlay}.`);
    render();
    requestPreviewOverlayDraw();
  });
  els.previewDeveloperModeToggle.addEventListener("change", () => {
    if (applyHostSetting("set-preview-developer-mode", els.previewDeveloperModeToggle.checked, (resolvedValue) => {
      state.previewDeveloperMode = resolvedValue;
      postStateToSettingsFrame();
    })) {
      return;
    }
    state.previewDeveloperMode = els.previewDeveloperModeToggle.checked;
    addLog(`Preview developer mode changed to ${state.previewDeveloperMode}.`);
    render();
    postStateToSettingsFrame();
  });
  els.runtimeSurfaceFixedRefreshToggle.addEventListener("change", () => {
    if (applyHostSetting("set-runtime-surface-fixed-refresh", els.runtimeSurfaceFixedRefreshToggle.checked, (resolvedValue) => {
      state.runtimeSurfaceFixedRefresh = resolvedValue;
      postStateToSettingsFrame();
    })) {
      return;
    }
    state.runtimeSurfaceFixedRefresh = els.runtimeSurfaceFixedRefreshToggle.checked;
    addLog(`Runtime Surface low-latency polling changed to ${state.runtimeSurfaceFixedRefresh}.`);
    render();
    postStateToSettingsFrame();
  });
  els.previewDirtyRectToggle.addEventListener("change", () => {
    state.previewDirtyRectVisible = els.previewDirtyRectToggle.checked;
    addLog(`Preview dirty rect overlay changed to ${state.previewDirtyRectVisible}.`);
    render();
    requestPreviewOverlayDraw();
  });
  if (els.previewPointerOverlayToggle) {
    els.previewPointerOverlayToggle.addEventListener("change", () => {
      state.previewPointerOverlayVisible = els.previewPointerOverlayToggle.checked;
      addLog(`Preview pointer overlay changed to ${state.previewPointerOverlayVisible}.`);
      render();
      requestPreviewOverlayDraw();
    });
  }
  els.activityLogToggle.addEventListener("change", () => {
    state.activityLogVisible = els.activityLogToggle.checked;
    addLog(`Activity log visibility changed to ${state.activityLogVisible}.`);
    render();
  });
  els.statusLightGroupToggle.addEventListener("change", () => {
    if (applyHostSetting("set-status-light-group", els.statusLightGroupToggle.checked, (resolvedValue) => {
      state.statusLightGroupVisible = resolvedValue;
    })) {
      return;
    }
    state.statusLightGroupVisible = els.statusLightGroupToggle.checked;
    addLog(`Status lights changed to ${state.statusLightGroupVisible}.`);
    render();
  });

  els.browsePathButton.addEventListener("click", () => {
    postHostCommand("choose-save-root", null, "Path browsing is only available in the desktop WebView host.");
  });
  els.openFolderButton.addEventListener("click", () => {
    if (postHostCommand("open-save-root", null, "Open folder is only available in the desktop WebView host.")) {
      return;
    }
    addLog(`Open output folder: ${state.savePath || "(empty)"}.`);
  });
  if (els.toggleSettingsButton) {
    els.toggleSettingsButton.addEventListener("click", () => {
      openSettingsPage("appSettings");
    });
  }
  if (els.launchSaiButton) {
    els.launchSaiButton.addEventListener("click", () => {
      postHostCommand("launch-sai2", null, "Launch SAI2 is only available in the desktop WebView host.");
    });
  }
  if (els.quickExportButton) {
    els.quickExportButton.addEventListener("click", () => {
      if (quickExportActive) {
        return;
      }
      if (postHostCommand("quick-export", null, "Quick export is only available in the desktop WebView host.")) {
        setQuickExportButtonProgress(0, true);
      }
    });
  }
  if (els.quickExportCancelButton) {
    els.quickExportCancelButton.addEventListener("click", (event) => {
      event.stopPropagation();
      if (!quickExportActive) {
        return;
      }
      setQuickExportCancelPending(true);
    });
  }
  if (els.quickExportCancelConfirmButton) {
    els.quickExportCancelConfirmButton.addEventListener("click", (event) => {
      event.stopPropagation();
      if (!quickExportActive) {
        setQuickExportCancelPending(false);
        return;
      }
      if (postHostCommand("quick-export-cancel", null, "Quick export cancel is only available in the desktop WebView host.")) {
        setQuickExportCancelPending(false);
      }
    });
  }
  if (els.quickExportCancelDismissButton) {
    els.quickExportCancelDismissButton.addEventListener("click", (event) => {
      event.stopPropagation();
      setQuickExportCancelPending(false);
    });
  }
  if (els.checkUpdateButton) {
    els.checkUpdateButton.addEventListener("click", () => {
      openSettingsPage("updateCenter");
    });
  }
}

function bindHostBridge() {
  const bridge = getHostBridge();
  const isTrustedEmbeddedMessage = (event) => {
    if (window.location.protocol === "file:") {
      return true;
    }
    return event.origin === window.location.origin;
  };
  const forwardToSettingsFrame = (data) => {
    const settingsFrame = els.settingsPageFrame;
    if (settingsFrame && settingsFrame.contentWindow && data && data.kind) {
      settingsFrame.contentWindow.postMessage(data, getEmbeddedTargetOrigin());
    }
  };
  const forwardToSettingsContent = (data) => {
    forwardToSettingsFrame(data);
    dispatchInlineSettingsMessage(data);
  };

  window.addEventListener("message", (event) => {
    if (!isTrustedEmbeddedMessage(event)) {
      return;
    }

    const data = event.data;
    if (typeof data === "string") {
      if (data === hostRequestCloseWindowMessage) {
        beginDashboardCloseSequence();
      }
      if (data === hostWindowShownMessage) {
        beginDashboardRestoreSequence();
      }
      return;
    }

    if (!data || typeof data !== "object") {
      return;
    }

    if (data.kind === "readsai2-embedded-host-command") {
      postHostCommand(data.command, data.payload || null);
      if (data.command === "app-settings-save" && data.payload && typeof data.payload === "object") {
        if (typeof data.payload.do_not_minimize_to_tray === "boolean") {
          state.doNotMinimizeToTray = data.payload.do_not_minimize_to_tray;
        }
        if (typeof data.payload.disable_global_hotkeys === "boolean") {
          state.disableGlobalHotkeys = data.payload.disable_global_hotkeys;
        }
        if (typeof data.payload.command_palette_passthrough_forwarding === "boolean") {
          state.commandPalettePassthroughForwarding = data.payload.command_palette_passthrough_forwarding;
        }
        const hasThemeSlotPreset = Object.prototype.hasOwnProperty.call(data.payload, "webui_light_theme_preset")
          || Object.prototype.hasOwnProperty.call(data.payload, "webui_dark_theme_preset");
        if (Array.isArray(data.payload.webui_theme_custom_presets)) {
          state.webuiThemeCustomPresets = normalizeWebUiThemeCustomPresets(data.payload.webui_theme_custom_presets);
        }
        if (typeof data.payload.webui_light_theme_preset === "string") {
          state.webuiLightThemePreset = normalizeWebUiThemePresetId(data.payload.webui_light_theme_preset, "light");
        }
        if (typeof data.payload.webui_dark_theme_preset === "string") {
          state.webuiDarkThemePreset = normalizeWebUiThemePresetId(data.payload.webui_dark_theme_preset, "dark");
        }
        if (typeof data.payload.webui_theme_color === "string") {
          state.webuiThemeColor = normalizeWebUiThemeColor(data.payload.webui_theme_color);
        }
        if (typeof data.payload.webui_background_color === "string") {
          state.webuiBackgroundColor = normalizeWebUiBackgroundColor(data.payload.webui_background_color);
        }
        if (typeof data.payload.webui_masthead_background_path === "string") {
          state.webuiMastheadBackgroundPath = normalizeWebUiMastheadBackgroundPath(data.payload.webui_masthead_background_path);
        }
        if (typeof data.payload.webui_masthead_background_url === "string") {
          state.webuiMastheadBackgroundUrl = normalizeWebUiMastheadBackgroundUrl(data.payload.webui_masthead_background_url);
        } else if (!state.webuiMastheadBackgroundPath) {
          state.webuiMastheadBackgroundUrl = "";
        }
        if (typeof data.payload.webui_masthead_background_scale_percent === "number") {
          state.webuiMastheadBackgroundScalePercent = normalizeWebUiMastheadBackgroundScalePercent(data.payload.webui_masthead_background_scale_percent);
        }
        if (typeof data.payload.webui_masthead_background_rotation_deg === "number") {
          state.webuiMastheadBackgroundRotationDeg = normalizeWebUiMastheadBackgroundRotationDeg(data.payload.webui_masthead_background_rotation_deg);
        }
        if (typeof data.payload.webui_masthead_background_offset_x === "number") {
          state.webuiMastheadBackgroundOffsetX = normalizeWebUiMastheadBackgroundOffset(data.payload.webui_masthead_background_offset_x);
        }
        if (typeof data.payload.webui_masthead_background_offset_y === "number") {
          state.webuiMastheadBackgroundOffsetY = normalizeWebUiMastheadBackgroundOffset(data.payload.webui_masthead_background_offset_y);
        }
        if (typeof data.payload.webui_masthead_background_tile_enabled === "boolean") {
          state.webuiMastheadBackgroundTileEnabled = data.payload.webui_masthead_background_tile_enabled;
        }
        if (typeof data.payload.webui_theme_preset === "string") {
          const legacyPreset = normalizeWebUiThemePreset(data.payload.webui_theme_preset, state.webuiThemeColor, state.webuiBackgroundColor, state);
          if (!hasThemeSlotPreset && legacyPreset && legacyPreset !== "light" && legacyPreset !== "dark") {
            const effectiveThemeMode = getEffectiveThemeMode(state.themeMode);
            if (effectiveThemeMode === "dark") {
              state.webuiDarkThemePreset = legacyPreset;
            } else {
              state.webuiLightThemePreset = legacyPreset;
            }
          }
        }
        if (typeof data.payload.auto_launch_sai === "boolean") {
          state.autoLaunch = data.payload.auto_launch_sai;
        }
        if (typeof data.payload.status_light_group_visible === "boolean") {
          state.statusLightGroupVisible = data.payload.status_light_group_visible;
        }
        if (typeof data.payload.auto_resize_navigator === "boolean") {
          state.navigatorAutoResize = data.payload.auto_resize_navigator;
        }
        if (typeof data.payload.custom_brush_overlay_visible === "boolean") {
          state.customBrushOverlay = data.payload.custom_brush_overlay_visible;
        }
        if (typeof data.payload.preview_developer_mode === "boolean") {
          state.previewDeveloperMode = data.payload.preview_developer_mode;
        }
        if (typeof data.payload.runtime_surface_fixed_refresh === "boolean") {
          state.runtimeSurfaceFixedRefresh = data.payload.runtime_surface_fixed_refresh;
        }
        if (typeof data.payload.runtime_surface_preview_fps_limit === "number") {
          state.runtimeSurfacePreviewFpsLimit = Math.max(0, Math.min(240, Math.trunc(data.payload.runtime_surface_preview_fps_limit)));
        }
        applyThemePresetForMode(getEffectiveThemeMode(state.themeMode));
        render();
      }
      return;
    }

    if (data.kind === "readsai2-embedded-return-dashboard") {
      returnToDashboard();
      return;
    }

    if (data.kind === "readsai2-embedded-host-message" && typeof data.message === "string") {
      postHostMessage(data.message);
    }
  });

  if (!bridge || typeof bridge.addEventListener !== "function") {
    return;
  }

  bridge.addEventListener("message", (event) => {
    const data = event.data;
    if (typeof data === "string") {
      if (data === hostRequestCloseWindowMessage) {
        beginDashboardCloseSequence();
        return;
      }
      if (data === hostWindowShownMessage) {
        beginDashboardRestoreSequence();
        return;
      }

      const prefix = "host:backdrop-mode:";
      if (!data.startsWith(prefix)) {
        return;
      }
      if (!els.hostBackdropButton) {
        return;
      }

      const label = data.slice(prefix.length).trim() || "未知";
      els.hostBackdropButton.textContent = `FX: ${label}`;
      els.hostBackdropButton.title = `窗口背景效果：${label}`;
      els.hostBackdropButton.setAttribute("aria-label", els.hostBackdropButton.title);
      return;
    }

    if (!data || typeof data !== "object") {
      return;
    }

    if (data.kind === "custom-brush-state") {
      applyCustomBrushState(data.state);
      forwardToSettingsContent(data);
      return;
    }

    if (data.kind === "open-settings-page") {
      openSettingsPage(typeof data.page === "string" ? data.page : "blank");
      return;
    }

    forwardToSettingsContent(data);

    if (data.kind === "webui-state") {
      applyHostState(data.state);
      render();
      return;
    }

    if (data.kind === "webui-ack") {
      handleQuickExportAck(data);
      if (data.phase !== "progress" && typeof data.message === "string" && data.message.trim()) {
        addLog(data.message.trim());
      }
    }
  });

  postHostCommand("sync-state");
  postHostCommand("custom-brush-sync");
  syncHostZoomPageKey();
}

function attachTilt(el, maxTilt, lift) {
  if (!el) {
    return;
  }

  const reduceMotion = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
  const finePointer = window.matchMedia("(pointer: fine)").matches;
  if (reduceMotion || !finePointer) {
    return;
  }

  let raf = 0;
  const reset = () => {
    el.style.setProperty("--rx", "0deg");
    el.style.setProperty("--ry", "0deg");
    el.style.setProperty("--lift", "0px");
  };

  el.addEventListener("pointermove", (event) => {
    if (event.pointerType && event.pointerType !== "mouse" && event.pointerType !== "pen") {
      return;
    }
    if (raf) {
      return;
    }

    raf = window.requestAnimationFrame(() => {
      const rect = el.getBoundingClientRect();
      const x = clamp(event.clientX - rect.left, 0, rect.width);
      const y = clamp(event.clientY - rect.top, 0, rect.height);
      const dx = rect.width > 0 ? (x / rect.width) * 2 - 1 : 0;
      const dy = rect.height > 0 ? (y / rect.height) * 2 - 1 : 0;
      el.style.setProperty("--ry", `${(dx * maxTilt).toFixed(2)}deg`);
      el.style.setProperty("--rx", `${(-dy * maxTilt).toFixed(2)}deg`);
      if (lift) {
        el.style.setProperty("--lift", lift);
      }
      raf = 0;
    });
  });

  el.addEventListener("pointerleave", () => {
    if (raf) {
      window.cancelAnimationFrame(raf);
      raf = 0;
    }
    reset();
  });

  el.addEventListener("pointercancel", reset);
}

function attachGlowDrift(el, options) {
  if (!el) {
    return;
  }

  const reduceMotion = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
  const settings = {
    defaultX: options && typeof options.defaultX === "number" ? options.defaultX : 50,
    defaultY: options && typeof options.defaultY === "number" ? options.defaultY : 50,
    inverse: !!(options && options.inverse),
    minX: options && typeof options.minX === "number" ? options.minX : 0,
    maxX: options && typeof options.maxX === "number" ? options.maxX : 100,
    minY: options && typeof options.minY === "number" ? options.minY : 0,
    maxY: options && typeof options.maxY === "number" ? options.maxY : 100,
    clampMin: options && typeof options.clampMin === "number" ? options.clampMin : -50,
    clampMax: options && typeof options.clampMax === "number" ? options.clampMax : 150,
    dynamicBounds: !!(options && options.dynamicBounds),
    radiusScale: options && typeof options.radiusScale === "number" ? options.radiusScale : 0.38,
    observeResize: !!(options && options.observeResize)
  };
  const glowState = {
    currentX: settings.defaultX,
    currentY: settings.defaultY,
    targetX: settings.defaultX,
    targetY: settings.defaultY,
    raf: 0
  };

  const geometryState = {
    left: 0,
    top: 0,
    width: 0,
    height: 0,
    radius: 0,
    initialized: false
  };
  const settleThreshold = settings.dynamicBounds ? 0.45 : 0.12;
  const targetThreshold = settings.dynamicBounds ? 0.25 : 0.08;
  const easing = settings.dynamicBounds ? 0.14 : 0.1;
  let geometryDirty = true;
  let lastGlowKey = "";
  let lastRadiusText = "";
  let pointerRaf = 0;
  let pendingPointer = null;

  const getDefaultNormalizedPoint = () => ({
    x: clamp(settings.defaultX / 100, 0, 1),
    y: clamp(settings.defaultY / 100, 0, 1)
  });

  const getDynamicRange = (geometry) => ({
    minX: -geometry.radius,
    maxX: geometry.width + geometry.radius,
    minY: -geometry.radius,
    maxY: geometry.height + geometry.radius,
    spanX: geometry.width + (geometry.radius * 2),
    spanY: geometry.height + (geometry.radius * 2)
  });

  const formatGlowNumber = (value) => {
    const normalized = Object.is(value, -0) ? 0 : value;
    return normalized.toFixed(1);
  };

  const formatGlowCoordinate = (value, unit) => {
    const precision = unit === "px" ? 2 : 10;
    const rounded = Math.round(value * precision) / precision;
    return `${formatGlowNumber(rounded)}${unit}`;
  };

  const updateDynamicGeometry = (force = false) => {
    if (!settings.dynamicBounds) {
      return false;
    }
    if (!force && !geometryDirty && geometryState.initialized) {
      return false;
    }

    const rect = el.getBoundingClientRect();
    const width = Math.max(0, rect.width);
    const height = Math.max(0, rect.height);
    const radius = Math.max(0, Math.hypot(width, height) * settings.radiusScale);
    const sizeChanged = !geometryState.initialized
      || Math.abs(width - geometryState.width) > 1
      || Math.abs(height - geometryState.height) > 1;
    const positionChanged = !geometryState.initialized
      || Math.abs(rect.left - geometryState.left) > 1
      || Math.abs(rect.top - geometryState.top) > 1;

    geometryState.left = rect.left;
    geometryState.top = rect.top;
    geometryState.width = width;
    geometryState.height = height;
    geometryState.radius = radius;
    geometryState.initialized = true;
    geometryDirty = false;

    const radiusText = formatGlowCoordinate(radius, "px");
    if (lastRadiusText !== radiusText) {
      el.style.setProperty("--glow-radius", radiusText);
      lastRadiusText = radiusText;
    }

    return sizeChanged || positionChanged;
  };

  const getNormalizedDynamicPoint = (x, y, geometry) => {
    const defaults = getDefaultNormalizedPoint();
    const range = getDynamicRange(geometry);
    return {
      x: range.spanX > 0 ? clamp((x - range.minX) / range.spanX, 0, 1) : defaults.x,
      y: range.spanY > 0 ? clamp((y - range.minY) / range.spanY, 0, 1) : defaults.y
    };
  };

  const getDynamicPointFromNormalized = (normalizedX, normalizedY, geometry) => {
    const defaults = getDefaultNormalizedPoint();
    const range = getDynamicRange(geometry);
    const safeX = Number.isFinite(normalizedX) ? clamp(normalizedX, 0, 1) : defaults.x;
    const safeY = Number.isFinite(normalizedY) ? clamp(normalizedY, 0, 1) : defaults.y;
    return {
      x: range.minX + (range.spanX * safeX),
      y: range.minY + (range.spanY * safeY)
    };
  };

  const setGlow = (xPercent, yPercent) => {
    let xText = "";
    let yText = "";
    if (settings.dynamicBounds) {
      xText = formatGlowCoordinate(xPercent, "px");
      yText = formatGlowCoordinate(yPercent, "px");
    } else {
      xText = formatGlowCoordinate(clamp(xPercent, settings.clampMin, settings.clampMax), "%");
      yText = formatGlowCoordinate(clamp(yPercent, settings.clampMin, settings.clampMax), "%");
    }

    const glowKey = `${xText}|${yText}`;
    if (lastGlowKey === glowKey) {
      return;
    }

    el.style.setProperty("--glow-x", xText);
    el.style.setProperty("--glow-y", yText);
    lastGlowKey = glowKey;
  };

  const setInitialPercentGlow = () => {
    const xText = formatGlowCoordinate(settings.defaultX, "%");
    const yText = formatGlowCoordinate(settings.defaultY, "%");
    const glowKey = `${xText}|${yText}`;
    if (lastGlowKey === glowKey) {
      return;
    }

    el.style.setProperty("--glow-x", xText);
    el.style.setProperty("--glow-y", yText);
    lastGlowKey = glowKey;
  };

  const stopAnimation = () => {
    if (glowState.raf) {
      window.cancelAnimationFrame(glowState.raf);
      glowState.raf = 0;
    }
  };

  const animateGlow = () => {
    glowState.raf = 0;

    const dx = glowState.targetX - glowState.currentX;
    const dy = glowState.targetY - glowState.currentY;
    if (Math.abs(dx) < settleThreshold && Math.abs(dy) < settleThreshold) {
      glowState.currentX = glowState.targetX;
      glowState.currentY = glowState.targetY;
      setGlow(glowState.currentX, glowState.currentY);
      return;
    }

    glowState.currentX += dx * easing;
    glowState.currentY += dy * easing;
    setGlow(glowState.currentX, glowState.currentY);
    glowState.raf = window.requestAnimationFrame(animateGlow);
  };

  const initializeDynamicGeometry = () => {
    updateDynamicGeometry(true);
    const defaultNormalized = getDefaultNormalizedPoint();
    const defaultPoint = getDynamicPointFromNormalized(defaultNormalized.x, defaultNormalized.y, geometryState);
    glowState.currentX = defaultPoint.x;
    glowState.currentY = defaultPoint.y;
    glowState.targetX = defaultPoint.x;
    glowState.targetY = defaultPoint.y;
    setGlow(defaultPoint.x, defaultPoint.y);
  };

  const syncDynamicGeometry = (force = false) => {
    if (!settings.dynamicBounds) {
      return;
    }
    if (!geometryState.initialized) {
      initializeDynamicGeometry();
      return;
    }

    const previousGeometry = {
      width: geometryState.width,
      height: geometryState.height,
      radius: geometryState.radius
    };
    const currentNormalized = getNormalizedDynamicPoint(glowState.currentX, glowState.currentY, previousGeometry);
    const targetNormalized = getNormalizedDynamicPoint(glowState.targetX, glowState.targetY, previousGeometry);

    const geometryChanged = updateDynamicGeometry(force);
    if (!geometryChanged && !force) {
      return;
    }

    const currentPoint = getDynamicPointFromNormalized(currentNormalized.x, currentNormalized.y, geometryState);
    const targetPoint = getDynamicPointFromNormalized(targetNormalized.x, targetNormalized.y, geometryState);
    glowState.currentX = currentPoint.x;
    glowState.currentY = currentPoint.y;
    glowState.targetX = targetPoint.x;
    glowState.targetY = targetPoint.y;
    setGlow(glowState.currentX, glowState.currentY);
  };

  const ensureDynamicGeometry = () => {
    if (!settings.dynamicBounds) {
      return;
    }
    if (!geometryState.initialized) {
      initializeDynamicGeometry();
      return;
    }
    if (geometryDirty) {
      syncDynamicGeometry();
    }
  };

  const updateGlowTarget = (xPercent, yPercent) => {
    let nextX = xPercent;
    let nextY = yPercent;
    if (settings.dynamicBounds) {
      const range = getDynamicRange(geometryState);
      nextX = clamp(xPercent, range.minX, range.maxX);
      nextY = clamp(yPercent, range.minY, range.maxY);
    } else {
      nextX = clamp(xPercent, settings.clampMin, settings.clampMax);
      nextY = clamp(yPercent, settings.clampMin, settings.clampMax);
    }

    if (Math.abs(nextX - glowState.targetX) < targetThreshold && Math.abs(nextY - glowState.targetY) < targetThreshold) {
      return;
    }

    glowState.targetX = nextX;
    glowState.targetY = nextY;

    if (reduceMotion) {
      glowState.currentX = glowState.targetX;
      glowState.currentY = glowState.targetY;
      setGlow(glowState.currentX, glowState.currentY);
      return;
    }

    if (!glowState.raf) {
      glowState.raf = window.requestAnimationFrame(animateGlow);
    }
  };

  const cancelPointerFrame = () => {
    if (pointerRaf) {
      window.cancelAnimationFrame(pointerRaf);
      pointerRaf = 0;
    }
    pendingPointer = null;
  };

  const reset = () => {
    if (settings.dynamicBounds) {
      ensureDynamicGeometry();
      const defaultNormalized = getDefaultNormalizedPoint();
      const defaultPoint = getDynamicPointFromNormalized(defaultNormalized.x, defaultNormalized.y, geometryState);
      updateGlowTarget(defaultPoint.x, defaultPoint.y);
      return;
    }

    updateGlowTarget(settings.defaultX, settings.defaultY);
  };

  if (settings.dynamicBounds) {
    setInitialPercentGlow();
  } else {
    setGlow(settings.defaultX, settings.defaultY);
  }

  const updatePointerGlow = () => {
    pointerRaf = 0;
    const pointer = pendingPointer;
    pendingPointer = null;
    if (!pointer) {
      return;
    }

    let left = 0;
    let top = 0;
    let width = 0;
    let height = 0;

    if (settings.dynamicBounds) {
      ensureDynamicGeometry();
      left = geometryState.left;
      top = geometryState.top;
      width = geometryState.width;
      height = geometryState.height;
    } else {
      const rect = el.getBoundingClientRect();
      left = rect.left;
      top = rect.top;
      width = rect.width;
      height = rect.height;
    }

    if (width <= 0 || height <= 0) {
      return;
    }

    const pointerX = clamp(pointer.clientX - left, 0, width) / width;
    const pointerY = clamp(pointer.clientY - top, 0, height) / height;
    const normalizedX = settings.inverse ? 1 - pointerX : pointerX;
    const normalizedY = settings.inverse ? 1 - pointerY : pointerY;
    const mappedPoint = settings.dynamicBounds
      ? getDynamicPointFromNormalized(normalizedX, normalizedY, geometryState)
      : {
        x: settings.minX + ((settings.maxX - settings.minX) * normalizedX),
        y: settings.minY + ((settings.maxY - settings.minY) * normalizedY)
      };
    const glowX = mappedPoint.x;
    const glowY = mappedPoint.y;
    updateGlowTarget(glowX, glowY);
  };

  el.addEventListener("pointerenter", (event) => {
    if (event.pointerType && event.pointerType !== "mouse" && event.pointerType !== "pen") {
      return;
    }

    geometryDirty = true;
    if (settings.dynamicBounds) {
      ensureDynamicGeometry();
    }
  }, { passive: true });

  el.addEventListener("pointermove", (event) => {
    if (event.pointerType && event.pointerType !== "mouse" && event.pointerType !== "pen") {
      return;
    }

    pendingPointer = {
      clientX: event.clientX,
      clientY: event.clientY
    };
    if (!pointerRaf) {
      pointerRaf = window.requestAnimationFrame(updatePointerGlow);
    }
  }, { passive: true });

  el.addEventListener("pointerleave", () => {
    cancelPointerFrame();
    reset();
  });

  el.addEventListener("pointercancel", () => {
    cancelPointerFrame();
    reset();
  });

  if (settings.dynamicBounds && settings.observeResize && typeof ResizeObserver === "function") {
    const resizeObserver = new ResizeObserver(() => {
      geometryDirty = true;
    });
    resizeObserver.observe(el);
  }

  if (!reduceMotion) {
    el.addEventListener("blur", reset);
  } else {
    stopAnimation();
  }
}

function attachAmbientSurfaceMotion(el, options) {
  if (!el) {
    return;
  }

  if (el.dataset.ambientMotionBound === "true") {
    return;
  }
  el.dataset.ambientMotionBound = "true";
  attachTilt(el, options.tiltMax, options.lift);
  attachGlowDrift(el, options.glow);
}

function initAmbientMotion(root = document) {
  root.querySelectorAll(".card").forEach((card) => {
    attachAmbientSurfaceMotion(card, {
      tiltMax: card.classList.contains("settings-page-card") ? 1.4 : 3.5,
      lift: card.classList.contains("settings-page-card") ? "-1px" : "-2px",
      glow: {
        defaultX: 68,
        defaultY: 32,
        inverse: true,
        dynamicBounds: true,
        radiusScale: 1.14
      }
    });
  });
  const masthead = root === document ? document.querySelector(".masthead") : null;
  attachAmbientSurfaceMotion(masthead, {
    tiltMax: 2.4,
    lift: "-1px",
    glow: {
      defaultX: 15,
      defaultY: 10,
      inverse: true,
      dynamicBounds: true,
      radiusScale: 1.14
    }
  });
}

function refreshDynamicSurface(root) {
  if (window.ReadSAI2WebUi && window.ReadSAI2WebUi.ui && typeof window.ReadSAI2WebUi.ui.initCustomSelects === "function") {
    window.ReadSAI2WebUi.ui.initCustomSelects(root);
  }
  initAmbientMotion(root || document);
  queuePageScrollFadeUpdate();
}

window.ReadSAI2WebUi = window.ReadSAI2WebUi || {};
window.ReadSAI2WebUi.ui = {
  ...(window.ReadSAI2WebUi.ui || {}),
  refreshSurface: refreshDynamicSurface
};

async function init() {
  runtime.provider = window.location.protocol === "file:" ? createMockProvider() : createHttpProvider();
  initCustomSelects();
  bindThemePreferenceChange();
  bindHostBridge();
  bindMastheadIntroMotion();
  bindControls();
  bindControlRailPanelMotion();
  bindRecordPresetTagMenus();
  bindPreviewSurface();
  bindPageScrollFade();
  initAmbientMotion();
  updatePreviewViewportSize();
  if (window.ReadSAI2PageLoader && typeof window.ReadSAI2PageLoader.init === "function") {
    await window.ReadSAI2PageLoader.init();
  }
  bindSearchCommandShortcuts();
  renderLog();
  render();
  drawPreview();

  await runtime.provider.init();
}

void init();
