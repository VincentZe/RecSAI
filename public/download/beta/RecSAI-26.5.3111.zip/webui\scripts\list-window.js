﻿(function () {
  const scrollFadeThresholdPx = 3;
  const closeAnimationDurationMs = 180;
  const projectPollIntervalMs = 1000;
  const historyPollIntervalMs = 250;
  const hostRequestCloseWindowMessage = "host:request-close-window";
  const hostWindowShownMessage = "host:window-shown";
  const hostCloseWindowMessage = "host:close-window";
  const hostDragMoveMessage = "host:drag-move";
  const hostResizeBottomLeftMessage = "host:resize-bottom-left";
  const hostResizeBottomRightMessage = "host:resize-bottom-right";

  const state = {
    kind: document.body && document.body.dataset && document.body.dataset.listKind === "history" ? "history" : "project",
    items: [],
    visibleItems: [],
    activeIndex: -1,
    filter: {
      defaultSkipAll: false,
      exceptionCount: 0,
      checkState: 0,
      statusText: "全量"
    },
    disableGlobalHotkeys: false,
    isClosing: false,
    editingKey: "",
    closeTimerId: 0,
    pollTimerId: 0,
    refreshTimerId: 0,
    filterMutationCount: 0,
    filterRevision: 0
  };

  const els = {
    listWindow: document.getElementById("listWindow"),
    listCard: document.getElementById("listCard"),
    listDragHandle: document.getElementById("listDragHandle"),
    listTitle: document.getElementById("listTitle"),
    listSubtitle: document.getElementById("listSubtitle"),
    resultMeta: document.getElementById("resultMeta"),
    listCloseButton: document.getElementById("listCloseButton"),
    filterToolbar: document.getElementById("filterToolbar"),
    filterToggle: document.getElementById("filterToggle"),
    filterStatus: document.getElementById("filterStatus"),
    listContentShell: document.querySelector(".list-content-shell"),
    listScroll: document.getElementById("listScroll"),
    listEmpty: document.getElementById("listEmpty"),
    listHint: document.getElementById("listHint"),
    listResizeBottomLeftButton: document.getElementById("listResizeBottomLeftButton"),
    listResizeBottomRightButton: document.getElementById("listResizeBottomRightButton")
  };

  let filterRequestChain = Promise.resolve();

  function getHostBridge() {
    const bridge = window.chrome && window.chrome.webview;
    if (!bridge || typeof bridge.postMessage !== "function") {
      return null;
    }
    return bridge;
  }

  function postHostMessage(message) {
    const bridge = getHostBridge();
    if (!bridge) {
      return false;
    }
    bridge.postMessage(message);
    return true;
  }

  function buildHostDragMoveMessage(event) {
    return JSON.stringify({
      kind: hostDragMoveMessage,
      screenX: event.screenX,
      screenY: event.screenY,
      clientX: event.clientX,
      clientY: event.clientY
    });
  }

  const windowTheme = window.ReadSAI2WindowTheme
    ? window.ReadSAI2WindowTheme.createController()
    : null;

  function applyWindowTheme(payload) {
    if (windowTheme) {
      windowTheme.apply(payload);
      return;
    }

    document.documentElement.dataset.theme = "light";
    document.documentElement.dataset.themeMode = "light";
  }

  function escapeHtml(text) {
    return String(text == null ? "" : text)
      .replace(/&/g, "&amp;")
      .replace(/</g, "&lt;")
      .replace(/>/g, "&gt;")
      .replace(/"/g, "&quot;")
      .replace(/'/g, "&#39;");
  }

  function getApiPath() {
    return state.kind === "history" ? "/api/list/history" : "/api/list/projects";
  }

  function postApiPath(path) {
    return path;
  }

  function toTrimmedString(value) {
    return typeof value === "string" ? value.trim() : "";
  }

  function isCssColor(value) {
    return /^#[0-9a-f]{6}$/i.test(value || "");
  }

  function getIconText(item, index) {
    if (state.kind === "history") {
      return String(index + 1);
    }

    const title = item && item.title ? item.title : "";
    const compact = title.replace(/\s+/g, "");
    return compact ? compact.slice(0, 2).toUpperCase() : "PJ";
  }

  function normalizeProjectItem(item) {
    if (!item || typeof item !== "object") {
      return null;
    }

    const name = toTrimmedString(item.name);
    const path = toTrimmedString(item.path);
    const title = toTrimmedString(item.title) || name || path || "未命名项目";
    return {
      title,
      meta: toTrimmedString(item.meta) || path,
      sourceText: title,
      filterKey: toTrimmedString(item.filter_key),
      canToggleFilter: item.can_toggle_filter === true,
      isSkipped: item.is_skipped === true
    };
  }

  function normalizeHistoryItem(item) {
    const title = typeof item === "string" ? item.trim() : toTrimmedString(item && item.title);
    const sourceText = typeof item === "string"
      ? item.trim()
      : toTrimmedString(item && (item.source_text || item.text || item.title));
    return {
      title: title || "未命名历史",
      meta: toTrimmedString(item && item.meta),
      sourceText,
      filterKey: toTrimmedString(item && item.filter_key),
      canToggleFilter: item && item.can_toggle_filter === true,
      isSkipped: item && item.is_skipped === true,
      tagText: toTrimmedString(item && item.tag_text),
      tagBackColor: isCssColor(item && item.tag_back_color) ? item.tag_back_color : "",
      tagForeColor: isCssColor(item && item.tag_fore_color) ? item.tag_fore_color : "",
      canEditTag: item && item.can_edit_tag === true
    };
  }

  function normalizeFilter(data) {
    const filter = data && typeof data.filter === "object" ? data.filter : {};
    return {
      defaultSkipAll: filter.default_skip_all === true,
      exceptionCount: Number.isFinite(Number(filter.exception_count)) ? Math.max(0, Math.trunc(Number(filter.exception_count))) : 0,
      checkState: Number.isFinite(Number(filter.check_state)) ? Math.max(0, Math.min(2, Math.trunc(Number(filter.check_state)))) : 0,
      statusText: toTrimmedString(filter.status_text) || "全量"
    };
  }

  function getFilterUnit() {
    return state.kind === "history" ? "组" : "项";
  }

  function buildFilterStatusText(defaultSkipAll, exceptionCount) {
    const unit = getFilterUnit();
    if (defaultSkipAll) {
      return exceptionCount <= 0 ? "全跳" : `全跳+录制${exceptionCount}${unit}`;
    }
    return exceptionCount <= 0 ? "全量" : `全量+跳过${exceptionCount}${unit}`;
  }

  function buildFilterState(defaultSkipAll, exceptionCount) {
    const safeExceptionCount = Math.max(0, Math.trunc(Number(exceptionCount) || 0));
    return {
      defaultSkipAll: !!defaultSkipAll,
      exceptionCount: safeExceptionCount,
      checkState: defaultSkipAll
        ? (safeExceptionCount <= 0 ? 2 : 1)
        : (safeExceptionCount <= 0 ? 0 : 1),
      statusText: buildFilterStatusText(!!defaultSkipAll, safeExceptionCount)
    };
  }

  function normalizeState(data) {
    const rawItems = Array.isArray(data && data.items) ? data.items : [];
    const items = rawItems
      .map((item) => (state.kind === "history" ? normalizeHistoryItem(item) : normalizeProjectItem(item)))
      .filter((item) => !!item);
    const activeIndex = Number.isFinite(Number(data && data.active_index)) ? Math.trunc(Number(data.active_index)) : -1;
    return {
      items,
      activeIndex,
      filter: normalizeFilter(data)
    };
  }

  function syncVisibleItems() {
    state.visibleItems = state.items.map((item, index) => ({ ...item, originalIndex: index }));
  }

  function updateScrollFade() {
    const scrollRoot = els.listScroll;
    if (!scrollRoot) {
      return;
    }

    const scrollTop = Math.max(0, scrollRoot.scrollTop || 0);
    const maxScrollTop = Math.max(0, (scrollRoot.scrollHeight || 0) - (scrollRoot.clientHeight || 0));
    const hasTopFade = scrollTop > scrollFadeThresholdPx;
    const hasBottomFade = maxScrollTop - scrollTop > scrollFadeThresholdPx;

    let nextFadeClass = "scroll-fade-none";
    if (hasTopFade && hasBottomFade) {
      nextFadeClass = "scroll-fade-both";
    } else if (hasTopFade) {
      nextFadeClass = "scroll-fade-top";
    } else if (hasBottomFade) {
      nextFadeClass = "scroll-fade-bottom";
    }

    scrollRoot.classList.remove("scroll-fade-none", "scroll-fade-top", "scroll-fade-bottom", "scroll-fade-both");
    scrollRoot.classList.add(nextFadeClass);
  }

  function renderPreservingScroll() {
    const scrollTop = els.listScroll ? els.listScroll.scrollTop : 0;
    render();
    if (els.listScroll) {
      els.listScroll.scrollTop = scrollTop;
      updateScrollFade();
    }
  }

  function render() {
    if (els.listTitle) {
      els.listTitle.textContent = state.kind === "history" ? "历史列表" : "项目列表";
    }
    if (els.listSubtitle) {
      els.listSubtitle.textContent = state.kind === "history" ? "当前项目历史记录" : "当前项目与最近项目";
    }
    if (els.resultMeta) {
      els.resultMeta.textContent = `${state.visibleItems.length} 项`;
    }
    if (els.filterToolbar) {
      els.filterToolbar.hidden = false;
    }
    if (els.filterToggle) {
      els.filterToggle.dataset.checkState = String(state.filter.checkState);
      els.filterToggle.setAttribute("aria-pressed", state.filter.checkState === 2 ? "true" : "false");
      els.filterToggle.title = state.filter.defaultSkipAll ? "取消跳过全部" : "跳过全部";
    }
    if (els.filterStatus) {
      els.filterStatus.textContent = state.filter.statusText;
    }
    if (els.listHint) {
      els.listHint.hidden = state.disableGlobalHotkeys;
      els.listHint.textContent = state.kind === "history" ? "按 F4 关闭" : "按 F3 关闭";
    }

    els.listScroll.innerHTML = "";
    els.listEmpty.hidden = state.visibleItems.length !== 0;

    state.visibleItems.forEach((item, index) => {
      const row = document.createElement("div");
      row.className = "list-row";
      if (item.originalIndex === state.activeIndex) {
        row.classList.add("is-active");
      }
      if (item.isSkipped) {
        row.classList.add("is-skipped");
      }
      if (item.canToggleFilter) {
        row.classList.add("can-toggle-filter");
        row.title = item.isSkipped ? "点击恢复录制" : "点击跳过录制";
      }

      row.dataset.itemIndex = String(index);
      const tagStyle = item.tagBackColor
        ? ` style="--tag-bg:${escapeHtml(item.tagBackColor)};--tag-fg:${escapeHtml(item.tagForeColor || "#ffffff")}"`
        : "";
      const tagHtml = state.kind === "history" && item.canEditTag
        ? `<button class="list-tag ${item.tagText ? "has-tag" : "is-add"}" type="button" data-tag-index="${index}"${tagStyle}>${escapeHtml(item.tagText || "+标签")}</button>`
        : "";
      row.innerHTML = `
        <div class="list-icon">${escapeHtml(getIconText(item, item.originalIndex))}</div>
        <div class="list-body">
          <div class="list-title-line">
            <p class="list-title">${escapeHtml(item.title)}</p>
            ${tagHtml}
          </div>
          ${item.meta ? `<p class="list-meta">${escapeHtml(item.meta)}</p>` : ""}
        </div>
      `;
      els.listScroll.appendChild(row);
    });

    updateScrollFade();
  }

  async function fetchJson(path) {
    const response = await fetch(path, {
      cache: "no-store",
      headers: {
        "Content-Type": "application/json"
      }
    });

    let payload = null;
    try {
      payload = await response.json();
    } catch {
      payload = null;
    }

    if (!response.ok || !payload || payload.ok !== true) {
      const message = payload && payload.error && payload.error.message
        ? payload.error.message
        : `HTTP ${response.status}`;
      throw new Error(message);
    }

    return payload.data || {};
  }

  async function postJson(path, body) {
    const response = await fetch(postApiPath(path), {
      method: "POST",
      cache: "no-store",
      headers: {
        "Content-Type": "application/json"
      },
      body: JSON.stringify(body || {})
    });

    let payload = null;
    try {
      payload = await response.json();
    } catch {
      payload = null;
    }

    if (!response.ok || !payload || payload.ok !== true) {
      const message = payload && payload.error && payload.error.message
        ? payload.error.message
        : `HTTP ${response.status}`;
      throw new Error(message);
    }

    return payload.data || {};
  }

  function enqueueFilterPost(path, body) {
    const request = filterRequestChain
      .catch(() => {})
      .then(() => postJson(path, body));
    filterRequestChain = request.catch(() => {});
    return request;
  }

  async function refresh() {
    if (state.editingKey || state.filterMutationCount > 0) {
      return;
    }
    const requestRevision = state.filterRevision;
    try {
      const data = await fetchJson(getApiPath());
      if (state.editingKey || state.filterMutationCount > 0 || requestRevision !== state.filterRevision) {
        return;
      }
      const nextState = normalizeState(data);
      state.items = nextState.items;
      state.activeIndex = nextState.activeIndex;
      state.filter = nextState.filter;
      syncVisibleItems();
      render();
    } catch {
      if (state.editingKey || state.filterMutationCount > 0 || requestRevision !== state.filterRevision) {
        return;
      }
      state.items = [];
      state.visibleItems = [];
      state.activeIndex = -1;
      state.filter = normalizeFilter(null);
      render();
    }
  }

  function findVisibleItemByRow(target) {
    const row = target instanceof Element ? target.closest(".list-row") : null;
    if (!row) {
      return null;
    }
    const index = Number(row.dataset.itemIndex);
    if (!Number.isFinite(index) || index < 0 || index >= state.visibleItems.length) {
      return null;
    }
    return state.visibleItems[index];
  }

  function scheduleRefresh(delayMs) {
    if (state.refreshTimerId) {
      window.clearTimeout(state.refreshTimerId);
      state.refreshTimerId = 0;
    }

    state.refreshTimerId = window.setTimeout(() => {
      state.refreshTimerId = 0;
      void refresh();
    }, Math.max(0, Number(delayMs) || 0));
  }

  function beginFilterMutation() {
    state.filterMutationCount += 1;
    state.filterRevision += 1;
    if (state.refreshTimerId) {
      window.clearTimeout(state.refreshTimerId);
      state.refreshTimerId = 0;
    }
    return state.filterRevision;
  }

  function endFilterMutation() {
    state.filterMutationCount = Math.max(0, state.filterMutationCount - 1);
    if (state.filterMutationCount === 0) {
      scheduleRefresh(180);
    }
  }

  function setSkippedForFilterKey(filterKey, isSkipped) {
    state.items.forEach((entry) => {
      if (entry && entry.filterKey === filterKey) {
        entry.isSkipped = isSkipped;
      }
    });
    syncVisibleItems();
  }

  function createSkippedSnapshot(filterKey) {
    return state.items
      .map((entry, index) => (entry && entry.filterKey === filterKey
        ? { index, isSkipped: entry.isSkipped === true }
        : null))
      .filter((entry) => !!entry);
  }

  function restoreSkippedSnapshot(snapshot) {
    snapshot.forEach((entry) => {
      if (state.items[entry.index]) {
        state.items[entry.index].isSkipped = entry.isSkipped;
      }
    });
    syncVisibleItems();
  }

  async function toggleRowFilter(item) {
    if (!item || !item.canToggleFilter || !item.filterKey) {
      return;
    }

    const previousFilter = { ...state.filter };
    const previousSkipped = createSkippedSnapshot(item.filterKey);
    const wasSkipped = item.isSkipped === true;
    const nextSkipped = !wasSkipped;
    const wasException = state.filter.defaultSkipAll ? !wasSkipped : wasSkipped;
    const nextException = state.filter.defaultSkipAll ? !nextSkipped : nextSkipped;
    const exceptionDelta = (nextException ? 1 : 0) - (wasException ? 1 : 0);

    const mutationRevision = beginFilterMutation();
    state.filter = buildFilterState(
      state.filter.defaultSkipAll,
      state.filter.exceptionCount + exceptionDelta
    );
    setSkippedForFilterKey(item.filterKey, nextSkipped);
    renderPreservingScroll();

    try {
      const data = await enqueueFilterPost("/api/list/filter/toggle", {
        kind: state.kind,
        key: item.filterKey,
        item_text: item.sourceText || item.title || "",
        is_skipped: nextSkipped
      });
      if (mutationRevision === state.filterRevision) {
        state.filter = normalizeFilter(data);
        renderPreservingScroll();
      }
    } catch {
      if (mutationRevision === state.filterRevision) {
        state.filter = previousFilter;
        restoreSkippedSnapshot(previousSkipped);
        renderPreservingScroll();
      }
    } finally {
      endFilterMutation();
    }
  }

  async function toggleDefaultSkipAll() {
    const nextDefaultSkipAll = state.filter.checkState === 2 ? false : true;
    const previousFilter = { ...state.filter };
    const previousSkipped = state.items.map((entry, index) => ({
      index,
      isSkipped: entry && entry.isSkipped === true
    }));

    const mutationRevision = beginFilterMutation();
    state.filter = buildFilterState(nextDefaultSkipAll, 0);
    state.items.forEach((entry) => {
      if (entry) {
        entry.isSkipped = nextDefaultSkipAll;
      }
    });
    syncVisibleItems();
    renderPreservingScroll();

    try {
      const data = await enqueueFilterPost("/api/list/filter/default", {
        kind: state.kind,
        default_skip_all: nextDefaultSkipAll,
        clear_exceptions: true
      });
      if (mutationRevision === state.filterRevision) {
        state.filter = normalizeFilter(data);
        renderPreservingScroll();
      }
    } catch {
      if (mutationRevision === state.filterRevision) {
        state.filter = previousFilter;
        previousSkipped.forEach((entry) => {
          if (state.items[entry.index]) {
            state.items[entry.index].isSkipped = entry.isSkipped;
          }
        });
        syncVisibleItems();
        renderPreservingScroll();
      }
    } finally {
      endFilterMutation();
    }
  }

  function beginTagEdit(button) {
    if (state.kind !== "history" || !(button instanceof HTMLElement)) {
      return;
    }
    const index = Number(button.dataset.tagIndex);
    if (!Number.isFinite(index) || index < 0 || index >= state.visibleItems.length) {
      return;
    }
    const item = state.visibleItems[index];
    if (!item || !item.canEditTag) {
      return;
    }

    const input = document.createElement("input");
    input.className = "list-tag-input";
    input.type = "text";
    input.value = item.tagText || "";
    input.placeholder = "标签";
    input.maxLength = 24;
    input.dataset.tagIndex = String(index);
    state.editingKey = item.filterKey || item.sourceText || String(index);
    button.replaceWith(input);
    input.focus();
    input.select();

    let committed = false;
    const cancel = () => {
      if (committed) {
        return;
      }
      committed = true;
      state.editingKey = "";
      render();
    };
    const commit = async () => {
      if (committed) {
        return;
      }
      committed = true;
      const label = input.value.trim();
      if (!label) {
        state.editingKey = "";
        render();
        return;
      }
      try {
        await postJson("/api/list/history/tag", {
          item_text: item.sourceText || item.title || "",
          key: item.filterKey || "",
          label
        });
      } catch {
      } finally {
        state.editingKey = "";
      }
      await refresh();
    };

    input.addEventListener("keydown", (event) => {
      if (event.key === "Enter") {
        event.preventDefault();
        event.stopPropagation();
        void commit();
      } else if (event.key === "Escape") {
        event.preventDefault();
        event.stopPropagation();
        cancel();
      }
    });
    input.addEventListener("blur", () => {
      void commit();
    });
  }

  function beginCloseSequence() {
    if (state.isClosing) {
      return;
    }

    state.isClosing = true;
    if (state.closeTimerId) {
      window.clearTimeout(state.closeTimerId);
    }

    if (els.listWindow) {
      els.listWindow.classList.add("is-closing");
    }

    state.closeTimerId = window.setTimeout(() => {
      state.closeTimerId = 0;
      postHostMessage(hostCloseWindowMessage);
    }, closeAnimationDurationMs);
  }

  function resetWindowState() {
    state.isClosing = false;
    if (state.closeTimerId) {
      window.clearTimeout(state.closeTimerId);
      state.closeTimerId = 0;
    }

    if (els.listWindow) {
      els.listWindow.classList.remove("is-closing");
      els.listWindow.classList.remove("is-ready");
      window.requestAnimationFrame(() => {
        els.listWindow.classList.add("is-ready");
      });
    }

    window.focus();
  }

  function bindHostBridge() {
    const bridge = getHostBridge();
    if (!bridge || typeof bridge.addEventListener !== "function") {
      return;
    }

    bridge.addEventListener("message", (event) => {
      const data = event.data;
      if (typeof data === "string") {
        if (data === hostRequestCloseWindowMessage) {
          beginCloseSequence();
        } else if (data === hostWindowShownMessage) {
          resetWindowState();
          void refresh();
        }
        return;
      }

      if (!data || typeof data !== "object") {
        return;
      }

      if (data.kind === "list-window-state") {
        state.disableGlobalHotkeys = !!(data.state && data.state.disable_global_hotkeys);
        applyWindowTheme(data.state);
        render();
      }
    });

    postHostMessage(JSON.stringify({
      kind: "webui-command",
      command: "list-window-sync",
      payload: {}
    }));
  }

  function bindDragRegion() {
    const handleDragStart = (event) => {
      if (event.button !== 0 || !event.isPrimary) {
        return;
      }

      const interactiveTarget = event.target instanceof Element
        ? event.target.closest("button, input, select, textarea, a, label, summary, [role='button'], [data-host-drag-ignore='true']")
        : null;
      if (interactiveTarget) {
        return;
      }

      if (postHostMessage(buildHostDragMoveMessage(event))) {
        event.preventDefault();
      }
    };

    if (els.listDragHandle) {
      els.listDragHandle.addEventListener("pointerdown", handleDragStart);
    }

    if (els.listCard) {
      els.listCard.addEventListener("pointerdown", handleDragStart);
    }
  }

  function bindResizeGrip(el, message) {
    if (!el) {
      return;
    }

    el.addEventListener("pointerdown", (event) => {
      if (event.button !== 0 || !event.isPrimary) {
        return;
      }

      event.preventDefault();
      event.stopPropagation();
      postHostMessage(message);
    });
  }

  function attachGlowDrift(el, options) {
    if (!el) {
      return;
    }

    const reduceMotion = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
    const settings = {
      defaultX: options && typeof options.defaultX === "number" ? options.defaultX : 50,
      defaultY: options && typeof options.defaultY === "number" ? options.defaultY : 50,
      inverse: !!(options && options.inverse),
      radiusScale: options && typeof options.radiusScale === "number" ? options.radiusScale : 1.12
    };
    const glowState = {
      currentX: settings.defaultX,
      currentY: settings.defaultY,
      targetX: settings.defaultX,
      targetY: settings.defaultY,
      raf: 0
    };

    function clamp(value, min, max) {
      return Math.max(min, Math.min(max, value));
    }

    function setGlow(x, y) {
      el.style.setProperty("--glow-x", `${x.toFixed(2)}%`);
      el.style.setProperty("--glow-y", `${y.toFixed(2)}%`);
    }

    function updateRadius() {
      const rect = el.getBoundingClientRect();
      const radius = Math.max(rect.width, rect.height) * settings.radiusScale;
      el.style.setProperty("--glow-radius", `${radius.toFixed(2)}px`);
    }

    function animateGlow() {
      glowState.raf = 0;
      const dx = glowState.targetX - glowState.currentX;
      const dy = glowState.targetY - glowState.currentY;
      if (Math.abs(dx) < 0.03 && Math.abs(dy) < 0.03) {
        glowState.currentX = glowState.targetX;
        glowState.currentY = glowState.targetY;
        setGlow(glowState.currentX, glowState.currentY);
        return;
      }

      glowState.currentX += dx * 0.05;
      glowState.currentY += dy * 0.05;
      setGlow(glowState.currentX, glowState.currentY);
      glowState.raf = window.requestAnimationFrame(animateGlow);
    }

    function updateGlowTarget(x, y) {
      glowState.targetX = clamp(x, 0, 100);
      glowState.targetY = clamp(y, 0, 100);

      if (reduceMotion) {
        glowState.currentX = glowState.targetX;
        glowState.currentY = glowState.targetY;
        setGlow(glowState.currentX, glowState.currentY);
        return;
      }

      if (!glowState.raf) {
        glowState.raf = window.requestAnimationFrame(animateGlow);
      }
    }

    function reset() {
      updateGlowTarget(settings.defaultX, settings.defaultY);
    }

    updateRadius();
    setGlow(settings.defaultX, settings.defaultY);

    el.addEventListener("pointermove", (event) => {
      if (event.pointerType && event.pointerType !== "mouse" && event.pointerType !== "pen") {
        return;
      }

      const rect = el.getBoundingClientRect();
      if (rect.width <= 0 || rect.height <= 0) {
        return;
      }

      const pointerX = clamp((event.clientX - rect.left) / rect.width, 0, 1);
      const pointerY = clamp((event.clientY - rect.top) / rect.height, 0, 1);
      const mappedX = (settings.inverse ? (1 - pointerX) : pointerX) * 100;
      const mappedY = (settings.inverse ? (1 - pointerY) : pointerY) * 100;
      updateGlowTarget(mappedX, mappedY);
    });

    el.addEventListener("pointerleave", reset);
    el.addEventListener("pointercancel", reset);

    if (typeof ResizeObserver === "function") {
      const resizeObserver = new ResizeObserver(() => {
        updateRadius();
      });
      resizeObserver.observe(el);
    }
  }

  function bindEvents() {
    bindResizeGrip(els.listResizeBottomLeftButton, hostResizeBottomLeftMessage);
    bindResizeGrip(els.listResizeBottomRightButton, hostResizeBottomRightMessage);

    if (els.listScroll) {
      els.listScroll.addEventListener("scroll", updateScrollFade, { passive: true });
      els.listScroll.addEventListener("click", (event) => {
        const tagButton = event.target instanceof Element ? event.target.closest(".list-tag") : null;
        if (tagButton) {
          event.preventDefault();
          event.stopPropagation();
          beginTagEdit(tagButton);
          return;
        }

        const interactive = event.target instanceof Element
          ? event.target.closest("input, button, textarea, select, a")
          : null;
        if (interactive) {
          return;
        }

        const item = findVisibleItemByRow(event.target);
        if (item) {
          void toggleRowFilter(item);
        }
      });
    }

    if (els.filterToggle) {
      els.filterToggle.addEventListener("click", (event) => {
        event.preventDefault();
        void toggleDefaultSkipAll();
      });
    }

    if (els.listCloseButton) {
      els.listCloseButton.addEventListener("click", (event) => {
        event.preventDefault();
        beginCloseSequence();
      });
    }

    window.addEventListener("keydown", (event) => {
      if (state.disableGlobalHotkeys) {
        return;
      }

      const isCloseHotkey = event.key === "Escape"
        || (state.kind === "history" && event.key === "F4")
        || (state.kind === "project" && event.key === "F3");
      if (isCloseHotkey) {
        event.preventDefault();
        beginCloseSequence();
      }
    });

    window.addEventListener("resize", updateScrollFade);
  }

  function startPolling() {
    if (state.pollTimerId) {
      window.clearInterval(state.pollTimerId);
    }

    state.pollTimerId = window.setInterval(() => {
      void refresh();
    }, state.kind === "history" ? historyPollIntervalMs : projectPollIntervalMs);
  }

  function initAmbientMotion() {
    attachGlowDrift(els.listContentShell, {
      defaultX: 68,
      defaultY: 32,
      inverse: true,
      radiusScale: 1.18
    });
  }

  function init() {
    applyWindowTheme(null);
    bindEvents();
    bindDragRegion();
    bindHostBridge();
    initAmbientMotion();
    resetWindowState();
    startPolling();
    void refresh();
  }

  init();
})();
