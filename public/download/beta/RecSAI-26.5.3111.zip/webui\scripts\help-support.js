﻿(function () {
  const hostWindowShownMessage = "host:window-shown";
  const hostDragMoveMessage = "host:drag-move";
  const hostCloseWindowMessage = "host:close-window";
  const pageScrollFadeThresholdPx = 3;
  const isEmbedded = new URLSearchParams(window.location.search).get("embedded") === "1";
  const defaultStatusText = "准备就绪";

  const state = {
    title: "支持与反馈",
    subtitle: "从这里获得支持 或者 支持作者",
    cards: [],
    statusText: defaultStatusText,
    statusIsError: false
  };

  const els = {
    supportHeader: document.getElementById("supportHeader"),
    titleText: document.getElementById("titleText"),
    pageScrollRoot: document.getElementById("pageScrollRoot"),
    closeWindowButton: document.getElementById("closeWindowButton"),
    refreshButton: document.getElementById("refreshButton"),
    subtitleText: document.getElementById("subtitleText"),
    statusText: document.getElementById("statusText"),
    supportCards: document.getElementById("supportCards")
  };

  let statusTimerId = 0;
  let pageScrollFadeRaf = 0;

  function getEmbeddedTargetOrigin() {
    return window.location.protocol === "file:" ? "*" : window.location.origin;
  }

  function hasEmbeddedParentHostBridge() {
    if (!isEmbedded || !window.parent || window.parent === window) {
      return false;
    }

    try {
      const parentHost = window.parent.ReadSAI2WebUi && window.parent.ReadSAI2WebUi.host;
      return !!(parentHost && typeof parentHost.hasBridge === "function" && parentHost.hasBridge());
    } catch {
      return false;
    }
  }

  function getHostBridge() {
    if (hasEmbeddedParentHostBridge()) {
      return {
        postMessage(message) {
          window.parent.postMessage({
            kind: "readsai2-embedded-host-message",
            message
          }, getEmbeddedTargetOrigin());
        }
      };
    }

    const bridge = window.chrome && window.chrome.webview;
    if (!bridge || typeof bridge.postMessage !== "function") {
      return null;
    }
    return bridge;
  }

  function hasHostBridge() {
    return !!getHostBridge();
  }

  function postHostMessage(message) {
    const bridge = getHostBridge();
    if (!bridge) {
      return false;
    }
    bridge.postMessage(message);
    return true;
  }

  function buildHostDragMoveMessage(event) {
    return JSON.stringify({
      kind: hostDragMoveMessage,
      screenX: event.screenX,
      screenY: event.screenY,
      clientX: event.clientX,
      clientY: event.clientY
    });
  }

  function returnEmbeddedPageToDashboard() {
    if (!isEmbedded || !window.parent || window.parent === window) {
      return false;
    }

    window.parent.postMessage({
      kind: "readsai2-embedded-return-dashboard"
    }, getEmbeddedTargetOrigin());
    return true;
  }

  function bindEmbeddedContextReturn() {
    if (!isEmbedded) {
      return;
    }

    let rightPointerStart = null;
    const isReturnBlockedTarget = (target) => target instanceof Element
      && !!target.closest("button, input, select, textarea, a, label, summary, [role='button'], [data-host-drag-ignore='true']");

    window.addEventListener("pointerdown", (event) => {
      if (event.button !== 2) {
        rightPointerStart = null;
        return;
      }

      rightPointerStart = {
        time: performance.now(),
        blocked: isReturnBlockedTarget(event.target)
      };
    }, { capture: true });

    window.addEventListener("contextmenu", (event) => {
      const pointerStart = rightPointerStart;
      rightPointerStart = null;
      if (event.defaultPrevented) {
        return;
      }

      event.preventDefault();
      const hasFreshPointerStart = pointerStart && performance.now() - pointerStart.time < 2500;
      const shouldBlockReturn = hasFreshPointerStart
        ? pointerStart.blocked
        : isReturnBlockedTarget(event.target);
      if (shouldBlockReturn) {
        return;
      }

      returnEmbeddedPageToDashboard();
    });
  }

  function postHostCommand(command, payload) {
    if (hasEmbeddedParentHostBridge()) {
      window.parent.postMessage({
        kind: "readsai2-embedded-host-command",
        command,
        payload: payload && typeof payload === "object" ? payload : {}
      }, getEmbeddedTargetOrigin());
      return true;
    }

    const bridge = getHostBridge();
    if (!bridge) {
      return false;
    }
    bridge.postMessage(JSON.stringify({
      kind: "webui-command",
      command,
      payload: payload && typeof payload === "object" ? payload : {}
    }));
    return true;
  }

  function setStatus(text, isError, sticky) {
    state.statusText = typeof text === "string" && text.trim() ? text.trim() : defaultStatusText;
    state.statusIsError = !!isError;
    if (els.statusText) {
      els.statusText.textContent = state.statusText;
      els.statusText.style.color = state.statusIsError ? "var(--danger)" : "var(--muted)";
    }

    if (statusTimerId) {
      window.clearTimeout(statusTimerId);
      statusTimerId = 0;
    }

    if (!sticky && !state.statusIsError && state.statusText !== defaultStatusText) {
      statusTimerId = window.setTimeout(() => {
        statusTimerId = 0;
        setStatus(defaultStatusText, false, false);
      }, 1800);
    }
  }

  function requestStateSync() {
    if (postHostCommand("help-support-sync")) {
      setStatus("正在同步支持信息…", false, true);
      return;
    }
    applyMockState();
  }

  function applyState(payload) {
    const source = payload && typeof payload === "object" ? payload : {};
    state.title = String(source.title || "支持与反馈");
    state.subtitle = String(source.subtitle || "从这里获得支持 或者 支持作者");
    state.cards = Array.isArray(source.cards) ? source.cards.map(normalizeCard).filter(Boolean) : [];
    render();
  }

  function normalizeCard(card) {
    if (!card || typeof card !== "object") {
      return null;
    }

    return {
      title: String(card.title || ""),
      subtitle: String(card.subtitle || ""),
      note: String(card.note || ""),
      body: String(card.body || ""),
      foot: String(card.foot || ""),
      imageUrl: String(card.image_url || ""),
      targetUrl: String(card.target_url || ""),
      tone: String(card.tone || "default")
    };
  }

  function applyMockState() {
    applyState({
      title: "支持与反馈",
      subtitle: "从这里获得支持 或者 支持作者",
      cards: [
        {
          title: "赞助入口",
          subtitle: " ",
          note: "使用支付宝 [扫一扫]",
          body: "感觉用的人不多\n不过随便了",
          foot: "我恰饭",
          image_url: "./assets/support/QRcode%201.jpg",
          tone: "sponsor"
        },
        {
          title: "RecSAI反馈群",
          subtitle: "群号：825116351",
          note: "扫一扫二维码 加入QQ群聊",
          body: "☆☆☆☆☆☆\nBug出率提高50%↑↑↑",
          foot: "我码字",
          image_url: "./assets/support/QRcode%202.jpg",
          tone: "feedback"
        },
        {
          title: "开发不易，欢迎支持",
          subtitle: "五年开发 三年摸鱼",
          note: " ",
          body: "我的频道：\nhttps://space.bilibili.com/10543701",
          foot: "BB空间 什么都发 谨慎关注",
          image_url: "./assets/support/bg_1.jpg",
          target_url: "https://space.bilibili.com/10543701",
          tone: "channel"
        }
      ]
    });
    setStatus("使用本地调试数据", false);
  }

  function render() {
    if (els.titleText) {
      els.titleText.textContent = state.title || "支持与反馈";
    }
    if (els.subtitleText) {
      els.subtitleText.textContent = state.subtitle;
    }
    renderCards();
    queuePageScrollFadeUpdate();
  }

  function renderCards() {
    if (!els.supportCards) {
      return;
    }

    els.supportCards.replaceChildren();
    state.cards.forEach((card) => {
      els.supportCards.appendChild(createSupportCard(card));
    });
  }

  function resolveAssetUrl(url) {
    const raw = String(url || "").trim();
    if (!raw) {
      return "";
    }

    try {
      return new URL(raw, window.location.href).href;
    } catch {
      return raw;
    }
  }

  function createSupportCard(card) {
    const article = document.createElement("article");
    article.className = `support-card is-${card.tone}`;
    if (card.targetUrl) {
      article.classList.add("has-target");
      article.tabIndex = 0;
      article.addEventListener("click", () => openTarget(card.targetUrl));
      article.addEventListener("keydown", (event) => {
        if (event.key === "Enter" || event.key === " ") {
          event.preventDefault();
          openTarget(card.targetUrl);
        }
      });
    }

    const media = document.createElement("div");
    media.className = "support-card-media";
    const imageUrl = resolveAssetUrl(card.imageUrl);
    if (imageUrl && card.tone === "channel") {
      article.style.setProperty("--support-card-image", `url("${imageUrl.replace(/"/g, "%22")}")`);
    }
    if (imageUrl) {
      const img = document.createElement("img");
      img.src = imageUrl;
      img.alt = "";
      img.loading = "lazy";
      media.appendChild(img);
    }

    const copy = document.createElement("div");
    copy.className = "support-card-copy";
    const header = document.createElement("div");
    header.className = "support-card-header";
    const title = document.createElement("h2");
    title.textContent = card.title;
    const subtitle = document.createElement("p");
    subtitle.textContent = card.subtitle.trim() || " ";
    header.append(title, subtitle);

    const note = document.createElement("p");
    note.className = "support-card-note";
    note.textContent = card.note.trim() || " ";

    const body = document.createElement("div");
    body.className = "support-card-body";
    String(card.body || "").split(/\r?\n/).forEach((line) => {
      const p = document.createElement("p");
      p.textContent = line || " ";
      body.appendChild(p);
    });

    const foot = document.createElement("p");
    foot.className = "support-card-foot";
    foot.textContent = card.foot;

    copy.append(header, media, note, body, foot);
    article.append(copy);
    return article;
  }

  function openTarget(targetUrl) {
    if (!targetUrl) {
      return;
    }

    if (!postHostCommand("help-support-open-target", { target: targetUrl })) {
      window.open(targetUrl, "_blank", "noopener");
    }
    setStatus("已请求打开链接", false);
  }

  function updatePageScrollFade() {
    pageScrollFadeRaf = 0;
    if (!els.pageScrollRoot) {
      return;
    }

    const scrollTop = Math.max(0, els.pageScrollRoot.scrollTop || 0);
    const maxScrollTop = Math.max(0, (els.pageScrollRoot.scrollHeight || 0) - (els.pageScrollRoot.clientHeight || 0));
    const hasTopFade = scrollTop > pageScrollFadeThresholdPx;
    const hasBottomFade = maxScrollTop - scrollTop > pageScrollFadeThresholdPx;

    let nextClass = "scroll-fade-none";
    if (hasTopFade && hasBottomFade) {
      nextClass = "scroll-fade-both";
    } else if (hasTopFade) {
      nextClass = "scroll-fade-top";
    } else if (hasBottomFade) {
      nextClass = "scroll-fade-bottom";
    }

    els.pageScrollRoot.classList.remove("scroll-fade-none", "scroll-fade-top", "scroll-fade-bottom", "scroll-fade-both");
    els.pageScrollRoot.classList.add(nextClass);
  }

  function queuePageScrollFadeUpdate() {
    if (pageScrollFadeRaf) {
      return;
    }
    pageScrollFadeRaf = window.requestAnimationFrame(updatePageScrollFade);
  }

  function bindDragSurface(el) {
    if (!el) {
      return;
    }

    el.addEventListener("pointerdown", (event) => {
      if (event.button !== 0 || !event.isPrimary) {
        return;
      }

      const interactiveTarget = event.target instanceof Element
        ? event.target.closest("button, input, select, textarea, a, label, summary, [role='button'], [data-host-drag-ignore='true']")
        : null;
      if (interactiveTarget || !hasHostBridge()) {
        return;
      }

      event.preventDefault();
      postHostMessage(buildHostDragMoveMessage(event));
    });
  }

  function bindEvents() {
    bindEmbeddedContextReturn();
    bindDragSurface(els.supportHeader);
    if (els.pageScrollRoot) {
      els.pageScrollRoot.addEventListener("scroll", queuePageScrollFadeUpdate, { passive: true });
    }
    window.addEventListener("resize", queuePageScrollFadeUpdate);

    if (els.closeWindowButton) {
      els.closeWindowButton.addEventListener("click", () => {
        if (!returnEmbeddedPageToDashboard()) {
          postHostMessage(hostCloseWindowMessage);
        }
      });
    }
    if (els.refreshButton) {
      els.refreshButton.addEventListener("click", requestStateSync);
    }

    window.addEventListener("keydown", (event) => {
      if (event.key === "Escape") {
        if (!returnEmbeddedPageToDashboard()) {
          postHostMessage(hostCloseWindowMessage);
        }
      }
    });
  }

  function bindHostBridge() {
    if (isEmbedded && window.parent && window.parent !== window) {
      const isTrustedParentMessage = (event) => {
        if (window.location.protocol === "file:") {
          return true;
        }
        return event.origin === window.location.origin;
      };

      window.addEventListener("message", (event) => {
        if (!isTrustedParentMessage(event)) {
          return;
        }
        handleHostBridgeMessage(event.data);
      });
      return;
    }

    const bridge = getHostBridge();
    if (!bridge || typeof bridge.addEventListener !== "function") {
      return;
    }

    bridge.addEventListener("message", (event) => {
      handleHostBridgeMessage(event.data);
    });
  }

  function handleHostBridgeMessage(data) {
    if (typeof data === "string") {
      if (data === hostWindowShownMessage) {
        requestStateSync();
      }
      return;
    }

    if (!data || typeof data !== "object") {
      return;
    }

    if (data.kind === "help-support-state") {
      applyState(data.state);
      setStatus("已同步", false);
      return;
    }

    if (data.kind === "webui-ack" && typeof data.message === "string" && data.message.trim()) {
      setStatus(data.message.trim(), data.ok === false, data.ok === false);
    }
  }

  function init() {
    if (isEmbedded) {
      document.documentElement.classList.add("is-embedded");
    }
    bindEvents();
    bindHostBridge();
    render();
    requestStateSync();
  }

  init();
})();
