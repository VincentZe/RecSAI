﻿(() => {
  const pageLoaderConfig = {
    defaultRoute: "dashboard",
    routePrefix: "#/",
    partialBasePath: "./partials/",
    moduleBasePath: "./pages/",
    pages: {
      dashboard: {
        title: "Dashboard",
        staticElementId: "dashboardPage"
      }
    }
  };

  const loaderState = {
    currentRoute: "",
    currentModule: null,
    currentContext: null,
    outlet: null,
    staticPages: new Map()
  };

  function normalizeRoute(value) {
    let route = typeof value === "string" ? value.trim() : "";
    if (route.indexOf("?") >= 0) {
      route = route.slice(0, route.indexOf("?"));
    }
    if (route.indexOf("#") >= 0) {
      route = route.slice(0, route.indexOf("#"));
    }
    route = route.replace(/^\/+/, "").replace(/\/+$/, "");
    return route || pageLoaderConfig.defaultRoute;
  }

  function getRouteFromLocation() {
    const hash = window.location.hash || "";
    if (!hash || hash === "#") {
      return pageLoaderConfig.defaultRoute;
    }

    if (hash.startsWith(pageLoaderConfig.routePrefix)) {
      return normalizeRoute(hash.slice(pageLoaderConfig.routePrefix.length));
    }

    return normalizeRoute(hash.slice(1));
  }

  function getPageSpec(route) {
    const normalizedRoute = normalizeRoute(route);
    return pageLoaderConfig.pages[normalizedRoute] || null;
  }

  function createPageContext(route, spec, root) {
    return {
      route,
      spec,
      root,
      state: window.ReadSAI2WebUi && window.ReadSAI2WebUi.state,
      runtime: window.ReadSAI2WebUi && window.ReadSAI2WebUi.runtime,
      host: window.ReadSAI2WebUi && window.ReadSAI2WebUi.host,
      ui: window.ReadSAI2WebUi && window.ReadSAI2WebUi.ui,
      render: window.ReadSAI2WebUi && window.ReadSAI2WebUi.render,
      addLog: window.ReadSAI2WebUi && window.ReadSAI2WebUi.addLog
    };
  }

  function setStaticPageVisible(element, visible) {
    if (!element) {
      return;
    }
    element.hidden = !visible;
  }

  function hideStaticPages() {
    loaderState.staticPages.forEach((element) => {
      setStaticPageVisible(element, false);
    });
  }

  function clearDynamicOutlet() {
    if (!loaderState.outlet) {
      return;
    }
    loaderState.outlet.replaceChildren();
    loaderState.outlet.hidden = true;
  }

  async function unmountCurrentPage() {
    const previousModule = loaderState.currentModule;
    const previousContext = loaderState.currentContext;
    loaderState.currentModule = null;
    loaderState.currentContext = null;

    if (previousModule && typeof previousModule.unmount === "function") {
      await previousModule.unmount(previousContext);
    }
  }

  async function loadPartialIntoOutlet(spec) {
    if (!loaderState.outlet) {
      throw new Error("Dynamic page outlet is unavailable.");
    }

    if (!spec.partial) {
      loaderState.outlet.replaceChildren();
      return;
    }

    const response = await fetch(pageLoaderConfig.partialBasePath + spec.partial, {
      cache: "no-store"
    });
    if (!response.ok) {
      throw new Error(`Failed to load page partial: ${response.status}`);
    }

    const html = await response.text();
    loaderState.outlet.innerHTML = html;
  }

  async function loadPageModule(spec) {
    if (!spec.module) {
      return null;
    }
    return import(pageLoaderConfig.moduleBasePath + spec.module);
  }

  function showFallbackError(route, error) {
    if (!loaderState.outlet) {
      return;
    }

    loaderState.outlet.hidden = false;
    loaderState.outlet.replaceChildren();

    const card = document.createElement("section");
    card.className = "card dynamic-page-error";

    const title = document.createElement("h2");
    title.textContent = "Page failed to load";

    const detail = document.createElement("p");
    detail.textContent = `${route}: ${error && error.message ? error.message : "Unknown error"}`;

    card.append(title, detail);
    loaderState.outlet.appendChild(card);
  }

  async function mountRoute(route) {
    const normalizedRoute = normalizeRoute(route);
    const spec = getPageSpec(normalizedRoute) || getPageSpec(pageLoaderConfig.defaultRoute);
    if (!spec) {
      return false;
    }

    await unmountCurrentPage();
    loaderState.currentRoute = normalizedRoute;

    if (spec.staticElementId) {
      clearDynamicOutlet();
      hideStaticPages();
      const staticPage = loaderState.staticPages.get(spec.staticElementId);
      setStaticPageVisible(staticPage, true);
      loaderState.currentContext = createPageContext(normalizedRoute, spec, staticPage);
      if (typeof spec.mount === "function") {
        await spec.mount(loaderState.currentContext);
      }
      return true;
    }

    hideStaticPages();
    if (loaderState.outlet) {
      loaderState.outlet.hidden = false;
    }

    try {
      await loadPartialIntoOutlet(spec);
      const pageModule = await loadPageModule(spec);
      const context = createPageContext(normalizedRoute, spec, loaderState.outlet);
      loaderState.currentModule = pageModule;
      loaderState.currentContext = context;
      if (pageModule && typeof pageModule.mount === "function") {
        await pageModule.mount(context);
      }
      if (context.ui && typeof context.ui.refreshSurface === "function") {
        context.ui.refreshSurface(loaderState.outlet);
      }
      return true;
    } catch (error) {
      showFallbackError(normalizedRoute, error);
      return false;
    }
  }

  function registerPage(route, spec) {
    const normalizedRoute = normalizeRoute(route);
    pageLoaderConfig.pages[normalizedRoute] = {
      ...(spec || {})
    };
  }

  async function navigate(route, options = {}) {
    const normalizedRoute = normalizeRoute(route);
    const nextHash = pageLoaderConfig.routePrefix + normalizedRoute;
    if (!options.replaceHash && window.location.hash !== nextHash) {
      window.location.hash = nextHash;
      return true;
    }
    return mountRoute(normalizedRoute);
  }

  function initPageLoader() {
    loaderState.outlet = document.querySelector("[data-dynamic-page-outlet]");
    document.querySelectorAll("[data-route-page]").forEach((element) => {
      if (element.id) {
        loaderState.staticPages.set(element.id, element);
      }
    });

    window.addEventListener("hashchange", () => {
      void mountRoute(getRouteFromLocation());
    });

    return mountRoute(getRouteFromLocation());
  }

  window.ReadSAI2PageLoader = {
    config: pageLoaderConfig,
    init: initPageLoader,
    navigate,
    registerPage,
    mountRoute
  };
})();
