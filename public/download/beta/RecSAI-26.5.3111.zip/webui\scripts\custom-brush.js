﻿(function () {
  const hostWindowShownMessage = "host:window-shown";
  const hostDragMoveMessage = "host:drag-move";
  const hostCloseWindowMessage = "host:close-window";
  const pageScrollFadeThresholdPx = 3;
  const isEmbedded = new URLSearchParams(window.location.search).get("embedded") === "1";

  const defaultBrushId = "default";
  const defaultStatusText = "准备就绪";

  const state = {
    version: 1,
    activeBrushId: defaultBrushId,
    selectedBrushId: defaultBrushId,
    brushes: [],
    dirty: false,
    statusText: defaultStatusText,
    statusIsError: false
  };

  const els = {
    brushApp: document.getElementById("brushApp"),
    brushHeader: document.getElementById("brushHeader"),
    pageScrollRoot: document.getElementById("pageScrollRoot"),
    activeBrushText: document.getElementById("activeBrushText"),
    statusText: document.getElementById("statusText"),
    closeWindowButton: document.getElementById("closeWindowButton"),
    importBrushButton: document.getElementById("importBrushButton"),
    importBrushInlineButton: document.getElementById("importBrushInlineButton"),
    brushFileInput: document.getElementById("brushFileInput"),
    saveBrushButton: document.getElementById("saveBrushButton"),
    saveBrushInlineButton: document.getElementById("saveBrushInlineButton"),
    brushListPanel: document.getElementById("brushListPanel"),
    brushEditorPanel: document.getElementById("brushEditorPanel"),
    brushList: document.getElementById("brushList"),
    editorTitle: document.getElementById("editorTitle"),
    activateBrushButton: document.getElementById("activateBrushButton"),
    fileNameText: document.getElementById("fileNameText"),
    formatText: document.getElementById("formatText"),
    sizeText: document.getElementById("sizeText"),
    offsetText: document.getElementById("offsetText"),
    scaleInput: document.getElementById("scaleInput"),
    rotationInput: document.getElementById("rotationInput"),
    previewShell: document.getElementById("previewShell"),
    previewImage: document.getElementById("brushPreviewImage"),
    previewBounds: document.getElementById("brushPreviewBounds"),
    previewAnchor: document.getElementById("brushPreviewAnchor"),
    previewDefaultPointer: document.getElementById("brushDefaultPointer"),
    helpText: document.getElementById("helpText"),
    inlineStatusText: document.getElementById("inlineStatusText")
  };

  let statusTimerId = 0;
  let autoSaveTimerId = 0;
  let autoSaveInFlight = false;
  let autoSavePending = false;
  let lastSaveWasAuto = false;
  let changeSerial = 0;
  let inFlightSaveSerial = 0;
  let pendingDeleteBrushId = "";
  let pageScrollFadeRaf = 0;
  let previewRaf = 0;
  let previewResizeObserver = null;
  let previewInteraction = null;
  let hasAppliedInitialSelection = false;
  let pendingSelectImportedBrush = false;

  function getEmbeddedTargetOrigin() {
    return window.location.protocol === "file:" ? "*" : window.location.origin;
  }

  function hasEmbeddedParentHostBridge() {
    if (!isEmbedded || !window.parent || window.parent === window) {
      return false;
    }

    try {
      const parentHost = window.parent.ReadSAI2WebUi && window.parent.ReadSAI2WebUi.host;
      return !!(parentHost && typeof parentHost.hasBridge === "function" && parentHost.hasBridge());
    } catch {
      return false;
    }
  }

  function getHostBridge() {
    if (hasEmbeddedParentHostBridge()) {
      return {
        postMessage(message) {
          window.parent.postMessage({
            kind: "readsai2-embedded-host-message",
            message
          }, getEmbeddedTargetOrigin());
        }
      };
    }

    const bridge = window.chrome && window.chrome.webview;
    if (!bridge || typeof bridge.postMessage !== "function") {
      return null;
    }
    return bridge;
  }

  function hasHostBridge() {
    return !!getHostBridge();
  }

  function postHostMessage(message) {
    const bridge = getHostBridge();
    if (!bridge) {
      return false;
    }
    bridge.postMessage(message);
    return true;
  }

  function buildHostDragMoveMessage(event) {
    return JSON.stringify({
      kind: hostDragMoveMessage,
      screenX: event.screenX,
      screenY: event.screenY,
      clientX: event.clientX,
      clientY: event.clientY
    });
  }

  function postHostCommand(command, payload) {
    if (hasEmbeddedParentHostBridge()) {
      window.parent.postMessage({
        kind: "readsai2-embedded-host-command",
        command,
        payload: payload && typeof payload === "object" ? payload : {}
      }, getEmbeddedTargetOrigin());
      return true;
    }

    const bridge = getHostBridge();
    if (!bridge) {
      return false;
    }
    bridge.postMessage(JSON.stringify({
      kind: "webui-command",
      command,
      payload: payload && typeof payload === "object" ? payload : {}
    }));
    return true;
  }

  function returnEmbeddedPageToDashboard() {
    if (!isEmbedded || !window.parent || window.parent === window) {
      return false;
    }

    window.parent.postMessage({
      kind: "readsai2-embedded-return-dashboard"
    }, getEmbeddedTargetOrigin());
    return true;
  }

  function bindEmbeddedContextReturn() {
    if (!isEmbedded) {
      return;
    }

    let rightPointerStart = null;
    const isReturnBlockedTarget = (target) => target instanceof Element
      && !!target.closest("button, input, select, textarea, a, label, summary, [role='button'], [data-host-drag-ignore='true']");

    window.addEventListener("pointerdown", (event) => {
      if (event.button !== 2) {
        rightPointerStart = null;
        return;
      }

      rightPointerStart = {
        time: performance.now(),
        blocked: isReturnBlockedTarget(event.target)
      };
    }, { capture: true });

    window.addEventListener("contextmenu", (event) => {
      const pointerStart = rightPointerStart;
      rightPointerStart = null;
      if (event.defaultPrevented) {
        return;
      }

      event.preventDefault();
      const hasFreshPointerStart = pointerStart && performance.now() - pointerStart.time < 2500;
      const shouldBlockReturn = hasFreshPointerStart
        ? pointerStart.blocked
        : isReturnBlockedTarget(event.target);
      if (shouldBlockReturn) {
        return;
      }

      returnEmbeddedPageToDashboard();
    });
  }

  function clamp(value, min, max) {
    return Math.max(min, Math.min(max, value));
  }

  function toNumber(value, fallback) {
    const numeric = Number(value);
    return Number.isFinite(numeric) ? numeric : fallback;
  }

  function escapeHtml(text) {
    return String(text == null ? "" : text)
      .replace(/&/g, "&amp;")
      .replace(/</g, "&lt;")
      .replace(/>/g, "&gt;")
      .replace(/"/g, "&quot;")
      .replace(/'/g, "&#39;");
  }

  function normalizeScale(value) {
    return Math.trunc(clamp(toNumber(value, 100), 10, 400));
  }

  function normalizeRotation(value) {
    let rotation = Math.trunc(toNumber(value, 0)) % 360;
    if (rotation < 0) {
      rotation += 360;
    }
    return rotation;
  }

  function normalizeBrush(item) {
    if (!item || typeof item !== "object") {
      return null;
    }

    const isDefault = !!item.is_default || item.id === defaultBrushId;
    const id = isDefault ? defaultBrushId : String(item.id || "").trim();
    if (!id) {
      return null;
    }

    return {
      id,
      displayName: String(item.display_name || (isDefault ? "系统默认指针" : id)).trim(),
      assetRelPath: String(item.asset_rel_path || "").trim(),
      assetUrl: String(item.asset_url || "").trim(),
      format: String(item.format || (isDefault ? "default" : "")).trim().toLowerCase(),
      scalePercent: normalizeScale(item.scale_percent),
      rotationDeg: normalizeRotation(item.rotation_deg),
      offsetX: Math.trunc(toNumber(item.offset_x, 0)),
      offsetY: Math.trunc(toNumber(item.offset_y, 0)),
      width: Math.max(0, Math.trunc(toNumber(item.width, 0))),
      height: Math.max(0, Math.trunc(toNumber(item.height, 0))),
      isDefault,
      isActive: !!item.is_active,
      isAnimated: !!item.is_animated,
      previewDataUrl: String(item.preview_data_url || "")
    };
  }

  function getDefaultBrush() {
    return {
      id: defaultBrushId,
      displayName: "系统默认指针",
      assetRelPath: "",
      assetUrl: "",
      format: "default",
      scalePercent: 100,
      rotationDeg: 0,
      offsetX: 0,
      offsetY: 0,
      width: 0,
      height: 0,
      isDefault: true,
      isActive: state.activeBrushId === defaultBrushId,
      isAnimated: false,
      previewDataUrl: ""
    };
  }

  function ensureDefaultBrush(brushes) {
    const next = Array.isArray(brushes) ? brushes.filter(Boolean) : [];
    const hasDefault = next.some((brush) => brush.id === defaultBrushId);
    if (!hasDefault) {
      next.unshift(getDefaultBrush());
    }
    return next;
  }

  function getBrushById(brushId) {
    return state.brushes.find((item) => item.id === brushId) || null;
  }

  function getSelectedBrush() {
    return getBrushById(state.selectedBrushId) || getBrushById(defaultBrushId);
  }

  function getActiveBrush() {
    return getBrushById(state.activeBrushId) || getBrushById(defaultBrushId);
  }

  function selectBrush(brushId) {
    if (!getBrushById(brushId)) {
      return;
    }
    hasAppliedInitialSelection = true;
    state.selectedBrushId = brushId;
    render();
  }

  function clearAutoSaveTimer() {
    if (autoSaveTimerId) {
      window.clearTimeout(autoSaveTimerId);
      autoSaveTimerId = 0;
    }
  }

  function scheduleAutoSave(delayMs = 700) {
    clearAutoSaveTimer();
    if (!state.dirty) {
      return;
    }

    autoSaveTimerId = window.setTimeout(() => {
      autoSaveTimerId = 0;
      saveBrushSettings({ auto: true });
    }, Math.max(0, delayMs));
  }

  function markDirty(message) {
    changeSerial += 1;
    state.dirty = true;
    setStatus(message || "有未保存修改，稍后自动保存", false, true);
    renderHeader();
    scheduleAutoSave();
  }

  function setStatus(text, isError, sticky) {
    state.statusText = typeof text === "string" && text.trim() ? text.trim() : defaultStatusText;
    state.statusIsError = !!isError;
    if (els.statusText) {
      els.statusText.textContent = state.statusText;
      els.statusText.style.color = state.statusIsError ? "var(--danger)" : "var(--muted)";
    }
    if (els.inlineStatusText) {
      els.inlineStatusText.textContent = state.statusText;
      els.inlineStatusText.classList.toggle("is-error", state.statusIsError);
      els.inlineStatusText.classList.toggle("is-saving", autoSaveInFlight && !state.statusIsError);
    }

    if (statusTimerId) {
      window.clearTimeout(statusTimerId);
      statusTimerId = 0;
    }

    if (!sticky && !state.statusIsError && state.statusText !== defaultStatusText) {
      statusTimerId = window.setTimeout(() => {
        statusTimerId = 0;
        setStatus(defaultStatusText, false, false);
      }, 1800);
    }
  }

  function applyState(payload) {
    const normalizedBrushes = Array.isArray(payload && payload.brushes)
      ? payload.brushes.map(normalizeBrush).filter(Boolean)
      : [];
    state.version = Math.max(1, Math.trunc(toNumber(payload && payload.version, 1)));
    state.activeBrushId = String(payload && payload.active_brush_id ? payload.active_brush_id : defaultBrushId).trim() || defaultBrushId;
    state.brushes = ensureDefaultBrush(normalizedBrushes).map((brush) => ({
      ...brush,
      isActive: brush.id === state.activeBrushId
    }));

    if (pendingSelectImportedBrush) {
      state.selectedBrushId = getBrushById(state.activeBrushId) ? state.activeBrushId : defaultBrushId;
      hasAppliedInitialSelection = true;
      pendingSelectImportedBrush = false;
    } else if (!hasAppliedInitialSelection) {
      state.selectedBrushId = getBrushById(state.activeBrushId) ? state.activeBrushId : defaultBrushId;
      hasAppliedInitialSelection = true;
    } else if (!getBrushById(state.selectedBrushId)) {
      state.selectedBrushId = getBrushById(state.activeBrushId) ? state.activeBrushId : defaultBrushId;
    }

    state.dirty = false;
    clearAutoSaveTimer();
    render();
    queuePreviewDraw();
  }

  function applyMockState() {
    applyState({
      version: 1,
      active_brush_id: defaultBrushId,
      brushes: [
        { id: defaultBrushId, display_name: "系统默认指针", format: "default", is_default: true, is_active: true },
        {
          id: "debug-soft-dot",
          display_name: "调试圆点.png",
          format: "png",
          scale_percent: 100,
          rotation_deg: 0,
          offset_x: 0,
          offset_y: 0,
          width: 96,
          height: 96,
          is_default: false,
          is_active: false,
          asset_url: "",
          preview_data_url: ""
        }
      ]
    });
    setStatus("使用本地调试数据", false);
  }

  function requestStateSync() {
    if (postHostCommand("custom-brush-sync")) {
      setStatus("正在同步画笔…", false, true);
      return;
    }

    applyMockState();
  }

  function buildSavePayload() {
    return {
      version: state.version,
      active_brush_id: state.activeBrushId || defaultBrushId,
      brushes: state.brushes
        .filter((brush) => !brush.isDefault)
        .map((brush) => ({
          id: brush.id,
          display_name: brush.displayName,
          scale_percent: normalizeScale(brush.scalePercent),
          rotation_deg: normalizeRotation(brush.rotationDeg),
          offset_x: Math.trunc(toNumber(brush.offsetX, 0)),
          offset_y: Math.trunc(toNumber(brush.offsetY, 0))
        }))
    };
  }

  function saveBrushSettings(options = {}) {
    const isAutoSave = !!(options && options.auto);
    clearAutoSaveTimer();
    if (!state.dirty && !isAutoSave) {
      setStatus("没有需要保存的修改", false);
      return;
    }
    if (!state.dirty && isAutoSave) {
      return;
    }
    if (autoSaveInFlight) {
      autoSavePending = true;
      return;
    }

    lastSaveWasAuto = isAutoSave;
    autoSaveInFlight = true;
    inFlightSaveSerial = changeSerial;
    renderHeader();
    if (!postHostCommand("custom-brush-save", buildSavePayload())) {
      autoSaveInFlight = false;
      autoSavePending = false;
      lastSaveWasAuto = false;
      inFlightSaveSerial = 0;
      state.dirty = false;
      setStatus("浏览器调试模式已应用本地修改", false);
      render();
      return;
    }

    setStatus(isAutoSave ? "正在自动保存画笔…" : "正在保存画笔…", false, true);
  }

  function importBrush() {
    if (!hasHostBridge()) {
      setStatus("导入图片仅在桌面宿主中可用", true, true);
      return;
    }

    if (!els.brushFileInput) {
      setStatus("文件选择控件不可用", true, true);
      return;
    }

    els.brushFileInput.value = "";
    els.brushFileInput.click();
  }

  function importBrushFile(file) {
    if (!file) {
      setStatus(defaultStatusText, false, false);
      return;
    }

    const name = String(file.name || "");
    const lowerName = name.toLowerCase();
    if (!/\.(png|jpe?g|gif)$/.test(lowerName)) {
      setStatus("仅支持 png、jpg、jpeg 和 gif 图片", true, true);
      return;
    }

    const reader = new FileReader();
    reader.onload = () => {
      const result = String(reader.result || "");
      const commaIndex = result.indexOf(",");
      const dataBase64 = commaIndex >= 0 ? result.slice(commaIndex + 1) : result;
      if (!dataBase64.trim()) {
        setStatus("图片数据为空", true, true);
        return;
      }

      if (!postHostCommand("custom-brush-import", {
        display_name: name,
        data_base64: dataBase64
      })) {
        setStatus("导入图片仅在桌面宿主中可用", true, true);
        return;
      }

      pendingSelectImportedBrush = true;
      setStatus("正在导入图片…", false, true);
    };
    reader.onerror = () => {
      setStatus("读取图片失败", true, true);
    };
    reader.readAsDataURL(file);
  }

  function requestBrushDelete(brushId) {
    const brush = getBrushById(brushId);
    if (!brush || brush.isDefault) {
      return;
    }

    pendingDeleteBrushId = brush.id;
    renderList();
  }

  function cancelBrushDelete(brushId) {
    if (!brushId || pendingDeleteBrushId === brushId) {
      pendingDeleteBrushId = "";
      renderList();
    }
  }

  function confirmBrushDelete(brushId) {
    const brush = getBrushById(brushId);
    if (!brush || brush.isDefault) {
      pendingDeleteBrushId = "";
      renderList();
      return;
    }

    pendingDeleteBrushId = "";
    if (!postHostCommand("custom-brush-delete", { brush_id: brush.id })) {
      state.brushes = state.brushes.filter((item) => item.id !== brush.id);
      if (state.activeBrushId === brush.id) {
        state.activeBrushId = defaultBrushId;
      }
      state.selectedBrushId = state.activeBrushId;
      markDirty("已从本地列表移除，稍后自动保存");
      render();
      return;
    }

    setStatus("正在删除画笔…", false, true);
    renderList();
  }

  function activateSelectedBrush() {
    const brush = getSelectedBrush();
    if (!brush) {
      return;
    }

    state.activeBrushId = brush.id;
    state.brushes = state.brushes.map((item) => ({
      ...item,
      isActive: item.id === brush.id
    }));
    markDirty("当前画笔已更改，稍后自动保存");
    render();
  }

  function updateSelectedBrushFromInputs() {
    const brush = getSelectedBrush();
    if (!brush || brush.isDefault) {
      return;
    }

    brush.scalePercent = normalizeScale(els.scaleInput ? els.scaleInput.value : brush.scalePercent);
    brush.rotationDeg = normalizeRotation(els.rotationInput ? els.rotationInput.value : brush.rotationDeg);
    markDirty("参数已修改，稍后自动保存");
    renderList();
    renderEditor(false);
    queuePreviewDraw();
  }

  function renderHeader() {
    const active = getActiveBrush();
    if (els.activeBrushText) {
      const suffix = state.dirty ? "（自动保存中）" : "";
      els.activeBrushText.textContent = active ? `当前画笔 ${active.displayName}${suffix}` : `当前画笔 -${suffix}`;
    }
    [els.saveBrushButton, els.saveBrushInlineButton].filter(Boolean).forEach((button) => {
      button.disabled = !state.dirty || autoSaveInFlight;
      button.textContent = autoSaveInFlight ? "保存中" : "保存";
    });
  }

  function buildBrushThumbnail(brush) {
    const source = getBrushImageSource(brush, { preferPreview: true });
    if (source) {
      return `<img class="brush-list-thumb" src="${escapeHtml(source)}" alt="">`;
    }
    if (brush.isDefault) {
      return '<span class="brush-default-thumb" aria-hidden="true"></span>';
    }
    return '<span class="brush-default-thumb" aria-hidden="true"></span>';
  }

  function buildIconMarkup(iconName) {
    if (iconName === "check") {
      return '<svg class="brush-list-action-icon" viewBox="0 0 24 24" aria-hidden="true" focusable="false"><path d="M20 6 9 17l-5-5"></path></svg>';
    }
    return '<svg class="brush-list-action-icon" viewBox="0 0 24 24" aria-hidden="true" focusable="false"><path d="M18 6 6 18"></path><path d="m6 6 12 12"></path></svg>';
  }

  function renderList() {
    if (!els.brushList) {
      return;
    }

    els.brushList.innerHTML = "";
    state.brushes.forEach((brush) => {
      const item = document.createElement("div");
      item.className = "brush-list-item";
      item.setAttribute("role", "option");
      item.setAttribute("aria-selected", brush.id === state.selectedBrushId ? "true" : "false");
      if (brush.id === state.selectedBrushId) {
        item.classList.add("is-selected");
      }
      if (brush.id === pendingDeleteBrushId) {
        item.classList.add("is-delete-pending");
      }
      const sizeText = brush.width > 0 && brush.height > 0 ? `${brush.width} x ${brush.height}` : "-";
      item.innerHTML = `
        <button class="brush-list-main" type="button">
          ${buildBrushThumbnail(brush)}
          <span class="brush-list-body">
          <span class="brush-list-title">${escapeHtml(brush.displayName)}</span>
          <span class="brush-list-meta">
            <span class="brush-pill">${escapeHtml(brush.isDefault ? "默认" : brush.format.toUpperCase())}</span>
            ${brush.isActive ? '<span class="brush-pill is-active">当前</span>' : ""}
            ${brush.isAnimated ? '<span class="brush-pill">动图</span>' : ""}
            <span>${escapeHtml(sizeText)}</span>
          </span>
          </span>
        </button>
        <span class="brush-list-delete-slot">
          ${brush.isDefault
            ? ""
            : brush.id === pendingDeleteBrushId
              ? `<span class="brush-list-delete-confirm">
                   <span class="brush-list-delete-confirm-text">确认删除?</span>
                   <button class="brush-list-delete-action is-confirm" type="button" data-delete-confirm="${escapeHtml(brush.id)}" aria-label="确认删除 ${escapeHtml(brush.displayName)}" title="确认删除 ${escapeHtml(brush.displayName)}">${buildIconMarkup("check")}</button>
                   <button class="brush-list-delete-action is-cancel" type="button" data-delete-cancel="${escapeHtml(brush.id)}" aria-label="取消删除 ${escapeHtml(brush.displayName)}" title="取消删除 ${escapeHtml(brush.displayName)}">${buildIconMarkup("x")}</button>
                 </span>`
              : `<button class="brush-list-delete-button" type="button" data-delete-request="${escapeHtml(brush.id)}" aria-label="删除 ${escapeHtml(brush.displayName)}" title="删除 ${escapeHtml(brush.displayName)}">${buildIconMarkup("x")}</button>`}
        </span>
      `;
      const mainButton = item.querySelector(".brush-list-main");
      if (mainButton) {
        mainButton.addEventListener("click", () => {
          if (pendingDeleteBrushId && pendingDeleteBrushId !== brush.id) {
            pendingDeleteBrushId = "";
          }
          selectBrush(brush.id);
        });
      }
      const deleteSlot = item.querySelector(".brush-list-delete-slot");
      if (deleteSlot) {
        ["click", "dblclick"].forEach((eventName) => {
          deleteSlot.addEventListener(eventName, (event) => {
            event.stopPropagation();
          });
        });
      }
      const deleteButton = item.querySelector("[data-delete-request]");
      if (deleteButton) {
        deleteButton.addEventListener("click", (event) => {
          event.stopPropagation();
          requestBrushDelete(brush.id);
        });
        deleteButton.addEventListener("dblclick", (event) => {
          event.stopPropagation();
        });
      }
      const confirmButton = item.querySelector("[data-delete-confirm]");
      if (confirmButton) {
        confirmButton.addEventListener("click", (event) => {
          event.stopPropagation();
          confirmBrushDelete(brush.id);
        });
        confirmButton.addEventListener("dblclick", (event) => {
          event.stopPropagation();
        });
      }
      const cancelButton = item.querySelector("[data-delete-cancel]");
      if (cancelButton) {
        cancelButton.addEventListener("click", (event) => {
          event.stopPropagation();
          cancelBrushDelete(brush.id);
        });
        cancelButton.addEventListener("dblclick", (event) => {
          event.stopPropagation();
        });
      }
      item.addEventListener("dblclick", () => {
        selectBrush(brush.id);
      });
      els.brushList.appendChild(item);
    });
  }

  function renderEditor(syncInputs = true) {
    const brush = getSelectedBrush();
    const hasBrush = !!brush;
    const isDefault = !brush || brush.isDefault;

    if (els.editorTitle) {
      els.editorTitle.textContent = hasBrush ? brush.displayName : "未选择画笔";
    }
    if (els.fileNameText) {
      els.fileNameText.textContent = hasBrush ? brush.displayName : "-";
    }
    if (els.formatText) {
      els.formatText.textContent = hasBrush ? (isDefault ? "默认" : brush.format.toUpperCase()) : "-";
    }
    if (els.sizeText) {
      els.sizeText.textContent = hasBrush && brush.width > 0 && brush.height > 0 ? `${brush.width} x ${brush.height}` : "-";
    }
    if (els.offsetText) {
      els.offsetText.textContent = hasBrush ? `${brush.offsetX}, ${brush.offsetY}` : "-";
    }

    if (els.scaleInput) {
      if (syncInputs && document.activeElement !== els.scaleInput) {
        els.scaleInput.value = hasBrush ? String(brush.scalePercent) : "100";
      }
      els.scaleInput.disabled = isDefault;
    }
    if (els.rotationInput) {
      if (syncInputs && document.activeElement !== els.rotationInput) {
        els.rotationInput.value = hasBrush ? String(brush.rotationDeg) : "0";
      }
      els.rotationInput.disabled = isDefault;
    }
    if (els.activateBrushButton) {
      els.activateBrushButton.disabled = !hasBrush || brush.id === state.activeBrushId;
    }
    if (els.saveBrushInlineButton) {
      els.saveBrushInlineButton.hidden = isDefault;
    }
    if (els.helpText) {
      els.helpText.textContent = isDefault
        ? "系统默认指针不需要编辑。导入 PNG、JPG 或 GIF 后可调整缩放、旋转和偏移。"
        : "拖拽图片移动画笔，拖拽包围盒边角缩放，盒外拖动旋转，双击回到中心；修改会自动保存。";
    }
  }

  function render() {
    renderHeader();
    renderList();
    renderEditor(true);
    queuePreviewDraw();
  }

  function getBrushImageSource(brush, options) {
    if (!brush) {
      return "";
    }

    const preferPreview = !!(options && options.preferPreview);
    const isAnimatedSource = brush.isAnimated || brush.format === "gif";
    if (isAnimatedSource) {
      return brush.assetUrl || brush.previewDataUrl || "";
    }
    if (preferPreview) {
      return brush.previewDataUrl || brush.assetUrl || "";
    }

    return brush.assetUrl || brush.previewDataUrl || "";
  }

  function getBrushGeometry(brush, canvasSize) {
    const width = brush && brush.width > 0 ? brush.width : 96;
    const height = brush && brush.height > 0 ? brush.height : 96;
    const scale = normalizeScale(brush ? brush.scalePercent : 100) / 100;
    return {
      centerX: canvasSize.width / 2 + (brush ? brush.offsetX : 0),
      centerY: canvasSize.height / 2 + (brush ? brush.offsetY : 0),
      width: Math.max(1, width * scale),
      height: Math.max(1, height * scale),
      rotation: normalizeRotation(brush ? brush.rotationDeg : 0)
    };
  }

  function drawPreview() {
    previewRaf = 0;
    if (!els.previewShell) {
      return;
    }

    const canvasSize = getPreviewSurfaceSize();
    const brush = getSelectedBrush();
    const centerX = canvasSize.width / 2;
    const centerY = canvasSize.height / 2;
    if (!brush || brush.isDefault) {
      showDefaultPreviewPointer(centerX, centerY, Math.max(10, Math.min(canvasSize.width, canvasSize.height) / 22));
      return;
    }

    const geometry = getBrushGeometry(brush, canvasSize);
    const source = getBrushImageSource(brush);
    if (!source) {
      showDefaultPreviewPointer(geometry.centerX, geometry.centerY, Math.max(10, Math.min(geometry.width, geometry.height) / 3.6));
      return;
    }

    hideDefaultPreviewPointer();
    updatePreviewImage(source, geometry);
    updatePreviewBounds(geometry);
    updatePreviewAnchor(centerX, centerY);
  }

  function queuePreviewDraw() {
    if (previewRaf) {
      return;
    }
    previewRaf = window.requestAnimationFrame(drawPreview);
  }

  function getPreviewLocalPoint(event) {
    const rect = els.previewShell.getBoundingClientRect();
    return {
      x: event.clientX - rect.left,
      y: event.clientY - rect.top,
      width: rect.width,
      height: rect.height
    };
  }

  function getPreviewSurfaceSize() {
    const rect = els.previewShell
      ? els.previewShell.getBoundingClientRect()
      : { width: 1, height: 1 };
    return {
      width: Math.max(1, rect.width),
      height: Math.max(1, rect.height)
    };
  }

  function updatePreviewImage(source, geometry) {
    if (!els.previewImage) {
      return;
    }

    if (els.previewImage.getAttribute("src") !== source) {
      els.previewImage.src = source;
    }
    els.previewImage.hidden = false;
    els.previewImage.style.left = `${geometry.centerX}px`;
    els.previewImage.style.top = `${geometry.centerY}px`;
    els.previewImage.style.width = `${geometry.width}px`;
    els.previewImage.style.height = `${geometry.height}px`;
    els.previewImage.style.transform = `translate(-50%, -50%) rotate(${geometry.rotation}deg)`;
  }

  function updatePreviewBounds(geometry) {
    if (!els.previewBounds) {
      return;
    }

    els.previewBounds.hidden = false;
    els.previewBounds.style.left = `${geometry.centerX}px`;
    els.previewBounds.style.top = `${geometry.centerY}px`;
    els.previewBounds.style.width = `${geometry.width}px`;
    els.previewBounds.style.height = `${geometry.height}px`;
    els.previewBounds.style.transform = `translate(-50%, -50%) rotate(${geometry.rotation}deg)`;
  }

  function updatePreviewAnchor(x, y) {
    if (!els.previewAnchor) {
      return;
    }

    els.previewAnchor.hidden = false;
    els.previewAnchor.style.left = `${x}px`;
    els.previewAnchor.style.top = `${y}px`;
  }

  function clearPreviewImageState() {
    if (els.previewImage) {
      els.previewImage.hidden = true;
      els.previewImage.removeAttribute("src");
      els.previewImage.style.left = "";
      els.previewImage.style.top = "";
      els.previewImage.style.width = "";
      els.previewImage.style.height = "";
      els.previewImage.style.transform = "";
    }
    if (els.previewBounds) {
      els.previewBounds.hidden = true;
      els.previewBounds.style.left = "";
      els.previewBounds.style.top = "";
      els.previewBounds.style.width = "";
      els.previewBounds.style.height = "";
      els.previewBounds.style.transform = "";
    }
  }

  function showDefaultPreviewPointer(x, y, radius) {
    clearPreviewImageState();
    updatePreviewAnchor(x, y);
    if (!els.previewDefaultPointer) {
      return;
    }

    els.previewDefaultPointer.hidden = false;
    els.previewDefaultPointer.style.left = `${x}px`;
    els.previewDefaultPointer.style.top = `${y}px`;
    els.previewDefaultPointer.style.setProperty("--pointer-radius", `${radius}px`);
  }

  function hideDefaultPreviewPointer() {
    if (els.previewDefaultPointer) {
      els.previewDefaultPointer.hidden = true;
    }
  }

  function getBrushBoundsPoints(geometry) {
    const halfWidth = geometry.width / 2;
    const halfHeight = geometry.height / 2;
    const radians = geometry.rotation * Math.PI / 180;
    const cos = Math.cos(radians);
    const sin = Math.sin(radians);
    return [
      [-halfWidth, -halfHeight],
      [halfWidth, -halfHeight],
      [halfWidth, halfHeight],
      [-halfWidth, halfHeight]
    ].map(([x, y]) => ({
      x: geometry.centerX + x * cos - y * sin,
      y: geometry.centerY + x * sin + y * cos
    }));
  }

  function getBrushLocalPoint(point, geometry) {
    const dx = point.x - geometry.centerX;
    const dy = point.y - geometry.centerY;
    const radians = -geometry.rotation * Math.PI / 180;
    return {
      x: dx * Math.cos(radians) - dy * Math.sin(radians),
      y: dx * Math.sin(radians) + dy * Math.cos(radians)
    };
  }

  function getPreviewInteractionMode(point, brush) {
    if (!brush || brush.isDefault) {
      return { mode: "idle", cursor: "default" };
    }

    const geometry = getBrushGeometry(brush, point);
    const local = getBrushLocalPoint(point, geometry);
    const halfWidth = geometry.width / 2;
    const halfHeight = geometry.height / 2;
    const handleSize = 10;
    const edgeSize = 9;
    const rotatePadding = 34;
    const insideX = Math.abs(local.x) <= halfWidth;
    const insideY = Math.abs(local.y) <= halfHeight;
    const nearX = Math.abs(local.x) <= halfWidth + edgeSize;
    const nearY = Math.abs(local.y) <= halfHeight + edgeSize;
    const nearVerticalEdge = Math.abs(Math.abs(local.x) - halfWidth) <= edgeSize && insideY;
    const nearHorizontalEdge = Math.abs(Math.abs(local.y) - halfHeight) <= edgeSize && insideX;
    const nearCorner = nearX && nearY
      && Math.abs(Math.abs(local.x) - halfWidth) <= handleSize
      && Math.abs(Math.abs(local.y) - halfHeight) <= handleSize;
    const nearEdge = nearX && nearY && (nearVerticalEdge || nearHorizontalEdge);

    if (nearCorner || nearEdge) {
      let cursor = "ew-resize";
      if (nearCorner) {
        cursor = local.x * local.y > 0 ? "nwse-resize" : "nesw-resize";
      } else if (nearHorizontalEdge) {
        cursor = "ns-resize";
      }
      return {
        mode: "scale",
        cursor,
        startDistance: Math.max(1, Math.hypot(local.x, local.y)),
        startScale: normalizeScale(brush.scalePercent)
      };
    }

    if (insideX && insideY) {
      return { mode: "drag", cursor: "grab" };
    }

    if (Math.abs(local.x) <= halfWidth + rotatePadding && Math.abs(local.y) <= halfHeight + rotatePadding) {
      return { mode: "rotate", cursor: "crosshair" };
    }

    return { mode: "idle", cursor: "default" };
  }

  function isPointInsideBrush(point, brush) {
    if (!brush || brush.isDefault) {
      return false;
    }

    const geometry = getBrushGeometry(brush, point);
    const local = getBrushLocalPoint(point, geometry);
    return Math.abs(local.x) <= geometry.width / 2 && Math.abs(local.y) <= geometry.height / 2;
  }

  function angleDegrees(centerX, centerY, pointX, pointY) {
    return Math.atan2(pointY - centerY, pointX - centerX) * 180 / Math.PI;
  }

  function normalizeAngleDelta(angle) {
    let value = angle;
    while (value <= -180) {
      value += 360;
    }
    while (value > 180) {
      value -= 360;
    }
    return value;
  }

  function updatePageScrollFade() {
    pageScrollFadeRaf = 0;
    if (!els.pageScrollRoot) {
      return;
    }

    const scrollTop = Math.max(0, els.pageScrollRoot.scrollTop || 0);
    const maxScrollTop = Math.max(0, (els.pageScrollRoot.scrollHeight || 0) - (els.pageScrollRoot.clientHeight || 0));
    const hasTopFade = scrollTop > pageScrollFadeThresholdPx;
    const hasBottomFade = maxScrollTop - scrollTop > pageScrollFadeThresholdPx;

    let nextClass = "scroll-fade-none";
    if (hasTopFade && hasBottomFade) {
      nextClass = "scroll-fade-both";
    } else if (hasTopFade) {
      nextClass = "scroll-fade-top";
    } else if (hasBottomFade) {
      nextClass = "scroll-fade-bottom";
    }

    els.pageScrollRoot.classList.remove("scroll-fade-none", "scroll-fade-top", "scroll-fade-bottom", "scroll-fade-both");
    els.pageScrollRoot.classList.add(nextClass);
  }

  function queuePageScrollFadeUpdate() {
    if (pageScrollFadeRaf) {
      return;
    }
    pageScrollFadeRaf = window.requestAnimationFrame(updatePageScrollFade);
  }

  function bindPageScrollFade() {
    if (!els.pageScrollRoot) {
      return;
    }
    els.pageScrollRoot.addEventListener("scroll", queuePageScrollFadeUpdate, { passive: true });
    window.addEventListener("resize", queuePageScrollFadeUpdate);
    queuePageScrollFadeUpdate();
  }

  function bindDragSurface(el) {
    if (!el) {
      return;
    }

    el.addEventListener("pointerdown", (event) => {
      if (event.button !== 0 || !event.isPrimary) {
        return;
      }

      const interactiveTarget = event.target instanceof Element
        ? event.target.closest("button, input, select, textarea, a, label, summary, [role='button'], [data-host-drag-ignore='true']")
        : null;
      if (interactiveTarget || !hasHostBridge()) {
        return;
      }

      event.preventDefault();
      postHostMessage(buildHostDragMoveMessage(event));
    });
  }

  function bindPreviewInteraction() {
    if (!els.previewShell) {
      return;
    }

    const syncHoverCursor = (event) => {
      if (previewInteraction) {
        return;
      }

      const brush = getSelectedBrush();
      if (!brush || brush.isDefault) {
        els.previewShell.classList.remove("is-scale-ready", "is-drag-ready", "is-rotate-ready");
        els.previewShell.style.cursor = "";
        return;
      }

      const point = getPreviewLocalPoint(event);
      const interaction = getPreviewInteractionMode(point, brush);
      els.previewShell.classList.toggle("is-scale-ready", interaction.mode === "scale");
      els.previewShell.classList.toggle("is-drag-ready", interaction.mode === "drag");
      els.previewShell.classList.toggle("is-rotate-ready", interaction.mode === "rotate");
      els.previewShell.style.cursor = interaction.cursor;
    };

    els.previewShell.addEventListener("pointermove", syncHoverCursor);
    els.previewShell.addEventListener("pointerleave", () => {
      if (!previewInteraction) {
        els.previewShell.classList.remove("is-scale-ready", "is-drag-ready", "is-rotate-ready");
        els.previewShell.style.cursor = "";
      }
    });

    els.previewShell.addEventListener("dblclick", () => {
      const brush = getSelectedBrush();
      if (!brush || brush.isDefault) {
        return;
      }
      brush.offsetX = 0;
      brush.offsetY = 0;
      markDirty("偏移已复位，稍后自动保存");
      renderEditor(false);
      queuePreviewDraw();
    });

    els.previewShell.addEventListener("pointerdown", (event) => {
      if (event.button !== 0 || !event.isPrimary) {
        return;
      }

      const brush = getSelectedBrush();
      if (!brush || brush.isDefault) {
        return;
      }

      event.preventDefault();
      const point = getPreviewLocalPoint(event);
      const geometry = getBrushGeometry(brush, point);
      const interactionMode = getPreviewInteractionMode(point, brush);
      if (interactionMode.mode === "idle") {
        return;
      }

      previewInteraction = {
        pointerId: event.pointerId,
        mode: interactionMode.mode,
        startX: point.x,
        startY: point.y,
        startOffsetX: brush.offsetX,
        startOffsetY: brush.offsetY,
        startScale: interactionMode.startScale || normalizeScale(brush.scalePercent),
        startDistance: interactionMode.startDistance || 1,
        startRotation: brush.rotationDeg,
        startAngle: angleDegrees(geometry.centerX, geometry.centerY, point.x, point.y)
      };
      els.previewShell.classList.toggle("is-dragging", previewInteraction.mode === "drag");
      els.previewShell.classList.toggle("is-scaling", previewInteraction.mode === "scale");
      els.previewShell.classList.toggle("is-rotating", previewInteraction.mode === "rotate");
      els.previewShell.style.cursor = interactionMode.cursor;
      try {
        els.previewShell.setPointerCapture(event.pointerId);
      } catch {
      }
    });

    els.previewShell.addEventListener("pointermove", (event) => {
      if (!previewInteraction || previewInteraction.pointerId !== event.pointerId) {
        return;
      }

      const brush = getSelectedBrush();
      if (!brush || brush.isDefault) {
        return;
      }

      const point = getPreviewLocalPoint(event);
      if (previewInteraction.mode === "drag") {
        brush.offsetX = Math.round(previewInteraction.startOffsetX + point.x - previewInteraction.startX);
        brush.offsetY = Math.round(previewInteraction.startOffsetY + point.y - previewInteraction.startY);
      } else if (previewInteraction.mode === "scale") {
        const geometry = getBrushGeometry({
          ...brush,
          scalePercent: previewInteraction.startScale,
          offsetX: previewInteraction.startOffsetX,
          offsetY: previewInteraction.startOffsetY
        }, point);
        const local = getBrushLocalPoint(point, geometry);
        const distance = Math.max(1, Math.hypot(local.x, local.y));
        brush.scalePercent = normalizeScale(Math.round(previewInteraction.startScale * (distance / previewInteraction.startDistance)));
        if (els.scaleInput) {
          els.scaleInput.value = String(brush.scalePercent);
        }
      } else {
        const geometry = getBrushGeometry(brush, point);
        const currentAngle = angleDegrees(geometry.centerX, geometry.centerY, point.x, point.y);
        brush.rotationDeg = normalizeRotation(previewInteraction.startRotation + Math.round(normalizeAngleDelta(currentAngle - previewInteraction.startAngle)));
        if (els.rotationInput) {
          els.rotationInput.value = String(brush.rotationDeg);
        }
      }

      const message = previewInteraction.mode === "drag"
        ? "偏移已修改，稍后自动保存"
        : previewInteraction.mode === "scale"
          ? "缩放已修改，稍后自动保存"
          : "旋转已修改，稍后自动保存";
      markDirty(message);
      renderEditor(false);
      queuePreviewDraw();
    });

    const stopInteraction = (event) => {
      if (!previewInteraction || previewInteraction.pointerId !== event.pointerId) {
        return;
      }

      previewInteraction = null;
      if (state.dirty) {
        scheduleAutoSave(280);
      }
      els.previewShell.classList.remove("is-dragging", "is-scaling", "is-rotating");
      els.previewShell.style.cursor = "";
      try {
        els.previewShell.releasePointerCapture(event.pointerId);
      } catch {
      }
    };

    els.previewShell.addEventListener("pointerup", stopInteraction);
    els.previewShell.addEventListener("pointercancel", stopInteraction);
  }

  function bindEvents() {
    bindEmbeddedContextReturn();
    bindDragSurface(els.brushHeader);
    bindDragSurface(els.brushListPanel);
    bindDragSurface(els.brushEditorPanel);

    if (els.closeWindowButton) {
      els.closeWindowButton.addEventListener("click", () => {
        postHostMessage(hostCloseWindowMessage);
      });
    }

    [els.importBrushButton, els.importBrushInlineButton].filter(Boolean).forEach((button) => {
      button.addEventListener("click", importBrush);
    });
    if (els.brushFileInput) {
      els.brushFileInput.addEventListener("change", () => {
        const file = els.brushFileInput.files && els.brushFileInput.files.length > 0
          ? els.brushFileInput.files[0]
          : null;
        importBrushFile(file);
      });
    }

    [els.saveBrushButton, els.saveBrushInlineButton].filter(Boolean).forEach((button) => {
      button.addEventListener("click", () => {
        saveBrushSettings({ auto: false });
      });
    });
    if (els.activateBrushButton) {
      els.activateBrushButton.addEventListener("click", activateSelectedBrush);
    }
    [els.scaleInput, els.rotationInput].filter(Boolean).forEach((input) => {
      input.addEventListener("change", updateSelectedBrushFromInputs);
      input.addEventListener("keydown", (event) => {
        if (event.key === "Enter") {
          event.preventDefault();
          input.blur();
        }
      });
    });

    window.addEventListener("keydown", (event) => {
      if (event.key === "Escape" && !isEmbedded) {
        postHostMessage(hostCloseWindowMessage);
      }
    });

    window.addEventListener("resize", queuePreviewDraw);
    if ("ResizeObserver" in window && els.previewShell) {
      previewResizeObserver = new ResizeObserver(queuePreviewDraw);
      previewResizeObserver.observe(els.previewShell);
    }
    bindPreviewInteraction();
  }

  function bindHostBridge() {
    if (isEmbedded && window.parent && window.parent !== window) {
      const isTrustedParentMessage = (event) => {
        if (window.location.protocol === "file:") {
          return true;
        }
        return event.origin === window.location.origin;
      };

      window.addEventListener("message", (event) => {
        if (!isTrustedParentMessage(event)) {
          return;
        }

        handleHostBridgeMessage(event.data);
      });
      return;
    }

    const bridge = getHostBridge();
    if (!bridge || typeof bridge.addEventListener !== "function") {
      return;
    }

    bridge.addEventListener("message", (event) => {
      handleHostBridgeMessage(event.data);
    });
  }

  function handleHostBridgeMessage(data) {
    if (typeof data === "string") {
      if (data === hostWindowShownMessage) {
        requestStateSync();
      }
      return;
    }

    if (!data || typeof data !== "object") {
      return;
    }

    if (data.kind === "custom-brush-state") {
      if (state.dirty && !autoSaveInFlight) {
        setStatus("本地修改待自动保存", false, true);
        scheduleAutoSave(180);
        return;
      }

      const wasSaving = autoSaveInFlight || state.dirty;
      const isStaleSaveState = autoSaveInFlight && changeSerial !== inFlightSaveSerial;
      autoSaveInFlight = false;
      if (!isStaleSaveState) {
        clearAutoSaveTimer();
        applyState(data.state);
      } else {
        renderHeader();
        renderList();
        renderEditor(false);
        queuePreviewDraw();
      }
      setStatus(
        isStaleSaveState
          ? "仍有修改待自动保存"
          : (wasSaving ? (lastSaveWasAuto ? "已自动保存" : "已保存") : "已同步"),
        false,
        isStaleSaveState);
      lastSaveWasAuto = false;
      inFlightSaveSerial = 0;
      if ((autoSavePending || isStaleSaveState) && state.dirty) {
        autoSavePending = false;
        scheduleAutoSave(180);
      } else {
        autoSavePending = false;
      }
      return;
    }

    if (data.kind === "webui-ack" && typeof data.message === "string" && data.message.trim()) {
      if (data.command === "custom-brush-save") {
        autoSaveInFlight = false;
        if (data.ok === false) {
          lastSaveWasAuto = false;
          inFlightSaveSerial = 0;
          if (autoSavePending || state.dirty) {
            autoSavePending = false;
            scheduleAutoSave(1200);
          }
        } else {
          lastSaveWasAuto = false;
          inFlightSaveSerial = 0;
          if (autoSavePending && state.dirty) {
            autoSavePending = false;
            scheduleAutoSave(180);
          } else {
            autoSavePending = false;
          }
          renderHeader();
          return;
        }
      }
      setStatus(data.message.trim(), data.ok === false, data.ok === false);
    }
  }

  function init() {
    if (isEmbedded) {
      document.documentElement.classList.add("is-embedded");
    }
    bindEvents();
    bindHostBridge();
    bindPageScrollFade();
    render();
    requestStateSync();
  }

  init();
})();
