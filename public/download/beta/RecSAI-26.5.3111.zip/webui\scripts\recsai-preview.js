﻿(function () {
  "use strict";

  const state = {
    session: null,
    currentIndex: 0,
    playing: false,
    playTimer: 0,
    imageToken: 0,
    pendingPlayRequest: false,
    currentPath: "",
    layout: null,
    skippedSegmentPaths: new Set(),
    seekRenderTimer: 0,
    seekRenderIndex: -1,
    seekRenderInFlight: false,
    lastActiveSegmentIndex: -1,
    segmentMarkerSeekTimer: 0,
    segmentWheelFrame: 0,
    segmentWheelTarget: null,
    segmentWheelLastAt: 0,
    segmentWheelBurst: 0,
    segmentWheelVelocity: 0,
    segmentWheelResetTimer: 0,
    segmentMomentumFrame: 0,
    segmentMomentumVelocity: 0,
    segmentMomentumLastAt: 0,
    quickExportResetTimer: 0,
    quickExportActive: false,
    quickExportCancelPending: false,
    exportDetailText: "",
    exportDiagnosticEnabled: false
  };

  const els = {
    titlebar: document.getElementById("previewTitlebar"),
    filePathLabel: document.getElementById("filePathLabel"),
    openFileButton: document.getElementById("openFileButton"),
    titleQuickExportButton: document.getElementById("titleQuickExportButton"),
    closeWindowButton: document.getElementById("closeWindowButton"),
    frameCanvas: document.getElementById("frameCanvas"),
    emptyState: document.getElementById("emptyState"),
    loadingState: document.getElementById("loadingState"),
    loadingTitle: document.getElementById("loadingTitle"),
    loadingDetail: document.getElementById("loadingDetail"),
    previewStage: document.getElementById("previewStage"),
    segmentStripShell: document.getElementById("segmentStripShell"),
    segmentStrip: document.getElementById("segmentStrip"),
    segmentList: document.getElementById("segmentList"),
    prevButton: document.getElementById("prevButton"),
    playButton: document.getElementById("playButton"),
    nextButton: document.getElementById("nextButton"),
    frameSlider: document.getElementById("frameSlider"),
    fpsSelect: document.getElementById("fpsSelect"),
    pointerToggle: document.getElementById("pointerToggle"),
    frameCounter: document.getElementById("frameCounter"),
    imageSizeText: document.getElementById("imageSizeText"),
    canvasSizeText: document.getElementById("canvasSizeText"),
    pointerText: document.getElementById("pointerText"),
    codecText: document.getElementById("codecText"),
    sourceText: document.getElementById("sourceText"),
    timeText: document.getElementById("timeText"),
    outputNameInput: document.getElementById("outputNameInput"),
    exportFpsInput: document.getElementById("exportFpsInput"),
    exportSpeedInput: document.getElementById("exportSpeedInput"),
    exportDiagnosticToggle: document.getElementById("exportDiagnosticToggle"),
    quickExportShell: document.getElementById("quickExportShell"),
    quickExportButton: document.getElementById("quickExportButton"),
    quickExportCancelSurface: document.querySelector(".quick-export-cancel-surface"),
    quickExportCancelButton: document.getElementById("quickExportCancelButton"),
    quickExportCancelConfirmButton: document.getElementById("quickExportCancelConfirmButton"),
    quickExportCancelDismissButton: document.getElementById("quickExportCancelDismissButton"),
    statusLine: document.getElementById("statusLine"),
    statusDetailButton: document.getElementById("statusDetailButton"),
    exportDetailPopover: document.getElementById("exportDetailPopover"),
    exportDetailText: document.getElementById("exportDetailText"),
    exportDetailCloseButton: document.getElementById("exportDetailCloseButton"),
    windowResizeBottomLeftButton: document.getElementById("windowResizeBottomLeftButton"),
    windowResizeBottomRightButton: document.getElementById("windowResizeBottomRightButton")
  };

  const ctx = els.frameCanvas.getContext("2d");
  const hostBridge = window.chrome && window.chrome.webview ? window.chrome.webview : null;
  const previewFrameScale = 0.5;

  function getQuickExportButtons() {
    return [els.quickExportButton, els.titleQuickExportButton].filter(Boolean);
  }

  function setStatus(text, tone = "") {
    els.statusLine.textContent = text || "";
    els.statusLine.classList.toggle("is-error", tone === "error");
  }

  function setExportDiagnosticEnabled(enabled) {
    state.exportDiagnosticEnabled = !!enabled;
    if (els.exportDiagnosticToggle) {
      els.exportDiagnosticToggle.checked = state.exportDiagnosticEnabled;
    }
  }

  function setExportDetail(text) {
    state.exportDetailText = typeof text === "string" ? text.trim() : "";
    if (els.statusDetailButton) {
      els.statusDetailButton.hidden = !state.exportDetailText;
    }
    if (els.exportDetailText) {
      els.exportDetailText.textContent = state.exportDetailText;
    }
    if (!state.exportDetailText) {
      closeExportDetail();
    }
  }

  function openExportDetail() {
    if (!els.exportDetailPopover || !state.exportDetailText) {
      return;
    }
    if (els.exportDetailText) {
      els.exportDetailText.textContent = state.exportDetailText;
    }
    els.exportDetailPopover.hidden = false;
  }

  function closeExportDetail() {
    if (els.exportDetailPopover) {
      els.exportDetailPopover.hidden = true;
    }
  }

  function isErrorStatusAck(data) {
    if (!data || data.ok !== false) {
      return false;
    }

    const message = typeof data.message === "string" ? data.message : "";
    if (message.indexOf("已取消封装") >= 0 || message.indexOf("封装已取消") >= 0) {
      return false;
    }
    return true;
  }

  function getAckProgress(data) {
    if (!data || typeof data !== "object") {
      return null;
    }

    const numericProgress = Number(data.progress);
    if (Number.isFinite(numericProgress)) {
      return clamp(numericProgress, 0, 1);
    }

    const processed = Number(data.processed);
    const total = Number(data.total);
    if (Number.isFinite(processed) && Number.isFinite(total) && total > 0) {
      return clamp(processed / total, 0, 1);
    }
    return null;
  }

  function setQuickExportProgress(progress, active) {
    const quickExportButtons = getQuickExportButtons();
    if (quickExportButtons.length === 0) {
      return;
    }

    const safeProgress = clamp(Number.isFinite(Number(progress)) ? Number(progress) : 0, 0, 1);
    state.quickExportActive = !!active;
    if (!state.quickExportActive) {
      state.quickExportCancelPending = false;
    }

    quickExportButtons.forEach((button) => {
      button.style.setProperty("--quick-export-progress", safeProgress.toFixed(4));
      button.style.setProperty("--quick-export-progress-percent", `${(safeProgress * 100).toFixed(1)}%`);
      button.classList.toggle("is-quick-exporting", !!active);
      button.setAttribute("aria-busy", active ? "true" : "false");
    });
    if (els.quickExportCancelButton) {
      els.quickExportCancelButton.disabled = !state.quickExportActive;
    }
    if (els.quickExportCancelConfirmButton) {
      els.quickExportCancelConfirmButton.disabled = !(state.quickExportActive && state.quickExportCancelPending);
    }
    if (els.quickExportCancelDismissButton) {
      els.quickExportCancelDismissButton.disabled = !(state.quickExportActive && state.quickExportCancelPending);
    }
    if (els.quickExportShell) {
      els.quickExportShell.classList.toggle("is-quick-exporting", state.quickExportActive);
      els.quickExportShell.classList.toggle("is-cancel-pending", state.quickExportActive && state.quickExportCancelPending);
    }
  }

  function setQuickExportCancelPending(pending) {
    state.quickExportCancelPending = state.quickExportActive && !!pending;
    if (els.quickExportCancelConfirmButton) {
      els.quickExportCancelConfirmButton.disabled = !state.quickExportCancelPending;
    }
    if (els.quickExportCancelDismissButton) {
      els.quickExportCancelDismissButton.disabled = !state.quickExportCancelPending;
    }
    if (els.quickExportShell) {
      els.quickExportShell.classList.toggle("is-cancel-pending", state.quickExportCancelPending);
    }
  }

  function handleQuickExportAck(data) {
    if (!data || (data.command !== "quick-export" && data.command !== "quick-export-cancel")) {
      return false;
    }

    if (data.command === "quick-export-cancel") {
      if (data.ok === true) {
        setQuickExportCancelPending(false);
      } else {
        setQuickExportProgress(0, false);
      }
      return true;
    }

    if (state.quickExportResetTimer) {
      window.clearTimeout(state.quickExportResetTimer);
      state.quickExportResetTimer = 0;
    }

    const progress = getAckProgress(data);
    const phase = typeof data.phase === "string" ? data.phase : "";
    const isTerminal = phase === "complete" || phase === "error" || data.ok === false;
    if (isTerminal) {
      setExportDetail(data.detail_message || "");
    } else if (phase === "start" || phase === "checking") {
      setExportDetail("");
    }
    if (progress !== null) {
      setQuickExportProgress(progress, !isTerminal);
    } else if (!isTerminal) {
      setQuickExportProgress(0, true);
    }

    if (isTerminal) {
      setQuickExportProgress(data.ok === false ? 0 : 1, false);
      state.quickExportResetTimer = window.setTimeout(() => {
        state.quickExportResetTimer = 0;
        setQuickExportProgress(0, false);
      }, 1200);
    }
    return true;
  }

  function setLoading(active, title = "正在加载", detail = "读取 .recsai 文件", dragReady = false) {
    if (els.loadingState) {
      els.loadingState.hidden = !active;
    }
    if (els.loadingTitle) {
      els.loadingTitle.textContent = title;
    }
    if (els.loadingDetail) {
      els.loadingDetail.textContent = detail || "";
    }
    if (els.previewStage) {
      els.previewStage.classList.toggle("is-drag-ready", !!dragReady);
    }
  }

  function postHostMessage(message, fallback) {
    if (hostBridge && typeof hostBridge.postMessage === "function") {
      hostBridge.postMessage(message);
      return true;
    }
    if (fallback) {
      setStatus(fallback);
    }
    return false;
  }

  function buildHostDragMoveMessage(event) {
    return JSON.stringify({
      kind: "host:drag-move",
      screenX: event.screenX,
      screenY: event.screenY,
      clientX: event.clientX,
      clientY: event.clientY
    });
  }

  function postHostCommand(command, payload, fallback) {
    if (hostBridge && typeof hostBridge.postMessage === "function") {
      hostBridge.postMessage(JSON.stringify({
        kind: "webui-command",
        command,
        payload: payload || null
      }));
      return true;
    }
    if (fallback) {
      setStatus(fallback);
    }
    return false;
  }

  function bindHostDrag(el) {
    if (!el) {
      return;
    }

    el.addEventListener("pointerdown", (event) => {
      if (event.button !== 0 || !event.isPrimary) {
        return;
      }

      const interactive = event.target instanceof Element
        ? event.target.closest("button, input, select, textarea, a, label, [role='button'], [data-host-drag-ignore='true']")
        : null;
      if (interactive) {
        return;
      }

      if (postHostMessage(buildHostDragMoveMessage(event))) {
        event.preventDefault();
      }
    });
  }

  function bindResizeGrip(el, message) {
    if (!el) {
      return;
    }

    el.addEventListener("pointerdown", (event) => {
      if (event.button !== 0 || !event.isPrimary) {
        return;
      }
      event.preventDefault();
      postHostMessage(message, "窗口缩放只能在桌面 WebView 中使用。");
    });
  }

  function bindDragScroll(el, axis, onDragFinish) {
    if (!el) {
      return;
    }

    let active = false;
    let dragging = false;
    let pointerId = 0;
    let startX = 0;
    let startY = 0;
    let startScrollLeft = 0;
    let startScrollTop = 0;
    let lastMoveAt = 0;
    let lastMoveX = 0;
    let lastMoveY = 0;
    let velocity = 0;
    let moved = false;
    let captured = false;

    el.addEventListener("pointerdown", (event) => {
      if (event.button !== 0 || !event.isPrimary) {
        return;
      }

      active = true;
      dragging = false;
      moved = false;
      captured = false;
      pointerId = event.pointerId;
      startX = event.clientX;
      startY = event.clientY;
      lastMoveAt = performance.now();
      lastMoveX = event.clientX;
      lastMoveY = event.clientY;
      velocity = 0;
      startScrollLeft = el.scrollLeft;
      startScrollTop = el.scrollTop;
      if (el === els.segmentStrip) {
        stopSegmentWheelScroll();
        stopSegmentMomentum();
      }
    });

    el.addEventListener("pointermove", (event) => {
      if (!active || event.pointerId !== pointerId) {
        return;
      }

      let dx = event.clientX - startX;
      let dy = event.clientY - startY;
      if (!dragging && (Math.abs(dx) > 6 || Math.abs(dy) > 6)) {
        dragging = true;
        moved = true;
        el.classList.add("is-dragging");
        try {
          el.setPointerCapture(pointerId);
          captured = true;
        } catch {
          captured = false;
        }
      }
      if (!dragging) {
        return;
      }
      if (axis === "x") {
        el.scrollLeft = startScrollLeft - dx;
      } else {
        el.scrollTop = startScrollTop - dy;
      }
      const now = performance.now();
      const elapsed = Math.max(8, now - lastMoveAt);
      const travel = axis === "x" ? event.clientX - lastMoveX : event.clientY - lastMoveY;
      velocity = (travel / elapsed) * -1;
      lastMoveAt = now;
      lastMoveX = event.clientX;
      lastMoveY = event.clientY;
      event.preventDefault();
    });

    const finish = (event) => {
      if (!active || event.pointerId !== pointerId) {
        return;
      }

      active = false;
      el.classList.remove("is-dragging");
      if (captured) {
        try {
          el.releasePointerCapture(pointerId);
        } catch {
          // capture is optional
        }
        captured = false;
      }
      if (moved) {
        el.dataset.suppressClick = "true";
        window.setTimeout(() => {
          delete el.dataset.suppressClick;
        }, 0);
        if (el === els.segmentStrip) {
          const momentumStarted = startSegmentMomentum(velocity);
          if (!momentumStarted && typeof onDragFinish === "function") {
            onDragFinish(el);
          }
        } else if (typeof onDragFinish === "function") {
          onDragFinish(el);
        }
      }
    };

    el.addEventListener("pointerup", finish);
    el.addEventListener("pointercancel", finish);
    el.addEventListener("click", (event) => {
      if (el.dataset.suppressClick === "true") {
        event.preventDefault();
        event.stopPropagation();
      }
    }, true);
  }

  async function readJsonResponse(response) {
    let payload = null;
    try {
      payload = await response.json();
    } catch {
      payload = null;
    }

    if (!response.ok || !payload || payload.ok !== true) {
      const message = payload && payload.error && payload.error.message
        ? payload.error.message
        : `HTTP ${response.status}`;
      throw new Error(message);
    }

    return payload.data || {};
  }

  function applyOpenedSession(data, fallbackPath) {
    state.session = data;
    state.currentPath = data.path || fallbackPath;
    state.currentIndex = clamp(data.initial_index || 0, 0, Math.max(0, (data.frame_count || 1) - 1));
    state.skippedSegmentPaths.clear();
    state.lastActiveSegmentIndex = -1;
    els.outputNameInput.value = makeOutputName(state.currentPath, data.folder);
    renderSession();
  }

  async function showOpenedInitialFrame(data) {
    const frameShown = await showFrame(state.currentIndex);
    if (frameShown !== false) {
      setStatus(`已打开 ${data.frame_count || 0} 帧。`);
    }
  }

  async function openRecording(path) {
    if (!path || !path.trim()) {
      setStatus("未选择文件。");
      return;
    }

    const normalizedPath = path.trim();
    if (state.currentPath && state.currentPath === normalizedPath && state.session) {
      return;
    }

    stopPlayback();
    setLoading(true, "正在加载", normalizedPath);
    setStatus("正在读取索引...");
    try {
      const response = await fetch("/api/recsai-preview/open", {
        method: "POST",
        headers: { "Content-Type": "application/json; charset=utf-8" },
        body: JSON.stringify({ path: normalizedPath })
      });
      const data = await readJsonResponse(response);
      applyOpenedSession(data, normalizedPath);
      await showOpenedInitialFrame(data);
    } finally {
      setLoading(false);
    }
  }

  async function openDroppedFile(file) {
    if (!file) {
      setStatus("未选择文件。");
      return;
    }
    if (!/\.recsai$/i.test(file.name || "")) {
      setStatus("请拖入 .recsai 录制文件。");
      return;
    }

    stopPlayback();
    setLoading(true, "正在加载", file.name || "拖入的 .recsai 文件");
    setStatus("正在读取拖入文件...");
    try {
      const response = await fetch(`/api/recsai-preview/upload?name=${encodeURIComponent(file.name || "dropped.recsai")}`, {
        method: "POST",
        headers: { "Content-Type": "application/octet-stream" },
        body: file
      });
      const data = await readJsonResponse(response);
      applyOpenedSession(data, file.name || "");
      await showOpenedInitialFrame(data);
    } finally {
      setLoading(false);
    }
  }

  function renderSession() {
    const session = state.session;
    const frameCount = session && session.frame_count ? session.frame_count : 0;
    els.filePathLabel.textContent = state.currentPath || "未打开文件";
    els.emptyState.hidden = frameCount > 0;
    els.frameSlider.max = String(Math.max(0, frameCount - 1));
    els.frameSlider.value = String(clamp(state.currentIndex, 0, Math.max(0, frameCount - 1)));
    setTransportEnabled(frameCount > 0);
    renderSegments({ autoScroll: true, smooth: false });
    updateFrameInfo();
  }

  function renderSegments(options = {}) {
    const session = state.session;
    const segments = session && Array.isArray(session.segments) ? session.segments : [];
    const activeSegmentIndex = getCurrentFrame() ? getCurrentFrame().segment_index : -1;
    const shouldAutoScroll = !!options.autoScroll
      && activeSegmentIndex >= 0
      && (!!options.forceAutoScroll || activeSegmentIndex !== state.lastActiveSegmentIndex);
    let activeTab = null;
    let activeRow = null;
    els.segmentStrip.textContent = "";
    els.segmentStrip.appendChild(createSegmentStripSpacer());
    els.segmentList.textContent = "";

    segments.forEach((segment) => {
      const segmentPath = segment.path || "";
      const isSkipped = segmentPath && state.skippedSegmentPaths.has(segmentPath);
      const tab = document.createElement("button");
      tab.type = "button";
      tab.dataset.segmentIndex = String(segment.index);
      tab.dataset.segmentStart = String(segment.start_index || 0);
      tab.className = [
        "segment-tab",
        segment.index === activeSegmentIndex ? "is-active" : "",
        isSkipped ? "is-skipped" : ""
      ].filter(Boolean).join(" ");
      tab.textContent = segment.name || `Segment ${segment.index + 1}`;
      tab.title = isSkipped ? "已跳过，点击恢复" : "点击跳过该分段";
      tab.addEventListener("click", () => {
        toggleSegmentSkipped(segment);
      });
      els.segmentStrip.appendChild(tab);
      if (segment.index === activeSegmentIndex) {
        activeTab = tab;
      }

      const row = document.createElement("button");
      row.type = "button";
      row.dataset.segmentIndex = String(segment.index);
      row.dataset.segmentStart = String(segment.start_index || 0);
      row.className = [
        "segment-row",
        segment.index === activeSegmentIndex ? "is-active" : "",
        isSkipped ? "is-skipped" : ""
      ].filter(Boolean).join(" ");
      const name = document.createElement("strong");
      name.textContent = segment.name || `Segment ${segment.index + 1}`;
      const count = document.createElement("span");
      count.textContent = isSkipped ? "跳过" : `${segment.frame_count || 0} 帧`;
      row.appendChild(name);
      row.appendChild(count);
      row.title = isSkipped ? "已跳过，点击恢复" : "点击跳过该分段";
      row.addEventListener("click", () => {
        toggleSegmentSkipped(segment);
      });
      els.segmentList.appendChild(row);
      if (segment.index === activeSegmentIndex) {
        activeRow = row;
      }
    });
    els.segmentStrip.appendChild(createSegmentStripSpacer());

    if (shouldAutoScroll) {
      centerChildInContainer(els.segmentStrip, activeTab, "x", options.smooth !== false);
      centerChildInContainer(els.segmentList, activeRow, "y", options.smooth !== false);
    }
    state.lastActiveSegmentIndex = activeSegmentIndex;
  }

  function toggleSegmentSkipped(segment) {
    if (!segment || !segment.path) {
      return;
    }
    if (state.skippedSegmentPaths.has(segment.path)) {
      state.skippedSegmentPaths.delete(segment.path);
    } else {
      state.skippedSegmentPaths.add(segment.path);
    }
    renderSegments();
  }

  function createSegmentStripSpacer() {
    const spacer = document.createElement("span");
    spacer.className = "segment-strip-spacer";
    spacer.setAttribute("aria-hidden", "true");
    return spacer;
  }

  function centerChildInContainer(container, child, axis, smooth) {
    if (!container || !child) {
      return;
    }

    const containerRect = container.getBoundingClientRect();
    const childRect = child.getBoundingClientRect();
    if (axis === "x") {
      const target = container.scrollLeft
        + childRect.left
        - containerRect.left
        - ((containerRect.width - childRect.width) / 2);
      container.scrollTo({ left: Math.max(0, target), behavior: smooth ? "smooth" : "auto" });
      return;
    }

    const target = container.scrollTop
      + childRect.top
      - containerRect.top
      - ((containerRect.height - childRect.height) / 2);
    container.scrollTo({ top: Math.max(0, target), behavior: smooth ? "smooth" : "auto" });
  }

  function getSegmentButtonAtMarker() {
    if (!els.segmentStrip) {
      return null;
    }

    const containerRect = els.segmentStrip.getBoundingClientRect();
    const markerX = containerRect.left + (containerRect.width / 2);
    const buttons = els.segmentStrip.querySelectorAll(".segment-tab");
    let bestButton = null;
    let bestDistance = Number.POSITIVE_INFINITY;
    buttons.forEach((button) => {
      const rect = button.getBoundingClientRect();
      const centerX = rect.left + (rect.width / 2);
      const distance = Math.abs(centerX - markerX);
      if (distance < bestDistance) {
        bestDistance = distance;
        bestButton = button;
      }
    });
    return bestButton;
  }

  function seekSegmentAtMarker() {
    const button = getSegmentButtonAtMarker();
    if (!button) {
      return;
    }

    const startIndex = parseInt(button.dataset.segmentStart || "0", 10);
    if (!Number.isFinite(startIndex)) {
      return;
    }

    stopPlayback();
    requestSeekFrame(startIndex, { forceAutoScroll: true, smooth: true });
  }

  function scheduleSegmentMarkerSeek(delayMs = 90) {
    if (state.segmentMarkerSeekTimer) {
      window.clearTimeout(state.segmentMarkerSeekTimer);
    }
    state.segmentMarkerSeekTimer = window.setTimeout(() => {
      state.segmentMarkerSeekTimer = 0;
      seekSegmentAtMarker();
    }, delayMs);
  }

  function getSegmentMaxScrollLeft() {
    if (!els.segmentStrip) {
      return 0;
    }
    return Math.max(0, els.segmentStrip.scrollWidth - els.segmentStrip.clientWidth);
  }

  function stopSegmentMomentum() {
    if (state.segmentMomentumFrame) {
      window.cancelAnimationFrame(state.segmentMomentumFrame);
      state.segmentMomentumFrame = 0;
    }
    state.segmentMomentumVelocity = 0;
    state.segmentMomentumLastAt = 0;
  }

  function tickSegmentMomentum(now) {
    if (!els.segmentStrip) {
      stopSegmentMomentum();
      return;
    }

    const elapsed = Math.min(32, Math.max(8, now - (state.segmentMomentumLastAt || now)));
    state.segmentMomentumLastAt = now;
    const next = clamp(
      els.segmentStrip.scrollLeft + (state.segmentMomentumVelocity * elapsed),
      0,
      getSegmentMaxScrollLeft()
    );
    const hitEdge = next <= 0 || next >= getSegmentMaxScrollLeft();
    els.segmentStrip.scrollLeft = next;
    state.segmentMomentumVelocity *= Math.pow(0.94, elapsed / 16);
    if (hitEdge || Math.abs(state.segmentMomentumVelocity) < 0.02) {
      stopSegmentMomentum();
      scheduleSegmentMarkerSeek(80);
      return;
    }

    state.segmentMomentumFrame = window.requestAnimationFrame(tickSegmentMomentum);
  }

  function startSegmentMomentum(velocity) {
    stopSegmentMomentum();
    if (!Number.isFinite(velocity) || Math.abs(velocity) < 0.08) {
      return false;
    }

    state.segmentMomentumVelocity = clamp(velocity, -2.4, 2.4);
    state.segmentMomentumLastAt = performance.now();
    state.segmentMomentumFrame = window.requestAnimationFrame(tickSegmentMomentum);
    return true;
  }

  function flushSegmentWheelScroll() {
    if (!els.segmentStrip || state.segmentWheelTarget === null) {
      state.segmentWheelFrame = 0;
      return;
    }

    const current = els.segmentStrip.scrollLeft;
    const next = current + ((state.segmentWheelTarget - current) * 0.28);
    if (Math.abs(state.segmentWheelTarget - next) < 0.5) {
      els.segmentStrip.scrollLeft = state.segmentWheelTarget;
      state.segmentWheelFrame = 0;
      if (!state.segmentWheelResetTimer) {
        state.segmentWheelTarget = null;
        state.segmentWheelBurst = 0;
        state.segmentWheelVelocity = 0;
        els.segmentStrip.classList.remove("is-wheel-scrolling");
        scheduleSegmentMarkerSeek(80);
      }
      return;
    }

    els.segmentStrip.scrollLeft = next;
    state.segmentWheelFrame = window.requestAnimationFrame(flushSegmentWheelScroll);
  }

  function clearSegmentWheelInput() {
    if (state.segmentWheelResetTimer) {
      window.clearTimeout(state.segmentWheelResetTimer);
      state.segmentWheelResetTimer = 0;
    }
  }

  function stopSegmentWheelScroll() {
    clearSegmentWheelInput();
    state.segmentWheelBurst = 0;
    state.segmentWheelVelocity = 0;
    state.segmentWheelTarget = null;
    if (els.segmentStrip) {
      els.segmentStrip.classList.remove("is-wheel-scrolling");
    }
  }

  function queueSegmentWheelScroll(delta) {
    if (!els.segmentStrip || !Number.isFinite(delta) || delta === 0) {
      return;
    }

    stopSegmentMomentum();
    const now = performance.now();
    state.segmentWheelBurst = now - state.segmentWheelLastAt < 140
      ? Math.min(state.segmentWheelBurst + 1, 10)
      : 1;
    state.segmentWheelLastAt = now;

    const boost = 1 + Math.min(1.7, state.segmentWheelBurst * 0.18);
    const base = state.segmentWheelTarget === null ? els.segmentStrip.scrollLeft : state.segmentWheelTarget;
    const boostedDelta = delta * boost;
    state.segmentWheelVelocity = (state.segmentWheelVelocity * 0.45) + (boostedDelta * 0.55);
    state.segmentWheelTarget = clamp(
      base + boostedDelta,
      0,
      getSegmentMaxScrollLeft()
    );
    els.segmentStrip.classList.add("is-wheel-scrolling");
    if (!state.segmentWheelFrame) {
      state.segmentWheelFrame = window.requestAnimationFrame(flushSegmentWheelScroll);
    }

    clearSegmentWheelInput();
    state.segmentWheelResetTimer = window.setTimeout(() => {
      if (Math.abs(state.segmentWheelVelocity) > 0.5 && state.segmentWheelTarget !== null) {
        state.segmentWheelTarget = clamp(
          state.segmentWheelTarget + (state.segmentWheelVelocity * 1.35),
          0,
          getSegmentMaxScrollLeft()
        );
      }
      state.segmentWheelResetTimer = 0;
      state.segmentWheelBurst = 0;
      state.segmentWheelVelocity = 0;
      if (!state.segmentWheelFrame) {
        state.segmentWheelTarget = null;
        els.segmentStrip.classList.remove("is-wheel-scrolling");
        scheduleSegmentMarkerSeek(80);
      }
    }, 180);
    scheduleSegmentMarkerSeek(200);
  }

  function setTransportEnabled(enabled) {
    els.prevButton.disabled = !enabled;
    els.playButton.disabled = !enabled;
    els.nextButton.disabled = !enabled;
    els.frameSlider.disabled = !enabled;
  }

  function applyFrameIndex(index, options = {}) {
    const session = state.session;
    const frameCount = session && Array.isArray(session.frames) ? session.frames.length : 0;
    if (frameCount <= 0) {
      return 0;
    }

    const nextIndex = clamp(index, 0, frameCount - 1);
    state.currentIndex = nextIndex;
    els.frameSlider.value = String(state.currentIndex);
    updateFrameInfo();
    renderSegments({
      autoScroll: options.autoScroll !== false,
      smooth: options.smooth !== false,
      forceAutoScroll: !!options.forceAutoScroll
    });
    return nextIndex;
  }

  async function showFrame(index, options = {}) {
    const session = state.session;
    if (!session || !session.session_id || !Array.isArray(session.frames) || session.frames.length === 0) {
      drawEmpty();
      return;
    }

    const frameCount = session.frames.length;
    const targetIndex = applyFrameIndex(index, options);
    const token = ++state.imageToken;
    const frameUrl = `/api/recsai-preview/frame?session_id=${encodeURIComponent(session.session_id)}&index=${targetIndex}&scale=${previewFrameScale}&t=${Date.now()}`;
    try {
      const image = await loadFrameImage(frameUrl);
      if (token !== state.imageToken) {
        return false;
      }
      if (options.requireCurrent && state.currentIndex !== targetIndex) {
        return false;
      }
      drawFrameImage(image);
      updateFrameInfo();
      renderSegments({ autoScroll: true });
      return true;
    } catch (error) {
      if (token === state.imageToken) {
        setStatus(error && error.message ? error.message : "帧解码失败。");
      }
      return false;
    }
  }

  function loadFrameImage(url) {
    return new Promise((resolve, reject) => {
      const image = new Image();
      image.decoding = "async";
      image.onload = () => resolve(image);
      image.onerror = () => reject(new Error("帧解码失败。"));
      image.src = url;
    });
  }

  function drawFrameImage(image) {
    const canvas = els.frameCanvas;
    const rect = els.previewStage.getBoundingClientRect();
    const scale = window.devicePixelRatio || 1;
    const width = Math.max(1, Math.round(rect.width * scale));
    const height = Math.max(1, Math.round(rect.height * scale));
    if (canvas.width !== width || canvas.height !== height) {
      canvas.width = width;
      canvas.height = height;
    }

    ctx.setTransform(1, 0, 0, 1, 0, 0);
    ctx.clearRect(0, 0, width, height);
    ctx.fillStyle = "#20242c";
    ctx.fillRect(0, 0, width, height);

    const fit = fitRect(image.naturalWidth || image.width, image.naturalHeight || image.height, width, height);
    state.layout = fit;
    ctx.imageSmoothingEnabled = true;
    ctx.imageSmoothingQuality = "high";
    ctx.drawImage(image, fit.x, fit.y, fit.width, fit.height);
    drawPointerOverlay();
  }

  function drawPointerOverlay() {
    if (!els.pointerToggle.checked || !state.layout) {
      return;
    }

    const frame = getCurrentFrame();
    if (!frame) {
      return;
    }

    const sourceWidth = frame.width || 0;
    const sourceHeight = frame.height || 0;
    if (sourceWidth <= 0 || sourceHeight <= 0) {
      return;
    }

    const pointer = resolvePointer(frame);
    if (!pointer) {
      return;
    }

    const x = state.layout.x + (pointer.x / sourceWidth) * state.layout.width;
    const y = state.layout.y + (pointer.y / sourceHeight) * state.layout.height;
    ctx.save();
    ctx.lineWidth = 1.5 * (window.devicePixelRatio || 1);
    ctx.strokeStyle = "rgba(255, 255, 255, 0.95)";
    ctx.fillStyle = "rgba(79, 140, 255, 0.95)";
    ctx.beginPath();
    ctx.arc(x, y, 5 * (window.devicePixelRatio || 1), 0, Math.PI * 2);
    ctx.fill();
    ctx.stroke();
    ctx.beginPath();
    ctx.moveTo(x - 14, y);
    ctx.lineTo(x + 14, y);
    ctx.moveTo(x, y - 14);
    ctx.lineTo(x, y + 14);
    ctx.stroke();
    ctx.restore();
  }

  function resolvePointer(frame) {
    const px = Number(frame.pointer_thumb_x);
    const py = Number(frame.pointer_thumb_y);
    if (Number.isFinite(px) && Number.isFinite(py) && (px !== 0 || py !== 0)) {
      return { x: px, y: py };
    }

    const canvasWidth = Number(frame.canvas_width);
    const canvasHeight = Number(frame.canvas_height);
    const pointerX = Number(frame.pointer_x);
    const pointerY = Number(frame.pointer_y);
    if (Number.isFinite(pointerX) && Number.isFinite(pointerY) && canvasWidth > 0 && canvasHeight > 0) {
      return {
        x: pointerX / canvasWidth * (frame.width || canvasWidth),
        y: pointerY / canvasHeight * (frame.height || canvasHeight)
      };
    }

    return null;
  }

  function drawEmpty() {
    const canvas = els.frameCanvas;
    ctx.clearRect(0, 0, canvas.width, canvas.height);
    state.layout = null;
  }

  function updateFrameInfo() {
    const session = state.session;
    const frame = getCurrentFrame();
    const total = session && session.frame_count ? session.frame_count : 0;
    els.frameCounter.textContent = total > 0 ? `${state.currentIndex + 1} / ${total}` : "0 / 0";

    if (!frame) {
      els.imageSizeText.textContent = "-";
      els.canvasSizeText.textContent = "-";
      els.pointerText.textContent = "-";
      els.codecText.textContent = "-";
      els.sourceText.textContent = "-";
      els.timeText.textContent = "-";
      return;
    }

    els.imageSizeText.textContent = `${frame.width || 0} x ${frame.height || 0}`;
    els.canvasSizeText.textContent = `${frame.canvas_width || 0} x ${frame.canvas_height || 0}`;
    els.pointerText.textContent = formatPointer(frame);
    els.codecText.textContent = formatCodec(frame);
    els.sourceText.textContent = frame.source_kind || "-";
    els.timeText.textContent = formatTicks(frame.utc_ticks);
  }

  function formatCodec(frame) {
    const explicit = typeof frame.codec === "string" ? frame.codec.trim() : "";
    const codecId = Number(frame.codec_id ?? explicit);
    if (!Number.isFinite(codecId) || codecId <= 0) {
      return explicit || "-";
    }

    switch (Math.trunc(codecId)) {
      case 8:
        return "无损";
      case 7:
        return "Patch JPEG";
      case 6:
        return "旧精简";
      case 5:
        return "自适应 JPEG";
      case 4:
        return "Frame JPEG";
      case 3:
        return "BGRA 无损";
      case 2:
        return "Lane Zstd";
      case 1:
        return "旧 Zstd";
      default:
        return explicit || String(Math.trunc(codecId));
    }
  }

  function formatPointer(frame) {
    const x = Number(frame.pointer_x);
    const y = Number(frame.pointer_y);
    if (!Number.isFinite(x) || !Number.isFinite(y)) {
      return "-";
    }
    return `${Math.round(x)}, ${Math.round(y)}`;
  }

  function formatTicks(ticks) {
    const value = Number(ticks);
    if (!Number.isFinite(value) || value <= 0) {
      return "-";
    }

    const ms = value / 10000 - 62135596800000;
    const date = new Date(ms);
    if (Number.isNaN(date.getTime())) {
      return "-";
    }
    return date.toLocaleString();
  }

  function makeOutputName(path, folder) {
    const folderName = (folder || "").split(/[\\/]/).filter(Boolean).pop();
    if (folderName) {
      return `${folderName}.mp4`;
    }

    const fileName = (path || "").split(/[\\/]/).pop() || "recording.recsai";
    return fileName.replace(/\.recsai$/i, ".mp4");
  }

  function fitRect(sourceWidth, sourceHeight, targetWidth, targetHeight) {
    if (sourceWidth <= 0 || sourceHeight <= 0 || targetWidth <= 0 || targetHeight <= 0) {
      return { x: 0, y: 0, width: targetWidth, height: targetHeight };
    }

    const scale = Math.min(targetWidth / sourceWidth, targetHeight / sourceHeight);
    const width = Math.max(1, Math.round(sourceWidth * scale));
    const height = Math.max(1, Math.round(sourceHeight * scale));
    return {
      x: Math.round((targetWidth - width) / 2),
      y: Math.round((targetHeight - height) / 2),
      width,
      height
    };
  }

  function getCurrentFrame() {
    const session = state.session;
    if (!session || !Array.isArray(session.frames)) {
      return null;
    }
    return session.frames[state.currentIndex] || null;
  }

  function clamp(value, min, max) {
    return Math.max(min, Math.min(max, value));
  }

  function stepFrame(delta) {
    const session = state.session;
    const total = session && session.frame_count ? session.frame_count : 0;
    if (total <= 0) {
      return;
    }
    void showFrame(clamp(state.currentIndex + delta, 0, total - 1));
  }

  function requestSeekFrame(index, options = {}) {
    const session = state.session;
    const total = session && session.frame_count ? session.frame_count : 0;
    if (total <= 0) {
      return;
    }

    state.seekRenderIndex = clamp(index, 0, total - 1);
    applyFrameIndex(state.seekRenderIndex, {
      autoScroll: true,
      smooth: options.smooth === true,
      forceAutoScroll: !!options.forceAutoScroll
    });
    if (state.seekRenderTimer) {
      window.clearTimeout(state.seekRenderTimer);
    }
    state.seekRenderTimer = window.setTimeout(() => {
      state.seekRenderTimer = 0;
      void flushSeekFrame();
    }, state.seekRenderInFlight ? 28 : 0);
  }

  async function flushSeekFrame() {
    if (state.seekRenderInFlight) {
      return;
    }

    const targetIndex = state.seekRenderIndex;
    if (targetIndex < 0) {
      return;
    }

    state.seekRenderInFlight = true;
    try {
      await showFrame(targetIndex, { autoScroll: true, smooth: false, requireCurrent: true });
    } finally {
      state.seekRenderInFlight = false;
    }

    if (state.seekRenderIndex !== targetIndex) {
      requestSeekFrame(state.seekRenderIndex);
    }
  }

  function togglePlayback() {
    if (state.playing) {
      stopPlayback();
      return;
    }

    const session = state.session;
    if (!session || !session.frame_count) {
      return;
    }

    state.playing = true;
    els.playButton.textContent = "Ⅱ";
    els.playButton.title = "暂停";
    els.playButton.setAttribute("aria-label", "暂停");
    scheduleNextFrame(0);
  }

  function scheduleNextFrame(delayMs) {
    window.clearTimeout(state.playTimer);
    if (!state.playing || state.pendingPlayRequest) {
      return;
    }

    const fps = clamp(parseInt(els.fpsSelect.value, 10) || 24, 1, 120);
    const intervalMs = Math.max(16, Math.round(1000 / fps));
    state.playTimer = window.setTimeout(async () => {
      const session = state.session;
      if (!session || !session.frame_count) {
        stopPlayback();
        return;
      }
      const next = state.currentIndex + 1 >= session.frame_count ? 0 : state.currentIndex + 1;
      state.pendingPlayRequest = true;
      const startedAt = performance.now();
      try {
        await showFrame(next);
      } finally {
        state.pendingPlayRequest = false;
      }
      if (!state.playing) {
        return;
      }
      const elapsed = performance.now() - startedAt;
      scheduleNextFrame(Math.max(0, intervalMs - elapsed));
    }, Math.max(0, Number.isFinite(delayMs) ? delayMs : intervalMs));
  }

  function stopPlayback() {
    state.playing = false;
    window.clearTimeout(state.playTimer);
    if (state.seekRenderTimer) {
      window.clearTimeout(state.seekRenderTimer);
      state.seekRenderTimer = 0;
    }
    state.playTimer = 0;
    state.pendingPlayRequest = false;
    els.playButton.textContent = "▶";
    els.playButton.title = "播放";
    els.playButton.setAttribute("aria-label", "播放");
  }

  function bindControls() {
    bindHostDrag(els.titlebar);
    bindResizeGrip(els.windowResizeBottomLeftButton, "host:resize-bottom-left");
    bindResizeGrip(els.windowResizeBottomRightButton, "host:resize-bottom-right");
    bindFileDropGuard();

    els.closeWindowButton.addEventListener("click", () => {
      postHostMessage("host:close-window", "窗口关闭只能在桌面 WebView 中使用。");
    });
    els.openFileButton.addEventListener("click", () => {
      postHostCommand("choose-recsai-preview-file", null, "文件选择只能在桌面 WebView 中使用。");
    });
    const startQuickExport = () => {
      if (state.quickExportActive) {
        return;
      }

      if (!state.currentPath) {
        setStatus("请先打开 .recsai 文件。");
        return;
      }

      if (postHostCommand("quick-export", {
        path: state.currentPath,
        output_name: els.outputNameInput.value || "",
        fps: parseNumberInput(els.exportFpsInput, 30),
        speed: parseNumberInput(els.exportSpeedInput, 1),
        enable_diagnostic_log: !!state.exportDiagnosticEnabled,
        skipped_segments: Array.from(state.skippedSegmentPaths)
      }, "快速封装只能在桌面宿主中使用。")) {
        setQuickExportProgress(0, true);
      }
    };
    if (els.quickExportButton) {
      els.quickExportButton.addEventListener("click", startQuickExport);
    }
    if (els.titleQuickExportButton) {
      els.titleQuickExportButton.addEventListener("click", startQuickExport);
    }
    if (els.quickExportCancelButton) {
      els.quickExportCancelButton.addEventListener("click", (event) => {
        event.stopPropagation();
        if (!state.quickExportActive) {
          return;
        }
        setQuickExportCancelPending(true);
      });
    }
    if (els.quickExportCancelConfirmButton) {
      els.quickExportCancelConfirmButton.addEventListener("click", (event) => {
        event.stopPropagation();
        if (!state.quickExportActive) {
          setQuickExportCancelPending(false);
          return;
        }
        if (postHostCommand("quick-export-cancel", null, "快速封装取消只能在桌面宿主中使用。")) {
          setQuickExportCancelPending(false);
        }
      });
    }
    if (els.quickExportCancelDismissButton) {
      els.quickExportCancelDismissButton.addEventListener("click", (event) => {
        event.stopPropagation();
        setQuickExportCancelPending(false);
      });
    }
    if (els.exportDiagnosticToggle) {
      els.exportDiagnosticToggle.addEventListener("change", () => {
        setExportDiagnosticEnabled(els.exportDiagnosticToggle.checked);
        postHostCommand("set-recsai-preview-export-diagnostics", {
          value: state.exportDiagnosticEnabled
        }, "封装诊断开关只能在桌面宿主中保存。");
      });
    }
    if (els.quickExportCancelSurface && els.quickExportShell) {
      els.quickExportCancelSurface.addEventListener("pointerenter", () => {
        els.quickExportShell.classList.add("is-cancel-hover");
      });
      els.quickExportCancelSurface.addEventListener("pointerleave", () => {
        els.quickExportShell.classList.remove("is-cancel-hover");
      });
      els.quickExportCancelSurface.addEventListener("focusin", () => {
        els.quickExportShell.classList.add("is-cancel-hover");
      });
      els.quickExportCancelSurface.addEventListener("focusout", () => {
        els.quickExportShell.classList.remove("is-cancel-hover");
      });
    }
    if (els.statusDetailButton) {
      els.statusDetailButton.addEventListener("click", openExportDetail);
    }
    if (els.exportDetailCloseButton) {
      els.exportDetailCloseButton.addEventListener("click", closeExportDetail);
    }
    if (els.exportDetailPopover) {
      els.exportDetailPopover.addEventListener("click", (event) => {
        if (event.target === els.exportDetailPopover) {
          closeExportDetail();
        }
      });
    }
    els.prevButton.addEventListener("click", () => stepFrame(-1));
    els.nextButton.addEventListener("click", () => stepFrame(1));
    els.playButton.addEventListener("click", togglePlayback);
    if (els.segmentStripShell) {
      els.segmentStripShell.addEventListener("wheel", (event) => {
        if (Math.abs(event.deltaY) <= Math.abs(event.deltaX)) {
          return;
        }

        queueSegmentWheelScroll(event.deltaY);
        event.preventDefault();
      }, { passive: false });
    }
    bindDragScroll(els.segmentStrip, "x", () => scheduleSegmentMarkerSeek(220));
    bindDragScroll(els.segmentList, "y");
    els.frameSlider.addEventListener("input", () => {
      stopPlayback();
      requestSeekFrame(parseInt(els.frameSlider.value, 10) || 0);
    });
    els.pointerToggle.addEventListener("change", () => {
      void showFrame(state.currentIndex);
    });
    window.addEventListener("resize", () => {
      void showFrame(state.currentIndex);
    });
  }

  function bindFileDropGuard() {
    const hasFileTransfer = (event) => {
      const transfer = event.dataTransfer;
      if (!transfer) {
        return false;
      }
      if (transfer.files && transfer.files.length > 0) {
        return true;
      }
      const types = transfer.types || [];
      for (let i = 0; i < types.length; i++) {
        if (types[i] === "Files") {
          return true;
        }
      }
      return false;
    };

    const getDroppedRecsaiFile = (event) => {
      const transfer = event.dataTransfer;
      const files = transfer && transfer.files ? transfer.files : null;
      if (!files || files.length === 0) {
        return null;
      }

      for (let i = 0; i < files.length; i++) {
        const file = files[i];
        if (file && /\.recsai$/i.test(file.name || "")) {
          return file;
        }
      }
      return null;
    };

    const preventFileDropDefault = (event) => {
      if (!hasFileTransfer(event)) {
        return;
      }

      event.preventDefault();
      event.stopPropagation();
      event.dataTransfer.dropEffect = "copy";
      setLoading(true, "松开以打开", "拖入 .recsai 录制文件", true);
    };

    const handleDrop = (event) => {
      preventFileDropDefault(event);
      const file = getDroppedRecsaiFile(event);
      if (!file) {
        setLoading(false);
        setStatus("请拖入 .recsai 录制文件。");
        return;
      }

      void openDroppedFile(file).catch((error) => {
        setLoading(false);
        setStatus(error.message || String(error));
      });
    };

    const handleDragLeave = (event) => {
      if (event.relatedTarget) {
        return;
      }
      setLoading(false);
    };

    window.addEventListener("dragenter", preventFileDropDefault);
    window.addEventListener("dragover", preventFileDropDefault);
    window.addEventListener("dragleave", handleDragLeave);
    window.addEventListener("drop", handleDrop);
  }

  function bindHostBridge() {
    if (!hostBridge || typeof hostBridge.addEventListener !== "function") {
      return;
    }

    hostBridge.addEventListener("message", (event) => {
      const data = event.data;
      if (!data || typeof data !== "object") {
        return;
      }
      if (data.kind === "recsai-preview-file-selected" && data.path) {
        void openRecording(data.path).catch((error) => setStatus(error.message || String(error)));
        return;
      }
      if (data.kind === "recsai-preview-settings") {
        setExportDiagnosticEnabled(data.export_diagnostics_enabled === true);
        return;
      }
      if (data.kind === "webui-ack" && data.message) {
        handleQuickExportAck(data);
        setStatus(data.message, isErrorStatusAck(data) ? "error" : "");
      }
    });

    postHostMessage("host:recsai-preview-ready");
  }

  function parseNumberInput(input, fallback) {
    const value = input ? Number(input.value) : Number.NaN;
    return Number.isFinite(value) ? value : fallback;
  }

  function applyInitialTheme() {
    const saved = window.localStorage ? window.localStorage.getItem("readsai2-webui-state") : null;
    if (!saved) {
      document.documentElement.dataset.theme = "dark";
      return;
    }
    try {
      const parsed = JSON.parse(saved);
      if (parsed.themeMode === "auto" && typeof window.matchMedia === "function") {
        document.documentElement.dataset.theme = window.matchMedia("(prefers-color-scheme: dark)").matches ? "dark" : "light";
        return;
      }
      document.documentElement.dataset.theme = parsed.themeMode === "light" ? "light" : "dark";
    } catch {
      document.documentElement.dataset.theme = "dark";
    }
  }

  function openInitialPath() {
    const params = new URLSearchParams(window.location.search || "");
    const path = params.get("path");
    if (!path) {
      setTransportEnabled(false);
      return;
    }

    void openRecording(path).catch((error) => setStatus(error.message || String(error)));
  }

  applyInitialTheme();
  bindControls();
  bindHostBridge();
  drawEmpty();
  openInitialPath();
}());
