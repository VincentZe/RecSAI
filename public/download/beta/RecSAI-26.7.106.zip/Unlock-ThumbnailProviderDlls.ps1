﻿param(
    [switch]$Force,
    [switch]$RestartExplorer
)

$ErrorActionPreference = "Stop"

$thumbnailCacheClassFactory = "{AB8902B4-09CA-4BB6-B78D-A8F59079A8D5}"
$providerDllNames = @("RecSAI.Sai2ThumbnailProvider.dll", "RecSAI.ThumbnailProvider.dll")

function Confirm-Continue {
    param([string]$Question)
    if ($Force) {
        return $true
    }
    $answer = Read-Host "$Question [y/N]"
    return $answer -match "^(y|yes|是)$"
}

function Confirm-RestartExplorer {
    if ($RestartExplorer) {
        return $true
    }
    if ($Force) {
        return $false
    }
    $answer = Read-Host "要关闭并重启资源管理器以释放 Shell 锁定吗？[y/N]"
    return $answer -match "^(y|yes|是)$"
}

function Add-ExistingPath {
    param(
        [System.Collections.Generic.List[string]]$Paths,
        [string]$Path
    )

    if ([string]::IsNullOrWhiteSpace($Path)) {
        return
    }

    if (-not (Test-Path -LiteralPath $Path -PathType Leaf)) {
        return
    }

    $fullPath = (Resolve-Path -LiteralPath $Path).ProviderPath
    foreach ($existing in $Paths) {
        if ($existing -ieq $fullPath) {
            return
        }
    }
    $Paths.Add($fullPath) | Out-Null
}

function Add-RegistryProviderPath {
    param(
        [System.Collections.Generic.List[string]]$Paths,
        [string]$Value
    )

    if ([string]::IsNullOrWhiteSpace($Value)) {
        return
    }

    $path = $Value.Trim()
    if ($path.StartsWith("file://", [System.StringComparison]::OrdinalIgnoreCase)) {
        try {
            $path = (New-Object System.Uri($path)).LocalPath
        } catch {
            return
        }
    }
    if ($path.StartsWith('"')) {
        $endQuote = $path.IndexOf('"', 1)
        if ($endQuote -gt 1) {
            $path = $path.Substring(1, $endQuote - 1)
        }
    } else {
        $comma = $path.IndexOf(',')
        if ($comma -gt 0) {
            $path = $path.Substring(0, $comma)
        }
    }
    Add-ExistingPath $Paths $path
}

function Add-RegistryProviderPaths {
    param([System.Collections.Generic.List[string]]$Paths)

    $classIds = @(
        "{3259D2F0-B82C-486D-8304-A8681E50B131}",
        "{F5EC4619-2F3A-428B-9E68-1B35E3DE2FD0}"
    )

    foreach ($classId in $classIds) {
        $inprocPath = "HKCU:\Software\Classes\CLSID\$classId\InprocServer32"
        if (Test-Path -LiteralPath $inprocPath) {
            $codeBase = (Get-ItemProperty -LiteralPath $inprocPath -Name "CodeBase" -ErrorAction SilentlyContinue).CodeBase
            Add-RegistryProviderPath $Paths $codeBase
        }
    }

    $iconKeys = @(
        "HKCU:\Software\Classes\.sai2",
        "HKCU:\Software\Classes\.sai2\DefaultIcon",
        "HKCU:\Software\Classes\RecSAI.Recsai",
        "HKCU:\Software\Classes\RecSAI.Recsai\DefaultIcon"
    )

    foreach ($keyPath in $iconKeys) {
        if (-not (Test-Path -LiteralPath $keyPath)) {
            continue
        }
        $item = Get-Item -LiteralPath $keyPath
        Add-RegistryProviderPath $Paths $item.GetValue("")
        Add-RegistryProviderPath $Paths $item.GetValue("TypeOverlay")
    }
}

function Get-KnownProviderDllPaths {
    $paths = New-Object "System.Collections.Generic.List[string]"
    $repoRoot = [System.IO.Path]::GetFullPath((Join-Path $PSScriptRoot ".."))

    $candidateDirs = @(
        $PSScriptRoot,
        (Join-Path $repoRoot "bin\Release_no_reserch"),
        (Join-Path $repoRoot "bin\Debug"),
        (Join-Path $repoRoot "bin\Release"),
        (Join-Path $repoRoot "ReadSAI2.Sai2ThumbnailProvider\bin\x64\Release_no_reserch"),
        (Join-Path $repoRoot "ReadSAI2.Sai2ThumbnailProvider\bin\x64\Debug"),
        (Join-Path $repoRoot "ReadSAI2.Sai2ThumbnailProvider\bin\x64\Release"),
        (Join-Path $repoRoot "ReadSAI2.ThumbnailProvider\bin\x64\Release_no_reserch"),
        (Join-Path $repoRoot "ReadSAI2.ThumbnailProvider\bin\x64\Debug"),
        (Join-Path $repoRoot "ReadSAI2.ThumbnailProvider\bin\x64\Release")
    )

    foreach ($dir in $candidateDirs) {
        foreach ($name in $providerDllNames) {
            Add-ExistingPath $paths (Join-Path $dir $name)
        }
    }

    Add-RegistryProviderPaths $paths
    return @($paths.ToArray())
}

function Test-FileLocked {
    param([string]$Path)

    if (-not (Test-Path -LiteralPath $Path -PathType Leaf)) {
        return $false
    }

    $stream = $null
    try {
        $stream = [System.IO.File]::Open($Path, [System.IO.FileMode]::Open, [System.IO.FileAccess]::ReadWrite, [System.IO.FileShare]::None)
        return $false
    } catch {
        return $true
    } finally {
        if ($null -ne $stream) {
            $stream.Dispose()
        }
    }
}

function Get-LockedProviderDllPaths {
    param([string[]]$Paths)

    $locked = New-Object "System.Collections.Generic.List[string]"
    foreach ($path in $Paths) {
        if (Test-FileLocked $path) {
            $locked.Add($path) | Out-Null
        }
    }
    return @($locked.ToArray())
}

function Wait-ProviderDllUnlock {
    param(
        [string[]]$Paths,
        [int]$TimeoutMilliseconds
    )

    $deadline = [DateTime]::UtcNow.AddMilliseconds($TimeoutMilliseconds)
    do {
        $locked = @(Get-LockedProviderDllPaths $Paths)
        if ($locked.Count -eq 0) {
            return @()
        }
        Start-Sleep -Milliseconds 200
    } while ([DateTime]::UtcNow -lt $deadline)

    return @(Get-LockedProviderDllPaths $Paths)
}

function Get-ThumbnailDllHosts {
    foreach ($process in Get-Process dllhost -ErrorAction SilentlyContinue) {
        $matched = $false
        try {
            foreach ($module in $process.Modules) {
                $name = [System.IO.Path]::GetFileName($module.FileName)
                if ($providerDllNames -icontains $name) {
                    $matched = $true
                    break
                }
            }
        } catch {
        }
        if ($matched) {
            $process
        }
    }
}

function Get-ThumbnailCacheDllHosts {
    $cacheHosts = New-Object "System.Collections.Generic.List[int]"
    try {
        $query = "name = 'dllhost.exe' and commandline like '%$thumbnailCacheClassFactory%'"
        foreach ($process in Get-CimInstance Win32_Process -Filter $query -ErrorAction SilentlyContinue) {
            $cacheHosts.Add([int]$process.ProcessId) | Out-Null
        }
    } catch {
    }

    foreach ($id in $cacheHosts.ToArray()) {
        $process = Get-Process -Id $id -ErrorAction SilentlyContinue
        if ($null -ne $process) {
            $process
        }
    }
}

function Stop-UniqueProcesses {
    param(
        [System.Diagnostics.Process[]]$Processes,
        [string]$Label
    )

    $ids = New-Object "System.Collections.Generic.HashSet[int]"
    foreach ($process in $Processes) {
        if ($null -eq $process) {
            continue
        }
        if (-not $ids.Add($process.Id)) {
            $process.Dispose()
            continue
        }
        try {
            Stop-Process -Id $process.Id -Force -ErrorAction SilentlyContinue
        } finally {
            $process.Dispose()
        }
    }
    if ($ids.Count -gt 0) {
        Write-Host "已关闭 $($ids.Count) 个 $Label。"
    }
    return $ids.Count
}

$providerPaths = @(Get-KnownProviderDllPaths)
$initialLocked = @(Get-LockedProviderDllPaths $providerPaths)
$moduleHosts = @(Get-ThumbnailDllHosts)
$cacheHosts = @(Get-ThumbnailCacheDllHosts)
$dllHosts = @(Get-Process dllhost -ErrorAction SilentlyContinue)
$explorers = @(Get-Process explorer -ErrorAction SilentlyContinue)

Write-Host ""
Write-Host "将执行以下操作："
Write-Host "  1. 检查 RecSAI 缩略图 Provider DLL 是否被占用：$($providerPaths.Count) 个候选文件，当前锁定 $($initialLocked.Count) 个。"
Write-Host "  2. 关闭已加载 RecSAI 缩略图 Provider 的 COM Surrogate：$($moduleHosts.Count) 个。"
Write-Host "  3. 关闭 Windows 缩略图缓存 COM Surrogate：$($cacheHosts.Count) 个。"
Write-Host "  4. 如果 DLL 仍被锁定，会询问是否关闭所有 COM Surrogate 进程。当前 dllhost：$($dllHosts.Count) 个。"
Write-Host "  5. 可选关闭并重启资源管理器。当前资源管理器进程：$($explorers.Count) 个。"
Write-Host "  6. 不修改任何注册表项。"
if ($initialLocked.Count -gt 0) {
    Write-Host ""
    Write-Host "当前被锁定的文件："
    foreach ($path in $initialLocked) {
        Write-Host "  $path"
    }
}
Write-Host ""

if (-not (Confirm-Continue "继续解锁缩略图 Provider DLL 吗？")) {
    Write-Host "已取消。"
    exit 0
}

$restartExplorerAfterUnlock = Confirm-RestartExplorer

if ($restartExplorerAfterUnlock -and $explorers.Count -gt 0) {
    Stop-UniqueProcesses $explorers "资源管理器进程" | Out-Null
}

$targetHosts = @($moduleHosts + $cacheHosts)
$targetKilled = Stop-UniqueProcesses $targetHosts "缩略图 COM Surrogate 进程"
if ($targetKilled -eq 0) {
    Write-Host "未发现需要定向关闭的缩略图 COM Surrogate 进程。"
}

$locked = @(Wait-ProviderDllUnlock $providerPaths 2000)
if ($locked.Count -gt 0) {
    Write-Host "定向关闭后仍有 DLL 被锁定："
    foreach ($path in $locked) {
        Write-Host "  $path"
    }

    if (Confirm-Continue "要关闭所有 COM Surrogate(dllhost.exe) 作为兜底吗？") {
        $allDllHosts = @(Get-Process dllhost -ErrorAction SilentlyContinue)
        Stop-UniqueProcesses $allDllHosts "COM Surrogate 进程" | Out-Null
        $locked = @(Wait-ProviderDllUnlock $providerPaths 3000)
    }
}

if ($restartExplorerAfterUnlock) {
    Start-Process explorer.exe
    Write-Host "资源管理器已重新启动。"
} else {
    Write-Host "未重启资源管理器。"
}

if ($locked.Count -gt 0) {
    Write-Host "仍有缩略图 Provider DLL 未释放："
    foreach ($path in $locked) {
        Write-Host "  $path"
    }
    exit 2
}

Write-Host "缩略图 Provider DLL 已解锁。"
