﻿param(
    [ValidateSet("sai2-file", "sai-icon", "provider")]
    [string]$Icon = "provider",
    [string]$IconPath,
    [switch]$Force,
    [switch]$RestartExplorer
)

$ErrorActionPreference = "Stop"

$thumbnailCacheClassFactory = "{AB8902B4-09CA-4BB6-B78D-A8F59079A8D5}"
$defaultSai2IconPath = "D:\Mini\[Saier]SAI Ver.2\sai2-file.ico"
$defaultSaiIconPath = "D:\Mini\[Saier]SAI Ver.2\sai-icon.ico"

function Confirm-Continue {
    param([string]$Question)
    if ($Force) {
        return $true
    }
    $answer = Read-Host "$Question [y/N]"
    return $answer -match "^(y|yes|是)$"
}

function Get-EffectiveClassDefaultValue {
    param([string]$KeyPath)

    $userPath = "HKCU:\Software\Classes\$KeyPath"
    if (Test-Path -LiteralPath $userPath) {
        $value = (Get-Item -LiteralPath $userPath).GetValue("")
        if (-not [string]::IsNullOrWhiteSpace($value)) {
            return $value
        }
    }

    $machinePath = "HKLM:\Software\Classes\$KeyPath"
    if (Test-Path -LiteralPath $machinePath) {
        $value = (Get-Item -LiteralPath $machinePath).GetValue("")
        if (-not [string]::IsNullOrWhiteSpace($value)) {
            return $value
        }
    }

    return $null
}

function Resolve-ExistingFile {
    param([string]$Path)

    if ([string]::IsNullOrWhiteSpace($Path)) {
        return $null
    }
    if (Test-Path -LiteralPath $Path -PathType Leaf) {
        return (Resolve-Path -LiteralPath $Path).ProviderPath
    }
    return $null
}

function Resolve-ProviderDllPath {
    $candidates = @(
        (Join-Path $PSScriptRoot "RecSAI.Sai2ThumbnailProvider.dll"),
        (Join-Path $PSScriptRoot "bin\x64\Release_no_reserch\RecSAI.Sai2ThumbnailProvider.dll"),
        (Join-Path $PSScriptRoot "..\bin\Release_no_reserch\RecSAI.Sai2ThumbnailProvider.dll"),
        (Join-Path $PSScriptRoot "..\ReadSAI2.Sai2ThumbnailProvider\bin\x64\Release_no_reserch\RecSAI.Sai2ThumbnailProvider.dll")
    )

    foreach ($candidate in $candidates) {
        $resolved = Resolve-ExistingFile $candidate
        if (-not [string]::IsNullOrWhiteSpace($resolved)) {
            return $resolved
        }
    }

    return $null
}

function Resolve-SelectedIconPath {
    if (-not [string]::IsNullOrWhiteSpace($IconPath)) {
        return Resolve-ExistingFile $IconPath
    }

    if ($Icon -eq "sai2-file") {
        return Resolve-ExistingFile $defaultSai2IconPath
    }
    if ($Icon -eq "sai-icon") {
        return Resolve-ExistingFile $defaultSaiIconPath
    }

    return Resolve-ProviderDllPath
}

function Stop-ThumbnailCacheHosts {
    $ids = New-Object "System.Collections.Generic.List[int]"
    try {
        $query = "name = 'dllhost.exe' and commandline like '%$thumbnailCacheClassFactory%'"
        foreach ($process in Get-CimInstance Win32_Process -Filter $query -ErrorAction SilentlyContinue) {
            $ids.Add([int]$process.ProcessId) | Out-Null
        }
    } catch {
    }

    foreach ($id in $ids.ToArray()) {
        Stop-Process -Id $id -Force -ErrorAction SilentlyContinue
    }

    return $ids.Count
}

function Refresh-ShellIcons {
    try {
        $ie4uinit = Join-Path $env:windir "System32\ie4uinit.exe"
        if (Test-Path -LiteralPath $ie4uinit -PathType Leaf) {
            Start-Process -FilePath $ie4uinit -ArgumentList "-show" -WindowStyle Hidden -Wait
        }
    } catch {
    }
}

$resolvedIconPath = Resolve-SelectedIconPath
if ([string]::IsNullOrWhiteSpace($resolvedIconPath)) {
    Write-Host "未找到要使用的图标文件。"
    Write-Host "当前选择：$Icon"
    Write-Host "也可以通过 -IconPath 指定一个 .ico/.dll/.exe 路径。"
    exit 1
}

$classes = "HKCU:\Software\Classes"
$progId = Get-EffectiveClassDefaultValue ".sai2"
$iconReference = "`"$resolvedIconPath`",0"
$preferencePath = "$classes\RecSAI"

Write-Host ""
Write-Host "将执行以下操作："
Write-Host "  1. 将 .sai2 的 DefaultIcon 和 TypeOverlay 设置为：$iconReference"
if (-not [string]::IsNullOrWhiteSpace($progId)) {
    Write-Host "  2. 当前 .sai2 ProgID 为 $progId，会同步设置 ProgID 的 DefaultIcon 和 TypeOverlay。"
} else {
    Write-Host "  2. 未发现 .sai2 ProgID，仅设置 .sai2 本身。"
}
Write-Host "  3. 关闭 Windows 缩略图缓存 COM Surrogate，让 Explorer 尽快重读图标。"
if ($RestartExplorer) {
    Write-Host "  4. 关闭并重启资源管理器。"
} else {
    Write-Host "  4. 不重启资源管理器。"
}
Write-Host "  5. 记录 RecSAI 的 .sai2 图标偏好，避免后续自动注册覆盖本次选择。"
Write-Host "  6. 不修改 .sai2 的默认打开方式和缩略图 Provider 注册。"
Write-Host ""

if (-not (Confirm-Continue "继续切换 .sai2 缩略图角标/文件图标吗？")) {
    Write-Host "已取消。"
    exit 0
}

New-Item -Path "$classes\.sai2" -Force | Out-Null
Set-ItemProperty -Path "$classes\.sai2" -Name "TypeOverlay" -Value $iconReference
New-Item -Path "$classes\.sai2\DefaultIcon" -Force | Out-Null
Set-Item -Path "$classes\.sai2\DefaultIcon" -Value $iconReference

if (-not [string]::IsNullOrWhiteSpace($progId)) {
    New-Item -Path "$classes\$progId" -Force | Out-Null
    Set-ItemProperty -Path "$classes\$progId" -Name "TypeOverlay" -Value $iconReference
    New-Item -Path "$classes\$progId\DefaultIcon" -Force | Out-Null
    Set-Item -Path "$classes\$progId\DefaultIcon" -Value $iconReference
}

New-Item -Path $preferencePath -Force | Out-Null
New-Item -Path "$preferencePath\Sai2ThumbnailIconPath" -Force | Out-Null
Set-Item -Path "$preferencePath\Sai2ThumbnailIconPath" -Value $resolvedIconPath

$stopped = Stop-ThumbnailCacheHosts
Refresh-ShellIcons

if ($RestartExplorer) {
    Get-Process explorer -ErrorAction SilentlyContinue | Stop-Process -Force -ErrorAction SilentlyContinue
    Start-Process explorer.exe
}

Write-Host ".sai2 图标已切换：$iconReference"
Write-Host "已关闭 $stopped 个缩略图缓存 COM Surrogate。"
