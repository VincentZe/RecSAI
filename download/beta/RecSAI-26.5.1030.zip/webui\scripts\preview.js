﻿function cycleVolumeMode() {
  state.volumeModeIndex = (state.volumeModeIndex + 1) % 3;
  addLog(`Volume display mode changed to ${state.volumeModeIndex + 1}.`);
  render();
}

function toggleThemeMode() {
  state.themeMode = state.themeMode === "dark" ? "light" : "dark";
  addLog(`Theme changed to ${state.themeMode}.`);
  render();
  drawPreview();
}

function getPreviewDeviceScale() {
  return clamp(window.devicePixelRatio || 1, 1, 2);
}

function getPreviewViewportSize() {
  return {
    width: Math.max(els.previewScroll.clientWidth || 0, 320),
    height: Math.max(els.previewScroll.clientHeight || 0, 240)
  };
}

function setCanvasSize(canvas, cssWidth, cssHeight, pixelWidth, pixelHeight) {
  const nextWidth = Math.max(1, Math.round(pixelWidth));
  const nextHeight = Math.max(1, Math.round(pixelHeight));
  if (canvas.width !== nextWidth) {
    canvas.width = nextWidth;
  }
  if (canvas.height !== nextHeight) {
    canvas.height = nextHeight;
  }
  canvas.style.width = `${Math.max(1, cssWidth)}px`;
  canvas.style.height = `${Math.max(1, cssHeight)}px`;
}

function ensureAtlasSize(width, height) {
  const safeWidth = Math.max(1, Math.round(width || 1));
  const safeHeight = Math.max(1, Math.round(height || 1));
  if (preview.atlasCanvas.width !== safeWidth) {
    preview.atlasCanvas.width = safeWidth;
  }
  if (preview.atlasCanvas.height !== safeHeight) {
    preview.atlasCanvas.height = safeHeight;
  }
}

function clearAtlas() {
  ensureAtlasSize(preview.session ? preview.session.width : 1, preview.session ? preview.session.height : 1);
  preview.atlasCtx.clearRect(0, 0, preview.atlasCanvas.width, preview.atlasCanvas.height);
}

function computeContainRect(sourceWidth, sourceHeight, targetWidth, targetHeight) {
  if (sourceWidth <= 0 || sourceHeight <= 0 || targetWidth <= 0 || targetHeight <= 0) {
    return { x: 0, y: 0, width: Math.max(0, targetWidth), height: Math.max(0, targetHeight) };
  }

  const sourceRatio = sourceWidth / sourceHeight;
  const targetRatio = targetWidth / targetHeight;
  let width = targetWidth;
  let height = targetHeight;
  if (sourceRatio > targetRatio) {
    height = width / sourceRatio;
  } else {
    width = height * sourceRatio;
  }

  return {
    x: Math.round((targetWidth - width) * 0.5),
    y: Math.round((targetHeight - height) * 0.5),
    width: Math.round(width),
    height: Math.round(height)
  };
}

function updatePreviewLayout() {
  const viewport = getPreviewViewportSize();
  const sessionWidth = preview.session && preview.session.width > 0 ? preview.session.width : 1280;
  const sessionHeight = preview.session && preview.session.height > 0 ? preview.session.height : 720;
  const canUseActual = false;

  let cssWidth;
  let cssHeight;
  let pixelWidth;
  let pixelHeight;
  let drawRect;

  if (canUseActual) {
    cssWidth = sessionWidth;
    cssHeight = sessionHeight;
    pixelWidth = sessionWidth;
    pixelHeight = sessionHeight;
    drawRect = { x: 0, y: 0, width: pixelWidth, height: pixelHeight };
  } else {
    const scale = getPreviewDeviceScale();
    cssWidth = viewport.width;
    cssHeight = viewport.height;
    pixelWidth = Math.max(1, Math.round(cssWidth * scale));
    pixelHeight = Math.max(1, Math.round(cssHeight * scale));
    drawRect = computeContainRect(sessionWidth, sessionHeight, pixelWidth, pixelHeight);
  }

  setCanvasSize(els.displayCanvas, cssWidth, cssHeight, pixelWidth, pixelHeight);
  setCanvasSize(els.overlayCanvas, cssWidth, cssHeight, pixelWidth, pixelHeight);
  els.previewSurface.style.width = `${Math.max(1, cssWidth)}px`;
  els.previewSurface.style.height = `${Math.max(1, cssHeight)}px`;

  preview.layout = {
    viewportWidth: viewport.width,
    viewportHeight: viewport.height,
    cssWidth,
    cssHeight,
    pixelWidth,
    pixelHeight,
    sessionWidth,
    sessionHeight,
    drawRect,
    mode: canUseActual ? "actual" : "fit"
  };
  renderPreviewChrome();
  return preview.layout;
}

function getPreviewPlaceholderLines() {
  if (isHttpProvider() && !state.backendAvailable) {
    return ["等待 HTTP bridge", "本地 bridge 恢复后会自动重连预览 socket"];
  }
  if (preview.error && preview.error.message) {
    return ["预览连接异常", preview.error.message];
  }
  if (isHttpProvider()) {
    return ["等待预览会话", "连接 /ws/preview/runtime 后会接收 hello/session 消息"];
  }
  return ["模拟预览模式", "当前页面运行在本地文件模式，使用内置模拟数据"];
}

function drawPreviewBackdrop(ctx, width, height) {
  ctx.clearRect(0, 0, width, height);
  const bg = ctx.createLinearGradient(0, 0, width, height);
  bg.addColorStop(0, "#16181c");
  bg.addColorStop(0.45, "#1b1e23");
  bg.addColorStop(1, "#242931");
  ctx.fillStyle = bg;
  ctx.fillRect(0, 0, width, height);

  ctx.strokeStyle = "rgba(255,255,255,0.05)";
  ctx.lineWidth = 1;
  for (let x = 60; x < width; x += 60) {
    ctx.beginPath();
    ctx.moveTo(x, 0);
    ctx.lineTo(x, height);
    ctx.stroke();
  }
  for (let y = 60; y < height; y += 60) {
    ctx.beginPath();
    ctx.moveTo(0, y);
    ctx.lineTo(width, y);
    ctx.stroke();
  }
}

function drawPreviewPlaceholder(ctx, width, height) {
  const lines = getPreviewPlaceholderLines();
  ctx.fillStyle = "rgba(242, 198, 108, 0.12)";
  ctx.fillRect(40, 48, Math.max(0, width - 80), Math.max(0, height - 96));
  ctx.fillStyle = "#f6e8e2";
  ctx.font = "700 30px Georgia";
  ctx.fillText(lines[0], 56, Math.max(74, height - 92));
  ctx.fillStyle = "rgba(246, 232, 226, 0.78)";
  ctx.font = "16px Segoe UI Variable Display";
  ctx.fillText(lines[1], 56, Math.max(98, height - 60));
}

function drawRuntimePreviewFrame(ctx, layout) {
  drawPreviewBackdrop(ctx, layout.pixelWidth, layout.pixelHeight);
  if (!preview.session) {
    drawPreviewPlaceholder(ctx, layout.pixelWidth, layout.pixelHeight);
    return;
  }

  const rect = layout.drawRect;
  ctx.imageSmoothingEnabled = true;
  ctx.drawImage(
    preview.atlasCanvas,
    0,
    0,
    preview.session.width,
    preview.session.height,
    rect.x,
    rect.y,
    rect.width,
    rect.height
  );
}

function drawMockPreviewFrame(ctx, layout) {
  drawPreviewBackdrop(ctx, layout.pixelWidth, layout.pixelHeight);
  const rect = layout.drawRect;
  ctx.fillStyle = "rgba(255, 255, 255, 0.04)";
  ctx.fillRect(rect.x, rect.y, rect.width, rect.height);

  preview.dots.forEach((dot, index) => {
    const alpha = (index + 1) / Math.max(1, preview.dots.length);
    ctx.beginPath();
    ctx.fillStyle = `hsla(${dot.hue}, 88%, 66%, ${alpha * 0.72})`;
    ctx.arc(dot.x, dot.y, dot.size, 0, Math.PI * 2);
    ctx.fill();
  });
}

function drawPreviewFrameNow() {
  const layout = updatePreviewLayout();
  if (!preview.displayCtx || !layout) {
    return;
  }

  if (runtime.provider && runtime.provider.kind === "mock") {
    drawMockPreviewFrame(preview.displayCtx, layout);
  } else {
    drawRuntimePreviewFrame(preview.displayCtx, layout);
  }
}

function getPreviewCursorPoint() {
  if (!preview.layout || !preview.session || !preview.cursor.attached) {
    return null;
  }
  if (preview.cursor.thumbWidth <= 0 || preview.cursor.thumbHeight <= 0) {
    return null;
  }

  const ratioX = clamp(preview.cursor.x / preview.cursor.thumbWidth, 0, 1);
  const ratioY = clamp(preview.cursor.y / preview.cursor.thumbHeight, 0, 1);
  const rect = preview.layout.drawRect;
  return {
    x: rect.x + (rect.width * ratioX),
    y: rect.y + (rect.height * ratioY)
  };
}

function drawPreviewRecordingOverlay(ctx, rect) {
  if (state.recordingState !== "recording" && state.recordingState !== "starting" && state.recordingState !== "stopping") {
    return;
  }

  ctx.save();
  ctx.strokeStyle = state.recordingState === "recording" ? "rgba(255, 110, 99, 0.92)" : "rgba(242, 198, 108, 0.92)";
  ctx.lineWidth = 4;
  ctx.strokeRect(rect.x + 2, rect.y + 2, Math.max(0, rect.width - 4), Math.max(0, rect.height - 4));
  ctx.fillStyle = "rgba(5, 15, 18, 0.82)";
  ctx.fillRect(rect.x + 16, rect.y + 16, 82, 34);
  ctx.fillStyle = "#fff4ec";
  ctx.font = "700 16px Segoe UI Variable Display";
  ctx.fillText(state.recordingState === "recording" ? "REC" : "SYNC", rect.x + 34, rect.y + 38);
  ctx.restore();
}

function drawPreviewOfflineOverlay(ctx, rect) {
  const offline = (!state.backendAvailable && isHttpProvider()) || !preview.cursor.attached || !!preview.error;
  if (!offline) {
    return;
  }

  ctx.save();
  ctx.fillStyle = "rgba(5, 12, 15, 0.52)";
  ctx.fillRect(rect.x, rect.y, rect.width, rect.height);
  ctx.fillStyle = "#f6e8e2";
  ctx.font = "700 20px Georgia";
  ctx.fillText(preview.error ? "连接异常" : "等待数据", rect.x + 24, rect.y + 36);
  ctx.restore();
}

function drawPreviewPointerOverlay(ctx) {
  const point = getPreviewCursorPoint();
  if (!point) {
    return;
  }

  ctx.save();
  ctx.strokeStyle = "rgba(98, 221, 192, 0.92)";
  ctx.lineWidth = 2;
  ctx.beginPath();
  ctx.moveTo(point.x - 24, point.y);
  ctx.lineTo(point.x + 24, point.y);
  ctx.moveTo(point.x, point.y - 24);
  ctx.lineTo(point.x, point.y + 24);
  ctx.stroke();
  ctx.beginPath();
  ctx.fillStyle = "rgba(98, 221, 192, 0.98)";
  ctx.arc(point.x, point.y, 6, 0, Math.PI * 2);
  ctx.fill();
  ctx.restore();
}

function drawPreviewOverlayNow() {
  const layout = preview.layout || updatePreviewLayout();
  if (!preview.overlayCtx || !layout) {
    return;
  }

  preview.overlayCtx.clearRect(0, 0, layout.pixelWidth, layout.pixelHeight);
  drawPreviewRecordingOverlay(preview.overlayCtx, layout.drawRect);
  drawPreviewOfflineOverlay(preview.overlayCtx, layout.drawRect);
  drawPreviewPointerOverlay(preview.overlayCtx);
}

function requestPreviewFrameDraw() {
  if (preview.renderQueued) {
    return;
  }
  preview.renderQueued = true;
  window.requestAnimationFrame(() => {
    preview.renderQueued = false;
    drawPreviewFrameNow();
  });
}

function requestPreviewOverlayDraw() {
  if (preview.overlayQueued) {
    return;
  }
  preview.overlayQueued = true;
  window.requestAnimationFrame(() => {
    preview.overlayQueued = false;
    drawPreviewOverlayNow();
  });
}

function drawPreview() {
  requestPreviewFrameDraw();
  requestPreviewOverlayDraw();
}

function computePreviewMaxDim() {
  const viewport = getPreviewViewportSize();
  const longestCssPx = Math.max(viewport.width, viewport.height);
  const scale = getPreviewDeviceScale();
  return clamp(Math.round(longestCssPx * scale), 1024, 3072);
}

function logPreviewEventThrottled(message) {
  const now = Date.now();
  if (now - preview.lastLogAt < 2000) {
    return;
  }
  preview.lastLogAt = now;
  addLog(message);
}

function sendPreviewControlMessage(type) {
  if (!preview.socket || preview.socket.readyState !== WebSocket.OPEN) {
    return;
  }

  const maxDim = computePreviewMaxDim();
  const mode = "fit";
  if (type === "resize" && preview.lastSentMaxDim === maxDim && preview.lastSentMode === mode) {
    return;
  }

  preview.socket.send(JSON.stringify({
    type,
    max_dim: maxDim,
    mode
  }));
  preview.openSent = true;
  preview.lastSentMaxDim = maxDim;
  preview.lastSentMode = mode;
}

function queuePreviewResizeSend() {
  if (!isHttpProvider() || preview.disposed) {
    return;
  }
  if (preview.resizeSendTimer) {
    window.clearTimeout(preview.resizeSendTimer);
  }
  preview.resizeSendTimer = window.setTimeout(() => {
    preview.resizeSendTimer = 0;
    sendPreviewControlMessage(preview.openSent ? "resize" : "open");
  }, previewResizeDebounceMs);
}

function disposeRuntimePreviewTransport(resetSession) {
  preview.disposed = true;
  if (preview.resizeSendTimer) {
    window.clearTimeout(preview.resizeSendTimer);
    preview.resizeSendTimer = 0;
  }
  if (preview.reconnectTimer) {
    window.clearTimeout(preview.reconnectTimer);
    preview.reconnectTimer = 0;
  }
  if (preview.socket) {
    try {
      preview.socket.close();
    } catch {
    }
    preview.socket = null;
  }
  preview.openSent = false;
  preview.lastSentMaxDim = 0;
  preview.lastSentMode = "";
  preview.layout = null;
  if (resetSession) {
    preview.session = null;
    preview.error = null;
    clearAtlas();
  }
}

function schedulePreviewReconnect() {
  if (preview.disposed || preview.reconnectTimer) {
    return;
  }
  preview.reconnectTimer = window.setTimeout(() => {
    preview.reconnectTimer = 0;
    connectRuntimePreviewSocket();
  }, previewReconnectMs);
}

function connectRuntimePreviewSocket() {
  if (!isHttpProvider() || preview.disposed || preview.socket) {
    return;
  }

  const protocol = window.location.protocol === "https:" ? "wss:" : "ws:";
  const url = `${protocol}//${window.location.host}/ws/preview/runtime`;
  const socket = new WebSocket(url);
  socket.binaryType = "arraybuffer";
  preview.socket = socket;
  preview.error = null;
  preview.openSent = false;
  preview.lastSentMaxDim = 0;
  preview.lastSentMode = "";

  socket.addEventListener("open", () => {
    if (preview.socket !== socket) {
      return;
    }
    preview.error = null;
    sendPreviewControlMessage("open");
    requestPreviewOverlayDraw();
  });

  socket.addEventListener("message", (event) => {
    if (typeof event.data === "string") {
      handlePreviewTextMessage(event.data);
      return;
    }
    if (event.data instanceof ArrayBuffer) {
      applyPreviewTilePacket(event.data);
      return;
    }
    if (event.data instanceof Blob) {
      void event.data.arrayBuffer().then(applyPreviewTilePacket).catch(() => {
      });
    }
  });

  socket.addEventListener("error", () => {
    logPreviewEventThrottled("Preview websocket error.");
  });

  socket.addEventListener("close", () => {
    if (preview.socket === socket) {
      preview.socket = null;
      preview.openSent = false;
      preview.lastSentMaxDim = 0;
      preview.lastSentMode = "";
      if (!preview.error) {
        preview.error = {
          code: "preview_socket_closed",
          message: "The preview socket closed.",
          retryable: true
        };
      }
      if (!preview.session) {
        requestPreviewFrameDraw();
      }
      requestPreviewOverlayDraw();
      schedulePreviewReconnect();
    }
  });
}

function handlePreviewTextMessage(text) {
  let message;
  try {
    message = JSON.parse(text);
  } catch {
    return;
  }

  if (!message || typeof message.type !== "string") {
    return;
  }

  if (message.type === "hello") {
    preview.error = null;
    requestPreviewOverlayDraw();
    return;
  }
  if (message.type === "session") {
    preview.error = null;
    const previousSession = preview.session;
    preview.session = {
      width: Math.max(1, toNumber(message.width, 1)),
      height: Math.max(1, toNumber(message.height, 1)),
      tileSize: Math.max(1, toNumber(message.tile_size, 256)),
      tilesX: Math.max(1, toNumber(message.tiles_x, 1)),
      tilesY: Math.max(1, toNumber(message.tiles_y, 1)),
      generation: toNumber(message.generation, 0),
      lodMaxDim: Math.max(0, toNumber(message.lod_max_dim, 0))
    };
    preview.layout = null;
    ensureAtlasSize(preview.session.width, preview.session.height);
    if (message.reset) {
      clearAtlas();
      requestPreviewFrameDraw();
    }
    if (!message.reset && (!previousSession
      || previousSession.width !== preview.session.width
      || previousSession.height !== preview.session.height
      || previousSession.tileSize !== preview.session.tileSize
      || previousSession.generation !== preview.session.generation)) {
      requestPreviewFrameDraw();
    }
    requestPreviewOverlayDraw();
    return;
  }
  if (message.type === "cursor") {
    const previousAttached = state.connected;
    const nextAttached = !!message.attached;
    preview.cursor = {
      x: toNumber(message.x, 0),
      y: toNumber(message.y, 0),
      thumbWidth: Math.max(0, toNumber(message.thumb_width, 0)),
      thumbHeight: Math.max(0, toNumber(message.thumb_height, 0)),
      attached: nextAttached
    };
    state.connected = nextAttached;
    if (preview.cursor.thumbWidth > 0 && preview.cursor.thumbHeight > 0) {
      state.thumbWidthValue = preview.cursor.thumbWidth;
      state.thumbHeightValue = preview.cursor.thumbHeight;
      state.thumbSize = formatSize(state.thumbWidthValue, state.thumbHeightValue);
    }
    if (previousAttached !== nextAttached) {
      renderStatus();
      renderFields();
      renderPreviewChrome();
    }
    requestPreviewOverlayDraw();
    return;
  }
  if (message.type === "error") {
    preview.error = {
      code: message.code || "preview_error",
      message: message.message || "Preview error.",
      retryable: message.retryable !== false
    };
    logPreviewEventThrottled(preview.error.message);
    if (!preview.session) {
      requestPreviewFrameDraw();
    }
    requestPreviewOverlayDraw();
  }
}

function applyPreviewTilePacket(buffer) {
  if (!(buffer instanceof ArrayBuffer) || buffer.byteLength < previewTileHeaderBytes) {
    return;
  }

  const bytes = new Uint8Array(buffer);
  const magic = String.fromCharCode(bytes[0], bytes[1], bytes[2], bytes[3]);
  if (magic !== "RST1") {
    return;
  }

  const view = new DataView(buffer);
  const version = view.getUint16(4, true);
  const kind = view.getUint16(6, true);
  if (version !== 1 || kind !== 1) {
    return;
  }

  const flags = view.getUint32(8, true);
  const generation = view.getInt32(12, true);
  const tileX = view.getInt32(24, true);
  const tileY = view.getInt32(28, true);
  const width = view.getInt32(32, true);
  const height = view.getInt32(36, true);
  const stride = view.getInt32(40, true);
  const payloadBytes = view.getUint32(44, true);

  if (flags & previewTileFlags.reset) {
    clearAtlas();
  }

  if (!preview.session || generation !== preview.session.generation) {
    if (flags & previewTileFlags.present) {
      requestPreviewFrameDraw();
    }
    return;
  }

  let appliedTile = false;
  if (payloadBytes > 0 && previewTileHeaderBytes + payloadBytes <= buffer.byteLength) {
    putPreviewTile(buffer, previewTileHeaderBytes, payloadBytes, tileX, tileY, width, height, stride);
    appliedTile = true;
  }

  if (appliedTile) {
    requestPreviewFrameDraw();
  }
  if (flags & previewTileFlags.present) {
    requestPreviewFrameDraw();
  }
}

function putPreviewTile(buffer, payloadOffset, payloadBytes, tileX, tileY, width, height, stride) {
  if (!preview.session || width <= 0 || height <= 0) {
    return;
  }
  if (stride < width * 4) {
    return;
  }
  const requiredBytes = stride * height;
  if (requiredBytes <= 0 || payloadBytes < requiredBytes) {
    return;
  }

  ensureAtlasSize(preview.session.width, preview.session.height);
  const destinationX = tileX * preview.session.tileSize;
  const destinationY = tileY * preview.session.tileSize;
  let rgba = null;

  if (stride === width * 4) {
    rgba = new Uint8ClampedArray(buffer, payloadOffset, payloadBytes);
  } else {
    rgba = new Uint8ClampedArray(width * height * 4);
    const source = new Uint8Array(buffer, payloadOffset, payloadBytes);
    for (let row = 0; row < height; row += 1) {
      const sourceOffset = row * stride;
      const targetOffset = row * width * 4;
      rgba.set(source.subarray(sourceOffset, sourceOffset + width * 4), targetOffset);
    }
  }

  const imageData = new ImageData(rgba, width, height);
  preview.atlasCtx.putImageData(imageData, destinationX, destinationY);
}

