﻿function bindHostResizeGrip(el, message) {
  if (!el) {
    return;
  }

  el.addEventListener("pointerdown", (event) => {
    if (event.button !== 0 || !event.isPrimary) {
      return;
    }

    event.preventDefault();
    postHostMessage(message, "Window resize grips are only available in the desktop WebView host.");
  });
}

function bindControls() {
  const bindHostDragHandle = (el) => {
    if (!el) {
      return;
    }

    el.addEventListener("pointerdown", (event) => {
      if (event.button !== 0 || !event.isPrimary) {
        return;
      }

      const interactiveTarget = event.target instanceof Element
        ? event.target.closest("button, input, select, textarea, a, label, summary, [role='button'], [data-host-drag-ignore='true']")
        : null;
      if (interactiveTarget) {
        return;
      }

      const bridge = getHostBridge();
      if (!bridge) {
        return;
      }

      event.preventDefault();
      bridge.postMessage("host:drag-move");
    });
  };

  bindHostDragHandle(els.masthead);
  document.querySelectorAll(".card").forEach((card) => {
    bindHostDragHandle(card);
  });

  els.topRecordButton.addEventListener("click", () => {
    void runtime.provider.toggleRecording();
  });
  if (els.overlayRecordButton) {
    els.overlayRecordButton.addEventListener("click", () => {
      void runtime.provider.toggleRecording();
    });
  }
  if (els.hostBackdropButton) {
    els.hostBackdropButton.addEventListener("click", () => {
      postHostMessage("host:cycle-backdrop-mode", "Host backdrop switching is only available in the desktop WebView host.");
    });
  }
  if (els.closeWindowButton) {
    els.closeWindowButton.addEventListener("click", () => {
      postHostMessage("host:close-window", "Window close is only available in the desktop WebView host.");
    });
  }
  if (els.commandLauncherButton) {
    els.commandLauncherButton.addEventListener("click", () => {
      const rect = els.commandLauncherButton.getBoundingClientRect();
      postHostCommand("open-search-command-window", {
        anchorRect: {
          left: rect.left,
          top: rect.top,
          right: rect.right,
          bottom: rect.bottom,
          width: rect.width,
          height: rect.height
        }
      }, "Search commands are only available in the desktop WebView host.");
    });
  }
  const openAnchoredWindow = (command, el, unavailableLog) => {
    if (!el) {
      return false;
    }

    const rect = el.getBoundingClientRect();
    return postHostCommand(command, {
      anchorRect: {
        left: rect.left,
        top: rect.top,
        right: rect.right,
        bottom: rect.bottom,
        width: rect.width,
        height: rect.height
      }
    }, unavailableLog);
  };
  bindHostResizeGrip(els.windowResizeBottomLeftButton, "host:resize-bottom-left");
  bindHostResizeGrip(els.windowResizeBottomRightButton, "host:resize-bottom-right");
  els.themeToggleButton.addEventListener("click", toggleThemeMode);
  if (els.volumeModeButton) {
    els.volumeModeButton.addEventListener("click", cycleVolumeMode);
  }
  els.volumeMetricPanel.addEventListener("click", cycleVolumeMode);
  els.volumeMetricPanel.addEventListener("keydown", (event) => {
    if (event.key === "Enter" || event.key === " ") {
      event.preventDefault();
      cycleVolumeMode();
    }
  });

  els.clearLogButton.addEventListener("click", () => {
    state.activityLog = [];
    renderLog();
  });

  const applyHostSetting = (command, value, applyState) => {
    if (!postHostCommand(command, { value })) {
      return false;
    }

    applyState(value);
    render();
    return true;
  };

  els.savePathInput.addEventListener("change", () => {
    const next = els.savePathInput.value.trim() || state.savePath || defaultState.savePath;
    if (applyHostSetting("set-save-root", next, (resolvedValue) => {
      state.savePath = resolvedValue;
    })) {
      return;
    }
    void runtime.provider.updateRecordConfig({ save_root: next }, `Save path updated to ${next}.`);
  });
  if (els.recordingPresetSelect) {
    els.recordingPresetSelect.addEventListener("change", () => {
      const next = els.recordingPresetSelect.value;
      if (!next) {
        return;
      }

      if (postHostCommand("recording-preset-activate", { preset_id: next })) {
        state.currentPresetId = next;
        render();
        return;
      }

      void runtime.provider.activateRecordingPreset(next);
    });
  }

  els.alwaysOnTopToggle.addEventListener("change", () => {
    if (applyHostSetting("set-always-on-top", els.alwaysOnTopToggle.checked, (resolvedValue) => {
      state.alwaysOnTop = resolvedValue;
    })) {
      return;
    }
    state.alwaysOnTop = els.alwaysOnTopToggle.checked;
    addLog(`Always-on-top changed to ${state.alwaysOnTop}.`);
    render();
  });
  els.autoLaunchToggle.addEventListener("change", () => {
    if (applyHostSetting("set-auto-launch-sai", els.autoLaunchToggle.checked, (resolvedValue) => {
      state.autoLaunch = resolvedValue;
    })) {
      return;
    }
    state.autoLaunch = els.autoLaunchToggle.checked;
    addLog(`Auto-launch changed to ${state.autoLaunch}.`);
    render();
  });
  els.doNotMinimizeToTrayToggle.addEventListener("change", () => {
    if (applyHostSetting("set-do-not-minimize-to-tray", els.doNotMinimizeToTrayToggle.checked, (resolvedValue) => {
      state.doNotMinimizeToTray = resolvedValue;
    })) {
      return;
    }
    state.doNotMinimizeToTray = els.doNotMinimizeToTrayToggle.checked;
    addLog(`Do-not-minimize changed to ${state.doNotMinimizeToTray}.`);
    render();
  });
  els.navigatorResizeToggle.addEventListener("change", () => {
    if (applyHostSetting("set-navigator-auto-resize", els.navigatorResizeToggle.checked, (resolvedValue) => {
      state.navigatorAutoResize = resolvedValue;
    })) {
      return;
    }
    state.navigatorAutoResize = els.navigatorResizeToggle.checked;
    addLog(`Navigator auto-resize changed to ${state.navigatorAutoResize}.`);
    render();
  });
  els.updateChannelSelect.addEventListener("change", () => {
    if (applyHostSetting("set-update-channel", els.updateChannelSelect.value, (resolvedValue) => {
      state.updateChannel = resolvedValue === "beta" ? "beta" : "stable";
    })) {
      return;
    }
    state.updateChannel = els.updateChannelSelect.value;
    addLog(`Update channel changed to ${state.updateChannel}.`);
    render();
  });
  els.customBrushOverlayToggle.addEventListener("change", () => {
    if (applyHostSetting("set-custom-brush-overlay", els.customBrushOverlayToggle.checked, (resolvedValue) => {
      state.customBrushOverlay = resolvedValue;
    })) {
      return;
    }
    state.customBrushOverlay = els.customBrushOverlayToggle.checked;
    addLog(`Custom brush overlay changed to ${state.customBrushOverlay}.`);
    render();
  });
  els.previewDeveloperModeToggle.addEventListener("change", () => {
    if (applyHostSetting("set-preview-developer-mode", els.previewDeveloperModeToggle.checked, (resolvedValue) => {
      state.previewDeveloperMode = resolvedValue;
    })) {
      return;
    }
    state.previewDeveloperMode = els.previewDeveloperModeToggle.checked;
    addLog(`Preview developer mode changed to ${state.previewDeveloperMode}.`);
    render();
  });
  els.runtimeSurfaceFixedRefreshToggle.addEventListener("change", () => {
    if (applyHostSetting("set-runtime-surface-fixed-refresh", els.runtimeSurfaceFixedRefreshToggle.checked, (resolvedValue) => {
      state.runtimeSurfaceFixedRefresh = resolvedValue;
    })) {
      return;
    }
    state.runtimeSurfaceFixedRefresh = els.runtimeSurfaceFixedRefreshToggle.checked;
    addLog(`Runtime Surface fixed refresh changed to ${state.runtimeSurfaceFixedRefresh}.`);
    render();
  });
  els.previewTileFrameSyncToggle.addEventListener("change", () => {
    if (applyHostSetting("set-preview-tile-frame-sync", els.previewTileFrameSyncToggle.checked, (resolvedValue) => {
      state.previewTileFrameSync = resolvedValue;
    })) {
      return;
    }
    state.previewTileFrameSync = els.previewTileFrameSyncToggle.checked;
    addLog(`Tile frame sync changed to ${state.previewTileFrameSync}.`);
    render();
  });
  els.statusLightGroupToggle.addEventListener("change", () => {
    if (applyHostSetting("set-status-light-group", els.statusLightGroupToggle.checked, (resolvedValue) => {
      state.statusLightGroupVisible = resolvedValue;
    })) {
      return;
    }
    state.statusLightGroupVisible = els.statusLightGroupToggle.checked;
    addLog(`Status lights changed to ${state.statusLightGroupVisible}.`);
    render();
  });

  els.browsePathButton.addEventListener("click", () => {
    postHostCommand("choose-save-root", null, "Path browsing is only available in the desktop WebView host.");
  });
  els.openFolderButton.addEventListener("click", () => {
    if (postHostCommand("open-save-root", null, "Open folder is only available in the desktop WebView host.")) {
      return;
    }
    addLog(`Open output folder: ${state.savePath || "(empty)"}.`);
  });
  els.recordingSettingsButton.addEventListener("click", () => {
    postHostCommand("recording-preset-window", null, "Recording preset window is only available in the desktop WebView host.");
  });
  els.toggleSettingsButton.addEventListener("click", () => {
    postHostCommand("toggle-settings", null, "Recsai settings are only available in the desktop WebView host.");
  });
  els.launchSaiButton.addEventListener("click", () => {
    postHostCommand("launch-sai2", null, "Launch SAI2 is only available in the desktop WebView host.");
  });
  els.quickExportButton.addEventListener("click", () => {
    postHostCommand("quick-export", null, "Quick export is only available in the desktop WebView host.");
  });
  els.projectListButton.addEventListener("click", () => {
    openAnchoredWindow("open-project-list-window", els.projectListButton, "Project list is only available in the desktop WebView host.");
  });
  els.historyListButton.addEventListener("click", () => {
    openAnchoredWindow("open-history-list-window", els.historyListButton, "History list is only available in the desktop WebView host.");
  });
  els.checkUpdateButton.addEventListener("click", () => {
    if (postHostCommand("open-update-center", null, "Update center is only available in the desktop WebView host.")) {
      return;
    }
    addLog(`Manual update check requested on the ${state.updateChannel} channel.`);
  });
  els.diagnosticsButton.addEventListener("click", () => {
    postHostCommand("export-diagnostics", null, "Diagnostics export is only available in the desktop WebView host.");
  });
  els.unregisterButton.addEventListener("click", () => {
    postHostCommand("unregister-recsai-association", null, "The .recsai unregister action is only available in the desktop WebView host.");
  });
}

function bindHostBridge() {
  const bridge = getHostBridge();
  if (!bridge || typeof bridge.addEventListener !== "function") {
    return;
  }

  bridge.addEventListener("message", (event) => {
    const data = event.data;
    if (typeof data === "string") {
      if (!els.hostBackdropButton) {
        return;
      }

      const prefix = "host:backdrop-mode:";
      if (!data.startsWith(prefix)) {
        return;
      }

      const label = data.slice(prefix.length).trim() || "Unknown";
      els.hostBackdropButton.textContent = `FX: ${label}`;
      els.hostBackdropButton.title = label;
      return;
    }

    if (!data || typeof data !== "object") {
      return;
    }

    if (data.kind === "webui-state") {
      applyHostState(data.state);
      render();
      return;
    }

    if (data.kind === "webui-ack" && typeof data.message === "string" && data.message.trim()) {
      addLog(data.message.trim());
    }
  });

  postHostCommand("sync-state");
}

function attachTilt(el, maxTilt, lift) {
  if (!el) {
    return;
  }

  const reduceMotion = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
  const finePointer = window.matchMedia("(pointer: fine)").matches;
  if (reduceMotion || !finePointer) {
    return;
  }

  let raf = 0;
  const reset = () => {
    el.style.setProperty("--rx", "0deg");
    el.style.setProperty("--ry", "0deg");
    el.style.setProperty("--lift", "0px");
  };

  el.addEventListener("pointermove", (event) => {
    if (event.pointerType && event.pointerType !== "mouse" && event.pointerType !== "pen") {
      return;
    }
    if (raf) {
      return;
    }

    raf = window.requestAnimationFrame(() => {
      const rect = el.getBoundingClientRect();
      const x = clamp(event.clientX - rect.left, 0, rect.width);
      const y = clamp(event.clientY - rect.top, 0, rect.height);
      const dx = rect.width > 0 ? (x / rect.width) * 2 - 1 : 0;
      const dy = rect.height > 0 ? (y / rect.height) * 2 - 1 : 0;
      el.style.setProperty("--ry", `${(dx * maxTilt).toFixed(2)}deg`);
      el.style.setProperty("--rx", `${(-dy * maxTilt).toFixed(2)}deg`);
      if (lift) {
        el.style.setProperty("--lift", lift);
      }
      raf = 0;
    });
  });

  el.addEventListener("pointerleave", () => {
    if (raf) {
      window.cancelAnimationFrame(raf);
      raf = 0;
    }
    reset();
  });

  el.addEventListener("pointercancel", reset);
}

function attachGlowDrift(el, options) {
  if (!el) {
    return;
  }

  const reduceMotion = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
  const settings = {
    defaultX: options && typeof options.defaultX === "number" ? options.defaultX : 50,
    defaultY: options && typeof options.defaultY === "number" ? options.defaultY : 50,
    inverse: !!(options && options.inverse),
    minX: options && typeof options.minX === "number" ? options.minX : 0,
    maxX: options && typeof options.maxX === "number" ? options.maxX : 100,
    minY: options && typeof options.minY === "number" ? options.minY : 0,
    maxY: options && typeof options.maxY === "number" ? options.maxY : 100,
    clampMin: options && typeof options.clampMin === "number" ? options.clampMin : -50,
    clampMax: options && typeof options.clampMax === "number" ? options.clampMax : 150,
    dynamicBounds: !!(options && options.dynamicBounds),
    radiusScale: options && typeof options.radiusScale === "number" ? options.radiusScale : 0.38
  };
  const glowState = {
    currentX: settings.defaultX,
    currentY: settings.defaultY,
    targetX: settings.defaultX,
    targetY: settings.defaultY,
    raf: 0
  };

  const geometryState = {
    width: 0,
    height: 0,
    radius: 0
  };

  const getDefaultNormalizedPoint = () => ({
    x: clamp(settings.defaultX / 100, 0, 1),
    y: clamp(settings.defaultY / 100, 0, 1)
  });

  const getDynamicRange = (geometry) => ({
    minX: -geometry.radius,
    maxX: geometry.width + geometry.radius,
    minY: -geometry.radius,
    maxY: geometry.height + geometry.radius,
    spanX: geometry.width + (geometry.radius * 2),
    spanY: geometry.height + (geometry.radius * 2)
  });

  const updateDynamicGeometry = () => {
    const rect = el.getBoundingClientRect();
    geometryState.width = Math.max(0, rect.width);
    geometryState.height = Math.max(0, rect.height);
    geometryState.radius = Math.max(0, Math.hypot(geometryState.width, geometryState.height) * settings.radiusScale);
    el.style.setProperty("--glow-radius", `${geometryState.radius.toFixed(2)}px`);
    return rect;
  };

  const getNormalizedDynamicPoint = (x, y, geometry) => {
    const defaults = getDefaultNormalizedPoint();
    const range = getDynamicRange(geometry);
    return {
      x: range.spanX > 0 ? clamp((x - range.minX) / range.spanX, 0, 1) : defaults.x,
      y: range.spanY > 0 ? clamp((y - range.minY) / range.spanY, 0, 1) : defaults.y
    };
  };

  const getDynamicPointFromNormalized = (normalizedX, normalizedY, geometry) => {
    const defaults = getDefaultNormalizedPoint();
    const range = getDynamicRange(geometry);
    const safeX = Number.isFinite(normalizedX) ? clamp(normalizedX, 0, 1) : defaults.x;
    const safeY = Number.isFinite(normalizedY) ? clamp(normalizedY, 0, 1) : defaults.y;
    return {
      x: range.minX + (range.spanX * safeX),
      y: range.minY + (range.spanY * safeY)
    };
  };

  const setGlow = (xPercent, yPercent) => {
    if (settings.dynamicBounds) {
      el.style.setProperty("--glow-x", `${xPercent.toFixed(2)}px`);
      el.style.setProperty("--glow-y", `${yPercent.toFixed(2)}px`);
      return;
    }

    el.style.setProperty("--glow-x", `${clamp(xPercent, settings.clampMin, settings.clampMax).toFixed(2)}%`);
    el.style.setProperty("--glow-y", `${clamp(yPercent, settings.clampMin, settings.clampMax).toFixed(2)}%`);
  };

  const stopAnimation = () => {
    if (glowState.raf) {
      window.cancelAnimationFrame(glowState.raf);
      glowState.raf = 0;
    }
  };

  const animateGlow = () => {
    glowState.raf = 0;

    const dx = glowState.targetX - glowState.currentX;
    const dy = glowState.targetY - glowState.currentY;
    if (Math.abs(dx) < 0.03 && Math.abs(dy) < 0.03) {
      glowState.currentX = glowState.targetX;
      glowState.currentY = glowState.targetY;
      setGlow(glowState.currentX, glowState.currentY);
      return;
    }

    glowState.currentX += dx * 0.06;
    glowState.currentY += dy * 0.06;
    setGlow(glowState.currentX, glowState.currentY);
    glowState.raf = window.requestAnimationFrame(animateGlow);
  };

  const syncDynamicGeometry = () => {
    const previousGeometry = {
      width: geometryState.width,
      height: geometryState.height,
      radius: geometryState.radius
    };
    const currentNormalized = getNormalizedDynamicPoint(glowState.currentX, glowState.currentY, previousGeometry);
    const targetNormalized = getNormalizedDynamicPoint(glowState.targetX, glowState.targetY, previousGeometry);

    updateDynamicGeometry();

    const currentPoint = getDynamicPointFromNormalized(currentNormalized.x, currentNormalized.y, geometryState);
    const targetPoint = getDynamicPointFromNormalized(targetNormalized.x, targetNormalized.y, geometryState);
    glowState.currentX = currentPoint.x;
    glowState.currentY = currentPoint.y;
    glowState.targetX = targetPoint.x;
    glowState.targetY = targetPoint.y;
    setGlow(glowState.currentX, glowState.currentY);
  };

  const updateGlowTarget = (xPercent, yPercent) => {
    if (settings.dynamicBounds) {
      const range = getDynamicRange(geometryState);
      glowState.targetX = clamp(xPercent, range.minX, range.maxX);
      glowState.targetY = clamp(yPercent, range.minY, range.maxY);
    } else {
      glowState.targetX = clamp(xPercent, settings.clampMin, settings.clampMax);
      glowState.targetY = clamp(yPercent, settings.clampMin, settings.clampMax);
    }

    if (reduceMotion) {
      glowState.currentX = glowState.targetX;
      glowState.currentY = glowState.targetY;
      setGlow(glowState.currentX, glowState.currentY);
      return;
    }

    if (!glowState.raf) {
      glowState.raf = window.requestAnimationFrame(animateGlow);
    }
  };

  const reset = () => {
    if (settings.dynamicBounds) {
      syncDynamicGeometry();
      const defaultNormalized = getDefaultNormalizedPoint();
      const defaultPoint = getDynamicPointFromNormalized(defaultNormalized.x, defaultNormalized.y, geometryState);
      updateGlowTarget(defaultPoint.x, defaultPoint.y);
      return;
    }

    updateGlowTarget(settings.defaultX, settings.defaultY);
  };

  if (settings.dynamicBounds) {
    updateDynamicGeometry();
    const defaultNormalized = getDefaultNormalizedPoint();
    const defaultPoint = getDynamicPointFromNormalized(defaultNormalized.x, defaultNormalized.y, geometryState);
    glowState.currentX = defaultPoint.x;
    glowState.currentY = defaultPoint.y;
    glowState.targetX = defaultPoint.x;
    glowState.targetY = defaultPoint.y;
    setGlow(defaultPoint.x, defaultPoint.y);
  } else {
    setGlow(settings.defaultX, settings.defaultY);
  }

  el.addEventListener("pointermove", (event) => {
    if (event.pointerType && event.pointerType !== "mouse" && event.pointerType !== "pen") {
      return;
    }

    const rect = el.getBoundingClientRect();
    if (settings.dynamicBounds && (rect.width !== geometryState.width || rect.height !== geometryState.height)) {
      syncDynamicGeometry();
    }
    if (rect.width <= 0 || rect.height <= 0) {
      return;
    }

    const pointerX = rect.width > 0 ? (clamp(event.clientX - rect.left, 0, rect.width) / rect.width) : 0.5;
    const pointerY = rect.height > 0 ? (clamp(event.clientY - rect.top, 0, rect.height) / rect.height) : 0.5;
    const normalizedX = settings.inverse ? 1 - pointerX : pointerX;
    const normalizedY = settings.inverse ? 1 - pointerY : pointerY;
    const mappedPoint = settings.dynamicBounds
      ? getDynamicPointFromNormalized(normalizedX, normalizedY, geometryState)
      : {
        x: settings.minX + ((settings.maxX - settings.minX) * normalizedX),
        y: settings.minY + ((settings.maxY - settings.minY) * normalizedY)
      };
    const glowX = mappedPoint.x;
    const glowY = mappedPoint.y;
    updateGlowTarget(glowX, glowY);
  });

  el.addEventListener("pointerleave", reset);
  el.addEventListener("pointercancel", reset);

  if (settings.dynamicBounds && typeof ResizeObserver === "function") {
    const resizeObserver = new ResizeObserver(() => {
      syncDynamicGeometry();
    });
    resizeObserver.observe(el);
  }

  if (!reduceMotion) {
    el.addEventListener("blur", reset);
  } else {
    stopAnimation();
  }
}

function attachAmbientSurfaceMotion(el, options) {
  if (!el) {
    return;
  }

  attachTilt(el, options.tiltMax, options.lift);
  attachGlowDrift(el, options.glow);
}

function initAmbientMotion() {
  document.querySelectorAll(".card").forEach((card) => {
    attachAmbientSurfaceMotion(card, {
      tiltMax: 3.5,
      lift: "-2px",
      glow: {
        defaultX: 68,
        defaultY: 32,
        inverse: true,
        dynamicBounds: true,
        radiusScale: 1.14
      }
    });
  });
  const masthead = document.querySelector(".masthead");
  attachAmbientSurfaceMotion(masthead, {
    tiltMax: 4.5,
    lift: "-1px",
    glow: {
      defaultX: 15,
      defaultY: 10,
      inverse: true,
      dynamicBounds: true,
      radiusScale: 1.14
    }
  });
}

async function init() {
  initCustomSelects();
  bindHostBridge();
  bindControls();
  bindPreviewSurface();
  bindPageScrollFade();
  initAmbientMotion();
  renderLog();
  render();
  drawPreview();

  runtime.provider = window.location.protocol === "file:" ? createMockProvider() : createHttpProvider();
  await runtime.provider.init();
}

void init();
