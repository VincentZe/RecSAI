﻿(function () {
  const scrollFadeThresholdPx = 3;
  const closeAnimationDurationMs = 180;
  const hostRequestCloseWindowMessage = "host:request-close-window";
  const hostWindowShownMessage = "host:window-shown";
  const hostCloseWindowMessage = "host:close-window";

  const state = {
    commands: [],
    filteredCommands: [],
    query: "",
    selectedIndex: -1,
    isClosing: false,
    closeTimerId: 0
  };

  const els = {
    commandWindow: document.getElementById("commandWindow"),
    commandCard: document.getElementById("commandCard"),
    commandDragHandle: document.getElementById("commandDragHandle"),
    commandSearchInput: document.getElementById("commandSearchInput"),
    favoriteSection: document.getElementById("favoriteSection"),
    favoriteChips: document.getElementById("favoriteChips"),
    resultMeta: document.getElementById("resultMeta"),
    commandList: document.getElementById("commandList"),
    commandEmpty: document.getElementById("commandEmpty")
  };

  function getHostBridge() {
    const bridge = window.chrome && window.chrome.webview;
    if (!bridge || typeof bridge.postMessage !== "function") {
      return null;
    }

    return bridge;
  }

  function postHostMessage(message) {
    const bridge = getHostBridge();
    if (!bridge) {
      return false;
    }

    bridge.postMessage(message);
    return true;
  }

  function postHostCommand(command, payload) {
    const bridge = getHostBridge();
    if (!bridge) {
      return false;
    }

    bridge.postMessage(JSON.stringify({
      kind: "webui-command",
      command,
      payload: payload && typeof payload === "object" ? payload : {}
    }));
    return true;
  }

  function clamp(value, min, max) {
    return Math.max(min, Math.min(max, value));
  }

  function compareByFavorite(left, right) {
    const leftFavorite = !!left.is_favorite;
    const rightFavorite = !!right.is_favorite;
    if (leftFavorite !== rightFavorite) {
      return leftFavorite ? -1 : 1;
    }

    const leftOrder = Number.isFinite(left.favorite_order) ? left.favorite_order : Number.MAX_SAFE_INTEGER;
    const rightOrder = Number.isFinite(right.favorite_order) ? right.favorite_order : Number.MAX_SAFE_INTEGER;
    if (leftOrder !== rightOrder) {
      return leftOrder - rightOrder;
    }

    return String(left.title || "").localeCompare(String(right.title || ""), "zh-CN");
  }

  function normalizeCommands(commands) {
    if (!Array.isArray(commands)) {
      return [];
    }

    return commands
      .filter((command) => command && typeof command === "object" && typeof command.id === "string" && command.id.trim())
      .map((command) => ({
        id: command.id.trim(),
        title: typeof command.title === "string" ? command.title.trim() : "",
        search_text: typeof command.search_text === "string" ? command.search_text.trim() : "",
        icon_text: typeof command.icon_text === "string" ? command.icon_text.trim() : "",
        shortcut_text: typeof command.shortcut_text === "string" ? command.shortcut_text.trim() : "",
        is_favorite: !!command.is_favorite,
        favorite_order: Number.isFinite(Number(command.favorite_order)) ? Number(command.favorite_order) : -1
      }))
      .sort(compareByFavorite);
  }

  function getSelectedCommandId() {
    if (state.selectedIndex < 0 || state.selectedIndex >= state.filteredCommands.length) {
      return "";
    }

    return state.filteredCommands[state.selectedIndex].id;
  }

  function filterCommands(preferredSelectedId) {
    const query = (state.query || "").trim().toLowerCase();
    state.filteredCommands = state.commands.filter((command) => {
      if (!query) {
        return true;
      }

      return String(command.search_text || command.title || "")
        .toLowerCase()
        .indexOf(query) >= 0;
    });

    if (state.filteredCommands.length === 0) {
      state.selectedIndex = -1;
      return;
    }

    if (preferredSelectedId) {
      const nextIndex = state.filteredCommands.findIndex((command) => command.id === preferredSelectedId);
      if (nextIndex >= 0) {
        state.selectedIndex = nextIndex;
        return;
      }
    }

    if (state.selectedIndex < 0 || state.selectedIndex >= state.filteredCommands.length) {
      state.selectedIndex = 0;
    }
  }

  function applyState(payload) {
    const previousSelectedId = getSelectedCommandId();
    state.commands = normalizeCommands(payload && payload.commands);
    filterCommands(previousSelectedId);
    render();
  }

  function updateScrollFade() {
    const scrollRoot = els.commandList;
    if (!scrollRoot) {
      return;
    }

    const scrollTop = Math.max(0, scrollRoot.scrollTop || 0);
    const maxScrollTop = Math.max(0, (scrollRoot.scrollHeight || 0) - (scrollRoot.clientHeight || 0));
    const hasTopFade = scrollTop > scrollFadeThresholdPx;
    const hasBottomFade = maxScrollTop - scrollTop > scrollFadeThresholdPx;

    let nextFadeClass = "scroll-fade-none";
    if (hasTopFade && hasBottomFade) {
      nextFadeClass = "scroll-fade-both";
    } else if (hasTopFade) {
      nextFadeClass = "scroll-fade-top";
    } else if (hasBottomFade) {
      nextFadeClass = "scroll-fade-bottom";
    }

    scrollRoot.classList.remove("scroll-fade-none", "scroll-fade-top", "scroll-fade-bottom", "scroll-fade-both");
    scrollRoot.classList.add(nextFadeClass);
  }

  function ensureSelectedVisible() {
    if (state.selectedIndex < 0) {
      return;
    }

    const row = els.commandList.querySelector(`[data-command-index="${state.selectedIndex}"]`);
    if (row) {
      row.scrollIntoView({ block: "nearest" });
    }
  }

  function beginCloseSequence() {
    if (state.isClosing) {
      return;
    }

    state.isClosing = true;
    if (state.closeTimerId) {
      window.clearTimeout(state.closeTimerId);
    }

    if (els.commandWindow) {
      els.commandWindow.classList.add("is-closing");
    }

    state.closeTimerId = window.setTimeout(() => {
      state.closeTimerId = 0;
      postHostMessage(hostCloseWindowMessage);
    }, closeAnimationDurationMs);
  }

  function resetWindowState() {
    state.isClosing = false;
    if (state.closeTimerId) {
      window.clearTimeout(state.closeTimerId);
      state.closeTimerId = 0;
    }

    if (els.commandWindow) {
      els.commandWindow.classList.remove("is-closing");
      els.commandWindow.classList.remove("is-ready");
      window.requestAnimationFrame(() => {
        els.commandWindow.classList.add("is-ready");
      });
    }

    if (els.commandSearchInput) {
      window.requestAnimationFrame(() => {
        els.commandSearchInput.focus();
        els.commandSearchInput.select();
      });
    }

    updateScrollFade();
  }

  function executeCommand(commandId) {
    if (!commandId) {
      return;
    }

    if (postHostCommand("search-command-execute", { value: commandId })) {
      beginCloseSequence();
    }
  }

  function toggleFavorite(commandId) {
    if (!commandId) {
      return;
    }

    postHostCommand("search-command-toggle-favorite", { value: commandId });
  }

  function assignShortcut(commandId) {
    if (!commandId) {
      return;
    }

    postHostCommand("search-command-assign-shortcut", { value: commandId });
  }

  function escapeHtml(text) {
    return String(text == null ? "" : text)
      .replace(/&/g, "&amp;")
      .replace(/</g, "&lt;")
      .replace(/>/g, "&gt;")
      .replace(/"/g, "&quot;")
      .replace(/'/g, "&#39;");
  }

  function buildFavoriteChips() {
    els.favoriteChips.innerHTML = "";
    const favorites = state.commands.filter((command) => command.is_favorite).sort(compareByFavorite);
    els.favoriteSection.hidden = favorites.length === 0;

    favorites.forEach((command) => {
      const button = document.createElement("button");
      button.className = "favorite-chip";
      button.type = "button";
      button.dataset.commandId = command.id;
      button.innerHTML = `
        <span>${escapeHtml(command.title || command.id)}</span>
        ${command.shortcut_text ? `<span class="favorite-chip-shortcut">${escapeHtml(command.shortcut_text)}</span>` : ""}
      `;
      button.addEventListener("click", () => executeCommand(command.id));
      els.favoriteChips.appendChild(button);
    });
  }

  function buildCommandRow(command, index) {
    const row = document.createElement("div");
    row.className = "command-row";
    if (index === state.selectedIndex) {
      row.classList.add("is-selected");
    }

    row.dataset.commandIndex = String(index);
    row.dataset.commandId = command.id;
    row.tabIndex = -1;
    row.innerHTML = `
      <div class="command-icon">${escapeHtml(command.icon_text || command.title.slice(0, 2) || "..")}</div>
      <div class="command-body">
        <p class="command-title">${escapeHtml(command.title || command.id)}</p>
        <p class="command-search-text">${escapeHtml(command.search_text || command.id)}</p>
      </div>
      <button class="command-shortcut" type="button">${escapeHtml(command.shortcut_text || "设置快捷键")}</button>
      <button class="command-favorite${command.is_favorite ? " is-active" : ""}" type="button" aria-label="${command.is_favorite ? "取消收藏" : "加入收藏"}"></button>
    `;

    row.addEventListener("mouseenter", () => {
      state.selectedIndex = index;
      syncSelectedStyles();
    });

    row.addEventListener("click", (event) => {
      const favoriteButton = event.target instanceof Element ? event.target.closest(".command-favorite") : null;
      const shortcutButton = event.target instanceof Element ? event.target.closest(".command-shortcut") : null;
      if (favoriteButton || shortcutButton) {
        return;
      }

      executeCommand(command.id);
    });

    const shortcutButton = row.querySelector(".command-shortcut");
    if (shortcutButton) {
      shortcutButton.addEventListener("click", (event) => {
        event.stopPropagation();
        assignShortcut(command.id);
      });
    }

    const favoriteButton = row.querySelector(".command-favorite");
    if (favoriteButton) {
      favoriteButton.addEventListener("click", (event) => {
        event.stopPropagation();
        toggleFavorite(command.id);
      });
    }

    return row;
  }

  function syncSelectedStyles() {
    const rows = els.commandList.querySelectorAll(".command-row");
    rows.forEach((row) => {
      const index = Number(row.getAttribute("data-command-index"));
      row.classList.toggle("is-selected", index === state.selectedIndex);
    });
  }

  function renderList() {
    els.commandList.innerHTML = "";
    els.commandEmpty.hidden = state.filteredCommands.length !== 0;
    els.resultMeta.textContent = `${state.filteredCommands.length} 项`;

    state.filteredCommands.forEach((command, index) => {
      els.commandList.appendChild(buildCommandRow(command, index));
    });

    updateScrollFade();
    ensureSelectedVisible();
  }

  function render() {
    buildFavoriteChips();
    renderList();
  }

  function moveSelection(delta) {
    if (state.filteredCommands.length === 0) {
      state.selectedIndex = -1;
      return;
    }

    let nextIndex = state.selectedIndex < 0 ? 0 : state.selectedIndex + delta;
    if (nextIndex < 0) {
      nextIndex = state.filteredCommands.length - 1;
    } else if (nextIndex >= state.filteredCommands.length) {
      nextIndex = 0;
    }

    state.selectedIndex = clamp(nextIndex, 0, state.filteredCommands.length - 1);
    syncSelectedStyles();
    ensureSelectedVisible();
  }

  function executeSelected() {
    if (state.selectedIndex < 0 || state.selectedIndex >= state.filteredCommands.length) {
      return;
    }

    executeCommand(state.filteredCommands[state.selectedIndex].id);
  }

  function bindHostBridge() {
    const bridge = getHostBridge();
    if (!bridge || typeof bridge.addEventListener !== "function") {
      return;
    }

    bridge.addEventListener("message", (event) => {
      const data = event.data;
      if (typeof data === "string") {
        if (data === hostRequestCloseWindowMessage) {
          beginCloseSequence();
        } else if (data === hostWindowShownMessage) {
          resetWindowState();
        }
        return;
      }

      if (!data || typeof data !== "object") {
        return;
      }

      if (data.kind === "search-command-state") {
        applyState(data.state);
      }
    });

    postHostCommand("search-command-sync");
  }

  function bindDragRegion() {
    const handleDragStart = (event) => {
      if (event.button !== 0 || !event.isPrimary) {
        return;
      }

      const interactiveTarget = event.target instanceof Element
        ? event.target.closest("button, input, select, textarea, a, label, summary, [role='button'], [data-host-drag-ignore='true']")
        : null;
      if (interactiveTarget) {
        return;
      }

      if (postHostMessage("host:drag-move")) {
        event.preventDefault();
      }
    };

    if (els.commandDragHandle) {
      els.commandDragHandle.addEventListener("pointerdown", handleDragStart);
    }

    if (els.commandCard) {
      els.commandCard.addEventListener("pointerdown", handleDragStart);
    }
  }

  function attachGlowDrift(el, options) {
    if (!el) {
      return;
    }

    const reduceMotion = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
    const settings = {
      defaultX: options && typeof options.defaultX === "number" ? options.defaultX : 50,
      defaultY: options && typeof options.defaultY === "number" ? options.defaultY : 50,
      inverse: !!(options && options.inverse),
      minX: options && typeof options.minX === "number" ? options.minX : 0,
      maxX: options && typeof options.maxX === "number" ? options.maxX : 100,
      minY: options && typeof options.minY === "number" ? options.minY : 0,
      maxY: options && typeof options.maxY === "number" ? options.maxY : 100,
      clampMin: options && typeof options.clampMin === "number" ? options.clampMin : -50,
      clampMax: options && typeof options.clampMax === "number" ? options.clampMax : 150,
      dynamicBounds: !!(options && options.dynamicBounds),
      radiusScale: options && typeof options.radiusScale === "number" ? options.radiusScale : 0.38
    };
    const glowState = {
      currentX: settings.defaultX,
      currentY: settings.defaultY,
      targetX: settings.defaultX,
      targetY: settings.defaultY,
      raf: 0
    };
    const geometryState = {
      width: 0,
      height: 0,
      radius: 0
    };

    function getDefaultNormalizedPoint() {
      return {
        x: clamp(settings.defaultX / 100, 0, 1),
        y: clamp(settings.defaultY / 100, 0, 1)
      };
    }

    function getDynamicRange(geometry) {
      return {
        minX: -geometry.radius,
        maxX: geometry.width + geometry.radius,
        minY: -geometry.radius,
        maxY: geometry.height + geometry.radius,
        spanX: geometry.width + (geometry.radius * 2),
        spanY: geometry.height + (geometry.radius * 2)
      };
    }

    function updateDynamicGeometry() {
      const rect = el.getBoundingClientRect();
      geometryState.width = Math.max(0, rect.width);
      geometryState.height = Math.max(0, rect.height);
      geometryState.radius = Math.max(0, Math.hypot(geometryState.width, geometryState.height) * settings.radiusScale);
      el.style.setProperty("--glow-radius", `${geometryState.radius.toFixed(2)}px`);
      return rect;
    }

    function getNormalizedDynamicPoint(x, y, geometry) {
      const defaults = getDefaultNormalizedPoint();
      const range = getDynamicRange(geometry);
      return {
        x: range.spanX > 0 ? clamp((x - range.minX) / range.spanX, 0, 1) : defaults.x,
        y: range.spanY > 0 ? clamp((y - range.minY) / range.spanY, 0, 1) : defaults.y
      };
    }

    function getDynamicPointFromNormalized(normalizedX, normalizedY, geometry) {
      const defaults = getDefaultNormalizedPoint();
      const range = getDynamicRange(geometry);
      const safeX = Number.isFinite(normalizedX) ? clamp(normalizedX, 0, 1) : defaults.x;
      const safeY = Number.isFinite(normalizedY) ? clamp(normalizedY, 0, 1) : defaults.y;
      return {
        x: range.minX + (range.spanX * safeX),
        y: range.minY + (range.spanY * safeY)
      };
    }

    function setGlow(x, y) {
      if (settings.dynamicBounds) {
        el.style.setProperty("--glow-x", `${x.toFixed(2)}px`);
        el.style.setProperty("--glow-y", `${y.toFixed(2)}px`);
        return;
      }

      el.style.setProperty("--glow-x", `${clamp(x, settings.clampMin, settings.clampMax).toFixed(2)}%`);
      el.style.setProperty("--glow-y", `${clamp(y, settings.clampMin, settings.clampMax).toFixed(2)}%`);
    }

    function animateGlow() {
      glowState.raf = 0;
      const dx = glowState.targetX - glowState.currentX;
      const dy = glowState.targetY - glowState.currentY;
      if (Math.abs(dx) < 0.03 && Math.abs(dy) < 0.03) {
        glowState.currentX = glowState.targetX;
        glowState.currentY = glowState.targetY;
        setGlow(glowState.currentX, glowState.currentY);
        return;
      }

      glowState.currentX += dx * 0.06;
      glowState.currentY += dy * 0.06;
      setGlow(glowState.currentX, glowState.currentY);
      glowState.raf = window.requestAnimationFrame(animateGlow);
    }

    function updateGlowTarget(x, y) {
      if (settings.dynamicBounds) {
        const range = getDynamicRange(geometryState);
        glowState.targetX = clamp(x, range.minX, range.maxX);
        glowState.targetY = clamp(y, range.minY, range.maxY);
      } else {
        glowState.targetX = clamp(x, settings.clampMin, settings.clampMax);
        glowState.targetY = clamp(y, settings.clampMin, settings.clampMax);
      }

      if (reduceMotion) {
        glowState.currentX = glowState.targetX;
        glowState.currentY = glowState.targetY;
        setGlow(glowState.currentX, glowState.currentY);
        return;
      }

      if (!glowState.raf) {
        glowState.raf = window.requestAnimationFrame(animateGlow);
      }
    }

    function syncDynamicGeometry() {
      const previousGeometry = {
        width: geometryState.width,
        height: geometryState.height,
        radius: geometryState.radius
      };
      const currentNormalized = getNormalizedDynamicPoint(glowState.currentX, glowState.currentY, previousGeometry);
      const targetNormalized = getNormalizedDynamicPoint(glowState.targetX, glowState.targetY, previousGeometry);
      updateDynamicGeometry();
      const currentPoint = getDynamicPointFromNormalized(currentNormalized.x, currentNormalized.y, geometryState);
      const targetPoint = getDynamicPointFromNormalized(targetNormalized.x, targetNormalized.y, geometryState);
      glowState.currentX = currentPoint.x;
      glowState.currentY = currentPoint.y;
      glowState.targetX = targetPoint.x;
      glowState.targetY = targetPoint.y;
      setGlow(glowState.currentX, glowState.currentY);
    }

    function reset() {
      if (settings.dynamicBounds) {
        syncDynamicGeometry();
        const defaultNormalized = getDefaultNormalizedPoint();
        const defaultPoint = getDynamicPointFromNormalized(defaultNormalized.x, defaultNormalized.y, geometryState);
        updateGlowTarget(defaultPoint.x, defaultPoint.y);
        return;
      }

      updateGlowTarget(settings.defaultX, settings.defaultY);
    }

    if (settings.dynamicBounds) {
      updateDynamicGeometry();
      const defaultNormalized = getDefaultNormalizedPoint();
      const defaultPoint = getDynamicPointFromNormalized(defaultNormalized.x, defaultNormalized.y, geometryState);
      glowState.currentX = defaultPoint.x;
      glowState.currentY = defaultPoint.y;
      glowState.targetX = defaultPoint.x;
      glowState.targetY = defaultPoint.y;
      setGlow(defaultPoint.x, defaultPoint.y);
    } else {
      setGlow(settings.defaultX, settings.defaultY);
    }

    el.addEventListener("pointermove", (event) => {
      if (event.pointerType && event.pointerType !== "mouse" && event.pointerType !== "pen") {
        return;
      }

      const rect = el.getBoundingClientRect();
      if (settings.dynamicBounds && (rect.width !== geometryState.width || rect.height !== geometryState.height)) {
        syncDynamicGeometry();
      }
      if (rect.width <= 0 || rect.height <= 0) {
        return;
      }

      const pointerX = rect.width > 0 ? (clamp(event.clientX - rect.left, 0, rect.width) / rect.width) : 0.5;
      const pointerY = rect.height > 0 ? (clamp(event.clientY - rect.top, 0, rect.height) / rect.height) : 0.5;
      const normalizedX = settings.inverse ? 1 - pointerX : pointerX;
      const normalizedY = settings.inverse ? 1 - pointerY : pointerY;
      const mappedPoint = settings.dynamicBounds
        ? getDynamicPointFromNormalized(normalizedX, normalizedY, geometryState)
        : {
          x: settings.minX + ((settings.maxX - settings.minX) * normalizedX),
          y: settings.minY + ((settings.maxY - settings.minY) * normalizedY)
        };
      updateGlowTarget(mappedPoint.x, mappedPoint.y);
    });

    el.addEventListener("pointerleave", reset);
    el.addEventListener("pointercancel", reset);

    if (settings.dynamicBounds && typeof ResizeObserver === "function") {
      const resizeObserver = new ResizeObserver(() => {
        syncDynamicGeometry();
      });
      resizeObserver.observe(el);
    }

    if (!reduceMotion) {
      el.addEventListener("blur", reset);
    }
  }

  function initAmbientMotion() {
    const contentShell = document.querySelector(".command-content-shell");
    const searchShell = document.querySelector(".command-search");
    attachGlowDrift(contentShell, {
      defaultX: 68,
      defaultY: 32,
      inverse: true,
      dynamicBounds: true,
      radiusScale: 1.14
    });
    attachGlowDrift(searchShell, {
      defaultX: 26,
      defaultY: 44,
      inverse: true,
      dynamicBounds: true,
      radiusScale: 1.06
    });
  }

  function bindEvents() {
    if (els.commandSearchInput) {
      els.commandSearchInput.addEventListener("input", () => {
        state.query = els.commandSearchInput.value || "";
        filterCommands(getSelectedCommandId());
        renderList();
      });

      els.commandSearchInput.addEventListener("keydown", (event) => {
        if (event.key === "ArrowDown") {
          event.preventDefault();
          moveSelection(1);
          return;
        }

        if (event.key === "ArrowUp") {
          event.preventDefault();
          moveSelection(-1);
          return;
        }

        if (event.key === "Enter") {
          event.preventDefault();
          executeSelected();
          return;
        }

        if (event.key === "Escape") {
          event.preventDefault();
          beginCloseSequence();
        }
      });
    }

    if (els.commandList) {
      els.commandList.addEventListener("scroll", updateScrollFade, { passive: true });
    }

    window.addEventListener("resize", updateScrollFade);
  }

  function initWindowAnimation() {
    if (!els.commandWindow) {
      return;
    }

    window.requestAnimationFrame(() => {
      els.commandWindow.classList.add("is-ready");
    });
  }

  function init() {
    document.documentElement.dataset.theme = "light";
    bindEvents();
    bindDragRegion();
    bindHostBridge();
    updateScrollFade();
    initAmbientMotion();
    initWindowAnimation();

    if (els.commandSearchInput) {
      window.requestAnimationFrame(() => {
        els.commandSearchInput.focus();
        els.commandSearchInput.select();
      });
    }
  }

  init();
})();
