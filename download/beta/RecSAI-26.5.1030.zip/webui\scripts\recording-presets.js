﻿(function () {
  const hostWindowShownMessage = "host:window-shown";
  const hostDragMoveMessage = "host:drag-move";
  const hostCloseWindowMessage = "host:close-window";
  const pageScrollFadeThresholdPx = 3;

  const resolutionModeOptions = [
    { value: "highest", label: "固定最高" },
    { value: "long_side", label: "录制长边" }
  ];
  const longSideOptions = [1024, 1536, 2048, 2560, 3072, 4096, 6144, 8192].map((value) => ({
    value: String(value),
    label: String(value)
  }));
  const stepIntervalOptions = [1, 2, 3, 4, 5, 6, 8, 10, 12, 15].map((value) => ({
    value: String(value),
    label: String(value)
  }));
  const codecOptions = [
    { value: "1", label: "Zstd" },
    { value: "5", label: "自适应 JPEG" },
    { value: "6", label: "精简" },
    { value: "2", label: "Lane Zstd" },
    { value: "3", label: "无损" }
  ];
  const qualityOptions = [60, 70, 75, 80, 85, 90, 95, 100].map((value) => ({
    value: String(value),
    label: String(value)
  }));

  const state = {
    version: 1,
    currentPresetId: "",
    currentPresetName: "",
    presets: [],
    selectedPresetId: "",
    pendingSelectName: "",
    saveStatusText: "准备就绪",
    saveStatusIsError: false
  };

  const els = {
    presetApp: document.getElementById("presetApp"),
    presetHeader: document.getElementById("presetHeader"),
    pageScrollRoot: document.getElementById("pageScrollRoot"),
    currentPresetText: document.getElementById("currentPresetText"),
    statusText: document.getElementById("statusText"),
    closeWindowButton: document.getElementById("closeWindowButton"),
    openLegacyButton: document.getElementById("openLegacyButton"),
    createPresetButton: document.getElementById("createPresetButton"),
    duplicatePresetButton: document.getElementById("duplicatePresetButton"),
    presetEditorPanel: document.getElementById("presetEditorPanel"),
    presetTabStrip: document.getElementById("presetTabStrip"),
    editorTitle: document.getElementById("editorTitle"),
    activatePresetButton: document.getElementById("activatePresetButton"),
    deletePresetButton: document.getElementById("deletePresetButton"),
    presetNameInput: document.getElementById("presetNameInput"),
    resolutionModeSelect: document.getElementById("resolutionModeSelect"),
    targetLongSideField: document.getElementById("targetLongSideField"),
    targetLongSideSelect: document.getElementById("targetLongSideSelect"),
    stepIntervalSelect: document.getElementById("stepIntervalSelect"),
    codecSelect: document.getElementById("codecSelect"),
    qualitySelect: document.getElementById("qualitySelect"),
    presetSummaryText: document.getElementById("presetSummaryText"),
    builtinBadge: document.getElementById("builtinBadge"),
    currentBadge: document.getElementById("currentBadge")
  };

  const customSelects = new Map();
  let customSelectIdSeed = 0;
  let customSelectDismissBound = false;
  let statusTimerId = 0;
  let pageScrollFadeRaf = 0;

  function hasHostBridge() {
    return !!getHostBridge();
  }

  function getHostBridge() {
    const bridge = window.chrome && window.chrome.webview;
    if (!bridge || typeof bridge.postMessage !== "function") {
      return null;
    }
    return bridge;
  }

  function postHostMessage(message) {
    const bridge = getHostBridge();
    if (!bridge) {
      return false;
    }
    bridge.postMessage(message);
    return true;
  }

  function postHostCommand(command, payload) {
    const bridge = getHostBridge();
    if (!bridge) {
      return false;
    }
    bridge.postMessage(JSON.stringify({
      kind: "webui-command",
      command,
      payload: payload && typeof payload === "object" ? payload : {}
    }));
    return true;
  }

  async function fetchJson(path, init) {
    const response = await fetch(path, {
      cache: "no-store",
      headers: {
        "Content-Type": "application/json"
      },
      ...init
    });

    let payload = null;
    try {
      payload = await response.json();
    } catch {
      payload = null;
    }

    if (!response.ok || !payload || payload.ok !== true) {
      const message = payload && payload.error && payload.error.message
        ? payload.error.message
        : `HTTP ${response.status}`;
      throw new Error(message);
    }

    return payload.data || {};
  }

  function setStatus(text, isError) {
    state.saveStatusText = typeof text === "string" && text.trim()
      ? text.trim()
      : "准备就绪";
    state.saveStatusIsError = !!isError;
    if (els.statusText) {
      els.statusText.textContent = state.saveStatusText;
      els.statusText.style.color = state.saveStatusIsError ? "var(--danger)" : "var(--muted)";
    }

    if (statusTimerId) {
      window.clearTimeout(statusTimerId);
      statusTimerId = 0;
    }

    if (!state.saveStatusIsError && state.saveStatusText !== "准备就绪") {
      statusTimerId = window.setTimeout(() => {
        statusTimerId = 0;
        setStatus("准备就绪", false);
      }, 1800);
    }
  }

  function toNumber(value, fallback) {
    const numeric = Number(value);
    return Number.isFinite(numeric) ? numeric : fallback;
  }

  function escapeHtml(text) {
    return String(text == null ? "" : text)
      .replace(/&/g, "&amp;")
      .replace(/</g, "&lt;")
      .replace(/>/g, "&gt;")
      .replace(/"/g, "&quot;")
      .replace(/'/g, "&#39;");
  }

  function normalizeResolutionMode(value) {
    return value === "long_side" ? "long_side" : "highest";
  }

  function normalizePreset(item) {
    if (!item || typeof item !== "object") {
      return null;
    }

    const config = item.config && typeof item.config === "object" ? item.config : {};
    return {
      id: typeof item.id === "string" ? item.id.trim() : "",
      name: typeof item.name === "string" && item.name.trim() ? item.name.trim() : "未命名预设",
      is_builtin: !!item.is_builtin,
      is_current: !!item.is_current,
      config: {
        resolution_mode: normalizeResolutionMode(config.resolution_mode),
        record_target_long_side: Math.max(256, toNumber(config.record_target_long_side, 2048)),
        step_interval: Math.max(1, toNumber(config.step_interval, 2)),
        codec_id: Math.trunc(toNumber(config.codec_id, 1)),
        jpeg_quality: Math.max(1, Math.min(100, Math.trunc(toNumber(config.jpeg_quality, 95))))
      }
    };
  }

  function getCodecLabel(codecId) {
    switch (Math.trunc(toNumber(codecId, 1))) {
      case 3:
        return "无损";
      case 6:
        return "精简";
      case 5:
        return "自适应 JPEG";
      case 2:
        return "Lane Zstd";
      case 1:
      default:
        return "Zstd";
    }
  }

  function formatPresetSummary(config) {
    if (!config || typeof config !== "object") {
      return "-";
    }

    const resolutionMode = normalizeResolutionMode(config.resolution_mode);
    const modeText = resolutionMode === "long_side"
      ? `录制长边 ${Math.max(256, toNumber(config.record_target_long_side, 2048))}`
      : "固定最高";
    return `${modeText} / ${getCodecLabel(config.codec_id)} / 质量 ${Math.max(1, Math.min(100, toNumber(config.jpeg_quality, 95)))} / 间隔 ${Math.max(1, toNumber(config.step_interval, 2))}`;
  }

  function getPresetById(presetId) {
    if (!presetId) {
      return null;
    }
    return state.presets.find((item) => item.id === presetId) || null;
  }

  function getCurrentPreset() {
    return getPresetById(state.currentPresetId);
  }

  function getSelectedPreset() {
    return getPresetById(state.selectedPresetId);
  }

  function choosePreset(presetId) {
    if (!getPresetById(presetId)) {
      return;
    }
    state.selectedPresetId = presetId;
    render();
  }

  function ensureSelectedPreset() {
    const selected = getSelectedPreset();
    if (selected) {
      return;
    }

    if (state.pendingSelectName) {
      const byName = state.presets.find((item) => item.name === state.pendingSelectName);
      if (byName) {
        state.selectedPresetId = byName.id;
        state.pendingSelectName = "";
        return;
      }
    }

    if (getPresetById(state.currentPresetId)) {
      state.selectedPresetId = state.currentPresetId;
      return;
    }

    if (state.presets.length > 0) {
      state.selectedPresetId = state.presets[0].id;
    }
  }

  function applyState(payload) {
    state.version = Math.max(1, toNumber(payload && payload.version, 1));
    state.currentPresetId = payload && typeof payload.current_preset_id === "string"
      ? payload.current_preset_id.trim()
      : "";
    state.currentPresetName = payload && typeof payload.current_preset_name === "string"
      ? payload.current_preset_name.trim()
      : "";

    const nextPresets = Array.isArray(payload && payload.presets)
      ? payload.presets.map(normalizePreset).filter(Boolean)
      : [];
    state.presets = nextPresets;
    ensureSelectedPreset();
    render();
  }

  function buildUniqueName(baseName) {
    const normalizedBase = typeof baseName === "string" && baseName.trim()
      ? baseName.trim()
      : "新预设";
    const usedNames = new Set(state.presets.map((item) => item.name));
    if (!usedNames.has(normalizedBase)) {
      return normalizedBase;
    }

    let index = 2;
    let candidate = `${normalizedBase} ${index}`;
    while (usedNames.has(candidate)) {
      index += 1;
      candidate = `${normalizedBase} ${index}`;
    }
    return candidate;
  }

  function buildUpdatePayload(preset) {
    const name = els.presetNameInput ? els.presetNameInput.value.trim() : preset.name;
    return {
      preset_id: preset.id,
      name: preset.is_builtin ? preset.name : name,
      resolution_mode: els.resolutionModeSelect ? els.resolutionModeSelect.value : preset.config.resolution_mode,
      record_target_long_side: Math.max(256, toNumber(els.targetLongSideSelect ? els.targetLongSideSelect.value : preset.config.record_target_long_side, 2048)),
      step_interval: Math.max(1, toNumber(els.stepIntervalSelect ? els.stepIntervalSelect.value : preset.config.step_interval, 2)),
      codec_id: Math.trunc(toNumber(els.codecSelect ? els.codecSelect.value : preset.config.codec_id, 1)),
      jpeg_quality: Math.max(1, Math.min(100, Math.trunc(toNumber(els.qualitySelect ? els.qualitySelect.value : preset.config.jpeg_quality, 95))))
    };
  }

  async function requestStateSync() {
    if (postHostCommand("recording-preset-sync")) {
      return;
    }

    try {
      const data = await fetchJson("/api/record/presets");
      applyState(data);
      setStatus("已同步", false);
    } catch (error) {
      setStatus(error && error.message ? error.message : "同步失败", true);
    }
  }

  async function createPreset(sourcePresetId, name) {
    state.pendingSelectName = name;
    if (postHostCommand("recording-preset-create", {
      source_preset_id: sourcePresetId,
      name
    })) {
      setStatus("正在创建预设…", false);
      return;
    }

    try {
      const data = await fetchJson("/api/record/presets/create", {
        method: "POST",
        body: JSON.stringify({
          source_preset_id: sourcePresetId,
          name
        })
      });
      applyState(data);
      setStatus("预设已创建", false);
    } catch (error) {
      state.pendingSelectName = "";
      setStatus(error && error.message ? error.message : "创建预设失败", true);
    }
  }

  async function updateSelectedPreset() {
    const preset = getSelectedPreset();
    if (!preset) {
      return;
    }

    const payload = buildUpdatePayload(preset);
    if (!preset.is_builtin && !payload.name) {
      setStatus("预设名称不能为空", true);
      return;
    }

    if (postHostCommand("recording-preset-update", payload)) {
      setStatus("正在保存…", false);
      return;
    }

    try {
      const data = await fetchJson("/api/record/presets/update", {
        method: "POST",
        body: JSON.stringify(payload)
      });
      applyState(data);
      setStatus("已保存", false);
    } catch (error) {
      setStatus(error && error.message ? error.message : "保存失败", true);
    }
  }

  async function activatePreset(presetId) {
    if (!presetId) {
      return;
    }

    if (postHostCommand("recording-preset-activate", { preset_id: presetId })) {
      setStatus("正在切换预设…", false);
      return;
    }

    try {
      const data = await fetchJson("/api/record/presets/activate", {
        method: "POST",
        body: JSON.stringify({ preset_id: presetId })
      });
      applyState(data);
      setStatus("当前预设已更新", false);
    } catch (error) {
      setStatus(error && error.message ? error.message : "切换预设失败", true);
    }
  }

  async function deleteSelectedPreset() {
    const preset = getSelectedPreset();
    if (!preset || preset.is_builtin) {
      return;
    }

    if (!window.confirm(`删除预设“${preset.name}”？`)) {
      return;
    }

    if (postHostCommand("recording-preset-delete", { preset_id: preset.id })) {
      setStatus("正在删除预设…", false);
      return;
    }

    try {
      const data = await fetchJson("/api/record/presets/delete", {
        method: "POST",
        body: JSON.stringify({ preset_id: preset.id })
      });
      applyState(data);
      setStatus("预设已删除", false);
    } catch (error) {
      setStatus(error && error.message ? error.message : "删除预设失败", true);
    }
  }

  function renderTabs() {
    if (!els.presetTabStrip) {
      return;
    }

    els.presetTabStrip.innerHTML = "";
    if (state.presets.length <= 0) {
      const empty = document.createElement("div");
      empty.className = "preset-tab-empty";
      empty.textContent = "暂无可用预设";
      els.presetTabStrip.appendChild(empty);
      return;
    }

    state.presets.forEach((preset) => {
      const button = document.createElement("button");
      button.type = "button";
      button.className = "preset-tab";
      if (preset.id === state.selectedPresetId) {
        button.classList.add("is-active");
      }
      button.setAttribute("role", "tab");
      button.setAttribute("aria-selected", preset.id === state.selectedPresetId ? "true" : "false");
      button.innerHTML = `
        <div class="preset-tab-tags">
          ${preset.is_builtin ? '<span class="preset-tab-tag">系统</span>' : ""}
          ${preset.id === state.currentPresetId ? '<span class="preset-tab-tag is-current">当前</span>' : ""}
        </div>
        <span class="preset-tab-name">${escapeHtml(preset.name)}</span>
        <p class="preset-tab-summary">${escapeHtml(formatPresetSummary(preset.config))}</p>
      `;
      button.addEventListener("click", () => {
        choosePreset(preset.id);
      });
      els.presetTabStrip.appendChild(button);
    });
  }

  function setEditorDisabledState(isDisabled) {
    if (els.presetNameInput) {
      els.presetNameInput.disabled = isDisabled;
    }

    [
      els.resolutionModeSelect,
      els.targetLongSideSelect,
      els.stepIntervalSelect,
      els.codecSelect,
      els.qualitySelect
    ].filter(Boolean).forEach((selectEl) => {
      selectEl.disabled = isDisabled;
      syncCustomSelect(selectEl);
    });
  }

  function renderEditor() {
    const preset = getSelectedPreset();
    const hasPreset = !!preset;

    if (els.editorTitle) {
      els.editorTitle.textContent = hasPreset ? preset.name : "未选择预设";
    }

    if (els.currentPresetText) {
      const currentName = state.currentPresetName || (getCurrentPreset() ? getCurrentPreset().name : "");
      els.currentPresetText.textContent = currentName ? `当前预设 ${currentName}` : "当前预设 -";
    }

    if (!hasPreset) {
      if (els.presetNameInput) {
        els.presetNameInput.value = "";
      }
      if (els.activatePresetButton) {
        els.activatePresetButton.disabled = true;
      }
      if (els.deletePresetButton) {
        els.deletePresetButton.disabled = true;
      }
      if (els.duplicatePresetButton) {
        els.duplicatePresetButton.disabled = true;
      }
      if (els.presetSummaryText) {
        els.presetSummaryText.textContent = "-";
      }
      if (els.builtinBadge) {
        els.builtinBadge.hidden = true;
      }
      if (els.currentBadge) {
        els.currentBadge.hidden = true;
      }
      if (els.targetLongSideField) {
        els.targetLongSideField.hidden = true;
      }
      setEditorDisabledState(true);
      return;
    }

    setSelectOptions(els.resolutionModeSelect, resolutionModeOptions, preset.config.resolution_mode);
    setSelectOptions(els.targetLongSideSelect, longSideOptions, String(preset.config.record_target_long_side));
    setSelectOptions(els.stepIntervalSelect, stepIntervalOptions, String(preset.config.step_interval));
    setSelectOptions(els.codecSelect, codecOptions, String(preset.config.codec_id));
    setSelectOptions(els.qualitySelect, qualityOptions, String(preset.config.jpeg_quality));

    if (els.presetNameInput) {
      if (document.activeElement !== els.presetNameInput) {
        els.presetNameInput.value = preset.name;
      }
      els.presetNameInput.disabled = preset.is_builtin;
    }

    const isCurrent = preset.id === state.currentPresetId;
    if (els.activatePresetButton) {
      els.activatePresetButton.disabled = isCurrent;
    }
    if (els.deletePresetButton) {
      els.deletePresetButton.disabled = preset.is_builtin;
    }
    if (els.duplicatePresetButton) {
      els.duplicatePresetButton.disabled = false;
    }
    if (els.presetSummaryText) {
      els.presetSummaryText.textContent = formatPresetSummary(preset.config);
    }
    if (els.builtinBadge) {
      els.builtinBadge.hidden = !preset.is_builtin;
    }
    if (els.currentBadge) {
      els.currentBadge.hidden = !isCurrent;
    }

    const resolutionMode = normalizeResolutionMode(els.resolutionModeSelect ? els.resolutionModeSelect.value : preset.config.resolution_mode);
    if (els.targetLongSideField) {
      els.targetLongSideField.hidden = resolutionMode !== "long_side";
    }

    [
      els.resolutionModeSelect,
      els.targetLongSideSelect,
      els.stepIntervalSelect,
      els.codecSelect,
      els.qualitySelect
    ].filter(Boolean).forEach((selectEl) => {
      selectEl.disabled = false;
    });

    syncAllCustomSelects();
  }

  function render() {
    renderTabs();
    renderEditor();
  }

  function setSelectHostCardOpenState(selectEl, isOpen) {
    const hostCard = selectEl.closest(".card");
    if (!hostCard) {
      return;
    }
    hostCard.classList.toggle("has-open-select", isOpen);
  }

  function closeCustomSelect(selectEl, focusTrigger) {
    const meta = customSelects.get(selectEl);
    if (!meta || !meta.shell.classList.contains("is-open")) {
      return;
    }

    meta.shell.classList.remove("is-open");
    meta.trigger.setAttribute("aria-expanded", "false");
    setSelectHostCardOpenState(selectEl, false);
    if (focusTrigger) {
      meta.trigger.focus();
    }
  }

  function closeAllCustomSelects(exceptSelect) {
    customSelects.forEach((_, selectEl) => {
      if (selectEl !== exceptSelect) {
        closeCustomSelect(selectEl, false);
      }
    });
  }

  function getSelectedOptionIndex(selectEl) {
    return selectEl.selectedIndex >= 0 ? selectEl.selectedIndex : 0;
  }

  function findEnabledOptionIndex(meta, startIndex, step) {
    const total = meta.optionButtons.length;
    if (total <= 0) {
      return -1;
    }

    for (let offset = 0; offset < total; offset += 1) {
      const index = (startIndex + (offset * step) + total) % total;
      const button = meta.optionButtons[index];
      if (button && !button.disabled) {
        return index;
      }
    }
    return -1;
  }

  function focusCustomSelectOption(selectEl, index) {
    const meta = customSelects.get(selectEl);
    if (!meta) {
      return;
    }
    const button = meta.optionButtons[index];
    if (button && !button.disabled) {
      button.focus();
    }
  }

  function openCustomSelect(selectEl, focusIndex) {
    const meta = customSelects.get(selectEl);
    if (!meta || meta.trigger.disabled) {
      return;
    }

    closeAllCustomSelects(selectEl);
    meta.shell.classList.add("is-open");
    meta.trigger.setAttribute("aria-expanded", "true");
    setSelectHostCardOpenState(selectEl, true);

    const selectedIndex = getSelectedOptionIndex(selectEl);
    const nextIndex = focusIndex >= 0
      ? focusIndex
      : findEnabledOptionIndex(meta, Math.max(0, selectedIndex), 1);
    if (nextIndex >= 0) {
      focusCustomSelectOption(selectEl, nextIndex);
    }
  }

  function syncCustomSelect(selectEl) {
    const meta = customSelects.get(selectEl);
    if (!meta) {
      return;
    }

    const selectedIndex = getSelectedOptionIndex(selectEl);
    const selectedOption = selectedIndex >= 0 ? selectEl.options[selectedIndex] : null;
    meta.trigger.disabled = !!selectEl.disabled;
    meta.trigger.title = selectedOption ? selectedOption.textContent.trim() : "";
    meta.label.textContent = selectedOption ? selectedOption.textContent.trim() : "";

    meta.optionButtons.forEach((button, index) => {
      const isSelected = index === selectedIndex;
      button.classList.toggle("is-selected", isSelected);
      button.setAttribute("aria-selected", isSelected ? "true" : "false");
    });
  }

  function syncAllCustomSelects() {
    customSelects.forEach((_, selectEl) => {
      syncCustomSelect(selectEl);
    });
  }

  function selectCustomSelectOption(selectEl, nextValue, dispatchChange) {
    const previousValue = selectEl.value;
    selectEl.value = nextValue;
    syncCustomSelect(selectEl);
    closeCustomSelect(selectEl, false);
    if (dispatchChange && previousValue !== nextValue) {
      selectEl.dispatchEvent(new Event("change", { bubbles: true }));
    }
  }

  function createCustomSelectOptionButton(selectEl, option, index, menuId) {
    const optionButton = document.createElement("button");
    optionButton.type = "button";
    optionButton.className = "select-option";
    optionButton.textContent = option.textContent.trim();
    optionButton.dataset.value = option.value;
    optionButton.setAttribute("role", "option");
    optionButton.id = `${menuId}-option-${index}`;
    if (option.disabled) {
      optionButton.disabled = true;
    }
    optionButton.addEventListener("click", () => {
      if (option.disabled) {
        return;
      }
      selectCustomSelectOption(selectEl, option.value, true);
      const meta = customSelects.get(selectEl);
      if (meta) {
        meta.trigger.focus();
      }
    });
    return optionButton;
  }

  function repopulateCustomSelectOptions(selectEl) {
    const meta = customSelects.get(selectEl);
    if (!meta) {
      return;
    }

    meta.menu.replaceChildren();
    meta.optionButtons = Array.from(selectEl.options).map((option, index) => {
      const optionButton = createCustomSelectOptionButton(selectEl, option, index, meta.menu.id);
      meta.menu.appendChild(optionButton);
      return optionButton;
    });
    syncCustomSelect(selectEl);
  }

  function setSelectOptions(selectEl, options, selectedValue) {
    if (!(selectEl instanceof HTMLSelectElement) || !Array.isArray(options) || options.length <= 0) {
      return;
    }

    const normalizedOptions = options.map((option) => ({
      value: String(option && option.value != null ? option.value : ""),
      label: String(option && option.label != null ? option.label : ""),
      disabled: !!(option && option.disabled)
    }));

    const currentSignature = Array.from(selectEl.options)
      .map((option) => `${option.value}\u0001${option.textContent}\u0001${option.disabled ? 1 : 0}`)
      .join("\u0002");
    const nextSignature = normalizedOptions
      .map((option) => `${option.value}\u0001${option.label}\u0001${option.disabled ? 1 : 0}`)
      .join("\u0002");

    if (currentSignature !== nextSignature) {
      selectEl.replaceChildren();
      normalizedOptions.forEach((option) => {
        const nextOption = document.createElement("option");
        nextOption.value = option.value;
        nextOption.textContent = option.label;
        nextOption.disabled = option.disabled;
        selectEl.appendChild(nextOption);
      });
      repopulateCustomSelectOptions(selectEl);
    }

    const preferredValue = String(selectedValue);
    if (normalizedOptions.some((option) => option.value === preferredValue)) {
      selectEl.value = preferredValue;
    } else {
      selectEl.value = normalizedOptions[0].value;
    }
    syncCustomSelect(selectEl);
  }

  function bindCustomSelectDismiss() {
    if (customSelectDismissBound) {
      return;
    }
    customSelectDismissBound = true;

    document.addEventListener("pointerdown", (event) => {
      customSelects.forEach((meta, selectEl) => {
        if (!meta.shell.contains(event.target)) {
          closeCustomSelect(selectEl, false);
        }
      });
    });

    window.addEventListener("blur", () => {
      closeAllCustomSelects(null);
    });
  }

  function buildCustomSelect(selectEl) {
    if (!(selectEl instanceof HTMLSelectElement) || customSelects.has(selectEl)) {
      return;
    }

    const shell = document.createElement("div");
    shell.className = "select-shell";

    const trigger = document.createElement("button");
    trigger.type = "button";
    trigger.className = "select-trigger";
    trigger.dataset.hostDragIgnore = "true";
    trigger.setAttribute("aria-haspopup", "listbox");
    trigger.setAttribute("aria-expanded", "false");

    const label = document.createElement("span");
    label.className = "select-trigger-label";
    trigger.appendChild(label);

    const menu = document.createElement("div");
    menu.className = "select-menu";
    menu.setAttribute("role", "listbox");

    const menuId = `preset-select-menu-${++customSelectIdSeed}`;
    menu.id = menuId;
    trigger.setAttribute("aria-controls", menuId);

    const optionButtons = Array.from(selectEl.options).map((option, index) => {
      const optionButton = createCustomSelectOptionButton(selectEl, option, index, menuId);
      menu.appendChild(optionButton);
      return optionButton;
    });

    selectEl.classList.add("select-native");
    selectEl.setAttribute("aria-hidden", "true");
    selectEl.tabIndex = -1;

    selectEl.parentNode.insertBefore(shell, selectEl);
    shell.append(selectEl, trigger, menu);

    const meta = {
      shell,
      trigger,
      menu,
      label,
      optionButtons
    };
    customSelects.set(selectEl, meta);

    trigger.addEventListener("click", () => {
      if (shell.classList.contains("is-open")) {
        closeCustomSelect(selectEl, false);
        return;
      }
      openCustomSelect(selectEl, -1);
    });

    trigger.addEventListener("keydown", (event) => {
      if (event.key === "ArrowDown" || event.key === "ArrowUp") {
        event.preventDefault();
        const direction = event.key === "ArrowDown" ? 1 : -1;
        const baseIndex = getSelectedOptionIndex(selectEl);
        const nextIndex = findEnabledOptionIndex(meta, baseIndex + direction, direction);
        if (!shell.classList.contains("is-open")) {
          openCustomSelect(selectEl, nextIndex);
          return;
        }
        if (nextIndex >= 0) {
          focusCustomSelectOption(selectEl, nextIndex);
        }
        return;
      }

      if (event.key === "Enter" || event.key === " ") {
        event.preventDefault();
        if (shell.classList.contains("is-open")) {
          closeCustomSelect(selectEl, false);
        } else {
          openCustomSelect(selectEl, -1);
        }
        return;
      }

      if (event.key === "Escape") {
        if (shell.classList.contains("is-open")) {
          event.preventDefault();
          closeCustomSelect(selectEl, true);
        }
      }
    });

    menu.addEventListener("keydown", (event) => {
      const currentIndex = meta.optionButtons.findIndex((button) => button === document.activeElement);
      if (event.key === "ArrowDown" || event.key === "ArrowUp") {
        event.preventDefault();
        const direction = event.key === "ArrowDown" ? 1 : -1;
        const baseIndex = currentIndex >= 0 ? currentIndex : getSelectedOptionIndex(selectEl);
        const nextIndex = findEnabledOptionIndex(meta, baseIndex + direction, direction);
        if (nextIndex >= 0) {
          focusCustomSelectOption(selectEl, nextIndex);
        }
        return;
      }

      if (event.key === "Enter" || event.key === " ") {
        if (currentIndex >= 0) {
          event.preventDefault();
          const optionButton = meta.optionButtons[currentIndex];
          if (optionButton && !optionButton.disabled) {
            optionButton.click();
          }
        }
        return;
      }

      if (event.key === "Escape") {
        event.preventDefault();
        closeCustomSelect(selectEl, true);
      }
    });

    selectEl.addEventListener("change", () => {
      syncCustomSelect(selectEl);
    });

    syncCustomSelect(selectEl);
  }

  function bindDragSurface(el) {
    if (!el) {
      return;
    }

    el.addEventListener("pointerdown", (event) => {
      if (event.button !== 0 || !event.isPrimary) {
        return;
      }

      const interactiveTarget = event.target instanceof Element
        ? event.target.closest("button, input, select, textarea, a, label, summary, [role='button'], [data-host-drag-ignore='true']")
        : null;
      if (interactiveTarget || !hasHostBridge()) {
        return;
      }

      event.preventDefault();
      postHostMessage(hostDragMoveMessage);
    });
  }

  function updatePageScrollFade() {
    pageScrollFadeRaf = 0;
    if (!els.pageScrollRoot) {
      return;
    }

    const scrollTop = Math.max(0, els.pageScrollRoot.scrollTop || 0);
    const maxScrollTop = Math.max(0, (els.pageScrollRoot.scrollHeight || 0) - (els.pageScrollRoot.clientHeight || 0));
    const hasTopFade = scrollTop > pageScrollFadeThresholdPx;
    const hasBottomFade = maxScrollTop - scrollTop > pageScrollFadeThresholdPx;

    let nextClass = "scroll-fade-none";
    if (hasTopFade && hasBottomFade) {
      nextClass = "scroll-fade-both";
    } else if (hasTopFade) {
      nextClass = "scroll-fade-top";
    } else if (hasBottomFade) {
      nextClass = "scroll-fade-bottom";
    }

    els.pageScrollRoot.classList.remove("scroll-fade-none", "scroll-fade-top", "scroll-fade-bottom", "scroll-fade-both");
    els.pageScrollRoot.classList.add(nextClass);
  }

  function queuePageScrollFadeUpdate() {
    if (pageScrollFadeRaf) {
      return;
    }
    pageScrollFadeRaf = window.requestAnimationFrame(updatePageScrollFade);
  }

  function bindPageScrollFade() {
    if (!els.pageScrollRoot) {
      return;
    }
    els.pageScrollRoot.addEventListener("scroll", queuePageScrollFadeUpdate, { passive: true });
    window.addEventListener("resize", queuePageScrollFadeUpdate);
    queuePageScrollFadeUpdate();
  }

  function bindEvents() {
    bindDragSurface(els.presetHeader);
    bindDragSurface(els.presetEditorPanel);

    if (els.closeWindowButton) {
      els.closeWindowButton.addEventListener("click", () => {
        postHostMessage(hostCloseWindowMessage);
      });
    }

    if (els.openLegacyButton) {
      els.openLegacyButton.addEventListener("click", () => {
        if (postHostCommand("recording-preset-legacy-settings")) {
          setStatus("正在打开旧录制设置…", false);
          return;
        }
        setStatus("旧录制设置仅在桌面宿主中可用", true);
      });
    }

    if (els.createPresetButton) {
      els.createPresetButton.addEventListener("click", () => {
        const name = buildUniqueName("新预设");
        void createPreset("system-advanced", name);
      });
    }

    if (els.duplicatePresetButton) {
      els.duplicatePresetButton.addEventListener("click", () => {
        const preset = getSelectedPreset() || getCurrentPreset();
        if (!preset) {
          return;
        }
        const name = buildUniqueName(`${preset.name} 副本`);
        void createPreset(preset.id, name);
      });
    }

    if (els.activatePresetButton) {
      els.activatePresetButton.addEventListener("click", () => {
        const preset = getSelectedPreset();
        if (!preset) {
          return;
        }
        void activatePreset(preset.id);
      });
    }

    if (els.deletePresetButton) {
      els.deletePresetButton.addEventListener("click", () => {
        void deleteSelectedPreset();
      });
    }

    if (els.presetNameInput) {
      els.presetNameInput.addEventListener("change", () => {
        void updateSelectedPreset();
      });
      els.presetNameInput.addEventListener("keydown", (event) => {
        if (event.key === "Enter") {
          event.preventDefault();
          els.presetNameInput.blur();
        }
      });
    }

    [els.resolutionModeSelect, els.targetLongSideSelect, els.stepIntervalSelect, els.codecSelect, els.qualitySelect]
      .filter(Boolean)
      .forEach((selectEl) => {
        selectEl.addEventListener("change", () => {
          if (selectEl === els.resolutionModeSelect) {
            const resolutionMode = normalizeResolutionMode(els.resolutionModeSelect.value);
            if (els.targetLongSideField) {
              els.targetLongSideField.hidden = resolutionMode !== "long_side";
            }
          }
          void updateSelectedPreset();
        });
      });

    window.addEventListener("keydown", (event) => {
      if (event.key === "Escape") {
        closeAllCustomSelects(null);
        postHostMessage(hostCloseWindowMessage);
      }
    });
  }

  function bindHostBridge() {
    const bridge = getHostBridge();
    if (!bridge || typeof bridge.addEventListener !== "function") {
      return;
    }

    bridge.addEventListener("message", (event) => {
      const data = event.data;
      if (typeof data === "string") {
        if (data === hostWindowShownMessage) {
          void requestStateSync();
        }
        return;
      }

      if (!data || typeof data !== "object") {
        return;
      }

      if (data.kind === "recording-preset-state") {
        applyState(data.state);
        setStatus("已同步", false);
        return;
      }

      if (data.kind === "webui-ack" && typeof data.message === "string" && data.message.trim()) {
        setStatus(data.message.trim(), data.ok === false);
      }
    });
  }

  function initSelects() {
    document.querySelectorAll("select.select-input").forEach((selectEl) => {
      buildCustomSelect(selectEl);
    });
    bindCustomSelectDismiss();
  }

  async function init() {
    initSelects();
    bindEvents();
    bindHostBridge();
    bindPageScrollFade();
    render();
    await requestStateSync();
  }

  void init();
})();
