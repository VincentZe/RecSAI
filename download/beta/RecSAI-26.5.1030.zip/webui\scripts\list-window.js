﻿(function () {
  const scrollFadeThresholdPx = 3;
  const closeAnimationDurationMs = 180;
  const pollIntervalMs = 1000;
  const hostRequestCloseWindowMessage = "host:request-close-window";
  const hostWindowShownMessage = "host:window-shown";
  const hostCloseWindowMessage = "host:close-window";
  const hostDragMoveMessage = "host:drag-move";

  const state = {
    kind: document.body && document.body.dataset && document.body.dataset.listKind === "history" ? "history" : "project",
    items: [],
    filteredItems: [],
    activeIndex: -1,
    query: "",
    isClosing: false,
    closeTimerId: 0,
    pollTimerId: 0
  };

  const els = {
    listWindow: document.getElementById("listWindow"),
    listCard: document.getElementById("listCard"),
    listDragHandle: document.getElementById("listDragHandle"),
    listSearchInput: document.getElementById("listSearchInput"),
    listTitle: document.getElementById("listTitle"),
    listSubtitle: document.getElementById("listSubtitle"),
    resultMeta: document.getElementById("resultMeta"),
    listScroll: document.getElementById("listScroll"),
    listEmpty: document.getElementById("listEmpty")
  };

  function getHostBridge() {
    const bridge = window.chrome && window.chrome.webview;
    if (!bridge || typeof bridge.postMessage !== "function") {
      return null;
    }
    return bridge;
  }

  function postHostMessage(message) {
    const bridge = getHostBridge();
    if (!bridge) {
      return false;
    }
    bridge.postMessage(message);
    return true;
  }

  function escapeHtml(text) {
    return String(text == null ? "" : text)
      .replace(/&/g, "&amp;")
      .replace(/</g, "&lt;")
      .replace(/>/g, "&gt;")
      .replace(/"/g, "&quot;")
      .replace(/'/g, "&#39;");
  }

  function getApiPath() {
    return state.kind === "history" ? "/api/list/history" : "/api/list/projects";
  }

  function getIconText(item, index) {
    if (state.kind === "history") {
      return String(index + 1);
    }

    const title = item && item.title ? item.title : "";
    const compact = title.replace(/\s+/g, "");
    return compact ? compact.slice(0, 2).toUpperCase() : "PJ";
  }

  function normalizeProjectItem(item) {
    if (!item || typeof item !== "object") {
      return null;
    }

    const name = typeof item.name === "string" ? item.name.trim() : "";
    const path = typeof item.path === "string" ? item.path.trim() : "";
    const title = name || path || "未命名项目";
    return {
      title,
      meta: path,
      search: `${title}\n${path}`.toLowerCase()
    };
  }

  function normalizeHistoryItem(item) {
    const title = typeof item === "string"
      ? item.trim()
      : item && typeof item.title === "string" ? item.title.trim() : "";
    return {
      title: title || "未命名历史",
      meta: "",
      search: (title || "").toLowerCase()
    };
  }

  function normalizeState(data) {
    const rawItems = Array.isArray(data && data.items) ? data.items : [];
    const items = rawItems
      .map((item) => (state.kind === "history" ? normalizeHistoryItem(item) : normalizeProjectItem(item)))
      .filter((item) => !!item);
    const activeIndex = Number.isFinite(Number(data && data.active_index)) ? Math.trunc(Number(data.active_index)) : -1;
    return { items, activeIndex };
  }

  function filterItems() {
    const query = (state.query || "").trim().toLowerCase();
    if (!query) {
      state.filteredItems = state.items.map((item, index) => ({ ...item, originalIndex: index }));
      return;
    }

    state.filteredItems = state.items
      .map((item, index) => ({ ...item, originalIndex: index }))
      .filter((item) => item.search.indexOf(query) >= 0);
  }

  function updateScrollFade() {
    const scrollRoot = els.listScroll;
    if (!scrollRoot) {
      return;
    }

    const scrollTop = Math.max(0, scrollRoot.scrollTop || 0);
    const maxScrollTop = Math.max(0, (scrollRoot.scrollHeight || 0) - (scrollRoot.clientHeight || 0));
    const hasTopFade = scrollTop > scrollFadeThresholdPx;
    const hasBottomFade = maxScrollTop - scrollTop > scrollFadeThresholdPx;

    let nextFadeClass = "scroll-fade-none";
    if (hasTopFade && hasBottomFade) {
      nextFadeClass = "scroll-fade-both";
    } else if (hasTopFade) {
      nextFadeClass = "scroll-fade-top";
    } else if (hasBottomFade) {
      nextFadeClass = "scroll-fade-bottom";
    }

    scrollRoot.classList.remove("scroll-fade-none", "scroll-fade-top", "scroll-fade-bottom", "scroll-fade-both");
    scrollRoot.classList.add(nextFadeClass);
  }

  function render() {
    if (els.listTitle) {
      els.listTitle.textContent = state.kind === "history" ? "历史列表" : "项目列表";
    }
    if (els.listSubtitle) {
      els.listSubtitle.textContent = state.kind === "history" ? "当前项目历史记录" : "当前项目与最近项目";
    }
    if (els.resultMeta) {
      els.resultMeta.textContent = `${state.filteredItems.length} 项`;
    }

    els.listScroll.innerHTML = "";
    els.listEmpty.hidden = state.filteredItems.length !== 0;

    state.filteredItems.forEach((item, index) => {
      const row = document.createElement("div");
      row.className = "list-row";
      if (item.originalIndex === state.activeIndex) {
        row.classList.add("is-active");
      }

      row.dataset.itemIndex = String(index);
      row.innerHTML = `
        <div class="list-icon">${escapeHtml(getIconText(item, item.originalIndex))}</div>
        <div class="list-body">
          <p class="list-title">${escapeHtml(item.title)}</p>
          ${item.meta ? `<p class="list-meta">${escapeHtml(item.meta)}</p>` : ""}
        </div>
      `;
      els.listScroll.appendChild(row);
    });

    updateScrollFade();
  }

  async function fetchJson(path) {
    const response = await fetch(path, {
      cache: "no-store",
      headers: {
        "Content-Type": "application/json"
      }
    });

    let payload = null;
    try {
      payload = await response.json();
    } catch {
      payload = null;
    }

    if (!response.ok || !payload || payload.ok !== true) {
      const message = payload && payload.error && payload.error.message
        ? payload.error.message
        : `HTTP ${response.status}`;
      throw new Error(message);
    }

    return payload.data || {};
  }

  async function refresh() {
    try {
      const data = await fetchJson(getApiPath());
      const nextState = normalizeState(data);
      state.items = nextState.items;
      state.activeIndex = nextState.activeIndex;
      filterItems();
      render();
    } catch {
      state.items = [];
      state.filteredItems = [];
      state.activeIndex = -1;
      render();
    }
  }

  function beginCloseSequence() {
    if (state.isClosing) {
      return;
    }

    state.isClosing = true;
    if (state.closeTimerId) {
      window.clearTimeout(state.closeTimerId);
    }

    if (els.listWindow) {
      els.listWindow.classList.add("is-closing");
    }

    state.closeTimerId = window.setTimeout(() => {
      state.closeTimerId = 0;
      postHostMessage(hostCloseWindowMessage);
    }, closeAnimationDurationMs);
  }

  function resetWindowState() {
    state.isClosing = false;
    if (state.closeTimerId) {
      window.clearTimeout(state.closeTimerId);
      state.closeTimerId = 0;
    }

    if (els.listWindow) {
      els.listWindow.classList.remove("is-closing");
      els.listWindow.classList.remove("is-ready");
      window.requestAnimationFrame(() => {
        els.listWindow.classList.add("is-ready");
      });
    }

    if (els.listSearchInput) {
      window.requestAnimationFrame(() => {
        els.listSearchInput.focus();
        els.listSearchInput.select();
      });
    }
  }

  function bindHostBridge() {
    const bridge = getHostBridge();
    if (!bridge || typeof bridge.addEventListener !== "function") {
      return;
    }

    bridge.addEventListener("message", (event) => {
      const data = event.data;
      if (typeof data === "string") {
        if (data === hostRequestCloseWindowMessage) {
          beginCloseSequence();
        } else if (data === hostWindowShownMessage) {
          resetWindowState();
          void refresh();
        }
      }
    });
  }

  function bindDragRegion() {
    const handleDragStart = (event) => {
      if (event.button !== 0 || !event.isPrimary) {
        return;
      }

      const interactiveTarget = event.target instanceof Element
        ? event.target.closest("button, input, select, textarea, a, label, summary, [role='button'], [data-host-drag-ignore='true']")
        : null;
      if (interactiveTarget) {
        return;
      }

      if (postHostMessage(hostDragMoveMessage)) {
        event.preventDefault();
      }
    };

    if (els.listDragHandle) {
      els.listDragHandle.addEventListener("pointerdown", handleDragStart);
    }

    if (els.listCard) {
      els.listCard.addEventListener("pointerdown", handleDragStart);
    }
  }

  function attachGlowDrift(el, options) {
    if (!el) {
      return;
    }

    const reduceMotion = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
    const settings = {
      defaultX: options && typeof options.defaultX === "number" ? options.defaultX : 50,
      defaultY: options && typeof options.defaultY === "number" ? options.defaultY : 50,
      inverse: !!(options && options.inverse),
      radiusScale: options && typeof options.radiusScale === "number" ? options.radiusScale : 1.12
    };
    const glowState = {
      currentX: settings.defaultX,
      currentY: settings.defaultY,
      targetX: settings.defaultX,
      targetY: settings.defaultY,
      raf: 0
    };

    function clamp(value, min, max) {
      return Math.max(min, Math.min(max, value));
    }

    function setGlow(x, y) {
      el.style.setProperty("--glow-x", `${x.toFixed(2)}%`);
      el.style.setProperty("--glow-y", `${y.toFixed(2)}%`);
    }

    function updateRadius() {
      const rect = el.getBoundingClientRect();
      const radius = Math.max(rect.width, rect.height) * settings.radiusScale;
      el.style.setProperty("--glow-radius", `${radius.toFixed(2)}px`);
    }

    function animateGlow() {
      glowState.raf = 0;
      const dx = glowState.targetX - glowState.currentX;
      const dy = glowState.targetY - glowState.currentY;
      if (Math.abs(dx) < 0.03 && Math.abs(dy) < 0.03) {
        glowState.currentX = glowState.targetX;
        glowState.currentY = glowState.targetY;
        setGlow(glowState.currentX, glowState.currentY);
        return;
      }

      glowState.currentX += dx * 0.05;
      glowState.currentY += dy * 0.05;
      setGlow(glowState.currentX, glowState.currentY);
      glowState.raf = window.requestAnimationFrame(animateGlow);
    }

    function updateGlowTarget(x, y) {
      glowState.targetX = clamp(x, 0, 100);
      glowState.targetY = clamp(y, 0, 100);

      if (reduceMotion) {
        glowState.currentX = glowState.targetX;
        glowState.currentY = glowState.targetY;
        setGlow(glowState.currentX, glowState.currentY);
        return;
      }

      if (!glowState.raf) {
        glowState.raf = window.requestAnimationFrame(animateGlow);
      }
    }

    function reset() {
      updateGlowTarget(settings.defaultX, settings.defaultY);
    }

    updateRadius();
    setGlow(settings.defaultX, settings.defaultY);

    el.addEventListener("pointermove", (event) => {
      if (event.pointerType && event.pointerType !== "mouse" && event.pointerType !== "pen") {
        return;
      }

      const rect = el.getBoundingClientRect();
      if (rect.width <= 0 || rect.height <= 0) {
        return;
      }

      const pointerX = clamp((event.clientX - rect.left) / rect.width, 0, 1);
      const pointerY = clamp((event.clientY - rect.top) / rect.height, 0, 1);
      const mappedX = (settings.inverse ? (1 - pointerX) : pointerX) * 100;
      const mappedY = (settings.inverse ? (1 - pointerY) : pointerY) * 100;
      updateGlowTarget(mappedX, mappedY);
    });

    el.addEventListener("pointerleave", reset);
    el.addEventListener("pointercancel", reset);

    if (typeof ResizeObserver === "function") {
      const resizeObserver = new ResizeObserver(() => {
        updateRadius();
      });
      resizeObserver.observe(el);
    }
  }

  function bindEvents() {
    if (els.listSearchInput) {
      els.listSearchInput.addEventListener("input", () => {
        state.query = els.listSearchInput.value || "";
        filterItems();
        render();
      });

      els.listSearchInput.addEventListener("keydown", (event) => {
        if (event.key === "Escape") {
          event.preventDefault();
          beginCloseSequence();
        }
      });
    }

    if (els.listScroll) {
      els.listScroll.addEventListener("scroll", updateScrollFade, { passive: true });
    }

    window.addEventListener("resize", updateScrollFade);
  }

  function startPolling() {
    if (state.pollTimerId) {
      window.clearInterval(state.pollTimerId);
    }

    state.pollTimerId = window.setInterval(() => {
      void refresh();
    }, pollIntervalMs);
  }

  function initAmbientMotion() {
    attachGlowDrift(els.listContentShell || document.querySelector(".list-content-shell"), {
      defaultX: 68,
      defaultY: 32,
      inverse: true,
      radiusScale: 1.18
    });
    attachGlowDrift(document.querySelector(".list-search"), {
      defaultX: 26,
      defaultY: 44,
      inverse: true,
      radiusScale: 1.08
    });
  }

  function init() {
    document.documentElement.dataset.theme = "light";
    bindEvents();
    bindDragRegion();
    bindHostBridge();
    initAmbientMotion();
    resetWindowState();
    startPolling();
    void refresh();
  }

  init();
})();
