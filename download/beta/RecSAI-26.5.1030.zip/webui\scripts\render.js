﻿function updatePageScrollFade() {
  pageScrollFadeRaf = 0;

  const scrollRoot = els.pageScrollRoot;
  if (!scrollRoot) {
    return;
  }

  const scrollTop = Math.max(0, scrollRoot.scrollTop || 0);
  const maxScrollTop = Math.max(0, (scrollRoot.scrollHeight || 0) - (scrollRoot.clientHeight || 0));
  const hasTopFade = scrollTop > pageScrollFadeThresholdPx;
  const hasBottomFade = maxScrollTop - scrollTop > pageScrollFadeThresholdPx;

  let nextFadeClass = "scroll-fade-none";
  if (hasTopFade && hasBottomFade) {
    nextFadeClass = "scroll-fade-both";
  } else if (hasTopFade) {
    nextFadeClass = "scroll-fade-top";
  } else if (hasBottomFade) {
    nextFadeClass = "scroll-fade-bottom";
  }

  if (!scrollRoot.classList.contains(nextFadeClass)) {
    scrollRoot.classList.remove("scroll-fade-none", "scroll-fade-top", "scroll-fade-bottom", "scroll-fade-both");
    scrollRoot.classList.add(nextFadeClass);
  }
}

function queuePageScrollFadeUpdate() {
  if (pageScrollFadeRaf) {
    return;
  }

  pageScrollFadeRaf = window.requestAnimationFrame(updatePageScrollFade);
}

function bindPageScrollFade() {
  if (!els.pageScrollRoot) {
    return;
  }

  els.pageScrollRoot.addEventListener("scroll", queuePageScrollFadeUpdate, { passive: true });
  window.addEventListener("resize", queuePageScrollFadeUpdate);

  if ("ResizeObserver" in window && document.body) {
    pageScrollFadeObserver = new ResizeObserver(() => {
      queuePageScrollFadeUpdate();
    });
    pageScrollFadeObserver.observe(els.pageScrollRoot);
    const workspace = document.querySelector(".workspace");
    if (workspace) {
      pageScrollFadeObserver.observe(workspace);
    }
  }

  queuePageScrollFadeUpdate();
}

function addLog(message) {
  const now = new Date();
  state.activityLog.unshift({
    time: now.toLocaleTimeString("zh-CN", { hour12: false }),
    message
  });
  state.activityLog = state.activityLog.slice(0, 12);
  renderLog();
}

function renderLog() {
  els.activityLog.innerHTML = "";
  if (state.activityLog.length === 0) {
    const empty = document.createElement("li");
    empty.className = "activity-item";
    empty.innerHTML = "<time>--:--:--</time><span>暂无最近活动。</span>";
    els.activityLog.appendChild(empty);
    return;
  }

  state.activityLog.forEach((item) => {
    const li = document.createElement("li");
    li.className = "activity-item";
    li.innerHTML = `<time>${item.time}</time><span>${item.message}</span>`;
    els.activityLog.appendChild(li);
  });
}

function clamp(value, min, max) {
  return Math.max(min, Math.min(max, value));
}

function formatSize(width, height) {
  if (!width || !height || width <= 0 || height <= 0) {
    return "N";
  }
  return `${width} x ${height}`;
}

function formatHex(value) {
  const numeric = Number(value);
  if (!Number.isFinite(numeric) || numeric <= 0) {
    return "N";
  }
  return `0x${Math.trunc(numeric).toString(16).toUpperCase()}`;
}

function fileNameFromPath(path) {
  if (!path) {
    return "";
  }
  const parts = path.split(/[/\\]/);
  return parts[parts.length - 1] || path;
}

function toNumber(value, fallback) {
  const numeric = Number(value);
  return Number.isFinite(numeric) ? numeric : fallback;
}

function isHttpProvider() {
  return runtime.provider && runtime.provider.kind === "http";
}

function setActionInFlight(active) {
  runtime.actionInFlight = active;
  renderButtons();
}

function getRecordingLabel() {
  if (state.recordingState === "recording") {
    return "录制中";
  }
  if (state.recordingState === "starting") {
    return "启动中...";
  }
  if (state.recordingState === "stopping") {
    return "停止中...";
  }
  return "待机";
}

function getStatusPillText() {
  if (!state.backendAvailable && isHttpProvider()) {
    return "Web API 不可用";
  }
  if (!state.connected) {
    return "未连接 SAI2";
  }
  if (state.recordingState === "recording") {
    return "已连接 / 录制中";
  }
  if (state.recordingState === "starting" || state.recordingState === "stopping") {
    return "正在处理录制";
  }
  return "已连接 SAI2";
}

function getStatusSubtext() {
  if (!state.backendAvailable && isHttpProvider()) {
    return "等待 HTTP bridge 恢复";
  }
  const channel = state.updateChannel === "beta" ? "beta" : "stable";
  if (!state.connected) {
    return `等待附着到 SAI2，当前更新通道 ${channel}`;
  }
  return `录制状态跟随运行时更新，当前更新通道 ${channel}`;
}

function getVolumeText() {
  if (state.volumeModeIndex === 1) {
    if (state.volumeRecentCount > 0) {
      return `${state.volumeRecentMbPerFrame.toFixed(1)} MB / frame (${state.volumeRecentCount} recent)`;
    }
    return "No recent volume data";
  }
  if (state.volumeModeIndex === 2) {
    if (state.volumePreviousCount > 0) {
      return `${state.volumePreviousMbPerFrame.toFixed(1)} MB / frame (${state.volumePreviousCount} previous)`;
    }
    return "No previous volume data";
  }
  return `${state.volumeEstimateMbPerFrame.toFixed(1)} MB / frame`;
}

function getRecordingSizeSummary() {
  if (state.recordingRuntimeRank === "-1") {
    return `自动/${state.recordTargetLongSide}`;
  }

  const option = createRuntimeRankOptions().find((item) => item.value === state.recordingRuntimeRank);
  return option ? option.label : `L${state.recordingRuntimeRank}`;
}

function getRecordSummary() {
  if (typeof state.recordingPresetSummary === "string" && state.recordingPresetSummary.trim()) {
    return state.recordingPresetSummary.trim();
  }

  if (isHttpProvider()) {
    if (!state.backendAvailable) {
      return "Waiting for the local HTTP bridge";
    }
    if (state.recordingState === "recording") {
      const lossless = normalizeRecordingCodecMode(state.recordingCodecMode, state.recordingCodecId) === "lossless";
      const modeLabel = lossless ? "无损" : "精简";
      const qualityText = lossless ? "" : ` / 质量=${state.quality}`;
      return `${modeLabel} / ${getRecordingSizeSummary()} / step=${state.stepInterval}${qualityText}`;
    }
    if (state.recordingState === "starting") {
      return "正在准备录制会话";
    }
    if (state.recordingState === "stopping") {
      return "正在等待 CLI 停止录制";
    }
    return "待机";
  }

  if (state.recordingState === "recording" && state.sessionStartedAt) {
    const elapsedSeconds = Math.max(1, Math.floor((Date.now() - state.sessionStartedAt) / 1000));
    return `${state.frameCount} frames / ${elapsedSeconds}s / ${getRecordingSizeSummary()} / step=${state.stepInterval}`;
  }
  if (state.recordingState === "starting") {
    return "正在准备录制会话";
  }
  if (state.recordingState === "stopping") {
    return "正在停止录制会话";
  }
  return "待机";
}

function renderButtons() {
  const label = getRecordingLabel();
  [els.topRecordButton, els.overlayRecordButton].filter(Boolean).forEach((button) => {
    button.textContent = label;
    button.disabled = runtime.actionInFlight;
    button.classList.toggle("is-recording", state.recordingState === "recording");
  });
}

function renderHeader() {
  if (els.perfLabelText) {
    const perfText = typeof state.perfLabel === "string" && state.perfLabel.trim()
      ? state.perfLabel.trim()
      : defaultState.perfLabel;
    const versionText = typeof state.appVersion === "string" && state.appVersion.trim()
      ? `v${state.appVersion.trim()}`
      : "";
    els.perfLabelText.textContent = versionText && perfText
      ? `${versionText} | ${perfText}`
      : (versionText || perfText);
  }
}

function renderStatus() {
  els.connectionBadge.textContent = getStatusPillText();
  els.connectionBadge.classList.toggle("is-offline", !state.connected || (!state.backendAvailable && isHttpProvider()));
  els.connectionBadge.classList.toggle("is-busy", state.recordingState === "starting" || state.recordingState === "stopping");
  if (els.statusSubtext) {
    els.statusSubtext.textContent = getStatusSubtext();
  }
  els.recordingStateLabel.textContent = state.recordingState === "idle" ? "待机" : getRecordingLabel();
  els.statusLamp.classList.toggle("is-recording", state.recordingState === "recording");
  els.statusLamp.classList.toggle("is-busy", state.recordingState === "starting" || state.recordingState === "stopping");
}

function renderRecordingFields() {
  if (!els.recordingPresetSelect) {
    return;
  }

  setSelectOptions(els.recordingPresetSelect, createRecordingPresetOptions(), state.currentPresetId || "");
  state.currentPresetId = els.recordingPresetSelect.value;
}

function renderFields() {
  renderRecordingFields();
  els.savePathInput.value = state.savePath;
  els.currentFileLabel.textContent = state.currentFile;
  if (els.openedFileNameLabel) {
    els.openedFileNameLabel.textContent = state.currentFile;
  }
  if (els.recordSummaryLabel) {
    els.recordSummaryLabel.textContent = getRecordSummary();
  }

  if (!state.backendAvailable && isHttpProvider()) {
    els.processNameLabel.textContent = "Web API 不可用";
    els.processBaseAddressLabel.textContent = "N";
    els.processIdLabel.textContent = "N";
    els.canvasSizeLabel.textContent = "N";
    els.thumbSizeLabel.textContent = "N";
    els.pointerLabel.textContent = "N";
    els.volumeApproxLabel.textContent = "N";
  } else {
    els.processNameLabel.textContent = state.connected ? state.processName : "SAI2 未连接";
    els.processBaseAddressLabel.textContent = state.connected ? state.processBaseAddress : "N";
    els.processIdLabel.textContent = state.connected ? state.processId : "N";
    els.canvasSizeLabel.textContent = state.connected ? state.canvasSize : "N";
    els.thumbSizeLabel.textContent = state.connected ? state.thumbSize : "N";
    els.pointerLabel.textContent = state.connected ? `${Math.round(state.pointerX)}, ${Math.round(state.pointerY)}` : "N";
    els.volumeApproxLabel.textContent = state.connected ? getVolumeText() : "N";
  }

  els.alwaysOnTopToggle.checked = state.alwaysOnTop;
  els.autoLaunchToggle.checked = state.autoLaunch;
  els.doNotMinimizeToTrayToggle.checked = state.doNotMinimizeToTray;
  els.navigatorResizeToggle.checked = state.navigatorAutoResize;
  els.updateChannelSelect.value = state.updateChannel;
  els.customBrushOverlayToggle.checked = state.customBrushOverlay;
  els.previewDeveloperModeToggle.checked = state.previewDeveloperMode;
  els.runtimeSurfaceFixedRefreshToggle.checked = state.runtimeSurfaceFixedRefresh;
  els.previewTileFrameSyncToggle.checked = state.previewTileFrameSync;
  els.statusLightGroupToggle.checked = state.statusLightGroupVisible;
  syncAllCustomSelects();
}

function renderTheme() {
  const themeMode = state.themeMode === "dark" ? "dark" : "light";
  document.documentElement.dataset.theme = themeMode;

  if (els.themeToggleButton) {
    els.themeToggleButton.textContent = themeMode === "light" ? "Theme: Light" : "Theme: Dark";
    els.themeToggleButton.setAttribute("aria-pressed", themeMode === "dark" ? "true" : "false");
  }
}

function renderPreviewChrome() {
  const hasPreviewIssue = (!!preview.error && isHttpProvider()) || (!state.connected && isHttpProvider()) || (!state.backendAvailable && isHttpProvider());
  els.previewFrame.classList.toggle("is-recording", state.recordingState === "recording" || state.recordingState === "starting");
  els.previewFrame.classList.toggle("is-offline", hasPreviewIssue);
  els.previewScroll.classList.add("is-fit");
  els.previewScroll.classList.remove("is-actual");
}

function render() {
  renderTheme();
  renderHeader();
  renderStatus();
  renderButtons();
  renderFields();
  renderPreviewChrome();
  persistState();
  queuePageScrollFadeUpdate();
}

