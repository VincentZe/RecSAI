﻿const storageKey = "readsai2-webui-state";
const statusPollMs = 1000;
const backendErrorLogThrottleMs = 10000;
const previewReconnectMs = 1000;
const previewResizeDebounceMs = 80;
const pageScrollFadeThresholdPx = 3;
const previewTileHeaderBytes = 48;
const previewTileFlags = {
  reset: 1,
  full: 2,
  present: 4
};

const defaultState = {
  backendAvailable: true,
  connected: true,
  recordingState: "idle",
  savePath: "",
  currentFile: "project_20260318_1738",
  appVersion: "",
  perfLabel: "*本软件仅适用于SAI.ver2 2024.08.14",
  processName: "sai2.exe",
  processBaseAddress: "0x00007FF6A1BE0000",
  processId: "18420",
  canvasSize: "5120 x 2880",
  canvasWidthValue: 5120,
  canvasHeightValue: 2880,
  thumbSize: "1280 x 720",
  thumbWidthValue: 1280,
  thumbHeightValue: 720,
  pointerX: 3400,
  pointerY: 1212,
  recordingCodecId: 1,
  recordingCodecMode: "compact",
  recordingRuntimeRank: "-1",
  recordTargetLongSide: "2048",
  recordingRuntimeLevelLabels: ["L0", "L1", "L2", "L3", "L4", "L5"],
  stepInterval: "1",
  quality: "95",
  recordingPresetSummary: "-",
  currentPresetId: "",
  currentPresetName: "",
  recordingPresets: [],
  previewMode: "fit",
  themeMode: "light",
  alwaysOnTop: false,
  autoLaunch: false,
  doNotMinimizeToTray: false,
  navigatorAutoResize: false,
  updateChannel: "stable",
  customBrushOverlay: false,
  previewDeveloperMode: false,
  runtimeSurfaceFixedRefresh: false,
  previewTileFrameSync: false,
  statusLightGroupVisible: true,
  volumeModeIndex: 0,
  frameCount: 0,
  sessionStartedAt: null,
  volumeEstimateMbPerFrame: 26.8,
  volumeRecentMbPerFrame: 24.8,
  volumePreviousMbPerFrame: 23.4,
  volumeRecentCount: 100,
  volumePreviousCount: 2000,
  activityLog: []
};

const els = {
  pageScrollRoot: document.getElementById("pageScrollRoot"),
  masthead: document.querySelector(".masthead"),
  previewCardHeader: document.getElementById("previewCardHeader"),
  perfLabelText: document.getElementById("perfLabelText"),
  connectionBadge: document.getElementById("connectionBadge"),
  statusSubtext: document.getElementById("statusSubtext"),
  topRecordButton: document.getElementById("topRecordButton"),
  overlayRecordButton: document.getElementById("overlayRecordButton"),
  hostBackdropButton: document.getElementById("hostBackdropButton"),
  closeWindowButton: document.getElementById("closeWindowButton"),
  themeToggleButton: document.getElementById("themeToggleButton"),
  savePathInput: document.getElementById("savePathInput"),
  currentFileLabel: document.getElementById("currentFileLabel"),
  openedFileNameLabel: document.getElementById("openedFileNameLabel"),
  recordSummaryLabel: document.getElementById("recordSummaryLabel"),
  processNameLabel: document.getElementById("processNameLabel"),
  processBaseAddressLabel: document.getElementById("processBaseAddressLabel"),
  processIdLabel: document.getElementById("processIdLabel"),
  canvasSizeLabel: document.getElementById("canvasSizeLabel"),
  thumbSizeLabel: document.getElementById("thumbSizeLabel"),
  pointerLabel: document.getElementById("pointerLabel"),
  volumeApproxLabel: document.getElementById("volumeApproxLabel"),
  recordingStateLabel: document.getElementById("recordingStateLabel"),
  statusLamp: document.getElementById("statusLamp"),
  recordingPresetSelect: document.getElementById("recordingPresetSelect"),
  alwaysOnTopToggle: document.getElementById("alwaysOnTopToggle"),
  autoLaunchToggle: document.getElementById("autoLaunchToggle"),
  doNotMinimizeToTrayToggle: document.getElementById("doNotMinimizeToTrayToggle"),
  navigatorResizeToggle: document.getElementById("navigatorResizeToggle"),
  updateChannelSelect: document.getElementById("updateChannelSelect"),
  customBrushOverlayToggle: document.getElementById("customBrushOverlayToggle"),
  previewDeveloperModeToggle: document.getElementById("previewDeveloperModeToggle"),
  runtimeSurfaceFixedRefreshToggle: document.getElementById("runtimeSurfaceFixedRefreshToggle"),
  previewTileFrameSyncToggle: document.getElementById("previewTileFrameSyncToggle"),
  statusLightGroupToggle: document.getElementById("statusLightGroupToggle"),
  activityLog: document.getElementById("activityLog"),
  clearLogButton: document.getElementById("clearLogButton"),
  browsePathButton: document.getElementById("browsePathButton"),
  openFolderButton: document.getElementById("openFolderButton"),
  recordingSettingsButton: document.getElementById("recordingSettingsButton"),
  launchSaiButton: document.getElementById("launchSaiButton"),
  quickExportButton: document.getElementById("quickExportButton"),
  projectListButton: document.getElementById("projectListButton"),
  historyListButton: document.getElementById("historyListButton"),
  toggleSettingsButton: document.getElementById("toggleSettingsButton"),
  checkUpdateButton: document.getElementById("checkUpdateButton"),
  diagnosticsButton: document.getElementById("diagnosticsButton"),
  unregisterButton: document.getElementById("unregisterButton"),
  volumeModeButton: document.getElementById("volumeModeButton"),
  volumeMetricPanel: document.getElementById("volumeMetricPanel"),
  windowResizeBottomLeftButton: document.getElementById("windowResizeBottomLeftButton"),
  windowResizeBottomRightButton: document.getElementById("windowResizeBottomRightButton"),
  commandLauncherButton: document.getElementById("commandLauncherButton"),
  previewFrame: document.getElementById("previewFrame"),
  previewScroll: document.getElementById("previewScroll"),
  previewSurface: document.getElementById("previewSurface"),
  displayCanvas: document.getElementById("displayCanvas"),
  overlayCanvas: document.getElementById("overlayCanvas")
};

const runtime = {
  provider: null,
  mockTimer: 0,
  statusPollTimer: 0,
  actionInFlight: false,
  backendErrorLoggedAt: 0
};

const preview = {
  atlasCanvas: document.createElement("canvas"),
  atlasCtx: null,
  displayCtx: null,
  overlayCtx: null,
  session: null,
  cursor: {
    x: 0,
    y: 0,
    thumbWidth: 0,
    thumbHeight: 0,
    attached: true
  },
  socket: null,
  reconnectTimer: 0,
  resizeSendTimer: 0,
  resizeObserver: null,
  renderQueued: false,
  overlayQueued: false,
  openSent: false,
  lastSentMaxDim: 0,
  lastSentMode: "",
  disposed: true,
  error: null,
  layout: null,
  dots: [],
  lastLogAt: 0
};

preview.atlasCtx = preview.atlasCanvas.getContext("2d");
preview.displayCtx = els.displayCanvas.getContext("2d");
preview.overlayCtx = els.overlayCanvas.getContext("2d");

const state = loadState();
document.documentElement.dataset.theme = state.themeMode === "dark" ? "dark" : "light";
const customSelects = new Map();
let customSelectIdSeed = 0;
let customSelectDismissBound = false;
let pageScrollFadeRaf = 0;
let pageScrollFadeObserver = null;

function cloneState(src) {
  return JSON.parse(JSON.stringify(src));
}

function setSelectHostCardOpenState(selectEl, isOpen) {
  const hostCard = selectEl.closest(".rail-card");
  if (!hostCard) {
    return;
  }

  hostCard.classList.toggle("has-open-select", isOpen);
}

function closeCustomSelect(selectEl, focusTrigger = false) {
  const meta = customSelects.get(selectEl);
  if (!meta || !meta.shell.classList.contains("is-open")) {
    return;
  }

  meta.shell.classList.remove("is-open");
  meta.trigger.setAttribute("aria-expanded", "false");
  setSelectHostCardOpenState(selectEl, false);
  if (focusTrigger) {
    meta.trigger.focus();
  }
}

function closeAllCustomSelects(exceptSelect = null) {
  customSelects.forEach((_, selectEl) => {
    if (selectEl !== exceptSelect) {
      closeCustomSelect(selectEl);
    }
  });
}

function findEnabledOptionIndex(meta, startIndex, step) {
  const total = meta.optionButtons.length;
  if (total === 0) {
    return -1;
  }

  for (let offset = 0; offset < total; offset += 1) {
    const index = (startIndex + (offset * step) + total) % total;
    const button = meta.optionButtons[index];
    if (button && !button.disabled) {
      return index;
    }
  }

  return -1;
}

function focusCustomSelectOption(selectEl, index) {
  const meta = customSelects.get(selectEl);
  if (!meta) {
    return;
  }

  const button = meta.optionButtons[index];
  if (button && !button.disabled) {
    button.focus();
  }
}

function getSelectedOptionIndex(selectEl) {
  const selectedIndex = selectEl.selectedIndex;
  if (selectedIndex >= 0) {
    return selectedIndex;
  }
  return selectEl.options.length > 0 ? 0 : -1;
}

function openCustomSelect(selectEl, focusIndex = -1) {
  const meta = customSelects.get(selectEl);
  if (!meta || meta.trigger.disabled) {
    return;
  }

  closeAllCustomSelects(selectEl);
  meta.shell.classList.add("is-open");
  meta.trigger.setAttribute("aria-expanded", "true");
  setSelectHostCardOpenState(selectEl, true);

  const selectedIndex = getSelectedOptionIndex(selectEl);
  const nextIndex = focusIndex >= 0
    ? focusIndex
    : findEnabledOptionIndex(meta, Math.max(0, selectedIndex), 1);
  if (nextIndex >= 0) {
    focusCustomSelectOption(selectEl, nextIndex);
  }
}

function selectCustomSelectOption(selectEl, nextValue, dispatchChange) {
  const previousValue = selectEl.value;
  selectEl.value = nextValue;
  syncCustomSelect(selectEl);
  closeCustomSelect(selectEl);

  if (dispatchChange && previousValue !== nextValue) {
    selectEl.dispatchEvent(new Event("change", { bubbles: true }));
  }
}

function syncCustomSelect(selectEl) {
  const meta = customSelects.get(selectEl);
  if (!meta) {
    return;
  }

  const selectedIndex = getSelectedOptionIndex(selectEl);
  const selectedOption = selectedIndex >= 0 ? selectEl.options[selectedIndex] : null;
  meta.trigger.disabled = !!selectEl.disabled;
  meta.trigger.title = selectedOption ? selectedOption.textContent.trim() : "";
  meta.label.textContent = selectedOption ? selectedOption.textContent.trim() : "";

  meta.optionButtons.forEach((button, index) => {
    const isSelected = index === selectedIndex;
    button.classList.toggle("is-selected", isSelected);
    button.setAttribute("aria-selected", isSelected ? "true" : "false");
  });
}

function syncAllCustomSelects() {
  customSelects.forEach((_, selectEl) => {
    syncCustomSelect(selectEl);
  });
}

function createCustomSelectOptionButton(selectEl, option, index, menuId) {
  const optionButton = document.createElement("button");
  optionButton.type = "button";
  optionButton.className = "select-option";
  optionButton.textContent = option.textContent.trim();
  optionButton.dataset.value = option.value;
  optionButton.setAttribute("role", "option");
  optionButton.id = `${menuId}-option-${index}`;
  if (option.disabled) {
    optionButton.disabled = true;
  }
  optionButton.addEventListener("click", () => {
    if (option.disabled) {
      return;
    }
    selectCustomSelectOption(selectEl, option.value, true);
    const meta = customSelects.get(selectEl);
    if (meta) {
      meta.trigger.focus();
    }
  });
  return optionButton;
}

function repopulateCustomSelectOptions(selectEl) {
  const meta = customSelects.get(selectEl);
  if (!meta) {
    return;
  }

  meta.menu.replaceChildren();
  meta.optionButtons = Array.from(selectEl.options).map((option, index) => {
    const optionButton = createCustomSelectOptionButton(selectEl, option, index, meta.menu.id);
    meta.menu.appendChild(optionButton);
    return optionButton;
  });
  syncCustomSelect(selectEl);
}

function setSelectOptions(selectEl, options, selectedValue) {
  if (!(selectEl instanceof HTMLSelectElement) || !Array.isArray(options) || options.length === 0) {
    return;
  }

  const normalizedOptions = options.map((option) => ({
    value: String(option && option.value != null ? option.value : ""),
    label: String(option && option.label != null ? option.label : option && option.value != null ? option.value : ""),
    disabled: !!(option && option.disabled)
  }));

  const currentSignature = Array.from(selectEl.options)
    .map((option) => `${option.value}\u0001${option.textContent}\u0001${option.disabled ? 1 : 0}`)
    .join("\u0002");
  const nextSignature = normalizedOptions
    .map((option) => `${option.value}\u0001${option.label}\u0001${option.disabled ? 1 : 0}`)
    .join("\u0002");

  if (currentSignature !== nextSignature) {
    selectEl.replaceChildren();
    normalizedOptions.forEach((option) => {
      const nextOption = document.createElement("option");
      nextOption.value = option.value;
      nextOption.textContent = option.label;
      nextOption.disabled = option.disabled;
      selectEl.appendChild(nextOption);
    });
    repopulateCustomSelectOptions(selectEl);
  }

  const preferredValue = String(selectedValue);
  const hasPreferredValue = normalizedOptions.some((option) => option.value === preferredValue);
  if (hasPreferredValue) {
    selectEl.value = preferredValue;
  } else {
    const fallbackOption = normalizedOptions.find((option) => !option.disabled) ?? normalizedOptions[0];
    selectEl.value = fallbackOption ? fallbackOption.value : "";
  }
  syncCustomSelect(selectEl);
}

function normalizeRecordingCodecMode(mode, codecId = state.recordingCodecId) {
  if (mode === "lossless" || mode === "compact") {
    return mode;
  }
  return Number(codecId) === 3 ? "lossless" : "compact";
}

function isLosslessCodecMode() {
  return normalizeRecordingCodecMode(state.recordingCodecMode, state.recordingCodecId) === "lossless";
}

function getCodecIdForMode(mode) {
  const normalizedMode = normalizeRecordingCodecMode(mode, state.recordingCodecId);
  if (normalizedMode === "lossless") {
    return 3;
  }

  const currentCodecId = Number(state.recordingCodecId);
  return currentCodecId > 0 && currentCodecId !== 3 ? currentCodecId : 6;
}

function createRuntimeRankOptions() {
  const labels = Array.isArray(state.recordingRuntimeLevelLabels) && state.recordingRuntimeLevelLabels.length > 0
    ? state.recordingRuntimeLevelLabels
    : defaultState.recordingRuntimeLevelLabels;
  return [
    { value: "-1", label: "自动选择" },
    ...labels.map((label, index) => ({ value: String(index), label: label && String(label).trim() ? String(label).trim() : `L${index}` }))
  ];
}

function createRecordTargetLongSideOptions() {
  const presetValues = [1024, 1536, 2048, 2560, 3072, 4096, 6144, 8192];
  const currentValue = Math.max(256, toNumber(state.recordTargetLongSide, 2048));
  const values = Array.from(new Set([...presetValues, currentValue])).sort((left, right) => left - right);
  return values.map((value) => ({
    value: String(value),
    label: String(value)
  }));
}

function createRecordingPresetOptions() {
  if (!Array.isArray(state.recordingPresets) || state.recordingPresets.length <= 0) {
    return [{
      value: state.currentPresetId || "",
      label: state.currentPresetName || "当前预设"
    }];
  }

  return state.recordingPresets.map((item) => ({
    value: String(item && item.id ? item.id : ""),
    label: String(item && item.name ? item.name : "")
  }));
}

function bindCustomSelectDismiss() {
  if (customSelectDismissBound) {
    return;
  }

  customSelectDismissBound = true;
  document.addEventListener("pointerdown", (event) => {
    customSelects.forEach((meta, selectEl) => {
      if (!meta.shell.contains(event.target)) {
        closeCustomSelect(selectEl);
      }
    });
  });

  window.addEventListener("blur", () => {
    closeAllCustomSelects();
  });
}

function buildCustomSelect(selectEl) {
  if (!(selectEl instanceof HTMLSelectElement) || customSelects.has(selectEl)) {
    return;
  }

  const shell = document.createElement("div");
  shell.className = "select-shell";

  const trigger = document.createElement("button");
  trigger.type = "button";
  trigger.className = "select-trigger";
  trigger.dataset.hostDragIgnore = "true";
  trigger.setAttribute("aria-haspopup", "listbox");
  trigger.setAttribute("aria-expanded", "false");

  const label = document.createElement("span");
  label.className = "select-trigger-label";
  trigger.appendChild(label);

  const menu = document.createElement("div");
  menu.className = "select-menu";
  menu.setAttribute("role", "listbox");

  const menuId = `custom-select-menu-${++customSelectIdSeed}`;
  menu.id = menuId;
  trigger.setAttribute("aria-controls", menuId);

  const optionButtons = Array.from(selectEl.options).map((option, index) => {
    const optionButton = createCustomSelectOptionButton(selectEl, option, index, menuId);
    menu.appendChild(optionButton);
    return optionButton;
  });

  selectEl.classList.add("select-native");
  selectEl.setAttribute("aria-hidden", "true");
  selectEl.tabIndex = -1;

  selectEl.parentNode.insertBefore(shell, selectEl);
  shell.append(selectEl, trigger, menu);

  const meta = {
    shell,
    trigger,
    menu,
    label,
    optionButtons
  };
  customSelects.set(selectEl, meta);

  trigger.addEventListener("click", () => {
    if (shell.classList.contains("is-open")) {
      closeCustomSelect(selectEl);
      return;
    }
    openCustomSelect(selectEl);
  });

  trigger.addEventListener("keydown", (event) => {
    if (event.key === "ArrowDown" || event.key === "ArrowUp") {
      event.preventDefault();
      const direction = event.key === "ArrowDown" ? 1 : -1;
      const baseIndex = getSelectedOptionIndex(selectEl);
      const focusIndex = findEnabledOptionIndex(meta, Math.max(0, baseIndex), direction);
      openCustomSelect(selectEl, focusIndex);
      return;
    }

    if (event.key === "Enter" || event.key === " ") {
      event.preventDefault();
      if (shell.classList.contains("is-open")) {
        closeCustomSelect(selectEl);
      } else {
        openCustomSelect(selectEl);
      }
      return;
    }

    if (event.key === "Escape") {
      event.preventDefault();
      closeCustomSelect(selectEl);
    }
  });

  menu.addEventListener("keydown", (event) => {
    const currentIndex = meta.optionButtons.indexOf(document.activeElement);
    if (event.key === "ArrowDown" || event.key === "ArrowUp") {
      event.preventDefault();
      const direction = event.key === "ArrowDown" ? 1 : -1;
      const startIndex = currentIndex >= 0
        ? currentIndex + direction
        : getSelectedOptionIndex(selectEl);
      const nextIndex = findEnabledOptionIndex(meta, startIndex, direction);
      if (nextIndex >= 0) {
        focusCustomSelectOption(selectEl, nextIndex);
      }
      return;
    }

    if (event.key === "Home" || event.key === "End") {
      event.preventDefault();
      const nextIndex = event.key === "Home"
        ? findEnabledOptionIndex(meta, 0, 1)
        : findEnabledOptionIndex(meta, meta.optionButtons.length - 1, -1);
      if (nextIndex >= 0) {
        focusCustomSelectOption(selectEl, nextIndex);
      }
      return;
    }

    if (event.key === "Escape") {
      event.preventDefault();
      closeCustomSelect(selectEl, true);
      return;
    }

    if (event.key === "Tab") {
      closeCustomSelect(selectEl);
      return;
    }

    if ((event.key === "Enter" || event.key === " ") && document.activeElement instanceof HTMLButtonElement) {
      event.preventDefault();
      document.activeElement.click();
    }
  });

  shell.addEventListener("focusout", (event) => {
    if (!shell.contains(event.relatedTarget)) {
      closeCustomSelect(selectEl);
    }
  });

  selectEl.addEventListener("change", () => {
    syncCustomSelect(selectEl);
  });

  syncCustomSelect(selectEl);
}

function initCustomSelects() {
  document.querySelectorAll("select.select-input:not(.recording-hidden-select)").forEach((selectEl) => {
    buildCustomSelect(selectEl);
  });
  bindCustomSelectDismiss();
}

function loadState() {
  try {
    const raw = localStorage.getItem(storageKey);
    if (!raw) {
      return cloneState(defaultState);
    }

    const parsed = { ...cloneState(defaultState), ...JSON.parse(raw) };
    parsed.previewMode = "fit";
    parsed.themeMode = parsed.themeMode === "dark" ? "dark" : "light";
    return parsed;
  } catch {
    return cloneState(defaultState);
  }
}

function persistState() {
  const persistent = {
    savePath: state.savePath,
    previewMode: state.previewMode,
    themeMode: state.themeMode,
    alwaysOnTop: state.alwaysOnTop,
    autoLaunch: state.autoLaunch,
    doNotMinimizeToTray: state.doNotMinimizeToTray,
    navigatorAutoResize: state.navigatorAutoResize,
    updateChannel: state.updateChannel,
    customBrushOverlay: state.customBrushOverlay,
    previewDeveloperMode: state.previewDeveloperMode,
    runtimeSurfaceFixedRefresh: state.runtimeSurfaceFixedRefresh,
    previewTileFrameSync: state.previewTileFrameSync,
    statusLightGroupVisible: state.statusLightGroupVisible,
    volumeModeIndex: state.volumeModeIndex
  };
  localStorage.setItem(storageKey, JSON.stringify(persistent));
}

